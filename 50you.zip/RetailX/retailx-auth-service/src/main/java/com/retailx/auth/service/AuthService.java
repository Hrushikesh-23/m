package com.retailx.auth.service;

import com.retailx.auth.domain.User;
import com.retailx.auth.domain.enums.Role;
import com.retailx.auth.dto.request.LoginRequest;
import com.retailx.auth.dto.request.RegisterRequest;
import com.retailx.auth.dto.response.AuthResponse;
import com.retailx.auth.repository.UserRepository;
import com.retailx.auth.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Service for authentication and authorization operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        log.info("Registering new user with email: {}", request.getEmail());
        
        if (userRepository.existsByEmailAndDeletedFalse(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        User user = User.builder()
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(request.getPassword()))
                .active(true)
                .passwordChangedAt(LocalDateTime.now())
                .build();
        
        // Set default role
        Set<Role> roles = new HashSet<>();
        if (request.getRole() != null) {
            try {
                roles.add(Role.valueOf(request.getRole().toUpperCase()));
            } catch (IllegalArgumentException e) {
                roles.add(Role.CUSTOMER); // Default to CUSTOMER
            }
        } else {
            roles.add(Role.CUSTOMER);
        }
        user.setRoles(roles);
        
        user = userRepository.save(user);
        
        Set<String> roleStrings = user.getRoles().stream()
                .map(Enum::name)
                .collect(Collectors.toSet());
        
        String token = jwtUtil.generateToken(user.getId(), user.getEmail(), roleStrings);
        
        return AuthResponse.builder()
                .token(token)
                .userId(user.getId())
                .email(user.getEmail())
                .roles(roleStrings)
                .expiresIn(jwtUtil.getExpirationDateFromToken(token).getTime() - System.currentTimeMillis())
                .build();
    }
    
    @Transactional
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());
        
        User user = userRepository.findActiveByEmail(request.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        
        if (!user.getActive()) {
            throw new RuntimeException("Account is inactive");
        }
        
        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            Integer currentAttempts = user.getFailedLoginAttempts() != null ? user.getFailedLoginAttempts() : 0;
            user.setFailedLoginAttempts(currentAttempts + 1);
            userRepository.save(user);
            throw new RuntimeException("Invalid credentials");
        }
        
        // Reset failed attempts on successful login
        user.setFailedLoginAttempts(0);
        user.setLastLoginAt(LocalDateTime.now());
        userRepository.save(user);
        
        Set<String> roleStrings = user.getRoles().stream()
                .map(Enum::name)
                .collect(Collectors.toSet());
        
        String token = jwtUtil.generateToken(user.getId(), user.getEmail(), roleStrings);
        
        return AuthResponse.builder()
                .token(token)
                .userId(user.getId())
                .email(user.getEmail())
                .roles(roleStrings)
                .expiresIn(jwtUtil.getExpirationDateFromToken(token).getTime() - System.currentTimeMillis())
                .build();
    }
}

