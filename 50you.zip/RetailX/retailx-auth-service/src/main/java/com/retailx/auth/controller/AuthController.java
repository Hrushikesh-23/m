package com.retailx.auth.controller;

import com.retailx.auth.dto.request.LoginRequest;
import com.retailx.auth.dto.request.RegisterRequest;
import com.retailx.auth.dto.response.AuthResponse;
import com.retailx.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for authentication and authorization endpoints.
 * Handles user registration, login, and JWT token generation.
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    
    private final AuthService authService;
    
    /**
     * Register a new user - public endpoint, no authentication required.
     * Creates user account with hashed password and default CUSTOMER role.
     */
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        log.info("Registration request received: email={}", request.getEmail());
        AuthResponse response = authService.register(request);
        log.info("User registered successfully: email={}, userId={}", 
                request.getEmail(), response.getUserId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    
    /**
     * Login and get JWT token - public endpoint, no authentication required.
     * Validates credentials and returns JWT token with user roles.
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        log.info("Login request received: email={}", request.getEmail());
        AuthResponse response = authService.login(request);
        log.info("User logged in successfully: email={}, userId={}", 
                request.getEmail(), response.getUserId());
        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Auth Service is running");
    }
}

