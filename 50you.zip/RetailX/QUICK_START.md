# RetailX Quick Start Guide

## 🚀 Quick Setup (5 Minutes)

### Step 1: Install Prerequisites
- **Java 21**: Download from https://adoptium.net/
- **Maven 3.8+**: Download from https://maven.apache.org/
- **Docker Desktop**: Download from https://www.docker.com/ (Optional but recommended)

### Step 2: Start Infrastructure
```bash
# Start MySQL, Kafka, Zookeeper using Docker
docker-compose up -d

# Or manually:
# 1. Start MySQL on port 3306
# 2. Start Zookeeper on port 2181
# 3. Start Kafka on port 9092
```

### Step 3: Build Project
```bash
# From project root
mvn clean install
```

### Step 4: Start Services (In Order)

**Terminal 1 - Eureka Server:**
```bash
cd retailx-eureka-server
mvn spring-boot:run
```
Wait for: "Started EurekaServerApplication" (http://localhost:8761)

**Terminal 2 - API Gateway:**
```bash
cd retailx-api-gateway
mvn spring-boot:run
```
Port: 8080

**Terminal 3 - Auth Service:**
```bash
cd retailx-auth-service
mvn spring-boot:run
```
Port: 8081

**Terminal 4+ - Other Services:**
```bash
# Product Service (8082)
cd retailx-product-service && mvn spring-boot:run

# Order Service (8083)
cd retailx-order-service && mvn spring-boot:run

# Payment Service (8084)
cd retailx-payment-service && mvn spring-boot:run

# Inventory Service (8085)
cd retailx-inventory-service && mvn spring-boot:run

# Frontend Service (8087)
cd retailx-frontend-service && mvn spring-boot:run
```

## ✅ Verify Setup

1. **Eureka Dashboard**: http://localhost:8761
   - Should show all registered services

2. **Test Auth Service**:
   ```bash
   # Register a new user
   curl -X POST http://localhost:8080/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{
       "email": "test@example.com",
       "password": "Test@1234",
       "name": "Test User",
       "role": "CUSTOMER"
     }'
   
   # Login
   curl -X POST http://localhost:8080/api/auth/login \
     -H "Content-Type: application/json" \
     -d '{
       "email": "admin@retailx.com",
       "password": "Admin@123"
     }'
   ```

3. **Default Admin Credentials**:
   - Email: `admin@retailx.com`
   - Password: `Admin@123`

## 📋 Service Ports

| Service | Port | Status |
|---------|------|--------|
| Eureka Server | 8761 | ✅ Ready |
| API Gateway | 8080 | ✅ Ready |
| Auth Service | 8081 | ✅ Ready |
| Product Service | 8082 | 🚧 Pending |
| Order Service | 8083 | 🚧 Pending |
| Payment Service | 8084 | 🚧 Pending |
| Inventory Service | 8085 | 🚧 Pending |
| Notification Service | 8086 | 🚧 Pending |
| Frontend Service | 8087 | 🚧 Pending |

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Windows
netstat -ano | findstr :8080
taskkill /PID <PID> /F

# Linux/Mac
lsof -ti:8080 | xargs kill -9
```

### Database Connection Failed
```bash
# Check MySQL is running
docker ps | grep mysql

# Or check MySQL service
# Windows: services.msc
# Linux: sudo systemctl status mysql
```

### Service Not Registering with Eureka
- Ensure Eureka Server is running first
- Wait 30-60 seconds for registration
- Check `application.yml` has correct Eureka URL

## 📚 Next Steps

1. Complete Product Service implementation
2. Implement Order Service with cart and checkout
3. Add Payment Service with mock provider
4. Create Thymeleaf frontend pages
5. Add comprehensive tests

See [PROJECT_STATUS.md](PROJECT_STATUS.md) for detailed progress.

