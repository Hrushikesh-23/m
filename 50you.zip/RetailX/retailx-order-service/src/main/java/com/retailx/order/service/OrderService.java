package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.OrderVersion;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderItemResponse;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.util.OrderNumberGenerator;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for order management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {
    
    private final OrderRepository orderRepository;
    private static final int MAX_VERSIONS = 10;
    
    public OrderResponse getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        
        if (order.getDeleted()) {
            throw new RuntimeException("Order not found with id: " + id);
        }
        
        return mapToResponse(order);
    }
    
    public OrderResponse getOrderByNumber(String orderNumber) {
        Order order = orderRepository.findByOrderNumberAndDeletedFalse(orderNumber)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderNumber));
        
        return mapToResponse(order);
    }
    
    public Page<OrderResponse> getOrdersByCustomer(Long customerId, Pageable pageable) {
        Page<Order> orders = orderRepository.findByCustomerIdAndDeletedFalse(customerId, pageable);
        return orders.map(this::mapToResponse);
    }
    
    public Page<OrderResponse> getOrdersByMerchant(Long merchantId, Pageable pageable) {
        Page<Order> orders = orderRepository.findByMerchantIdAndDeletedFalse(merchantId, pageable);
        return orders.map(this::mapToResponse);
    }
    
    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, OrderStatus newStatus, String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        OrderStatus oldStatus = order.getStatus();
        order.setStatus(newStatus);
        order = orderRepository.save(order);
        
        log.info("Order status updated: orderId={}, {} -> {}, actor={}", 
                orderId, oldStatus, newStatus, actorId);
        
        return mapToResponse(order);
    }
    
    @Transactional
    public OrderResponse updateOrderPreFulfillment(Long orderId, String shippingAddress, 
                                                   String shippingMethod, String giftNote, 
                                                   String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (order.getStatus().ordinal() >= OrderStatus.SHIPPED.ordinal()) {
            throw new RuntimeException("Cannot update order after it has been shipped");
        }
        
        // Create version history
        if (order.getVersions().size() >= MAX_VERSIONS) {
            // Remove oldest version
            order.getVersions().remove(0);
        }
        
        OrderVersion version = OrderVersion.builder()
                .order(order)
                .versionNumber(order.getVersion())
                .shippingAddress(order.getShippingAddress())
                .shippingMethod(order.getShippingMethod())
                .giftNote(order.getGiftNote())
                .shipping(order.getShipping())
                .changedBy(actorId)
                .changeReason(reason)
                .build();
        
        order.getVersions().add(version);
        
        // Update order
        order.setShippingAddress(shippingAddress);
        order.setShippingMethod(shippingMethod);
        order.setGiftNote(giftNote);
        order.setVersion(order.getVersion() + 1);
        
        order = orderRepository.save(order);
        
        return mapToResponse(order);
    }
    
    @Transactional
    public OrderResponse cancelOrder(Long orderId, String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (order.getStatus().ordinal() >= OrderStatus.SHIPPED.ordinal()) {
            throw new RuntimeException("Cannot cancel order after it has been shipped");
        }
        
        order.setStatus(OrderStatus.CANCELLED);
        order = orderRepository.save(order);
        
        log.info("Order cancelled: orderId={}, actor={}, reason={}", orderId, actorId, reason);
        
        return mapToResponse(order);
    }
    
    private OrderResponse mapToResponse(Order order) {
        List<OrderItemResponse> items = order.getItems().stream()
                .map(this::mapItemToResponse)
                .collect(Collectors.toList());
        
        return OrderResponse.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .customerId(order.getCustomerId())
                .merchantId(order.getMerchantId())
                .status(order.getStatus())
                .items(items)
                .subtotal(order.getSubtotal())
                .tax(order.getTax())
                .shipping(order.getShipping())
                .discount(order.getDiscount())
                .total(order.getTotal())
                .shippingAddress(order.getShippingAddress())
                .shippingMethod(order.getShippingMethod())
                .giftNote(order.getGiftNote())
                .version(order.getVersion())
                .createdOn(order.getCreatedOn())
                .updatedOn(order.getUpdatedOn())
                .build();
    }
    
    private OrderItemResponse mapItemToResponse(OrderItem item) {
        return OrderItemResponse.builder()
                .id(item.getId())
                .sku(item.getSku())
                .productName(item.getProductName())
                .quantity(item.getQuantity())
                .unitPrice(item.getUnitPrice())
                .lineTotal(item.getLineTotal())
                .build();
    }
}

