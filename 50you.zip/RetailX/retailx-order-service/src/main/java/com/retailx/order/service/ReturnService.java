package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Return;
import com.retailx.order.domain.ReturnItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ReturnRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Service for returns and refunds.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReturnService {
    
    private final ReturnRepository returnRepository;
    private final OrderRepository orderRepository;
    private final PaymentServiceClient paymentServiceClient;
    private final InventoryServiceClient inventoryServiceClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${retailx.return.window-days:30}")
    private int returnWindowDays;
    
    @Transactional
    public Return requestReturn(Long orderId, Long customerId, String reason, List<ReturnItemRequest> items) {
        log.info("Processing return request for order: {}", orderId);
        
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Verify ownership
        if (!order.getCustomerId().equals(customerId)) {
            throw new RuntimeException("Order does not belong to customer");
        }
        
        // Check return window
        if (order.getStatus() != OrderStatus.DELIVERED) {
            throw new RuntimeException("Order must be DELIVERED to request return");
        }
        
        LocalDateTime deliveryDate = order.getUpdatedOn(); // Assuming delivery date
        if (deliveryDate.plusDays(returnWindowDays).isBefore(LocalDateTime.now())) {
            throw new RuntimeException("RETURN_WINDOW_EXPIRED: Return window has expired");
        }
        
        String rmaNumber = "RMA-" + LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd")) + "-" + 
                UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        Return returnEntity = Return.builder()
                .orderId(orderId)
                .rmaNumber(rmaNumber)
                .requestedAt(LocalDateTime.now())
                .status("REQUESTED")
                .reason(reason)
                .build();
        
        // Create return items
        BigDecimal totalRefund = BigDecimal.ZERO;
        for (ReturnItemRequest itemRequest : items) {
            // Validate quantity
            OrderItem orderItem = order.getItems().stream()
                    .filter(item -> item.getSku().equals(itemRequest.getSku()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("INVALID_RETURN_QTY: SKU not found in order"));
            
            if (itemRequest.getQuantity().compareTo(orderItem.getQuantity()) > 0) {
                throw new RuntimeException("INVALID_RETURN_QTY: Return quantity exceeds order quantity");
            }
            
            ReturnItem returnItem = ReturnItem.builder()
                    .returnEntity(returnEntity)
                    .sku(itemRequest.getSku())
                    .quantity(itemRequest.getQuantity())
                    .build();
            returnEntity.getItems().add(returnItem);
            
            totalRefund = totalRefund.add(
                    orderItem.getUnitPrice().multiply(new BigDecimal(itemRequest.getQuantity())));
        }
        
        returnEntity.setRefundAmount(totalRefund);
        returnEntity = returnRepository.save(returnEntity);
        
        // Publish event
        kafkaTemplate.send("return.requested", rmaNumber,
                String.format("{\"returnId\":%d,\"orderId\":%d,\"rmaNumber\":\"%s\"}", 
                        returnEntity.getId(), orderId, rmaNumber));
        
        return returnEntity;
    }
    
    @Transactional
    public Return approveReturn(Long returnId, String actorId) {
        Return returnEntity = returnRepository.findById(returnId)
                .orElseThrow(() -> new RuntimeException("Return not found"));
        
        if (!"REQUESTED".equals(returnEntity.getStatus())) {
            throw new RuntimeException("Return must be REQUESTED to approve");
        }
        
        returnEntity.setStatus("APPROVED");
        returnEntity.setApprovedAt(LocalDateTime.now());
        returnEntity = returnRepository.save(returnEntity);
        
        // Restock inventory
        for (ReturnItem item : returnEntity.getItems()) {
            inventoryServiceClient.adjustInventory(item.getSku(), "default-warehouse", item.getQuantity());
        }
        returnEntity.setRestocked(true);
        returnEntity = returnRepository.save(returnEntity);
        
        // Process refund
        Order order = orderRepository.findById(returnEntity.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Call payment service to refund
        paymentServiceClient.refund(order.getId(), returnEntity.getRefundAmount());
        
        returnEntity.setStatus("COMPLETED");
        returnEntity.setCompletedAt(LocalDateTime.now());
        returnEntity = returnRepository.save(returnEntity);
        
        // Publish event
        kafkaTemplate.send("return.completed", returnEntity.getRmaNumber(),
                String.format("{\"returnId\":%d,\"refundAmount\":%s}", 
                        returnEntity.getId(), returnEntity.getRefundAmount()));
        
        return returnEntity;
    }
    
    @Transactional
    public Return rejectReturn(Long returnId, String reason, String actorId) {
        Return returnEntity = returnRepository.findById(returnId)
                .orElseThrow(() -> new RuntimeException("Return not found"));
        
        returnEntity.setStatus("REJECTED");
        returnEntity.setReason(returnEntity.getReason() + " | Rejection: " + reason);
        returnEntity = returnRepository.save(returnEntity);
        
        return returnEntity;
    }
    
    public List<Return> getReturnsByOrder(Long orderId) {
        return returnRepository.findByOrderIdAndDeletedFalse(orderId);
    }
    
    // DTO for return item request
    public static class ReturnItemRequest {
        private String sku;
        private java.math.BigInteger quantity;
        
        public String getSku() { return sku; }
        public void setSku(String sku) { this.sku = sku; }
        public java.math.BigInteger getQuantity() { return quantity; }
        public void setQuantity(java.math.BigInteger quantity) { this.quantity = quantity; }
    }
}

