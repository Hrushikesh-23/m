package com.retailx.order.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;

/**
 * Feign client for Payment Service.
 */
@FeignClient(name = "retailx-payment-service", path = "/api/payments")
public interface PaymentServiceClient {
    
    @GetMapping("/order/{orderId}")
    Object getPaymentByOrderId(@PathVariable Long orderId);
    
    @PostMapping("/refund")
    void refund(@RequestParam Long orderId, @RequestParam BigDecimal amount);
}

