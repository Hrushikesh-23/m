package com.retailx.order.service;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.IdempotencyKey;
import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.request.CheckoutRequest;
import com.retailx.order.dto.response.CheckoutResponse;
import com.retailx.order.repository.CartRepository;
import com.retailx.order.repository.IdempotencyKeyRepository;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.util.IdempotencyUtil;
import com.retailx.order.util.OrderNumberGenerator;
import com.retailx.order.annotation.Auditable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for checkout operations with idempotency support.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CheckoutService {
    
    private final CartRepository cartRepository;
    private final OrderRepository orderRepository;
    private final IdempotencyKeyRepository idempotencyKeyRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Transactional
    @Auditable
    public CheckoutResponse checkout(Long customerId, CheckoutRequest request, String idempotencyKey) {
        log.info("Checkout request: customerId={}, idempotencyKey={}", customerId, idempotencyKey);
        
        // Validate idempotency key
        if (idempotencyKey == null || !IdempotencyUtil.isValidKey(idempotencyKey)) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid or missing idempotency key");
        }
        
        // Check for existing idempotency key
        String requestHash = IdempotencyUtil.hashRequest(request.toString());
        IdempotencyKey existingKey = idempotencyKeyRepository.findByKeyValue(idempotencyKey)
                .orElse(null);
        
        if (existingKey != null) {
            if (existingKey.getUsed()) {
                // Same request - return cached response
                if (existingKey.getRequestHash().equals(requestHash)) {
                    log.info("Idempotent request detected, returning cached response");
                    return parseCachedResponse(existingKey.getResponseSummary());
                } else {
                    // Different payload with same key - conflict
                    throw new ResponseStatusException(HttpStatus.CONFLICT, 
                            "Idempotency key already used with different payload");
                }
            }
        }
        
        // Get cart
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new RuntimeException("Cart not found or empty"));
        
        if (cart.getItems().isEmpty()) {
            throw new RuntimeException("Cart is empty");
        }
        
        // Reserve inventory
        for (var item : cart.getItems()) {
            boolean reserved = inventoryServiceClient.reserveInventory(
                    item.getSku(), item.getQuantity(), "default-warehouse");
            if (!reserved) {
                throw new RuntimeException("Insufficient inventory for SKU: " + item.getSku());
            }
        }
        
        // Create order
        Order order = createOrderFromCart(cart, request);
        order = orderRepository.save(order);
        
        // Clear cart
        cart.getItems().clear();
        cartRepository.save(cart);
        
        // Save idempotency key
        IdempotencyKey key = IdempotencyKey.builder()
                .keyValue(idempotencyKey)
                .requestHash(requestHash)
                .responseSummary(String.format("{\"orderNumber\":\"%s\",\"orderId\":\"%d\"}", 
                        order.getOrderNumber(), order.getId()))
                .expiresAt(LocalDateTime.now().plusHours(24))
                .used(true)
                .build();
        idempotencyKeyRepository.save(key);
        
        // Publish event
        kafkaTemplate.send("order.created", order.getOrderNumber(), 
                String.format("{\"orderId\":%d,\"orderNumber\":\"%s\",\"customerId\":%d}", 
                        order.getId(), order.getOrderNumber(), customerId));
        
        return CheckoutResponse.builder()
                .orderNumber(order.getOrderNumber())
                .orderId(String.valueOf(order.getId()))
                .status(order.getStatus().name())
                .message("Order created successfully")
                .build();
    }
    
    private Order createOrderFromCart(Cart cart, CheckoutRequest request) {
        Order order = Order.builder()
                .orderNumber(OrderNumberGenerator.generate())
                .customerId(cart.getCustomerId())
                .merchantId(1L) // TODO: Get from product
                .status(OrderStatus.PENDING)
                .subtotal(cart.getSubtotal())
                .tax(cart.getTax())
                .shipping(cart.getShipping())
                .discount(cart.getDiscount())
                .total(cart.getTotal())
                .shippingAddress(request.getShippingAddress())
                .shippingMethod(request.getShippingMethod())
                .giftNote(request.getGiftNote())
                .version(1)
                .build();
        
        // Create order items
        List<OrderItem> orderItems = cart.getItems().stream()
                .map(cartItem -> OrderItem.builder()
                        .order(order)
                        .sku(cartItem.getSku())
                        .productName("Product " + cartItem.getSku()) // TODO: Get from product service
                        .quantity(cartItem.getQuantity())
                        .unitPrice(cartItem.getUnitPrice())
                        .lineTotal(cartItem.getLineTotal())
                        .build())
                .toList();
        
        order.setItems(orderItems);
        return order;
    }
    
    private CheckoutResponse parseCachedResponse(String responseSummary) {
        // Simple parsing - in production use JSON parser
        String orderNumber = responseSummary.substring(
                responseSummary.indexOf("\"orderNumber\":\"") + 15,
                responseSummary.indexOf("\"", responseSummary.indexOf("\"orderNumber\":\"") + 15));
        String orderId = responseSummary.substring(
                responseSummary.indexOf("\"orderId\":\"") + 11,
                responseSummary.indexOf("\"", responseSummary.indexOf("\"orderId\":\"") + 11));
        
        return CheckoutResponse.builder()
                .orderNumber(orderNumber)
                .orderId(orderId)
                .status("PENDING")
                .message("Idempotent response")
                .build();
    }
}

