package com.retailx.order.service;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.CartItem;

import java.util.ArrayList;
import com.retailx.order.dto.request.AddToCartRequest;
import com.retailx.order.dto.response.CartItemResponse;
import com.retailx.order.dto.response.CartResponse;
import com.retailx.order.repository.CartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for cart management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CartService {
    
    private final CartRepository cartRepository;
    private final ProductServiceClient productServiceClient;
    
    @Value("${retailx.cart.expiration-hours:24}")
    private int cartExpirationHours;
    
    @Transactional
    public CartResponse getOrCreateCart(Long customerId) {
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseGet(() -> createNewCart(customerId));
        
        calculateCartTotals(cart);
        cart = cartRepository.save(cart);
        
        return mapToResponse(cart);
    }
    
    @Transactional
    public CartResponse addToCart(Long customerId, AddToCartRequest request) {
        log.info("Adding item to cart: customerId={}, sku={}, quantity={}", 
                customerId, request.getSku(), request.getQuantity());
        
        // Get or create cart
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseGet(() -> {
                    Cart newCart = Cart.builder()
                            .customerId(customerId)
                            .items(new ArrayList<>())
                            .subtotal(BigDecimal.ZERO)
                            .tax(BigDecimal.ZERO)
                            .shipping(BigDecimal.ZERO)
                            .discount(BigDecimal.ZERO)
                            .total(BigDecimal.ZERO)
                            .build();
                    return cartRepository.save(newCart);
                });
        
        // Validate product exists and is active
        try {
            var productMap = productServiceClient.getProductBySku(request.getSku());
            if (productMap == null || !"ACTIVE".equals(productMap.get("status"))) {
                throw new RuntimeException("Product not found or not active: " + request.getSku());
            }
            BigDecimal unitPrice = new BigDecimal(productMap.get("basePrice").toString());
            
            // Check if item already exists in cart
            CartItem existingItem = cart.getItems().stream()
                    .filter(item -> item.getSku().equals(request.getSku()))
                    .findFirst()
                    .orElse(null);
            
            if (existingItem != null) {
                // Update quantity
                existingItem.setQuantity(existingItem.getQuantity().add(request.getQuantity()));
                existingItem.setLineTotal(existingItem.getUnitPrice()
                        .multiply(new BigDecimal(existingItem.getQuantity())));
            } else {
                // Add new item
                CartItem newItem = CartItem.builder()
                        .cart(cart)
                        .sku(request.getSku())
                        .quantity(request.getQuantity())
                        .unitPrice(unitPrice)
                        .lineTotal(unitPrice.multiply(new BigDecimal(request.getQuantity())))
                        .build();
                cart.getItems().add(newItem);
            }
            calculateCartTotals(cart);
            cart = cartRepository.save(cart);
        } catch (Exception e) {
            throw new RuntimeException("Product not found or not active: " + request.getSku(), e);
        }
        
        return mapToResponse(cart);
    }
    
    @Transactional
    public CartResponse updateCartItem(Long customerId, Long itemId, BigInteger quantity) {
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
        
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        
        if (quantity.compareTo(BigInteger.ZERO) <= 0) {
            cart.getItems().remove(item);
        } else {
            item.setQuantity(quantity);
            item.setLineTotal(item.getUnitPrice().multiply(new BigDecimal(quantity)));
        }
        
        calculateCartTotals(cart);
        cart = cartRepository.save(cart);
        
        return mapToResponse(cart);
    }
    
    @Transactional
    public CartResponse removeFromCart(Long customerId, Long itemId) {
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
        
        CartItem item = cart.getItems().stream()
                .filter(i -> i.getId().equals(itemId))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Cart item not found"));
        
        cart.getItems().remove(item);
        calculateCartTotals(cart);
        cart = cartRepository.save(cart);
        
        return mapToResponse(cart);
    }
    
    @Transactional
    public void clearCart(Long customerId) {
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
        
        cart.getItems().clear();
        calculateCartTotals(cart);
        cartRepository.save(cart);
    }
    
    private Cart createNewCart(Long customerId) {
        return Cart.builder()
                .customerId(customerId)
                .expiresAt(LocalDateTime.now().plusHours(cartExpirationHours))
                .abandoned(false)
                .build();
    }
    
    private void calculateCartTotals(Cart cart) {
        BigDecimal subtotal = cart.getItems().stream()
                .map(CartItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        cart.setSubtotal(subtotal);
        
        // Calculate tax (10% for demo)
        BigDecimal tax = subtotal.multiply(new BigDecimal("0.10"));
        cart.setTax(tax);
        
        // Calculate shipping (flat $10 for demo, or based on weight)
        BigDecimal shipping = subtotal.compareTo(new BigDecimal("100")) > 0 
                ? BigDecimal.ZERO 
                : new BigDecimal("10");
        cart.setShipping(shipping);
        
        // Discount (to be calculated from promotions)
        cart.setDiscount(BigDecimal.ZERO);
        
        // Total
        BigDecimal total = subtotal.add(tax).add(shipping).subtract(cart.getDiscount());
        cart.setTotal(total);
    }
    
    private CartResponse mapToResponse(Cart cart) {
        List<CartItemResponse> items = cart.getItems().stream()
                .map(this::mapItemToResponse)
                .collect(Collectors.toList());
        
        return CartResponse.builder()
                .id(cart.getId())
                .customerId(cart.getCustomerId())
                .items(items)
                .subtotal(cart.getSubtotal())
                .tax(cart.getTax())
                .shipping(cart.getShipping())
                .discount(cart.getDiscount())
                .total(cart.getTotal())
                .expiresAt(cart.getExpiresAt())
                .build();
    }
    
    private CartItemResponse mapItemToResponse(CartItem item) {
        return CartItemResponse.builder()
                .id(item.getId())
                .sku(item.getSku())
                .productName("Product " + item.getSku()) // Should fetch from product service
                .quantity(item.getQuantity())
                .unitPrice(item.getUnitPrice())
                .lineTotal(item.getLineTotal())
                .build();
    }
    
}

