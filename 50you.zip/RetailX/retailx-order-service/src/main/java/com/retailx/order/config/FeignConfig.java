package com.retailx.order.config;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

/**
 * Feign client configuration.
 */
@Configuration
@EnableFeignClients(basePackages = "com.retailx.order.service")
public class FeignConfig {
}

