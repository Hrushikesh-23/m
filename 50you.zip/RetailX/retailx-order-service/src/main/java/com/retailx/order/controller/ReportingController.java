package com.retailx.order.controller;

import com.retailx.order.service.ReportingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * REST controller for reporting and analytics endpoints.
 * Provides sales reports and order statistics for merchants.
 */
@Slf4j
@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportingController {
    
    private final ReportingService reportingService;
    
    /**
     * Get sales report for a merchant within a date range.
     * Only MERCHANT, ADMIN, or OPS can access.
     */
    @GetMapping("/sales")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<Map<String, Object>> getSalesReport(
            @RequestHeader("X-User-Id") Long merchantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime startDate,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime endDate) {
        
        log.info("Generating sales report: merchantId={}, startDate={}, endDate={}", 
                merchantId, startDate, endDate);
        Map<String, Object> report = reportingService.getSalesReport(merchantId, startDate, endDate);
        log.debug("Sales report generated: totalSales={}", report.get("totalSales"));
        return ResponseEntity.ok(report);
    }
    
    /**
     * Get order status counts for a merchant.
     * Only MERCHANT, ADMIN, or OPS can access.
     */
    @GetMapping("/order-status")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<Map<String, Long>> getOrderStatusCounts(
            @RequestHeader("X-User-Id") Long merchantId) {
        
        log.info("Fetching order status counts: merchantId={}", merchantId);
        Map<String, Long> counts = reportingService.getOrderStatusCounts(merchantId);
        log.debug("Order status counts retrieved: {}", counts);
        return ResponseEntity.ok(counts);
    }
}

