package com.retailx.order.domain;

import com.retailx.order.domain.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Order entity with versioning support.
 */
@Entity
@Table(name = "orders", indexes = {
    @Index(name = "idx_order_customer", columnList = "customerId"),
    @Index(name = "idx_order_merchant", columnList = "merchantId"),
    @Index(name = "idx_order_status", columnList = "status"),
    @Index(name = "idx_order_number", columnList = "orderNumber", unique = true)
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Order extends BaseEntity {
    
    @Column(nullable = false, unique = true, length = 50)
    private String orderNumber; // e.g., ORD-2024-001234
    
    @Column(nullable = false)
    private Long customerId; // Reference to auth service
    
    @Column(nullable = false)
    private Long merchantId; // Reference to auth service
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private OrderStatus status = OrderStatus.PENDING;
    
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<OrderItem> items = new ArrayList<>();
    
    @Column(precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal subtotal = BigDecimal.ZERO;
    
    @Column(precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal tax = BigDecimal.ZERO;
    
    @Column(precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal shipping = BigDecimal.ZERO;
    
    @Column(precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal discount = BigDecimal.ZERO;
    
    @Column(nullable = false, precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal total = BigDecimal.ZERO;
    
    @Column(length = 500)
    private String shippingAddress; // JSON or encrypted
    
    @Column(length = 50)
    private String shippingMethod;
    
    @Column(length = 500)
    private String giftNote;
    
    @Column
    private Integer version = 1; // Current version number
    
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    @Builder.Default
    private List<OrderVersion> versions = new ArrayList<>();
}

