package com.retailx.order.repository;

import com.retailx.order.domain.Shipment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Shipment entity.
 */
@Repository
public interface ShipmentRepository extends JpaRepository<Shipment, Long> {
    
    Optional<Shipment> findByShipmentNumberAndDeletedFalse(String shipmentNumber);
    
    List<Shipment> findByOrderIdAndDeletedFalse(Long orderId);
}

