package com.retailx.order.integration;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.Order;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.CartRepository;
import com.retailx.order.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests using Testcontainers (requires Docker).
 * These tests will use embedded database for simplicity.
 * Note: This test requires a database to be configured.
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
@org.junit.jupiter.api.Disabled("Requires database configuration")
class OrderIntegrationTest {
    
    @Autowired
    private TestEntityManager entityManager;
    
    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private CartRepository cartRepository;
    
    private Cart testCart;
    
    @BeforeEach
    void setUp() {
        testCart = Cart.builder()
                .customerId(1L)
                .subtotal(new BigDecimal("100"))
                .tax(new BigDecimal("10"))
                .shipping(new BigDecimal("5"))
                .total(new BigDecimal("115"))
                .build();
        testCart = entityManager.persistAndFlush(testCart);
    }
    
    @Test
    void testCreateOrder() {
        Order order = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(1L)
                .status(OrderStatus.PENDING)
                .subtotal(new BigDecimal("100"))
                .tax(new BigDecimal("10"))
                .shipping(new BigDecimal("5"))
                .total(new BigDecimal("115"))
                .version(1)
                .build();
        
        Order saved = orderRepository.save(order);
        
        assertNotNull(saved.getId());
        assertEquals(OrderStatus.PENDING, saved.getStatus());
    }
    
    @Test
    void testFindOrderByNumber() {
        Order order = Order.builder()
                .orderNumber("ORD-002")
                .customerId(1L)
                .merchantId(1L)
                .status(OrderStatus.PENDING)
                .total(new BigDecimal("100"))
                .version(1)
                .build();
        order = entityManager.persistAndFlush(order);
        
        Optional<Order> found = orderRepository.findByOrderNumberAndDeletedFalse("ORD-002");
        
        assertTrue(found.isPresent());
        assertEquals("ORD-002", found.get().getOrderNumber());
    }
    
    @Test
    void testFindCartByCustomer() {
        Optional<Cart> found = cartRepository.findByCustomerIdAndDeletedFalse(1L);
        
        assertTrue(found.isPresent());
        assertEquals(1L, found.get().getCustomerId());
    }
}

