package com.retailx.payment.service;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Random;
import java.util.UUID;

/**
 * Service for payment processing (mock provider).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {
    
    private final PaymentIntentRepository paymentIntentRepository;
    private final Random random = new Random();
    
    @Transactional
    public PaymentIntent createPaymentIntent(Long orderId, BigDecimal amount, String currency, String correlationId) {
        log.info("Creating payment intent: orderId={}, amount={}, correlationId={}", 
                orderId, amount, correlationId);
        
        // Check idempotency
        if (correlationId != null) {
            PaymentIntent existing = paymentIntentRepository.findByCorrelationId(correlationId)
                    .orElse(null);
            if (existing != null) {
                log.info("Idempotent payment intent creation, returning existing: {}", existing.getId());
                return existing;
            }
        }
        
        PaymentIntent paymentIntent = PaymentIntent.builder()
                .orderId(orderId)
                .paymentIntentId("pi_" + UUID.randomUUID().toString().replace("-", ""))
                .amount(amount)
                .currency(currency)
                .status(PaymentStatus.PENDING)
                .correlationId(correlationId)
                .build();
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "authorizeFallback")
    @Retry(name = "paymentService")
    public PaymentIntent authorize(Long paymentIntentId, String correlationId) {
        log.info("Authorizing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        if (paymentIntent.getStatus() == PaymentStatus.AUTHORIZED 
                || paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already authorized/captured");
            return paymentIntent;
        }
        
        // Mock payment provider - simulate success/failure
        boolean success = mockPaymentProvider(paymentIntent.getAmount());
        
        if (success) {
            paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        } else {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_DECLINED");
            paymentIntent.setErrorMessage("Payment was declined by the provider");
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "captureFallback")
    @Retry(name = "paymentService")
    public PaymentIntent capture(Long paymentIntentId, String correlationId) {
        log.info("Capturing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        if (paymentIntent.getStatus() != PaymentStatus.AUTHORIZED) {
            throw new RuntimeException("Payment must be authorized before capture");
        }
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        if (paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already captured");
            return paymentIntent;
        }
        
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    public PaymentIntent refund(Long paymentIntentId, BigDecimal amount, String correlationId) {
        log.info("Refunding payment: paymentIntentId={}, amount={}, correlationId={}", 
                paymentIntentId, amount, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        if (paymentIntent.getStatus() != PaymentStatus.CAPTURED) {
            throw new RuntimeException("Payment must be captured before refund");
        }
        
        if (amount.compareTo(paymentIntent.getAmount()) > 0) {
            throw new RuntimeException("Refund amount cannot exceed payment amount");
        }
        
        if (amount.compareTo(paymentIntent.getAmount()) < 0) {
            paymentIntent.setStatus(PaymentStatus.PARTIALLY_REFUNDED);
        } else {
            paymentIntent.setStatus(PaymentStatus.REFUNDED);
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    private boolean mockPaymentProvider(BigDecimal amount) {
        // Simulate 90% success rate
        // Simulate timeout for large amounts (>1000)
        if (amount.compareTo(new BigDecimal("1000")) > 0) {
            // 50% chance of timeout for large amounts
            if (random.nextDouble() < 0.5) {
                throw new RuntimeException("PAYMENT_PROVIDER_TIMEOUT");
            }
        }
        
        // 10% decline rate
        return random.nextDouble() > 0.1;
    }
    
    private PaymentIntent authorizeFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment authorization failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        paymentIntent.setStatus(PaymentStatus.FAILED);
        paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
        paymentIntent.setErrorMessage("Payment provider unavailable");
        return paymentIntentRepository.save(paymentIntent);
    }
    
    private PaymentIntent captureFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment capture failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        paymentIntent.setStatus(PaymentStatus.FAILED);
        paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
        paymentIntent.setErrorMessage("Payment provider unavailable");
        return paymentIntentRepository.save(paymentIntent);
    }
}

