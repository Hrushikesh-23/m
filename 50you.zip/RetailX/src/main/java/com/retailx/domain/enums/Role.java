package com.retailx.domain.enums;

/**
 * User roles in the RetailX system.
 */
public enum Role {
    CUSTOMER,
    MERCHANT,
    OPS,
    ADMIN
}

