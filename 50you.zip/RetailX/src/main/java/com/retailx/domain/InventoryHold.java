package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * Inventory reservation/hold for carts and orders.
 */
@Entity
@Table(name = "inventory_holds", indexes = {
    @Index(name = "idx_hold_cart", columnList = "cartId"),
    @Index(name = "idx_hold_order", columnList = "orderId"),
    @Index(name = "idx_hold_sku", columnList = "sku"),
    @Index(name = "idx_hold_expiry", columnList = "expiresAt")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InventoryHold extends BaseEntity {
    
    @Column(nullable = false, length = 100)
    private String sku;
    
    @Column(nullable = false)
    private BigInteger quantity;
    
    @Column(nullable = false, length = 100)
    private String warehouseId;
    
    @Column(length = 100)
    private String cartId; // For cart holds
    
    @Column
    private Long orderId; // For order holds
    
    @Column(nullable = false)
    private LocalDateTime expiresAt;
    
    @Column
    @Builder.Default
    private Boolean released = false;
}

