package com.retailx.domain;

import com.retailx.domain.enums.OnboardingStatus;
import com.retailx.encryption.EncryptedString;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Merchant entity.
 */
@Entity
@Table(name = "merchants", indexes = {
    @Index(name = "idx_merchant_user", columnList = "user_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Merchant extends BaseEntity {
    
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;
    
    @Column(nullable = false, length = 255)
    private String name;
    
    @Column(nullable = false, length = 255)
    @Convert(converter = EncryptedString.class)
    private String email;
    
    @Column(length = 50)
    @Convert(converter = EncryptedString.class)
    private String phone;
    
    @Column(nullable = false, length = 255)
    private String brandName;
    
    @Column(nullable = false, length = 100)
    private String defaultWarehouse;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private OnboardingStatus onboardingStatus = OnboardingStatus.PENDING;
}

