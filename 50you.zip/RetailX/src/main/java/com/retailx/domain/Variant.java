package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Product variant (e.g., size, color).
 */
@Entity
@Table(name = "variants", indexes = {
    @Index(name = "idx_variant_sku", columnList = "variantSku", unique = true),
    @Index(name = "idx_variant_product", columnList = "product_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Variant extends BaseEntity {
    
    @Column(nullable = false, unique = true, length = 100)
    private String variantSku;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;
    
    @Column(columnDefinition = "JSON")
    private String options; // e.g., {"size": "L", "color": "Blue"}
    
    @Column(precision = 19, scale = 2)
    private BigDecimal priceOverride; // Optional override of product basePrice
}

