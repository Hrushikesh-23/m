package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Return/refund entity.
 */
@Entity
@Table(name = "returns", indexes = {
    @Index(name = "idx_return_order", columnList = "order_id"),
    @Index(name = "idx_return_rma", columnList = "rmaNumber", unique = true)
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Return extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
    
    @Column(nullable = false, unique = true, length = 50)
    private String rmaNumber; // Return Merchandise Authorization
    
    @Column(nullable = false)
    private LocalDateTime requestedAt;
    
    @Column
    private LocalDateTime approvedAt;
    
    @Column
    private LocalDateTime completedAt;
    
    @Column(length = 50)
    @Builder.Default
    private String status = "REQUESTED"; // REQUESTED, APPROVED, REJECTED, COMPLETED
    
    @Column(length = 500)
    private String reason;
    
    @OneToMany(mappedBy = "returnEntity", cascade = CascadeType.ALL)
    @Builder.Default
    private List<ReturnItem> items = new ArrayList<>();
    
    @Column(precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal refundAmount = BigDecimal.ZERO;
    
    @Column
    @Builder.Default
    private Boolean restocked = false;
}

