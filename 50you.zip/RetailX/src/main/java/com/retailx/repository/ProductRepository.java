package com.retailx.repository;

import com.retailx.domain.Product;
import com.retailx.domain.enums.ProductStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Product entity.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    Optional<Product> findBySku(String sku);
    
    Page<Product> findByStatus(ProductStatus status, Pageable pageable);
    
    Page<Product> findByStatusAndCategoryPathStartingWith(ProductStatus status, String categoryPrefix, Pageable pageable);
    
    @Query("SELECT p FROM Product p WHERE p.status = :status " +
           "AND p.basePrice BETWEEN :minPrice AND :maxPrice " +
           "AND (:categoryPrefix IS NULL OR p.categoryPath LIKE CONCAT(:categoryPrefix, '%')) " +
           "AND (:searchText IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :searchText, '%')) " +
           "OR LOWER(p.description) LIKE LOWER(CONCAT('%', :searchText, '%')))")
    Page<Product> searchProducts(
        @Param("status") ProductStatus status,
        @Param("minPrice") BigDecimal minPrice,
        @Param("maxPrice") BigDecimal maxPrice,
        @Param("categoryPrefix") String categoryPrefix,
        @Param("searchText") String searchText,
        Pageable pageable
    );
    
    @Query("SELECT p FROM Product p WHERE p.catalogPath REGEXP :pattern")
    List<Product> findByCatalogPathRegex(@Param("pattern") String pattern);
    
    List<Product> findByMerchantId(Long merchantId);
    
    Page<Product> findByMerchantId(Long merchantId, Pageable pageable);
}

