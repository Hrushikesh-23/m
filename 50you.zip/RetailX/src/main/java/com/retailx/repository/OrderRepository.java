package com.retailx.repository;

import com.retailx.domain.Order;
import com.retailx.domain.enums.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Repository for Order entity.
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    
    Optional<Order> findByOrderNumber(String orderNumber);
    
    Page<Order> findByCustomerId(Long customerId, Pageable pageable);
    
    Page<Order> findByMerchantId(Long merchantId, Pageable pageable);
    
    Page<Order> findByStatus(OrderStatus status, Pageable pageable);
    
    @Query("SELECT o FROM Order o WHERE " +
           "(:customerId IS NULL OR o.customer.id = :customerId) " +
           "AND (:status IS NULL OR o.status = :status) " +
           "AND (:startDate IS NULL OR o.createdOn >= :startDate) " +
           "AND (:endDate IS NULL OR o.createdOn <= :endDate) " +
           "AND (:minTotal IS NULL OR o.total >= :minTotal) " +
           "AND (:maxTotal IS NULL OR o.total <= :maxTotal)")
    Page<Order> searchOrders(
        @Param("customerId") Long customerId,
        @Param("status") OrderStatus status,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate,
        @Param("minTotal") BigDecimal minTotal,
        @Param("maxTotal") BigDecimal maxTotal,
        Pageable pageable
    );
}

