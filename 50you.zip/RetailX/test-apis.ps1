# RetailX API Testing Script
# This script tests all the APIs through the API Gateway

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "RetailX API Testing Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$baseUrl = "http://localhost:8080"
$gatewayUrl = $baseUrl

# Function to make HTTP requests
function Test-API {
    param(
        [string]$Method,
        [string]$Url,
        [hashtable]$Headers = @{},
        [string]$Body = $null
    )
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            Headers = $Headers
            ContentType = "application/json"
            ErrorAction = "Stop"
        }
        
        if ($Body) {
            $params.Body = $Body
        }
        
        $response = Invoke-WebRequest @params
        Write-Host "✓ $Method $Url - Status: $($response.StatusCode)" -ForegroundColor Green
        return $response
    }
    catch {
        Write-Host "✗ $Method $Url - Error: $($_.Exception.Message)" -ForegroundColor Red
        return $null
    }
}

# Wait for services to be ready
Write-Host "Waiting for services to start..." -ForegroundColor Yellow
Start-Sleep -Seconds 10

# Test 1: Check Eureka Server
Write-Host "`n1. Testing Eureka Server..." -ForegroundColor Cyan
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8761" -ErrorAction Stop
    Write-Host "✓ Eureka Server is running" -ForegroundColor Green
} catch {
    Write-Host "✗ Eureka Server is not running" -ForegroundColor Red
}

# Test 2: Check API Gateway
Write-Host "`n2. Testing API Gateway..." -ForegroundColor Cyan
try {
    $response = Invoke-WebRequest -Uri "$gatewayUrl/actuator/health" -ErrorAction Stop
    Write-Host "✓ API Gateway is running" -ForegroundColor Green
} catch {
    Write-Host "✗ API Gateway is not running" -ForegroundColor Red
}

# Test 3: Public Product Endpoints
Write-Host "`n3. Testing Public Product Endpoints..." -ForegroundColor Cyan
Test-API -Method "GET" -Url "$gatewayUrl/api/products"
Test-API -Method "GET" -Url "$gatewayUrl/api/products?page=0`&size=10"
Test-API -Method "GET" -Url "$gatewayUrl/api/catalog"

# Test 4: Auth Service - Registration
Write-Host "`n4. Testing Auth Service - Registration..." -ForegroundColor Cyan
$registerBody = @{
    username = "testuser$(Get-Random)"
    email = "test$(Get-Random)@example.com"
    password = "Test123!"
    role = "CUSTOMER"
} | ConvertTo-Json

$registerResponse = Test-API -Method "POST" -Url "$gatewayUrl/api/auth/register" -Body $registerBody

# Test 5: Auth Service - Login
Write-Host "`n5. Testing Auth Service - Login..." -ForegroundColor Cyan
$loginBody = @{
    username = "testuser"
    password = "Test123!"
} | ConvertTo-Json

$loginResponse = Test-API -Method "POST" -Url "$gatewayUrl/api/auth/login" -Body $loginBody

# Extract token if login successful
$token = $null
if ($loginResponse) {
    try {
        $loginData = $loginResponse.Content | ConvertFrom-Json
        $token = $loginData.token
        Write-Host "✓ Token received: $($token.Substring(0, 20))..." -ForegroundColor Green
    } catch {
        Write-Host "⚠ Could not extract token from login response" -ForegroundColor Yellow
    }
}

# Test 6: Protected Endpoints (if token available)
if ($token) {
    Write-Host "`n6. Testing Protected Endpoints..." -ForegroundColor Cyan
    $authHeaders = @{
        "Authorization" = "Bearer $token"
        "X-User-Id" = "1"
    }
    
    # Test Cart Endpoints
    Test-API -Method "GET" -Url "$gatewayUrl/api/carts" -Headers $authHeaders
    Test-API -Method "GET" -Url "$gatewayUrl/api/orders" -Headers $authHeaders
    
    # Test Product Creation (if admin)
    $productBody = @{
        name = "Test Product"
        description = "Test Description"
        price = 99.99
        sku = "TEST-$(Get-Random)"
        category = "Electronics"
        stock = 100
    } | ConvertTo-Json
    
    Test-API -Method "POST" -Url "$gatewayUrl/api/products" -Headers $authHeaders -Body $productBody
}

# Test 7: Direct Service Health Checks
Write-Host "`n7. Testing Direct Service Health Checks..." -ForegroundColor Cyan
$services = @(
    @{Name="Auth Service"; Port=8081},
    @{Name="Product Service"; Port=8082},
    @{Name="Order Service"; Port=8083},
    @{Name="Payment Service"; Port=8084},
    @{Name="Inventory Service"; Port=8085},
    @{Name="Notification Service"; Port=8086},
    @{Name="Frontend Service"; Port=8087}
)

foreach ($service in $services) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$($service.Port)/actuator/health" -ErrorAction Stop
        Write-Host "✓ $($service.Name) is running on port $($service.Port)" -ForegroundColor Green
    } catch {
        Write-Host "✗ $($service.Name) is not running on port $($service.Port)" -ForegroundColor Red
    }
}

Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "API Testing Complete" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

