package com.retailx.product.service;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.dto.response.ProductResponse;
import com.retailx.product.repository.ProductRepository;
import com.retailx.product.util.SkuUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for product management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ProductService {
    
    private final ProductRepository productRepository;
    
    @Transactional
    @CacheEvict(value = "products", allEntries = true)
    public ProductResponse createProduct(ProductRequest request) {
        log.info("Creating product with SKU: {}", request.getSku());
        
        // Validate SKU
        if (!SkuUtil.isValidSku(request.getSku())) {
            throw new IllegalArgumentException("Invalid SKU format");
        }
        
        String normalizedSku = SkuUtil.normalizeSku(request.getSku());
        
        // Check if SKU already exists
        if (productRepository.findBySkuAndDeletedFalse(normalizedSku).isPresent()) {
            throw new IllegalArgumentException("Product with SKU already exists: " + normalizedSku);
        }
        
        // Normalize category path
        String normalizedCategoryPath = normalizeCategoryPath(request.getCategoryPath());
        String catalogPath = "/catalog" + normalizedCategoryPath + "/" + normalizedSku;
        
        Product product = Product.builder()
                .sku(normalizedSku)
                .name(request.getName())
                .description(request.getDescription())
                .basePrice(request.getBasePrice())
                .currency(request.getCurrency())
                .categoryPath(normalizedCategoryPath)
                .catalogPath(catalogPath)
                .status(request.getStatus() != null ? request.getStatus() : ProductStatus.DRAFT)
                .media(request.getMedia())
                .attributes(request.getAttributes())
                .merchantId(request.getMerchantId())
                .build();
        
        product = productRepository.save(product);
        return mapToResponse(product);
    }
    
    @Cacheable(value = "products", key = "#id")
    public ProductResponse getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new com.retailx.product.exception.ProductNotFoundException(id));
        
        if (product.getDeleted()) {
            throw new com.retailx.product.exception.ProductNotFoundException(id);
        }
        
        return mapToResponse(product);
    }
    
    @Cacheable(value = "products", key = "#sku")
    public ProductResponse getProductBySku(String sku) {
        String normalizedSku = SkuUtil.normalizeSku(sku);
        Product product = productRepository.findBySkuAndDeletedFalse(normalizedSku)
                .orElseThrow(() -> new com.retailx.product.exception.ProductNotFoundException("SKU", sku));
        
        return mapToResponse(product);
    }
    
    public Page<ProductResponse> searchProducts(
            ProductStatus status,
            BigDecimal minPrice,
            BigDecimal maxPrice,
            String categoryPrefix,
            String searchText,
            Pageable pageable) {
        
        if (minPrice == null) minPrice = BigDecimal.ZERO;
        if (maxPrice == null) maxPrice = BigDecimal.valueOf(Long.MAX_VALUE);
        if (status == null) status = ProductStatus.ACTIVE;
        
        String normalizedCategoryPrefix = categoryPrefix != null ? normalizeCategoryPath(categoryPrefix) : null;
        
        Page<Product> products = productRepository.searchProducts(
                status, minPrice, maxPrice, normalizedCategoryPrefix, searchText, pageable);
        
        return products.map(this::mapToResponse);
    }
    
    public List<ProductResponse> searchByRegex(String pattern) {
        if (pattern == null || pattern.length() > 128) {
            throw new IllegalArgumentException("Invalid regex pattern");
        }
        
        List<Product> products = productRepository.findByCatalogPathRegex(pattern);
        return products.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    public Page<ProductResponse> getProductsByMerchant(Long merchantId, Pageable pageable) {
        Page<Product> products = productRepository.findByMerchantIdAndDeletedFalse(merchantId, pageable);
        return products.map(this::mapToResponse);
    }
    
    @Transactional
    @CacheEvict(value = "products", allEntries = true)
    public ProductResponse updateProduct(Long id, ProductRequest request) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new com.retailx.product.exception.ProductNotFoundException(id));
        
        if (product.getDeleted()) {
            throw new com.retailx.product.exception.ProductNotFoundException(id);
        }
        
        product.setName(request.getName());
        product.setDescription(request.getDescription());
        product.setBasePrice(request.getBasePrice());
        product.setCurrency(request.getCurrency());
        product.setCategoryPath(normalizeCategoryPath(request.getCategoryPath()));
        product.setStatus(request.getStatus());
        product.setMedia(request.getMedia());
        product.setAttributes(request.getAttributes());
        
        // Update catalog path
        product.setCatalogPath("/catalog" + product.getCategoryPath() + "/" + product.getSku());
        
        product = productRepository.save(product);
        return mapToResponse(product);
    }
    
    @Transactional
    @CacheEvict(value = "products", allEntries = true)
    public void deleteProduct(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new com.retailx.product.exception.ProductNotFoundException(id));
        
        product.setDeleted(true);
        productRepository.save(product);
    }
    
    private String normalizeCategoryPath(String categoryPath) {
        if (categoryPath == null || categoryPath.trim().isEmpty()) {
            return "/default";
        }
        
        // Normalize: lowercase, slash-separated, no trailing slash
        String normalized = categoryPath.trim().toLowerCase()
                .replaceAll("\\s+", "/")
                .replaceAll("/+", "/");
        
        if (!normalized.startsWith("/")) {
            normalized = "/" + normalized;
        }
        
        if (normalized.endsWith("/") && normalized.length() > 1) {
            normalized = normalized.substring(0, normalized.length() - 1);
        }
        
        return normalized;
    }
    
    private ProductResponse mapToResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .sku(product.getSku())
                .name(product.getName())
                .description(product.getDescription())
                .basePrice(product.getBasePrice())
                .currency(product.getCurrency())
                .categoryPath(product.getCategoryPath())
                .catalogPath(product.getCatalogPath())
                .status(product.getStatus())
                .media(product.getMedia())
                .attributes(product.getAttributes())
                .merchantId(product.getMerchantId())
                .createdOn(product.getCreatedOn())
                .updatedOn(product.getUpdatedOn())
                .build();
    }
}

