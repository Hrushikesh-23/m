package com.retailx.product.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Product review entity.
 */
@Entity
@Table(name = "reviews", indexes = {
    @Index(name = "idx_review_product", columnList = "productId"),
    @Index(name = "idx_review_customer", columnList = "customerId"),
    @Index(name = "idx_review_order_item", columnList = "orderItemId"),
    @Index(name = "idx_review_status", columnList = "status")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review extends BaseEntity {
    
    @Column(nullable = false)
    private Long productId;
    
    @Column(nullable = false)
    private Long customerId; // Reference to auth service
    
    @Column(nullable = false)
    private Long orderItemId; // Reference to order service
    
    @Column(nullable = false)
    private Integer rating; // 1-5
    
    @Column(columnDefinition = "TEXT")
    private String text;
    
    @Column(length = 50)
    @Builder.Default
    private String status = "PENDING"; // PENDING, APPROVED, HIDDEN
    
    @Column
    @Builder.Default
    private Boolean moderated = false;
}

