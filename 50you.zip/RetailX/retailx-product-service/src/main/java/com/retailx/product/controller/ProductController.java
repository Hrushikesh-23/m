package com.retailx.product.controller;

import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.dto.response.ProductResponse;
import com.retailx.product.service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

/**
 * REST controller for product catalog management endpoints.
 * Handles product CRUD operations, search, filtering, and pagination.
 */
@Slf4j
@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {
    
    private final ProductService productService;
    
    @PostMapping
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")
    public ResponseEntity<ProductResponse> createProduct(
            @Valid @RequestBody ProductRequest request,
            @RequestHeader(value = "X-User-Id", required = false) Long userId) {
        log.info("Creating product: sku={}, name={}, userId={}", request.getSku(), request.getName(), userId);
        
        // Set merchantId from authenticated user if not provided
        if (request.getMerchantId() == null && userId != null) {
            request.setMerchantId(userId);
        }
        
        ProductResponse response = productService.createProduct(request);
        log.info("Product created successfully: id={}, sku={}", response.getId(), response.getSku());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    
    /**
     * Get product by ID - public read access, no authentication required.
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable Long id) {
        log.debug("Fetching product by ID: {}", id);
        ProductResponse response = productService.getProductById(id);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get product by SKU - public read access, no authentication required.
     */
    @GetMapping("/sku/{sku}")
    public ResponseEntity<ProductResponse> getProductBySku(@PathVariable String sku) {
        log.debug("Fetching product by SKU: {}", sku);
        ProductResponse response = productService.getProductBySku(sku);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Search products with filters and pagination - public read access.
     * Supports filtering by status, price range, category, and text search.
     */
    @GetMapping
    public ResponseEntity<Page<ProductResponse>> searchProducts(
            @RequestParam(required = false) ProductStatus status,
            @RequestParam(required = false) BigDecimal minPrice,
            @RequestParam(required = false) BigDecimal maxPrice,
            @RequestParam(required = false) String categoryPath,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdOn") String sortBy,
            @RequestParam(defaultValue = "DESC") String sortDir) {
        
        log.debug("Searching products: status={}, minPrice={}, maxPrice={}, category={}, search={}, page={}", 
                status, minPrice, maxPrice, categoryPath, search, page);
        
        Sort sort = sortDir.equalsIgnoreCase("ASC") 
            ? Sort.by(sortBy).ascending() 
            : Sort.by(sortBy).descending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        
        Page<ProductResponse> response = productService.searchProducts(
                status, minPrice, maxPrice, categoryPath, search, pageable);
        
        log.debug("Found {} products", response.getTotalElements());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Search products using regex pattern on catalog path - public read access.
     */
    @GetMapping("/search/regex")
    public ResponseEntity<List<ProductResponse>> searchByRegex(
            @RequestParam String pattern) {
        log.info("Regex search: pattern={}", pattern);
        List<ProductResponse> response = productService.searchByRegex(pattern);
        log.debug("Regex search found {} products", response.size());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get products by merchant - public read access.
     */
    @GetMapping("/merchant/{merchantId}")
    public ResponseEntity<Page<ProductResponse>> getProductsByMerchant(
            @PathVariable Long merchantId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        
        log.debug("Fetching products for merchant: {}, page={}", merchantId, page);
        Pageable pageable = PageRequest.of(page, size);
        Page<ProductResponse> response = productService.getProductsByMerchant(merchantId, pageable);
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/{id}")
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")
    public ResponseEntity<ProductResponse> updateProduct(
            @PathVariable Long id,
            @Valid @RequestBody ProductRequest request) {
        log.info("Updating product: id={}, sku={}", id, request.getSku());
        ProductResponse response = productService.updateProduct(id, request);
        log.info("Product updated successfully: id={}", id);
        return ResponseEntity.ok(response);
    }
    
    @DeleteMapping("/{id}")
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        log.info("Deleting product: id={}", id);
        productService.deleteProduct(id);
        log.info("Product deleted successfully: id={}", id);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Product Service is running");
    }
}

