# RetailX Application - Complete Running Guide

This guide provides detailed instructions for running the RetailX e-commerce platform both **with Docker** and **without Docker**, including all available APIs.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Running WITHOUT Docker (Local Setup)](#running-without-docker-local-setup)
3. [Running WITH Docker](#running-with-docker)
4. [Complete API Reference](#complete-api-reference)
5. [Testing the APIs](#testing-the-apis)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### For Both Methods:
- **Java 21 JDK** (or higher)
- **Maven 3.8+**
- **Git** (to clone the repository)

### For Without Docker:
- **MySQL 8.0+** installed and running locally
- **Apache Kafka** installed and running locally (or use Docker only for Kafka)

### For With Docker:
- **Docker Desktop** (Windows/Mac) or **Docker Engine** (Linux)
- **Docker Compose** (usually included with Docker Desktop)

---

## Running WITHOUT Docker (Local Setup)

### Step 1: Setup MySQL Database

1. **Install MySQL 8.0+** if not already installed
2. **Start MySQL service:**
   ```bash
   # Windows (as Administrator)
   net start MySQL80
   
   # Linux/Mac
   sudo systemctl start mysql
   # or
   sudo service mysql start
   ```

3. **Create databases:**
   ```sql
   -- Connect to MySQL
   mysql -u root -p
   
   -- Create databases for each service
   CREATE DATABASE retailx_auth;
   CREATE DATABASE retailx_product;
   CREATE DATABASE retailx_order;
   CREATE DATABASE retailx_payment;
   CREATE DATABASE retailx_inventory;
   ```

4. **Update database credentials** in each service's `application.yml` if needed:
   - Default: `username: root`, `password: root`
   - Change if your MySQL has different credentials

### Step 2: Setup Kafka (Optional - Can use Docker for Kafka only)

**Option A: Use Docker only for Kafka (Recommended)**
```bash
# Start only Kafka and Zookeeper
docker-compose up -d zookeeper kafka
```

**Option B: Install Kafka locally**
1. Download Kafka from https://kafka.apache.org/downloads
2. Extract and navigate to Kafka directory
3. Start Zookeeper:
   ```bash
   bin/zookeeper-server-start.sh config/zookeeper.properties
   ```
4. Start Kafka (in new terminal):
   ```bash
   bin/kafka-server-start.sh config/server.properties
   ```

### Step 3: Build All Services

```bash
# Navigate to project root
cd RetailX

# Build all services
mvn clean install -DskipTests
```

### Step 4: Start Services in Order

**Important:** Services must be started in this specific order:

#### Terminal 1: Eureka Server (Service Discovery)
```bash
cd retailx-eureka-server
mvn spring-boot:run
```
Wait until you see: `Started EurekaServerApplication` and `http://localhost:8761`

#### Terminal 2: API Gateway
```bash
cd retailx-api-gateway
mvn spring-boot:run
```
Wait until you see: `Started ApiGatewayApplication` and `http://localhost:8080`

#### Terminal 3: Auth Service
```bash
cd retailx-auth-service
mvn spring-boot:run
```
Wait until you see: `Started AuthServiceApplication` and `http://localhost:8081`

#### Terminal 4: Product Service
```bash
cd retailx-product-service
mvn spring-boot:run
```
Wait until you see: `Started ProductServiceApplication` and `http://localhost:8082`

#### Terminal 5: Order Service
```bash
cd retailx-order-service
mvn spring-boot:run
```
Wait until you see: `Started OrderServiceApplication` and `http://localhost:8083`

#### Terminal 6: Payment Service
```bash
cd retailx-payment-service
mvn spring-boot:run
```
Wait until you see: `Started PaymentServiceApplication` and `http://localhost:8084`

#### Terminal 7: Inventory Service
```bash
cd retailx-inventory-service
mvn spring-boot:run
```
Wait until you see: `Started InventoryServiceApplication` and `http://localhost:8085`

#### Terminal 8: Notification Service (Optional)
```bash
cd retailx-notification-service
mvn spring-boot:run
```
Wait until you see: `Started NotificationServiceApplication` and `http://localhost:8086`

#### Terminal 9: Frontend Service (Optional)
```bash
cd retailx-frontend-service
mvn spring-boot:run
```
Wait until you see: `Started FrontendServiceApplication` and `http://localhost:8087`

### Step 5: Verify Services

1. **Check Eureka Dashboard:** http://localhost:8761
   - You should see all services registered

2. **Check API Gateway:** http://localhost:8080/actuator/health
   - Should return `{"status":"UP"}`

3. **Check Service Health:**
   - Auth: http://localhost:8081/actuator/health
   - Product: http://localhost:8082/actuator/health
   - Order: http://localhost:8083/actuator/health
   - Payment: http://localhost:8084/actuator/health
   - Inventory: http://localhost:8085/actuator/health

---

## Running WITH Docker

### Step 1: Start Infrastructure Services

```bash
# Navigate to project root
cd RetailX

# Start MySQL, Kafka, and Zookeeper
docker-compose up -d

# Verify containers are running
docker-compose ps
```

You should see:
- `retailx-mysql` (port 3306)
- `retailx-zookeeper` (port 2181)
- `retailx-kafka` (port 9092)

### Step 2: Wait for Services to be Ready

```bash
# Check MySQL is ready
docker-compose logs mysql | grep "ready for connections"

# Check Kafka is ready
docker-compose logs kafka | grep "started"
```

### Step 3: Build All Services

```bash
# Build all services
mvn clean install -DskipTests
```

### Step 4: Start Services (Same as Without Docker)

Follow **Step 4** from the "Running WITHOUT Docker" section above. The services will connect to Docker containers automatically.

**Note:** For a fully containerized setup, you would need to create Dockerfiles for each service and use `docker-compose` to orchestrate everything. The current setup uses Docker only for infrastructure (MySQL, Kafka).

### Step 5: Stop Infrastructure

```bash
# Stop all containers
docker-compose down

# Stop and remove volumes (clean slate)
docker-compose down -v
```

---

## Complete API Reference

**Base URL:** `http://localhost:8080` (All requests go through API Gateway)

**Authentication:** Most endpoints require JWT token in `Authorization` header:
```
Authorization: Bearer <your-jwt-token>
```

---

### 🔐 Auth Service APIs

#### 1. Register User
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "customer@example.com",
  "password": "Customer@123",
  "name": "John Doe",
  "role": "CUSTOMER"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": 1,
  "email": "customer@example.com",
  "role": "CUSTOMER"
}
```

#### 2. Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@retailx.com",
  "password": "Admin@123"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": 1,
  "email": "admin@retailx.com",
  "role": "ADMIN"
}
```

**Default Credentials:**
- Admin: `admin@retailx.com` / `Admin@123`
- Roles: `CUSTOMER`, `MERCHANT`, `ADMIN`, `OPS`

---

### 📦 Product Service APIs

#### 3. List Products (Paginated)
```http
GET /api/products?page=0&size=10&status=ACTIVE&minPrice=0&maxPrice=1000&categoryPath=/electronics&searchText=laptop
Authorization: Bearer <token>
```

**Query Parameters:**
- `page` (default: 0)
- `size` (default: 20)
- `status` (ACTIVE, INACTIVE, DRAFT)
- `minPrice` (number)
- `maxPrice` (number)
- `categoryPath` (string, e.g., "/electronics")
- `searchText` (string, searches in name and description)

#### 4. Get Product by ID
```http
GET /api/products/1
Authorization: Bearer <token>
```

#### 5. Get Product by SKU
```http
GET /api/products/sku/PROD-001
Authorization: Bearer <token>
```

#### 6. Create Product (MERCHANT, ADMIN)
```http
POST /api/products
Authorization: Bearer <token>
Content-Type: application/json

{
  "sku": "PROD-001",
  "name": "Laptop Computer",
  "description": "High-performance laptop",
  "basePrice": 999.99,
  "currency": "USD",
  "categoryPath": "/electronics/computers",
  "status": "ACTIVE",
  "merchantId": 1
}
```

#### 7. Update Product (MERCHANT, ADMIN)
```http
PUT /api/products/1
Authorization: Bearer <token>
Content-Type: application/json

{
  "name": "Updated Laptop Name",
  "basePrice": 899.99
}
```

#### 8. Delete Product (MERCHANT, ADMIN)
```http
DELETE /api/products/1
Authorization: Bearer <token>
```

#### 9. Bulk Import CSV (MERCHANT, ADMIN)
```http
POST /api/products/bulk/import/csv
Authorization: Bearer <token>
Content-Type: multipart/form-data

file: <csv-file>
```

#### 10. Bulk Import XLSX (MERCHANT, ADMIN)
```http
POST /api/products/bulk/import/xlsx
Authorization: Bearer <token>
Content-Type: multipart/form-data

file: <xlsx-file>
```

#### 11. Regex Search on Catalog Path
```http
GET /api/products/search/regex?pattern=/electronics/.*/laptops
Authorization: Bearer <token>
```

#### 12. Get Products by Merchant
```http
GET /api/products/merchant/1?page=0&size=10
Authorization: Bearer <token>
```

---

### ⭐ Review Service APIs

#### 13. Create Review (CUSTOMER, ADMIN)
```http
POST /api/reviews/products/1?orderItemId=1
Authorization: Bearer <token>
Content-Type: application/json

{
  "rating": 5,
  "title": "Great Product!",
  "comment": "Very satisfied with the purchase",
  "customerId": 1
}
```

#### 14. Get Reviews by Product
```http
GET /api/reviews/products/1?page=0&size=10
Authorization: Bearer <token>
```

#### 15. Moderate Review (ADMIN, OPS)
```http
PUT /api/reviews/1/moderate?action=APPROVE
Authorization: Bearer <token>
```

**Actions:** `APPROVE`, `HIDE`, `REJECT`

#### 16. Get Pending Reviews (ADMIN, OPS)
```http
GET /api/reviews/pending?page=0&size=10
Authorization: Bearer <token>
```

---

### 🛒 Cart Service APIs

#### 17. Get or Create Cart (CUSTOMER, ADMIN)
```http
GET /api/carts
Authorization: Bearer <token>
```

**Response:**
```json
{
  "id": 1,
  "customerId": 1,
  "items": [
    {
      "id": 1,
      "sku": "PROD-001",
      "quantity": 2,
      "unitPrice": 99.99,
      "lineTotal": 199.98
    }
  ],
  "subtotal": 199.98,
  "tax": 19.99,
  "shipping": 5.00,
  "total": 224.97
}
```

#### 18. Add Item to Cart (CUSTOMER, ADMIN)
```http
POST /api/carts/items
Authorization: Bearer <token>
Content-Type: application/json

{
  "sku": "PROD-001",
  "quantity": 2
}
```

#### 19. Update Cart Item Quantity (CUSTOMER, ADMIN)
```http
PUT /api/carts/items/1?quantity=3
Authorization: Bearer <token>
```

#### 20. Remove Item from Cart (CUSTOMER, ADMIN)
```http
DELETE /api/carts/items/1
Authorization: Bearer <token>
```

#### 21. Clear Cart (CUSTOMER, ADMIN)
```http
DELETE /api/carts
Authorization: Bearer <token>
```

---

### 💳 Checkout Service APIs

#### 22. Checkout (CUSTOMER, ADMIN)
```http
POST /api/checkout
Authorization: Bearer <token>
Idempotency-Key: unique-key-12345
Content-Type: application/json

{
  "shippingAddress": "123 Main St, City, State, ZIP",
  "shippingMethod": "STANDARD",
  "paymentMethod": "CARD"
}
```

**Important:** Always include `Idempotency-Key` header for safe retries.

**Response:**
```json
{
  "orderNumber": "ORD-20241210-001",
  "orderId": 1,
  "status": "PENDING",
  "total": 224.97,
  "paymentIntentId": "pi_abc123"
}
```

---

### 📋 Order Service APIs

#### 23. Get Order by ID
```http
GET /api/orders/1
Authorization: Bearer <token>
```

#### 24. Get Order by Order Number
```http
GET /api/orders/number/ORD-20241210-001
Authorization: Bearer <token>
```

#### 25. Get Customer Orders (CUSTOMER, ADMIN)
```http
GET /api/orders/customer?page=0&size=10
Authorization: Bearer <token>
```

#### 26. Get Merchant Orders (MERCHANT, ADMIN, OPS)
```http
GET /api/orders/merchant?page=0&size=10
Authorization: Bearer <token>
```

#### 27. Update Order Status
```http
PUT /api/orders/1/status?status=CONFIRMED
Authorization: Bearer <token>
```

**Statuses:** `PENDING`, `CONFIRMED`, `PROCESSING`, `SHIPPED`, `DELIVERED`, `CANCELLED`

#### 28. Cancel Order
```http
PUT /api/orders/1/cancel?reason=Customer requested
Authorization: Bearer <token>
```

---

### 📦 Shipment Service APIs

#### 29. Create Shipment (OPS, ADMIN, MERCHANT)
```http
POST /api/shipments/orders/1
Authorization: Bearer <token>
Content-Type: application/json

{
  "carrier": "FEDEX",
  "trackingNumber": "TRACK123456",
  "estimatedDelivery": "2024-12-20T10:00:00"
}
```

#### 30. Mark Shipment as Delivered (OPS, ADMIN)
```http
PUT /api/shipments/1/delivered
Authorization: Bearer <token>
```

#### 31. Get Shipments by Order
```http
GET /api/shipments/orders/1
Authorization: Bearer <token>
```

---

### 🔄 Return Service APIs

#### 32. Request Return (CUSTOMER, ADMIN)
```http
POST /api/returns/orders/1
Authorization: Bearer <token>
Content-Type: application/json

{
  "reason": "Defective item",
  "items": [
    {
      "orderItemId": 1,
      "quantity": 1,
      "reason": "Damaged"
    }
  ]
}
```

#### 33. Approve Return (OPS, ADMIN, MERCHANT)
```http
PUT /api/returns/1/approve
Authorization: Bearer <token>
```

#### 34. Reject Return (OPS, ADMIN, MERCHANT)
```http
PUT /api/returns/1/reject
Authorization: Bearer <token>
Content-Type: application/json

{
  "reason": "Return period expired"
}
```

#### 35. Get Returns by Order
```http
GET /api/returns/orders/1
Authorization: Bearer <token>
```

---

### 💰 Payment Service APIs

#### 36. Create Payment Intent
```http
POST /api/payments/intents
Authorization: Bearer <token>
Content-Type: application/json

{
  "orderId": 1,
  "amount": 224.97,
  "currency": "USD",
  "correlationId": "unique-id-123"
}
```

**Response:**
```json
{
  "id": 1,
  "paymentIntentId": "pi_abc123",
  "orderId": 1,
  "amount": 224.97,
  "currency": "USD",
  "status": "PENDING"
}
```

#### 37. Authorize Payment
```http
POST /api/payments/intents/1/authorize
Authorization: Bearer <token>
Content-Type: application/json

{
  "correlationId": "unique-id-123"
}
```

#### 38. Capture Payment
```http
POST /api/payments/intents/1/capture
Authorization: Bearer <token>
Content-Type: application/json

{
  "correlationId": "unique-id-123"
}
```

#### 39. Refund Payment
```http
POST /api/payments/intents/1/refund
Authorization: Bearer <token>
Content-Type: application/json

{
  "amount": 224.97,
  "correlationId": "unique-id-123"
}
```

#### 40. Get Payment Intent by Order
```http
GET /api/payments/intents/orders/1
Authorization: Bearer <token>
```

---

### 📊 Inventory Service APIs

#### 41. Reserve Inventory
```http
POST /api/inventory/reserve
Authorization: Bearer <token>
Content-Type: application/json

{
  "sku": "PROD-001",
  "quantity": 2,
  "warehouseId": "default-warehouse"
}
```

#### 42. Get Low Stock Items
```http
GET /api/inventory/low-stock
Authorization: Bearer <token>
```

#### 43. Adjust Inventory
```http
POST /api/inventory/adjust
Authorization: Bearer <token>
Content-Type: application/json

{
  "sku": "PROD-001",
  "warehouseId": "default-warehouse",
  "quantity": 100
}
```

#### 44. Release Hold
```http
POST /api/inventory/release-hold
Authorization: Bearer <token>
Content-Type: application/json

{
  "cartId": "cart-123"
}
```

---

### 📈 Reporting Service APIs

#### 45. Get Sales Report (ADMIN, OPS, MERCHANT)
```http
GET /api/reports/sales?startDate=2024-01-01&endDate=2024-12-31&merchantId=1
Authorization: Bearer <token>
```

#### 46. Get Order Statistics (ADMIN, OPS, MERCHANT)
```http
GET /api/reports/orders/stats?startDate=2024-01-01&endDate=2024-12-31
Authorization: Bearer <token>
```

---

## Testing the APIs

### Method 1: Using Postman

1. **Import Collection:**
   - Open Postman
   - Click "Import"
   - Select `POSTMAN_COLLECTION.json` from project root
   - Set variable `baseUrl` to `http://localhost:8080`

2. **Get JWT Token:**
   - Run "Register User" or "Login" request
   - Token is automatically saved to `token` variable

3. **Test All Endpoints:**
   - All subsequent requests will use the saved token automatically

### Method 2: Using cURL

#### Register and Login:
```bash
# Register
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "Test@1234",
    "name": "Test User",
    "role": "CUSTOMER"
  }'

# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@retailx.com",
    "password": "Admin@123"
  }'
```

#### Use Token in Requests:
```bash
# Replace <TOKEN> with actual JWT token from login response
TOKEN="<your-jwt-token>"

# Get Products
curl -X GET http://localhost:8080/api/products \
  -H "Authorization: Bearer $TOKEN"

# Create Product (as MERCHANT/ADMIN)
curl -X POST http://localhost:8080/api/products \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "sku": "PROD-001",
    "name": "Test Product",
    "description": "Test Description",
    "basePrice": 99.99,
    "currency": "USD",
    "categoryPath": "/electronics",
    "status": "ACTIVE",
    "merchantId": 1
  }'
```

### Method 3: Using Swagger UI

1. **Access Swagger UI:**
   - Navigate to: http://localhost:8080/swagger-ui.html
   - Or: http://localhost:8082/swagger-ui.html (Product Service directly)

2. **Authorize:**
   - Click "Authorize" button
   - Enter: `Bearer <your-jwt-token>`
   - Click "Authorize"

3. **Test Endpoints:**
   - Expand any endpoint
   - Click "Try it out"
   - Fill in parameters
   - Click "Execute"

---

## Service URLs & Ports

| Service | Port | Direct URL | Gateway Path |
|---------|------|------------|--------------|
| Eureka Server | 8761 | http://localhost:8761 | - |
| API Gateway | 8080 | http://localhost:8080 | All `/api/**` |
| Auth Service | 8081 | http://localhost:8081 | `/api/auth/**` |
| Product Service | 8082 | http://localhost:8082 | `/api/products/**` |
| Order Service | 8083 | http://localhost:8083 | `/api/orders/**` |
| Payment Service | 8084 | http://localhost:8084 | `/api/payments/**` |
| Inventory Service | 8085 | http://localhost:8085 | `/api/inventory/**` |
| Notification Service | 8086 | http://localhost:8086 | - |
| Frontend Service | 8087 | http://localhost:8087 | `/` |

---

## Observability Endpoints

### Health Checks
```bash
# API Gateway
curl http://localhost:8080/actuator/health

# Individual Services
curl http://localhost:8081/actuator/health
curl http://localhost:8082/actuator/health
curl http://localhost:8083/actuator/health
```

### Prometheus Metrics
```bash
# API Gateway
curl http://localhost:8080/actuator/prometheus

# Individual Services
curl http://localhost:8081/actuator/prometheus
curl http://localhost:8082/actuator/prometheus
```

### Zipkin Tracing
1. **Start Zipkin:**
   ```bash
   docker run -d -p 9411:9411 openzipkin/zipkin
   ```

2. **Access UI:**
   - http://localhost:9411

3. **View Traces:**
   - Make API calls
   - Search traces in Zipkin UI

---

## Troubleshooting

### Issue: Services not registering with Eureka

**Solution:**
1. Ensure Eureka Server is running first
2. Wait 30 seconds after starting each service
3. Check Eureka dashboard: http://localhost:8761
4. Verify service logs for connection errors

### Issue: Database connection errors

**Solution:**
1. Verify MySQL is running:
   ```bash
   # Windows
   net start MySQL80
   
   # Linux/Mac
   sudo systemctl status mysql
   ```

2. Check database credentials in `application.yml`
3. Verify databases exist:
   ```sql
   SHOW DATABASES;
   ```

### Issue: Kafka connection errors

**Solution:**
1. Verify Kafka is running:
   ```bash
   docker-compose ps
   ```

2. Check Kafka logs:
   ```bash
   docker-compose logs kafka
   ```

3. Test Kafka connection:
   ```bash
   docker exec -it retailx-kafka kafka-topics --list --bootstrap-server localhost:9092
   ```

### Issue: JWT token invalid

**Solution:**
1. Re-login to get a fresh token
2. Ensure token is included in `Authorization` header:
   ```
   Authorization: Bearer <token>
   ```
3. Check token expiration (default: 1 hour)

### Issue: Rate limiting errors

**Solution:**
1. Default rate limit: 10 requests/second
2. Wait a few seconds before retrying
3. For higher limits, update `application.yml` in API Gateway

### Issue: Port already in use

**Solution:**
1. Find process using the port:
   ```bash
   # Windows
   netstat -ano | findstr :8080
   
   # Linux/Mac
   lsof -i :8080
   ```

2. Kill the process or change port in `application.yml`

---

## Quick Start Scripts

### Windows (PowerShell)

Create `start-services.ps1`:
```powershell
# Start Eureka
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd retailx-eureka-server; mvn spring-boot:run"
Start-Sleep -Seconds 10

# Start API Gateway
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd retailx-api-gateway; mvn spring-boot:run"
Start-Sleep -Seconds 10

# Start Auth Service
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd retailx-auth-service; mvn spring-boot:run"
Start-Sleep -Seconds 10

# Continue for other services...
```

### Linux/Mac (Bash)

Create `start-services.sh`:
```bash
#!/bin/bash

# Start Eureka
cd retailx-eureka-server && mvn spring-boot:run &
sleep 10

# Start API Gateway
cd ../retailx-api-gateway && mvn spring-boot:run &
sleep 10

# Start Auth Service
cd ../retailx-auth-service && mvn spring-boot:run &
sleep 10

# Continue for other services...
```

---

## Summary

### Running Without Docker:
1. Install MySQL locally
2. Use Docker only for Kafka (optional)
3. Build all services: `mvn clean install`
4. Start services in order (Eureka → Gateway → Others)

### Running With Docker:
1. Start infrastructure: `docker-compose up -d`
2. Build all services: `mvn clean install`
3. Start services in order (same as without Docker)

### Testing:
- Use Postman collection: `POSTMAN_COLLECTION.json`
- Or use Swagger UI: http://localhost:8080/swagger-ui.html
- Or use cURL commands

### All APIs:
- 46+ endpoints across 8 microservices
- All accessible through API Gateway at `http://localhost:8080`
- JWT authentication required for most endpoints
- Role-based access control (CUSTOMER, MERCHANT, ADMIN, OPS)

---

**For more details, see:**
- [README.md](README.md) - Project overview
- [docs/API_ENDPOINT_DIAGRAM.md](docs/API_ENDPOINT_DIAGRAM.md) - Complete API reference
- [POSTMAN_COLLECTION.json](POSTMAN_COLLECTION.json) - Postman collection

