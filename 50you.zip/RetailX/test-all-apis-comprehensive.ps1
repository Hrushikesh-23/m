# Comprehensive API Testing Script for RetailX with Role-Based Access Control
Write-Host "=== Comprehensive RetailX API Testing (Role-Based) ===" -ForegroundColor Magenta
Write-Host "Testing all endpoints with proper role-based access control`n" -ForegroundColor Cyan

$script:testResults = @()
$script:customerToken = $null
$script:customerId = $null
$script:merchantToken = $null
$script:merchantId = $null
$script:opsToken = $null
$script:opsId = $null
$script:adminToken = $null
$script:adminId = $null
$script:productId = $null
$script:orderId = $null
$script:orderNumber = $null
$script:cartItemId = $null
$script:paymentIntentId = $null
$script:reviewId = $null
$script:shipmentId = $null
$script:returnId = $null

function Test-API {
    param(
        [string]$Name,
        [string]$Method,
        [string]$Url,
        [hashtable]$Headers = @{},
        [string]$Body = $null,
        [int]$ExpectedStatus = 200,
        [bool]$SkipOnFail = $false,
        [string]$Role = "N/A"
    )
    
    $result = @{
        Name = $Name
        Method = $Method
        Url = $Url
        Status = "FAIL"
        StatusCode = 0
        Error = ""
        Response = $null
        Role = $Role
        ExpectedStatus = $ExpectedStatus
    }
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            Headers = $Headers
            TimeoutSec = 10
            ErrorAction = "Stop"
        }
        
        if ($Body) {
            $params.Body = $Body
            $params.ContentType = "application/json"
        }
        
        $response = Invoke-RestMethod @params
        $httpStatusCode = 200
        
        $result.Status = "PASS"
        $result.StatusCode = $httpStatusCode
        $result.Response = $response
        
        if ($result.StatusCode -eq $ExpectedStatus) {
            Write-Host "  [OK] $Name (Role: $Role)" -ForegroundColor Green
        } else {
            Write-Host "  [WARN] $Name (Role: $Role) - Expected $ExpectedStatus, got $($result.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        $statusCode = 0
        if ($_.Exception.Response) {
            $statusCode = [int]$_.Exception.Response.StatusCode.value__
            $result.StatusCode = $statusCode
            
            try {
                $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $errorBody = $reader.ReadToEnd()
                $result.Error = $errorBody
            } catch {
                $result.Error = $_.Exception.Message
            }
        } else {
            $result.Error = $_.Exception.Message
        }
        
        $statusColor = if ($statusCode -eq 401 -or $statusCode -eq 403) { "Yellow" } elseif ($statusCode -eq $ExpectedStatus) { "Green" } else { "Red" }
        if ($statusCode -eq $ExpectedStatus) {
            $result.Status = "PASS"
            Write-Host "  [OK] $Name (Role: $Role) - Got expected $ExpectedStatus" -ForegroundColor Green
        } else {
            if ($SkipOnFail) {
                Write-Host "  [SKIP] $Name (Role: $Role) - Status: $statusCode" -ForegroundColor Gray
            } else {
                $icon = if ($statusCode -eq 403 -and $ExpectedStatus -eq 200) { "[FORBIDDEN]" } else { "[FAIL]" }
                Write-Host "  $icon $Name (Role: $Role) - Status: $statusCode (Expected: $ExpectedStatus)" -ForegroundColor $statusColor
                if ($result.Error -and $statusCode -ne 403) {
                    Write-Host "    Error: $($result.Error.Substring(0, [Math]::Min(100, $result.Error.Length)))" -ForegroundColor Gray
                }
            }
        }
    }
    
    $script:testResults += $result
    return $result
}

# 1. Health Checks
Write-Host "`n1. HEALTH CHECKS" -ForegroundColor Cyan
$services = @(
    @{Port=8761; Name="Eureka"; Path=""},
    @{Port=8080; Name="API Gateway"; Path="/actuator/health"},
    @{Port=8081; Name="Auth Service"; Path="/actuator/health"},
    @{Port=8082; Name="Product Service"; Path="/actuator/health"},
    @{Port=8083; Name="Order Service"; Path="/actuator/health"},
    @{Port=8084; Name="Payment Service"; Path="/actuator/health"},
    @{Port=8085; Name="Inventory Service"; Path="/actuator/health"},
    @{Port=8087; Name="Frontend Service"; Path="/actuator/health"}
)

foreach ($svc in $services) {
    $url = "http://localhost:$($svc.Port)$($svc.Path)"
    Test-API -Name "$($svc.Name) Health" -Method "GET" -Url $url -SkipOnFail $true -Role "PUBLIC"
}

# 2. Auth Service APIs - Public Access
Write-Host "`n2. AUTH SERVICE APIs (PUBLIC)" -ForegroundColor Cyan

$randomNum = Get-Random -Minimum 1000 -Maximum 9999

# Register Customer
$customerEmail = "customer$randomNum@example.com"
$registerCustomerBody = @{
    name = "Test Customer $randomNum"
    email = $customerEmail
    password = "Test123!@$"
    role = "CUSTOMER"
} | ConvertTo-Json

$regCustomerResult = Test-API -Name "Register Customer" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $registerCustomerBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regCustomerResult.Status -eq "PASS" -and $regCustomerResult.Response) {
    $script:customerToken = $regCustomerResult.Response.token
    $script:customerId = $regCustomerResult.Response.userId
    Write-Host "    Customer Token obtained, User ID: $($script:customerId)" -ForegroundColor Gray
}

# Register Merchant
$merchantEmail = "merchant$randomNum@example.com"
$registerMerchantBody = @{
    name = "Test Merchant $randomNum"
    email = $merchantEmail
    password = "Test123!@$"
    role = "MERCHANT"
} | ConvertTo-Json

$regMerchantResult = Test-API -Name "Register Merchant" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $registerMerchantBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regMerchantResult.Status -eq "PASS" -and $regMerchantResult.Response) {
    $script:merchantToken = $regMerchantResult.Response.token
    $script:merchantId = $regMerchantResult.Response.userId
    Write-Host "    Merchant Token obtained, User ID: $($script:merchantId)" -ForegroundColor Gray
}

# Register OPS
$opsEmail = "ops$randomNum@example.com"
$registerOpsBody = @{
    name = "Test OPS $randomNum"
    email = $opsEmail
    password = "Test123!@$"
    role = "OPS"
} | ConvertTo-Json

$regOpsResult = Test-API -Name "Register OPS" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $registerOpsBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regOpsResult.Status -eq "PASS" -and $regOpsResult.Response) {
    $script:opsToken = $regOpsResult.Response.token
    $script:opsId = $regOpsResult.Response.userId
    Write-Host "    OPS Token obtained, User ID: $($script:opsId)" -ForegroundColor Gray
}

# Register Admin
$adminEmail = "admin$randomNum@example.com"
$registerAdminBody = @{
    name = "Test Admin $randomNum"
    email = $adminEmail
    password = "Test123!@$"
    role = "ADMIN"
} | ConvertTo-Json

$regAdminResult = Test-API -Name "Register Admin" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $registerAdminBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regAdminResult.Status -eq "PASS" -and $regAdminResult.Response) {
    $script:adminToken = $regAdminResult.Response.token
    $script:adminId = $regAdminResult.Response.userId
    Write-Host "    Admin Token obtained, User ID: $($script:adminId)" -ForegroundColor Gray
}

# Login all users
Write-Host "`n2.1 LOGIN (PUBLIC)" -ForegroundColor Cyan
$loginCustomerBody = @{ email = $customerEmail; password = "Test123!@#" } | ConvertTo-Json
$loginCustomerResult = Test-API -Name "Login Customer" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body $loginCustomerBody -Role "PUBLIC"
if ($loginCustomerResult.Status -eq "PASS" -and $loginCustomerResult.Response) {
    $script:customerToken = $loginCustomerResult.Response.token
    $script:customerId = $loginCustomerResult.Response.userId
}

$loginMerchantBody = @{ email = $merchantEmail; password = "Test123!@#" } | ConvertTo-Json
$loginMerchantResult = Test-API -Name "Login Merchant" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body $loginMerchantBody -Role "PUBLIC"
if ($loginMerchantResult.Status -eq "PASS" -and $loginMerchantResult.Response) {
    $script:merchantToken = $loginMerchantResult.Response.token
    $script:merchantId = $loginMerchantResult.Response.userId
}

$loginOpsBody = @{ email = $opsEmail; password = "Test123!@#" } | ConvertTo-Json
$loginOpsResult = Test-API -Name "Login OPS" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body $loginOpsBody -Role "PUBLIC"
if ($loginOpsResult.Status -eq "PASS" -and $loginOpsResult.Response) {
    $script:opsToken = $loginOpsResult.Response.token
    $script:opsId = $loginOpsResult.Response.userId
}

$loginAdminBody = @{ email = $adminEmail; password = "Test123!@#" } | ConvertTo-Json
$loginAdminResult = Test-API -Name "Login Admin" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body $loginAdminBody -Role "PUBLIC"
if ($loginAdminResult.Status -eq "PASS" -and $loginAdminResult.Response) {
    $script:adminToken = $loginAdminResult.Response.token
    $script:adminId = $loginAdminResult.Response.userId
}

# 3. Product Service APIs - Public Read Access
Write-Host "`n3. PRODUCT SERVICE APIs - PUBLIC READ ACCESS" -ForegroundColor Cyan

# List Products (Public)
Test-API -Name "List Products (Paginated)" -Method "GET" -Url "http://localhost:8080/api/products?page=0&size=20" -Role "PUBLIC"
Test-API -Name "List Products (Filtered)" -Method "GET" -Url "http://localhost:8080/api/products?status=ACTIVE&page=0&size=10" -Role "PUBLIC"
Test-API -Name "List Products (Price Range)" -Method "GET" -Url "http://localhost:8080/api/products?minPrice=10&maxPrice=1000&page=0&size=10" -Role "PUBLIC"

# Get Product by ID (Public)
$getProductResult = Test-API -Name "Get Product by ID" -Method "GET" -Url "http://localhost:8080/api/products/1" -Role "PUBLIC" -SkipOnFail $true
if ($getProductResult.Status -eq "PASS" -and $getProductResult.Response) {
    $script:productId = $getProductResult.Response.id
}

# Get Product by SKU (Public)
Test-API -Name "Get Product by SKU" -Method "GET" -Url "http://localhost:8080/api/products/sku/TEST-SKU-001" -Role "PUBLIC" -SkipOnFail $true

# Search Products (Public)
Test-API -Name "Search Products (Query)" -Method "GET" -Url "http://localhost:8080/api/products?search=laptop&page=0&size=10" -Role "PUBLIC"
Test-API -Name "Regex Search Products" -Method "GET" -Url "http://localhost:8080/api/products/search/regex?pattern=/electronics/.*" -Role "PUBLIC" -SkipOnFail $true

# Get Products by Merchant (Public)
if ($script:merchantId) {
    Test-API -Name "Get Products by Merchant" -Method "GET" -Url "http://localhost:8080/api/products/merchant/$($script:merchantId)?page=0&size=10" -Role "PUBLIC"
}

# 4. Product Service APIs - MERCHANT/ADMIN Write Access
Write-Host "`n4. PRODUCT SERVICE APIs - MERCHANT/ADMIN ACCESS" -ForegroundColor Cyan

# Test MERCHANT can create product
if ($script:merchantToken) {
    $createProductBody = @{
        sku = "TEST-PROD-$randomNum"
        name = "Test Product $randomNum"
        description = "Test Description"
        basePrice = 99.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    $createProductResult = Test-API -Name "Create Product (MERCHANT)" -Method "POST" -Url "http://localhost:8080/api/products" -Headers $headers -Body $createProductBody -ExpectedStatus 201 -Role "MERCHANT"
    if ($createProductResult.Status -eq "PASS" -and $createProductResult.Response) {
        $script:productId = $createProductResult.Response.id
        Write-Host "    Product created with ID: $($script:productId)" -ForegroundColor Gray
    }
}

# Test CUSTOMER cannot create product (should get 403)
if ($script:customerToken -and $script:productId) {
    $createProductBody = @{
        sku = "TEST-PROD-CUSTOMER-$randomNum"
        name = "Test Product Customer"
        description = "This should fail"
        basePrice = 99.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Create Product (CUSTOMER - should fail)" -Method "POST" -Url "http://localhost:8080/api/products" -Headers $headers -Body $createProductBody -ExpectedStatus 403 -Role "CUSTOMER"
}

# Test MERCHANT can update product
if ($script:merchantToken -and $script:productId) {
    $updateProductBody = @{
        sku = "TEST-PROD-UPDATED-$randomNum"
        name = "Updated Test Product"
        description = "Updated Description"
        basePrice = 129.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Update Product (MERCHANT)" -Method "PUT" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -Body $updateProductBody -Role "MERCHANT"
}

# Test CUSTOMER cannot update product
if ($script:customerToken -and $script:productId) {
    $updateProductBody = @{
        sku = "TEST-PROD-CUSTOMER-UPDATE"
        name = "Customer Update Attempt"
        description = "This should fail"
        basePrice = 99.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Update Product (CUSTOMER - should fail)" -Method "PUT" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -Body $updateProductBody -ExpectedStatus 403 -Role "CUSTOMER"
}

# 5. Review Service APIs
Write-Host "`n5. REVIEW SERVICE APIs" -ForegroundColor Cyan

# Get Reviews by Product (Public)
Test-API -Name "Get Reviews by Product (PUBLIC)" -Method "GET" -Url "http://localhost:8080/api/reviews/products/1?page=0&size=10" -Role "PUBLIC"
Test-API -Name "Get Reviews by Product (Filtered)" -Method "GET" -Url "http://localhost:8080/api/reviews/products/1?status=APPROVED&page=0&size=10" -Role "PUBLIC"

# Create Review (CUSTOMER/ADMIN)
if ($script:customerToken -and $script:productId) {
    $createReviewBody = @{
        rating = 5
        title = "Great Product!"
        comment = "This product is excellent."
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    # Note: Requires orderItemId - skipping if order doesn't exist
    $createReviewResult = Test-API -Name "Create Review (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/reviews/products/$($script:productId)?orderItemId=1" -Headers $headers -Body $createReviewBody -Role "CUSTOMER" -SkipOnFail $true
    if ($createReviewResult.Status -eq "PASS" -and $createReviewResult.Response) {
        $script:reviewId = $createReviewResult.Response.id
    }
}

# Get Pending Reviews (ADMIN/OPS)
if ($script:opsToken) {
    $headers = @{ "Authorization" = "Bearer $script:opsToken" }
    Test-API -Name "Get Pending Reviews (OPS)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -Role "OPS" -SkipOnFail $true
}

if ($script:adminToken) {
    $headers = @{ "Authorization" = "Bearer $script:adminToken" }
    Test-API -Name "Get Pending Reviews (ADMIN)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -Role "ADMIN" -SkipOnFail $true
}

# Test CUSTOMER cannot get pending reviews
if ($script:customerToken) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    Test-API -Name "Get Pending Reviews (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Moderate Review (ADMIN/OPS)
if ($script:opsToken -and $script:reviewId) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
    }
    Test-API -Name "Moderate Review (OPS)" -Method "PUT" -Url "http://localhost:8080/api/reviews/$($script:reviewId)/moderate?action=approve" -Headers $headers -Role "OPS" -SkipOnFail $true
}

# 6. Cart Service APIs - CUSTOMER/ADMIN Only
Write-Host "`n6. CART SERVICE APIs - CUSTOMER/ADMIN ACCESS" -ForegroundColor Cyan

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    
    # Get Cart (CUSTOMER)
    $getCartResult = Test-API -Name "Get Cart (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/carts" -Headers $headers -Role "CUSTOMER"
    if ($getCartResult.Status -eq "PASS" -and $getCartResult.Response -and $getCartResult.Response.items.Count -gt 0) {
        $script:cartItemId = $getCartResult.Response.items[0].id
    }
    
    # Add to Cart (CUSTOMER)
    $addToCartBody = @{
        sku = if ($script:productId) { "TEST-PROD-$randomNum" } else { "TEST-SKU-001" }
        quantity = 2
    } | ConvertTo-Json
    $addToCartResult = Test-API -Name "Add to Cart (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/carts/items" -Headers $headers -Body $addToCartBody -Role "CUSTOMER" -SkipOnFail $true
    if ($addToCartResult.Status -eq "PASS" -and $addToCartResult.Response -and $addToCartResult.Response.items.Count -gt 0) {
        $script:cartItemId = $addToCartResult.Response.items[0].id
    }
    
    # Update Cart Item (CUSTOMER)
    if ($script:cartItemId) {
        Test-API -Name "Update Cart Item (CUSTOMER)" -Method "PUT" -Url "http://localhost:8080/api/carts/items/$($script:cartItemId)?quantity=3" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
    }
}

# Test MERCHANT cannot access cart
if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Get Cart (MERCHANT - should fail)" -Method "GET" -Url "http://localhost:8080/api/carts" -Headers $headers -ExpectedStatus 403 -Role "MERCHANT"
}

# 7. Checkout Service APIs - CUSTOMER/ADMIN Only
Write-Host "`n7. CHECKOUT SERVICE APIs - CUSTOMER/ADMIN ACCESS" -ForegroundColor Cyan

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    
    # Ensure cart has items
    $addToCartForCheckoutBody = @{
        sku = if ($script:productId) { "TEST-PROD-$randomNum" } else { "TEST-SKU-001" }
        quantity = 1
    } | ConvertTo-Json
    Test-API -Name "Add Item for Checkout (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/carts/items" -Headers $headers -Body $addToCartForCheckoutBody -Role "CUSTOMER" -SkipOnFail $true
    
    # Checkout (CUSTOMER)
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $checkoutBody = @{
        shippingAddress = "123 Test St, City, State 12345"
        shippingMethod = "STANDARD"
        giftNote = "Test gift note"
    } | ConvertTo-Json
    $checkoutHeaders = $headers.Clone()
    $checkoutHeaders["Idempotency-Key"] = $idempotencyKey
    $checkoutResult = Test-API -Name "Checkout (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/checkout" -Headers $checkoutHeaders -Body $checkoutBody -Role "CUSTOMER" -SkipOnFail $true
    if ($checkoutResult.Status -eq "PASS" -and $checkoutResult.Response) {
        $script:orderId = $checkoutResult.Response.orderId
        $script:orderNumber = $checkoutResult.Response.orderNumber
        Write-Host "    Order created: ID=$($script:orderId), Number=$($script:orderNumber)" -ForegroundColor Gray
    }
}

# 8. Order Service APIs
Write-Host "`n8. ORDER SERVICE APIs" -ForegroundColor Cyan

# Get Order by ID (Authenticated)
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Get Order by ID (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER"
    
    # Get Order by Number
    if ($script:orderNumber) {
        Test-API -Name "Get Order by Number (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/number/$($script:orderNumber)" -Headers $headers -Role "CUSTOMER"
    }
}

# Get Customer Orders (CUSTOMER/ADMIN)
if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Get Customer Orders (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/customer?page=0&size=20" -Headers $headers -Role "CUSTOMER"
}

# Get Merchant Orders (MERCHANT/ADMIN/OPS)
if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Get Merchant Orders (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
    }
    Test-API -Name "Get Merchant Orders (OPS)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -Role "OPS"
}

# Test CUSTOMER cannot get merchant orders
if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Get Merchant Orders (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Update Order Status (Authenticated)
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Update Order Status (CUSTOMER)" -Method "PUT" -Url "http://localhost:8080/api/orders/$($script:orderId)/status?status=PROCESSING&actorId=$($script:customerId)" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
}

# 9. Shipment Service APIs
Write-Host "`n9. SHIPMENT SERVICE APIs" -ForegroundColor Cyan

# Create Shipment (OPS/ADMIN/MERCHANT)
if ($script:merchantToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    
    $shipmentBody = @{
        carrier = "UPS"
        trackingNumber = "UPS$randomNum"
        skus = @("TEST-PROD-$randomNum")
    } | ConvertTo-Json
    $createShipmentResult = Test-API -Name "Create Shipment (MERCHANT)" -Method "POST" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Body $shipmentBody -Role "MERCHANT" -SkipOnFail $true
    if ($createShipmentResult.Status -eq "PASS" -and $createShipmentResult.Response) {
        $script:shipmentId = $createShipmentResult.Response.id
    }
}

# Test CUSTOMER cannot create shipment
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    $shipmentBody = @{
        carrier = "UPS"
        trackingNumber = "UPS-INVALID"
        skus = @("TEST-SKU")
    } | ConvertTo-Json
    Test-API -Name "Create Shipment (CUSTOMER - should fail)" -Method "POST" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Body $shipmentBody -ExpectedStatus 403 -Role "CUSTOMER"
}

# Get Shipments by Order (CUSTOMER/MERCHANT/OPS/ADMIN)
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Get Shipments by Order (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER"
}

# Mark Shipment as Delivered (OPS/ADMIN)
if ($script:opsToken -and $script:shipmentId) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
    }
    Test-API -Name "Mark Shipment as Delivered (OPS)" -Method "PUT" -Url "http://localhost:8080/api/shipments/$($script:shipmentId)/delivered" -Headers $headers -Role "OPS" -SkipOnFail $true
}

# Test MERCHANT cannot mark as delivered
if ($script:merchantToken -and $script:shipmentId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Mark Shipment as Delivered (MERCHANT - should fail)" -Method "PUT" -Url "http://localhost:8080/api/shipments/$($script:shipmentId)/delivered" -Headers $headers -ExpectedStatus 403 -Role "MERCHANT"
}

# 10. Return Service APIs
Write-Host "`n10. RETURN SERVICE APIs" -ForegroundColor Cyan

# Request Return (CUSTOMER/ADMIN)
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    
    $returnBody = @{
        reason = "Defective item"
        items = @(
            @{
                sku = "TEST-PROD-$randomNum"
                quantity = 1
            }
        )
    } | ConvertTo-Json
    $requestReturnResult = Test-API -Name "Request Return (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/returns/orders/$($script:orderId)" -Headers $headers -Body $returnBody -Role "CUSTOMER" -SkipOnFail $true
    if ($requestReturnResult.Status -eq "PASS" -and $requestReturnResult.Response) {
        $script:returnId = $requestReturnResult.Response.id
    }
}

# Get Returns by Order (CUSTOMER/MERCHANT/OPS/ADMIN)
if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Get Returns by Order (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/returns/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER"
}

# Approve Return (OPS/ADMIN/MERCHANT)
if ($script:merchantToken -and $script:returnId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Approve Return (MERCHANT)" -Method "PUT" -Url "http://localhost:8080/api/returns/$($script:returnId)/approve" -Headers $headers -Role "MERCHANT" -SkipOnFail $true
}

# Test CUSTOMER cannot approve returns
if ($script:customerToken -and $script:returnId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Approve Return (CUSTOMER - should fail)" -Method "PUT" -Url "http://localhost:8080/api/returns/$($script:returnId)/approve" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# 11. Payment Service APIs
Write-Host "`n11. PAYMENT SERVICE APIs" -ForegroundColor Cyan

# Create Payment Intent (Authenticated)
if ($script:customerToken -and $script:orderId) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $createIntentHeaders = $headers.Clone()
    $createIntentHeaders["Idempotency-Key"] = $idempotencyKey
    $createIntentResult = Test-API -Name "Create Payment Intent (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/payments/intents?orderId=$($script:orderId)&amount=199.98&currency=USD" -Headers $createIntentHeaders -Role "CUSTOMER" -SkipOnFail $true
    if ($createIntentResult.Status -eq "PASS" -and $createIntentResult.Response) {
        $script:paymentIntentId = $createIntentResult.Response.id
    }
}

# Authorize Payment (Authenticated)
if ($script:customerToken -and $script:paymentIntentId) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $authHeaders = $headers.Clone()
    $authHeaders["Idempotency-Key"] = $idempotencyKey
    Test-API -Name "Authorize Payment (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/payments/$($script:paymentIntentId)/authorize" -Headers $authHeaders -Role "CUSTOMER" -SkipOnFail $true
    
    # Capture Payment
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $captureHeaders = $headers.Clone()
    $captureHeaders["Idempotency-Key"] = $idempotencyKey
    Test-API -Name "Capture Payment (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/payments/$($script:paymentIntentId)/capture" -Headers $captureHeaders -Role "CUSTOMER" -SkipOnFail $true
}

# Refund Payment (OPS/ADMIN only)
if ($script:opsToken -and $script:paymentIntentId) {
    $headers = @{ "Authorization" = "Bearer $script:opsToken" }
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $refundHeaders = $headers.Clone()
    $refundHeaders["Idempotency-Key"] = $idempotencyKey
    Test-API -Name "Refund Payment (OPS)" -Method "POST" -Url "http://localhost:8080/api/payments/$($script:paymentIntentId)/refund?amount=50.00" -Headers $refundHeaders -Role "OPS" -SkipOnFail $true
}

if ($script:adminToken -and $script:paymentIntentId) {
    $headers = @{ "Authorization" = "Bearer $script:adminToken" }
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $refundHeaders = $headers.Clone()
    $refundHeaders["Idempotency-Key"] = $idempotencyKey
    Test-API -Name "Refund Payment (ADMIN)" -Method "POST" -Url "http://localhost:8080/api/payments/$($script:paymentIntentId)/refund?amount=50.00" -Headers $refundHeaders -Role "ADMIN" -SkipOnFail $true
}

# Test CUSTOMER cannot refund
if ($script:customerToken -and $script:paymentIntentId) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $refundHeaders = $headers.Clone()
    $refundHeaders["Idempotency-Key"] = $idempotencyKey
    Test-API -Name "Refund Payment (CUSTOMER - should fail)" -Method "POST" -Url "http://localhost:8080/api/payments/$($script:paymentIntentId)/refund?amount=50.00" -Headers $refundHeaders -ExpectedStatus 403 -Role "CUSTOMER"
}

# 12. Inventory Service APIs
Write-Host "`n12. INVENTORY SERVICE APIs" -ForegroundColor Cyan

# Reserve Inventory (Authenticated)
if ($script:customerToken) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    Test-API -Name "Reserve Inventory (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/inventory/reserve?sku=TEST-SKU-001&quantity=5&warehouseId=WH-001" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
}

# Get Low Stock (MERCHANT/ADMIN/OPS)
if ($script:merchantToken) {
    $headers = @{ "Authorization" = "Bearer $script:merchantToken" }
    Test-API -Name "Get Low Stock Items (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{ "Authorization" = "Bearer $script:opsToken" }
    Test-API -Name "Get Low Stock Items (OPS)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -Role "OPS"
}

# Test CUSTOMER cannot get low stock
if ($script:customerToken) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    Test-API -Name "Get Low Stock Items (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Adjust Inventory (OPS/ADMIN only)
if ($script:opsToken) {
    $headers = @{ "Authorization" = "Bearer $script:opsToken" }
    Test-API -Name "Adjust Inventory (OPS)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=TEST-SKU-001&warehouseId=WH-001&quantity=10" -Headers $headers -Role "OPS" -SkipOnFail $true
}

if ($script:adminToken) {
    $headers = @{ "Authorization" = "Bearer $script:adminToken" }
    Test-API -Name "Adjust Inventory (ADMIN)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=TEST-SKU-001&warehouseId=WH-001&quantity=10" -Headers $headers -Role "ADMIN" -SkipOnFail $true
}

# Test MERCHANT cannot adjust inventory
if ($script:merchantToken) {
    $headers = @{ "Authorization" = "Bearer $script:merchantToken" }
    Test-API -Name "Adjust Inventory (MERCHANT - should fail)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=TEST-SKU-001&warehouseId=WH-001&quantity=10" -Headers $headers -ExpectedStatus 403 -Role "MERCHANT"
}

# 13. Reporting Service APIs - MERCHANT/ADMIN/OPS
Write-Host "`n13. REPORTING SERVICE APIs - MERCHANT/ADMIN/OPS ACCESS" -ForegroundColor Cyan

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    
    $startDate = (Get-Date).AddDays(-30).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -Role "MERCHANT"
    Test-API -Name "Order Status Report (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/reports/order-status" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
    }
    
    $startDate = (Get-Date).AddDays(-30).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (OPS)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -Role "OPS"
}

# Test CUSTOMER cannot access reports
if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    $startDate = (Get-Date).AddDays(-30).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# 14. Cleanup - Delete Product (MERCHANT/ADMIN)
Write-Host "`n14. CLEANUP APIs" -ForegroundColor Cyan

if ($script:merchantToken -and $script:productId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
    }
    Test-API -Name "Delete Product (MERCHANT)" -Method "DELETE" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -ExpectedStatus 204 -Role "MERCHANT" -SkipOnFail $true
}

# 15. API Documentation - Public
Write-Host "`n15. API DOCUMENTATION (PUBLIC)" -ForegroundColor Cyan
Test-API -Name "Swagger API Docs" -Method "GET" -Url "http://localhost:8080/v3/api-docs" -Role "PUBLIC" -SkipOnFail $true
Test-API -Name "Swagger UI" -Method "GET" -Url "http://localhost:8080/swagger-ui.html" -Role "PUBLIC" -SkipOnFail $true

# Summary
Write-Host "`n=== TEST SUMMARY ===" -ForegroundColor Magenta
$passed = ($script:testResults | Where-Object { $_.Status -eq "PASS" }).Count
$failed = ($script:testResults | Where-Object { $_.Status -eq "FAIL" }).Count
$total = $script:testResults.Count

Write-Host "Total Tests: $total" -ForegroundColor Cyan
Write-Host "Passed: $passed" -ForegroundColor Green
Write-Host "Failed: $failed" -ForegroundColor Red
Write-Host "Success Rate: $([Math]::Round(($passed / $total) * 100, 2))%" -ForegroundColor $(if ($passed -eq $total) { "Green" } else { "Yellow" })

# Role-based summary
Write-Host "`nRole-Based Test Summary:" -ForegroundColor Cyan
$roleGroups = $script:testResults | Group-Object -Property Role | Where-Object { $_.Name -ne "N/A" }
foreach ($roleGroup in $roleGroups) {
    $role = $roleGroup.Name
    $roleTests = $roleGroup.Group
    $rolePassed = ($roleTests | Where-Object { $_.Status -eq "PASS" }).Count
    $roleTotal = $roleTests.Count
    Write-Host "  $role : $rolePassed/$roleTotal passed" -ForegroundColor $(if ($rolePassed -eq $roleTotal) { "Green" } else { "Yellow" })
}

if ($failed -gt 0) {
    Write-Host "`nFailed Tests:" -ForegroundColor Yellow
    $script:testResults | Where-Object { $_.Status -eq "FAIL" } | ForEach-Object {
        Write-Host "  - [$($_.Role)] $($_.Name): Status $($_.StatusCode) (Expected: $($_.ExpectedStatus)) - $($_.Url)" -ForegroundColor Red
    }
}

# Export results
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$resultsFile = "api-test-results-$timestamp.json"
$script:testResults | ConvertTo-Json -Depth 5 | Out-File $resultsFile
Write-Host "`nResults exported to: $resultsFile" -ForegroundColor Gray

# Create summary report
$summaryFile = "api-test-summary-$timestamp.txt"
$summary = @"
RetailX API Test Summary - Role-Based Access Control Testing
Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

Total Tests: $total
Passed: $passed
Failed: $failed
Success Rate: $([Math]::Round(($passed / $total) * 100, 2))%

Role-Based Access Control Testing:
$(foreach ($roleGroup in ($script:testResults | Group-Object -Property Role | Where-Object { $_.Name -ne "N/A" })) {
    $role = $roleGroup.Name
    $roleTests = $roleGroup.Group
    $rolePassed = ($roleTests | Where-Object { $_.Status -eq "PASS" }).Count
    $roleTotal = $roleTests.Count
    "  $role : $rolePassed/$roleTotal passed"
})

Services Tested with Role-Based Access:
- Auth Service (PUBLIC)
- Product Service (PUBLIC read, MERCHANT/ADMIN write)
- Review Service (PUBLIC read, CUSTOMER/ADMIN create, ADMIN/OPS moderate)
- Cart Service (CUSTOMER/ADMIN only)
- Checkout Service (CUSTOMER/ADMIN only)
- Order Service (Various role-based access)
- Shipment Service (OPS/ADMIN/MERCHANT create, OPS/ADMIN deliver)
- Return Service (CUSTOMER/ADMIN request, OPS/ADMIN/MERCHANT approve)
- Payment Service (Authenticated, OPS/ADMIN refund)
- Inventory Service (Authenticated reserve, MERCHANT/ADMIN/OPS low-stock, OPS/ADMIN adjust)
- Reporting Service (MERCHANT/ADMIN/OPS only)

Access Control Tests:
- Verified that unauthorized roles get 403 Forbidden responses
- Verified that authorized roles can access their designated endpoints
- Tested role-based restrictions for all protected endpoints
"@
$summary | Out-File $summaryFile
Write-Host "Summary exported to: $summaryFile" -ForegroundColor Gray