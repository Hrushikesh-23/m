package com.retailx.gateway.filter;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * JWT Authentication filter for API Gateway.
 * Validates JWT token and extracts user info.
 */
@Slf4j
@Component
public class JwtAuthenticationFilter implements GlobalFilter, Ordered {
    
    @Value("${retailx.jwt.secret:RetailXSecretKeyForJWTTokenGeneration2024SecureAndLongEnough}")
    private String jwtSecret;
    
    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        
        String path = request.getURI().getPath();
        HttpMethod method = request.getMethod();

        // Skip auth for public endpoints (auth, swagger, actuator, public GETs)
        if (isPublic(path, method)) {
            log.debug("Public endpoint accessed: {} {}", method, path);
            return chain.filter(exchange);
        }
        
        log.debug("Protected endpoint accessed: {} {}", method, path);
        
        String authHeader = request.getHeaders().getFirst("Authorization");
        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            log.warn("Missing or invalid Authorization header for path: {}", path);
            return onError(exchange, "Missing or invalid Authorization header", HttpStatus.UNAUTHORIZED);
        }
        
        String token = authHeader.substring(7);
        
        try {
            Claims claims = validateToken(token);
            
            // Add user info to headers for downstream services
            ServerHttpRequest modifiedRequest = exchange.getRequest().mutate()
                    .header("X-User-Id", claims.getSubject())
                    .header("X-User-Email", claims.get("email", String.class))
                    .header("X-User-Role", extractRoles(claims))
                    .build();
            
            return chain.filter(exchange.mutate().request(modifiedRequest).build());
        } catch (Exception e) {
            log.error("JWT validation failed", e);
            return onError(exchange, "Invalid token", HttpStatus.UNAUTHORIZED);
        }
    }
    
    @Override
    public int getOrder() {
        return -100; // High priority, run early in the filter chain
    }
    
    private Claims validateToken(String token) {
        SecretKey key = Keys.hmacShaKeyFor(jwtSecret.getBytes(StandardCharsets.UTF_8));
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
    
    @SuppressWarnings("unchecked")
    private String extractRoles(Claims claims) {
        Object rolesObj = claims.get("roles");
        if (rolesObj instanceof List) {
            List<String> roles = (List<String>) rolesObj;
            return String.join(",", roles);
        }
        return "";
    }
    
    private Mono<Void> onError(ServerWebExchange exchange, String message, HttpStatus status) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        return response.setComplete();
    }

    private boolean isPublic(String path, HttpMethod method) {
        if (path == null) {
            return false;
        }

        // Auth endpoints - all methods are public
        if (path.startsWith("/api/auth")) {
            return true;
        }

        // Actuator/health/metrics
        if (path.startsWith("/actuator")) {
            return true;
        }

        // Swagger & OpenAPI resources
        if (path.startsWith("/swagger-ui") || path.equals("/swagger-ui.html")
                || path.startsWith("/v3/api-docs") || path.startsWith("/webjars/")) {
            return true;
        }

        // Public GET endpoints (catalog/reviews/products)
        if (HttpMethod.GET.equals(method)) {
            // Products - all GET endpoints are public
            if (path.startsWith("/api/products")) {
                return true;
            }
            // Reviews - GET endpoints are public
            if (path.startsWith("/api/reviews")) {
                return true;
            }
            // Catalog - all GET endpoints are public
            if (path.startsWith("/api/catalog")) {
                return true;
            }
        }

        return false;
    }
}
