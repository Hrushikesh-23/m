# Test Data Creation Guide

This guide explains how to add test data to the RetailX application for testing purposes.

## Quick Start

### Option 1: Automated Script (Recommended)

Run the PowerShell script to automatically create all test data:

```powershell
.\add-test-data.ps1
```

This script will:
1. Register 4 users (Customer, Merchant, OPS, Admin)
2. Create 5 sample products
3. Create inventory records
4. Add items to cart

### Option 2: Manual API Calls

Follow the steps below to create test data manually.

## Step-by-Step Manual Creation

### 1. Register Users

**Endpoint:** `POST http://localhost:8080/api/auth/register`

#### Customer
```json
{
  "name": "Test Customer",
  "email": "customer@example.com",
  "password": "Test123!@$",
  "role": "CUSTOMER"
}
```

#### Merchant
```json
{
  "name": "Test Merchant",
  "email": "merchant@example.com",
  "password": "Test123!@$",
  "role": "MERCHANT"
}
```

#### OPS
```json
{
  "name": "Test OPS",
  "email": "ops@example.com",
  "password": "Test123!@$",
  "role": "OPS"
}
```

#### Admin
```json
{
  "name": "Test Admin",
  "email": "admin@example.com",
  "password": "Test123!@$",
  "role": "ADMIN"
}
```

**Response:** Save the `token` and `userId` from each registration.

### 2. Create Products (as Merchant)

**Endpoint:** `POST http://localhost:8080/api/products`

**Headers:**
```
Authorization: Bearer <merchant_token>
```

**Example Product:**
```json
{
  "sku": "PROD-001",
  "name": "Laptop Computer",
  "description": "High-performance laptop with 16GB RAM, 512GB SSD",
  "basePrice": 1299.99,
  "currency": "USD",
  "categoryPath": "/electronics/computers",
  "status": "ACTIVE",
  "media": [
    "https://example.com/laptop1.jpg",
    "https://example.com/laptop2.jpg"
  ],
  "attributes": "{\"brand\":\"TechBrand\",\"model\":\"Laptop Pro\",\"warranty\":\"2 years\"}"
}
```

**More Product Examples:**

```json
{
  "sku": "PROD-002",
  "name": "Wireless Mouse",
  "description": "Ergonomic wireless mouse",
  "basePrice": 29.99,
  "currency": "USD",
  "categoryPath": "/electronics/accessories",
  "status": "ACTIVE"
}
```

```json
{
  "sku": "PROD-003",
  "name": "Mechanical Keyboard",
  "description": "RGB mechanical keyboard",
  "basePrice": 149.99,
  "currency": "USD",
  "categoryPath": "/electronics/accessories",
  "status": "ACTIVE"
}
```

### 3. Create Inventory (as OPS or Admin)

**Endpoint:** `POST http://localhost:8080/api/inventory/adjust?sku=PROD-001&warehouseId=WH-001&quantity=50`

**Headers:**
```
Authorization: Bearer <ops_or_admin_token>
```

**Example:**
```bash
POST http://localhost:8080/api/inventory/adjust?sku=PROD-001&warehouseId=WH-001&quantity=50
POST http://localhost:8080/api/inventory/adjust?sku=PROD-002&warehouseId=WH-001&quantity=100
POST http://localhost:8080/api/inventory/adjust?sku=PROD-003&warehouseId=WH-001&quantity=30
```

### 4. Add Items to Cart (as Customer)

**Endpoint:** `POST http://localhost:8080/api/carts/items`

**Headers:**
```
Authorization: Bearer <customer_token>
```

**Request Body:**
```json
{
  "sku": "PROD-001",
  "quantity": 1
}
```

### 5. Create Orders (Optional)

After adding items to cart, you can checkout to create orders:

**Endpoint:** `POST http://localhost:8080/api/checkout`

**Headers:**
```
Authorization: Bearer <customer_token>
```

**Request Body:**
```json
{
  "shippingAddress": {
    "street": "123 Main St",
    "city": "New York",
    "state": "NY",
    "zipCode": "10001",
    "country": "USA"
  },
  "paymentMethod": {
    "type": "CREDIT_CARD",
    "cardNumber": "4111111111111111",
    "expiryMonth": 12,
    "expiryYear": 2025,
    "cvv": "123"
  }
}
```

## Using cURL

### Register User
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Merchant",
    "email": "merchant@example.com",
    "password": "Test123!@$",
    "role": "MERCHANT"
  }'
```

### Create Product
```bash
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <token>" \
  -d '{
    "sku": "PROD-001",
    "name": "Laptop Computer",
    "description": "High-performance laptop",
    "basePrice": 1299.99,
    "currency": "USD",
    "categoryPath": "/electronics/computers",
    "status": "ACTIVE"
  }'
```

### Create Inventory
```bash
curl -X POST "http://localhost:8080/api/inventory/adjust?sku=PROD-001&warehouseId=WH-001&quantity=50" \
  -H "Authorization: Bearer <token>"
```

## Using PowerShell

### Register User
```powershell
$body = @{
    name = "Test Merchant"
    email = "merchant@example.com"
    password = "Test123!@$"
    role = "MERCHANT"
} | ConvertTo-Json

$response = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/register" `
    -Method POST `
    -Body $body `
    -ContentType "application/json"

$token = $response.token
$userId = $response.userId
```

### Create Product
```powershell
$product = @{
    sku = "PROD-001"
    name = "Laptop Computer"
    description = "High-performance laptop"
    basePrice = 1299.99
    currency = "USD"
    categoryPath = "/electronics/computers"
    status = "ACTIVE"
} | ConvertTo-Json

$headers = @{
    "Authorization" = "Bearer $token"
}

$productResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/products" `
    -Method POST `
    -Headers $headers `
    -Body $product `
    -ContentType "application/json"
```

## Direct Database Insertion (Advanced)

If you prefer to insert data directly into the database:

### MySQL Connection
```sql
USE retailx_product_db;

-- Insert Product
INSERT INTO products (sku, name, description, base_price, currency, category_path, catalog_path, status, merchant_id, created_on, updated_on, deleted)
VALUES ('PROD-001', 'Laptop Computer', 'High-performance laptop', 1299.99, 'USD', '/electronics/computers', '/catalog/electronics/computers/PROD-001', 'ACTIVE', 1, NOW(), NOW(), false);

-- Insert Inventory
USE retailx_inventory_db;
INSERT INTO inventory (sku, warehouse_id, quantity, reserved_quantity, created_on, updated_on)
VALUES ('PROD-001', 'WH-001', 50, 0, NOW(), NOW());
```

## Test Data Checklist

- [ ] Register Customer user
- [ ] Register Merchant user
- [ ] Register OPS user
- [ ] Register Admin user
- [ ] Create at least 3-5 products
- [ ] Create inventory for products
- [ ] Add items to cart (optional)
- [ ] Create orders (optional)

## Common Issues

### 1. "Product already exists"
- **Solution:** Use a different SKU or delete the existing product first

### 2. "Invalid credentials"
- **Solution:** Make sure you're using the correct password format: `Test123!@$`

### 3. "Access Denied" (403)
- **Solution:** Make sure you're using the correct role's token (e.g., Merchant token for creating products)

### 4. "Product not found" (404)
- **Solution:** Create the product first, or use an existing SKU

## Sample Test Data

The `add-test-data.ps1` script creates:

- **4 Users:**
  - Customer: `testcustomer@example.com`
  - Merchant: `testmerchant@example.com`
  - OPS: `testops@example.com`
  - Admin: `testadmin@example.com`
  - All passwords: `Test123!@$`

- **5 Products:**
  - PROD-001: Laptop Computer ($1299.99)
  - PROD-002: Wireless Mouse ($29.99)
  - PROD-003: Mechanical Keyboard ($149.99)
  - PROD-004: USB-C Cable ($19.99)
  - PROD-005: Monitor Stand ($79.99)

- **Inventory:**
  - All products have inventory in warehouse WH-001

## Next Steps

After creating test data:
1. Test product listing: `GET http://localhost:8080/api/products`
2. Test product by SKU: `GET http://localhost:8080/api/products/sku/PROD-001`
3. Test cart operations with customer token
4. Test inventory operations with OPS/Admin token



