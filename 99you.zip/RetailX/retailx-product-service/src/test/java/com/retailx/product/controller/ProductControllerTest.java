package com.retailx.product.controller;

import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.dto.response.ProductResponse;
import com.retailx.product.service.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ProductController.
 */
@ExtendWith(MockitoExtension.class)
class ProductControllerTest {
    
    @Mock
    private ProductService productService;
    
    @InjectMocks
    private ProductController productController;
    
    private ProductRequest productRequest;
    private ProductResponse productResponse;
    
    @BeforeEach
    void setUp() {
        productRequest = new ProductRequest();
        productRequest.setSku("PROD-001");
        productRequest.setName("Test Product");
        productRequest.setDescription("Test Description");
        productRequest.setBasePrice(new BigDecimal("99.99"));
        productRequest.setCurrency("USD");
        productRequest.setCategoryPath("/electronics");
        productRequest.setStatus(ProductStatus.ACTIVE);
        
        productResponse = ProductResponse.builder()
                .id(1L)
                .sku("PROD-001")
                .name("Test Product")
                .basePrice(new BigDecimal("99.99"))
                .status(ProductStatus.ACTIVE)
                .build();
    }
    
    @Test
    void testCreateProduct_Success() {
        when(productService.createProduct(any(ProductRequest.class))).thenReturn(productResponse);
        
        ResponseEntity<ProductResponse> response = productController.createProduct(productRequest, 1L);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("PROD-001", response.getBody().getSku());
        verify(productService, times(1)).createProduct(any(ProductRequest.class));
    }
    
    @Test
    void testCreateProduct_WithNullMerchantId() {
        productRequest.setMerchantId(null);
        when(productService.createProduct(any(ProductRequest.class))).thenReturn(productResponse);
        
        ResponseEntity<ProductResponse> response = productController.createProduct(productRequest, 1L);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        verify(productService, times(1)).createProduct(any(ProductRequest.class));
    }
    
    @Test
    void testGetProductById_Success() {
        when(productService.getProductById(1L)).thenReturn(productResponse);
        
        ResponseEntity<ProductResponse> response = productController.getProductById(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        verify(productService, times(1)).getProductById(1L);
    }
    
    @Test
    void testGetProductBySku_Success() {
        when(productService.getProductBySku("PROD-001")).thenReturn(productResponse);
        
        ResponseEntity<ProductResponse> response = productController.getProductBySku("PROD-001");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("PROD-001", response.getBody().getSku());
        verify(productService, times(1)).getProductBySku("PROD-001");
    }
    
    @Test
    void testSearchProducts_Success() {
        Page<ProductResponse> page = new PageImpl<>(Arrays.asList(productResponse));
        when(productService.searchProducts(any(), any(), any(), any(), any(), any()))
                .thenReturn(page);
        
        ResponseEntity<Page<ProductResponse>> response = productController.searchProducts(
                ProductStatus.ACTIVE, new BigDecimal("10"), new BigDecimal("100"), 
                "/electronics", "test", 0, 20, "createdOn", "DESC");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getTotalElements());
        verify(productService, times(1)).searchProducts(any(), any(), any(), any(), any(), any());
    }
    
    @Test
    void testSearchByRegex_Success() {
        List<ProductResponse> products = Arrays.asList(productResponse);
        when(productService.searchByRegex(anyString())).thenReturn(products);
        
        ResponseEntity<List<ProductResponse>> response = 
                productController.searchByRegex(".*electronics.*");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(productService, times(1)).searchByRegex(anyString());
    }
    
    @Test
    void testGetProductsByMerchant_Success() {
        Page<ProductResponse> page = new PageImpl<>(Arrays.asList(productResponse));
        when(productService.getProductsByMerchant(anyLong(), any())).thenReturn(page);
        
        ResponseEntity<Page<ProductResponse>> response = 
                productController.getProductsByMerchant(1L, 0, 20);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(productService, times(1)).getProductsByMerchant(anyLong(), any());
    }
    
    @Test
    void testUpdateProduct_Success() {
        when(productService.updateProduct(anyLong(), any(ProductRequest.class)))
                .thenReturn(productResponse);
        
        ResponseEntity<ProductResponse> response = 
                productController.updateProduct(1L, productRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(productService, times(1)).updateProduct(1L, productRequest);
    }
    
    @Test
    void testDeleteProduct_Success() {
        doNothing().when(productService).deleteProduct(anyLong());
        
        ResponseEntity<Void> response = productController.deleteProduct(1L);
        
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNull(response.getBody());
        verify(productService, times(1)).deleteProduct(1L);
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = productController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Product Service is running", response.getBody());
    }
}

