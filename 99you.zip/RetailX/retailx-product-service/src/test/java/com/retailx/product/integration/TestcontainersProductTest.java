package com.retailx.product.integration;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration test using Testcontainers with real MySQL.
 * Note: This test may fail if Docker is not available or configured properly.
 */
@DataJpaTest
@Testcontainers
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@org.junit.jupiter.api.Disabled("Requires Docker to be running")
class TestcontainersProductTest {
    
    @Container
    static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0")
            .withDatabaseName("test_retailx_product")
            .withUsername("test")
            .withPassword("test");
    
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", mysql::getJdbcUrl);
        registry.add("spring.datasource.username", mysql::getUsername);
        registry.add("spring.datasource.password", mysql::getPassword);
    }
    
    @Autowired
    private ProductRepository productRepository;
    
    @Test
    void testCreateProductWithTestcontainers() {
        Product product = Product.builder()
                .sku("TESTCONTAINER-001")
                .name("Test Product")
                .description("Test Description")
                .basePrice(new BigDecimal("99.99"))
                .currency("USD")
                .categoryPath("/electronics")
                .catalogPath("/catalog/electronics/TESTCONTAINER-001")
                .status(ProductStatus.ACTIVE)
                .merchantId(1L)
                .build();
        
        Product saved = productRepository.save(product);
        
        assertNotNull(saved.getId());
        assertEquals("TESTCONTAINER-001", saved.getSku());
    }
    
    @Test
    void testSearchProductsWithTestcontainers() {
        Product product = Product.builder()
                .sku("SEARCH-001")
                .name("Searchable Product")
                .description("This is searchable")
                .basePrice(new BigDecimal("50"))
                .currency("USD")
                .categoryPath("/electronics")
                .catalogPath("/catalog/electronics/SEARCH-001")
                .status(ProductStatus.ACTIVE)
                .merchantId(1L)
                .build();
        productRepository.save(product);
        
        Page<Product> results = productRepository.searchProducts(
                ProductStatus.ACTIVE,
                BigDecimal.ZERO,
                new BigDecimal("100"),
                null,
                "Searchable",
                PageRequest.of(0, 10)
        );
        
        assertTrue(results.getTotalElements() > 0);
    }
}

