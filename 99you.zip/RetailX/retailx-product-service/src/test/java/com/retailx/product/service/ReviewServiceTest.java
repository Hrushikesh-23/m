package com.retailx.product.service;

import com.retailx.product.domain.Review;
import com.retailx.product.dto.request.ReviewRequest;
import com.retailx.product.dto.response.ReviewResponse;
import com.retailx.product.repository.ReviewRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ReviewService.
 */
@ExtendWith(MockitoExtension.class)
class ReviewServiceTest {
    
    @Mock
    private ReviewRepository reviewRepository;
    
    @Mock
    private OrderServiceClient orderServiceClient;
    
    @InjectMocks
    private ReviewService reviewService;
    
    private Review review;
    private ReviewRequest reviewRequest;
    
    @BeforeEach
    void setUp() {
        reviewRequest = new ReviewRequest();
        reviewRequest.setRating(5);
        reviewRequest.setText("Great product!");
        
        review = Review.builder()
                .productId(1L)
                .customerId(1L)
                .orderItemId(1L)
                .rating(5)
                .text("Great product!")
                .status("PENDING")
                .moderated(false)
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.product.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(review, 1L);
        } catch (Exception e) {
            // Ignore
        }
    }
    
    @Test
    void testCreateReview_Success() {
        when(reviewRepository.findByProductIdAndCustomerIdAndOrderItemId(anyLong(), anyLong(), anyLong()))
                .thenReturn(Optional.empty());
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        
        ReviewResponse response = reviewService.createReview(1L, 1L, 1L, reviewRequest);
        
        assertNotNull(response);
        assertEquals(5, response.getRating());
        verify(reviewRepository, times(1)).save(any(Review.class));
    }
    
    @Test
    void testCreateReview_DuplicateReview() {
        when(reviewRepository.findByProductIdAndCustomerIdAndOrderItemId(anyLong(), anyLong(), anyLong()))
                .thenReturn(Optional.of(review));
        
        assertThrows(RuntimeException.class, () -> 
                reviewService.createReview(1L, 1L, 1L, reviewRequest));
        verify(reviewRepository, never()).save(any(Review.class));
    }
    
    @Test
    void testCreateReview_InvalidRating() {
        reviewRequest.setRating(6);
        when(reviewRepository.findByProductIdAndCustomerIdAndOrderItemId(anyLong(), anyLong(), anyLong()))
                .thenReturn(Optional.empty());
        
        assertThrows(RuntimeException.class, () -> 
                reviewService.createReview(1L, 1L, 1L, reviewRequest));
        verify(reviewRepository, never()).save(any(Review.class));
    }
    
    @Test
    void testGetReviewsByProduct_Success() {
        Page<Review> page = new PageImpl<>(Arrays.asList(review));
        when(reviewRepository.findByProductIdAndStatusAndDeletedFalse(anyLong(), anyString(), any()))
                .thenReturn(page);
        
        Page<ReviewResponse> response = reviewService.getReviewsByProduct(1L, "APPROVED", 
                PageRequest.of(0, 20));
        
        assertNotNull(response);
        assertEquals(1, response.getTotalElements());
        verify(reviewRepository, times(1)).findByProductIdAndStatusAndDeletedFalse(eq(1L), eq("APPROVED"), any());
    }
    
    @Test
    void testModerateReview_Approve() {
        review.setStatus("APPROVED");
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        
        ReviewResponse response = reviewService.moderateReview(1L, "approve", "1");
        
        assertNotNull(response);
        assertEquals("APPROVED", response.getStatus());
        verify(reviewRepository, times(1)).save(any(Review.class));
    }
    
    @Test
    void testModerateReview_Hide() {
        review.setStatus("HIDDEN");
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        
        ReviewResponse response = reviewService.moderateReview(1L, "hide", "1");
        
        assertNotNull(response);
        assertEquals("HIDDEN", response.getStatus());
        verify(reviewRepository, times(1)).save(any(Review.class));
    }
    
    @Test
    void testModerateReview_InvalidAction() {
        when(reviewRepository.findById(1L)).thenReturn(Optional.of(review));
        
        assertThrows(RuntimeException.class, () -> 
                reviewService.moderateReview(1L, "invalid", "1"));
        verify(reviewRepository, never()).save(any(Review.class));
    }
    
    @Test
    void testGetPendingReviews_Success() {
        List<Review> reviews = Arrays.asList(review);
        when(reviewRepository.findByStatusAndDeletedFalse("PENDING")).thenReturn(reviews);
        
        List<ReviewResponse> response = reviewService.getPendingReviews();
        
        assertNotNull(response);
        assertEquals(1, response.size());
        verify(reviewRepository, times(1)).findByStatusAndDeletedFalse("PENDING");
    }
}

