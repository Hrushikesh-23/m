package com.retailx.product.service;

import com.retailx.product.domain.Review;
import com.retailx.product.dto.request.ReviewRequest;
import com.retailx.product.dto.response.ReviewResponse;
import com.retailx.product.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for review management.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReviewService {
    
    private final ReviewRepository reviewRepository;
    private final OrderServiceClient orderServiceClient;
    
    @Transactional
    public ReviewResponse createReview(Long productId, Long customerId, Long orderItemId, ReviewRequest request) {
        log.info("Creating review: productId={}, customerId={}, orderItemId={}", productId, customerId, orderItemId);
        
        // Check if review already exists for this order item
        if (reviewRepository.findByProductIdAndCustomerIdAndOrderItemId(productId, customerId, orderItemId).isPresent()) {
            throw new RuntimeException("Review already exists for this order item");
        }
        
        // Validate rating
        if (request.getRating() < 1 || request.getRating() > 5) {
            throw new RuntimeException("Rating must be between 1 and 5");
        }
        
        // Validate order is delivered before allowing review
        try {
            // Get order item details to find order ID
            // Note: This requires OrderServiceClient to get order by orderItemId
            // For now, we'll validate through order status if orderId is available
            // This is a simplified validation - in production, you'd fetch order by orderItemId
            log.info("Validating order status for review: orderItemId={}", orderItemId);
            // TODO: Add order validation when OrderService provides orderItem lookup endpoint
        } catch (Exception e) {
            log.warn("Could not validate order status for review: {}", e.getMessage());
            // Continue - order validation is best effort
        }
        
        Review review = Review.builder()
                .productId(productId)
                .customerId(customerId)
                .orderItemId(orderItemId)
                .rating(request.getRating())
                .text(request.getText())
                .status("PENDING")
                .moderated(false)
                .build();
        
        review = reviewRepository.save(review);
        return mapToResponse(review);
    }
    
    public Page<ReviewResponse> getReviewsByProduct(Long productId, String status, Pageable pageable) {
        String reviewStatus = status != null ? status : "APPROVED";
        Page<Review> reviews = reviewRepository.findByProductIdAndStatusAndDeletedFalse(productId, reviewStatus, pageable);
        return reviews.map(this::mapToResponse);
    }
    
    @Transactional
    public ReviewResponse moderateReview(Long reviewId, String action, String actorId) {
        Review review = reviewRepository.findById(reviewId)
                .orElseThrow(() -> new RuntimeException("Review not found"));
        
        if ("approve".equalsIgnoreCase(action)) {
            review.setStatus("APPROVED");
        } else if ("hide".equalsIgnoreCase(action)) {
            review.setStatus("HIDDEN");
        } else {
            throw new RuntimeException("Invalid moderation action");
        }
        
        review.setModerated(true);
        review = reviewRepository.save(review);
        
        log.info("Review moderated: reviewId={}, action={}, actor={}", reviewId, action, actorId);
        
        return mapToResponse(review);
    }
    
    public List<ReviewResponse> getPendingReviews() {
        List<Review> reviews = reviewRepository.findByStatusAndDeletedFalse("PENDING");
        return reviews.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }
    
    private ReviewResponse mapToResponse(Review review) {
        return ReviewResponse.builder()
                .id(review.getId())
                .productId(review.getProductId())
                .customerId(review.getCustomerId())
                .orderItemId(review.getOrderItemId())
                .rating(review.getRating())
                .text(review.getText())
                .status(review.getStatus())
                .moderated(review.getModerated())
                .createdOn(review.getCreatedOn())
                .build();
    }
}

