package com.retailx.product.domain;

import com.retailx.product.domain.enums.ProductStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Product entity with variants and catalog path.
 */
@Entity
@Table(name = "products", indexes = {
    @Index(name = "idx_product_sku", columnList = "sku", unique = true),
    @Index(name = "idx_product_category", columnList = "categoryPath"),
    @Index(name = "idx_product_status", columnList = "status"),
    @Index(name = "idx_product_merchant", columnList = "merchantId")
    // Note: catalogPath index removed due to MySQL key length limit (3072 bytes)
    // catalogPath is VARCHAR(1000) which can exceed limit with UTF8MB4 encoding
    // Regex searches on catalogPath don't benefit from indexes anyway
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Product extends BaseEntity {
    
    @Column(nullable = false, unique = true, length = 100)
    private String sku;
    
    @Column(nullable = false, length = 255)
    private String name;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal basePrice;
    
    @Column(nullable = false, length = 3)
    @Builder.Default
    private String currency = "USD";
    
    @Column(nullable = false, length = 500)
    private String categoryPath; // Normalized: lowercase, slash-separated
    
    @Column(nullable = false, length = 1000)
    private String catalogPath; // /catalog/categoryPath/sku for regex search
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private ProductStatus status = ProductStatus.DRAFT;
    
    @ElementCollection
    @CollectionTable(name = "product_media", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "url")
    @Builder.Default
    private List<String> media = new ArrayList<>();
    
    @Column(columnDefinition = "JSON")
    private String attributes; // JSON string for flexible attributes
    
    @Column(nullable = false)
    private Long merchantId; // Reference to merchant in auth service
    
    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Variant> variants = new ArrayList<>();
}

