package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Promotion/coupon entity.
 */
@Entity
@Table(name = "promotions", indexes = {
    @Index(name = "idx_promotion_code", columnList = "code", unique = true),
    @Index(name = "idx_promotion_validity", columnList = "validFrom,validTo")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Promotion extends BaseEntity {
    
    @Column(nullable = false, unique = true, length = 50)
    private String code;
    
    @Column(nullable = false, length = 255)
    private String name;
    
    @Column(columnDefinition = "TEXT")
    private String description;
    
    @Column(nullable = false, length = 20)
    private String type; // PERCENTAGE, FLAT
    
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal value;
    
    @Column(nullable = false)
    private LocalDateTime validFrom;
    
    @Column(nullable = false)
    private LocalDateTime validTo;
    
    @Column
    @Builder.Default
    private Boolean stackable = false; // Can be combined with other promotions
    
    @Column
    private Integer maxUses;
    
    @Column
    private Integer usedCount = 0;
    
    @Column
    @Builder.Default
    private Boolean active = true;
}

