package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Shipment entity for order fulfillment.
 */
@Entity
@Table(name = "shipments", indexes = {
    @Index(name = "idx_shipment_order", columnList = "order_id"),
    @Index(name = "idx_shipment_tracking", columnList = "trackingNumber")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Shipment extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
    
    @Column(nullable = false, length = 100)
    private String shipmentNumber; // e.g., SHP-2024-001234
    
    @Column(nullable = false, length = 100)
    private String carrier; // UPS, FedEx, etc.
    
    @Column(nullable = false, length = 100)
    private String trackingNumber;
    
    @Column
    private LocalDateTime shippedAt;
    
    @Column
    private LocalDateTime deliveredAt;
    
    @OneToMany(mappedBy = "shipment", cascade = CascadeType.ALL)
    @Builder.Default
    private List<ShipmentItem> items = new ArrayList<>();
}

