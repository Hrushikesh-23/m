package com.retailx.repository;

import com.retailx.domain.PaymentIntent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Repository for PaymentIntent entity.
 */
@Repository
public interface PaymentIntentRepository extends JpaRepository<PaymentIntent, Long> {
    
    Optional<PaymentIntent> findByOrderId(Long orderId);
    
    Optional<PaymentIntent> findByCorrelationId(String correlationId);
}

