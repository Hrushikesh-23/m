package com.retailx.notification.controller;

import com.retailx.notification.dto.request.SendNotificationRequest;
import com.retailx.notification.dto.response.NotificationResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * REST controller for notification endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/notifications")
@Tag(name = "Notification Service", description = "API for sending notifications")
public class NotificationController {
    
    private final JavaMailSender mailSender;
    
    @Value("${spring.mail.username:noreply@retailx.com}")
    private String fromEmail;
    
    @Value("${retailx.mail.enabled:false}")
    private boolean emailEnabled;
    
    public NotificationController(@org.springframework.beans.factory.annotation.Autowired(required = false) JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }
    
    /**
     * Send a custom notification email.
     */
    @PostMapping("/send")
    @Operation(summary = "Send notification", description = "Send a custom notification email to a recipient")
    public ResponseEntity<NotificationResponse> sendNotification(
            @Valid @RequestBody SendNotificationRequest request) {
        
        log.info("Received notification request: recipient={}, subject={}", 
                request.getRecipientEmail(), request.getSubject());
        
        // If email is not enabled or mailSender is not configured, return success with QUEUED status
        if (!emailEnabled || mailSender == null) {
            log.info("Email not configured, notification queued for: {}", request.getRecipientEmail());
            NotificationResponse response = NotificationResponse.builder()
                    .recipientEmail(request.getRecipientEmail())
                    .subject(request.getSubject())
                    .message(request.getMessage())
                    .status("QUEUED")
                    .sentAt(LocalDateTime.now())
                    .build();
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        }
        
        try {
            // Send email
            SimpleMailMessage emailMessage = new SimpleMailMessage();
            emailMessage.setTo(request.getRecipientEmail());
            emailMessage.setSubject(request.getSubject());
            emailMessage.setText(request.getMessage());
            emailMessage.setFrom(fromEmail);
            
            mailSender.send(emailMessage);
            
            NotificationResponse response = NotificationResponse.builder()
                    .recipientEmail(request.getRecipientEmail())
                    .subject(request.getSubject())
                    .message(request.getMessage())
                    .status("SENT")
                    .sentAt(LocalDateTime.now())
                    .build();
            
            log.info("Notification sent successfully to: {}", request.getRecipientEmail());
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
            
        } catch (Exception e) {
            log.error("Failed to send notification to: {}", request.getRecipientEmail(), e);
            
            NotificationResponse response = NotificationResponse.builder()
                    .recipientEmail(request.getRecipientEmail())
                    .subject(request.getSubject())
                    .message(request.getMessage())
                    .status("FAILED")
                    .errorMessage(e.getMessage())
                    .build();
            
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
    
    /**
     * Health check endpoint for notifications.
     */
    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Check if the notification service is healthy")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Notification Service is running");
    }
    
    /**
     * Get service information.
     */
    @GetMapping("/info")
    @Operation(summary = "Service info", description = "Get information about the notification service")
    public ResponseEntity<ServiceInfo> getServiceInfo() {
        ServiceInfo info = new ServiceInfo(
                "RetailX Notification Service",
                "1.0.0",
                "Handles event-driven notifications via Kafka",
                LocalDateTime.now()
        );
        return ResponseEntity.ok(info);
    }
    
    /**
     * Simple service info DTO.
     */
    private record ServiceInfo(
            String name,
            String version,
            String description,
            LocalDateTime timestamp
    ) {}
}

