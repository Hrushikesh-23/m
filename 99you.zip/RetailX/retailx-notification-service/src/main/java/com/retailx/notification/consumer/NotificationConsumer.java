package com.retailx.notification.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.retailx.notification.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Kafka consumer for handling events and sending notifications.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class NotificationConsumer {
    
    private final NotificationService notificationService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Consume order.created events.
     */
    @KafkaListener(topics = "order.created", groupId = "notification-group")
    public void handleOrderCreated(String message) {
        log.info("Received order.created event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long orderId = json.get("orderId").asLong();
            String orderNumber = json.get("orderNumber").asText();
            Long customerId = json.get("customerId").asLong();
            
            notificationService.sendOrderConfirmation(orderId, orderNumber, customerId);
        } catch (Exception e) {
            log.error("Error processing order.created event: {}", message, e);
        }
    }
    
    /**
     * Consume payment.captured events.
     */
    @KafkaListener(topics = "payment.captured", groupId = "notification-group")
    public void handlePaymentCaptured(String message) {
        log.info("Received payment.captured event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long paymentIntentId = json.get("paymentIntentId").asLong();
            Long orderId = json.get("orderId").asLong();
            String amount = json.get("amount").asText();
            String currency = json.get("currency").asText();
            
            notificationService.sendPaymentConfirmation(paymentIntentId, orderId, amount, currency);
        } catch (Exception e) {
            log.error("Error processing payment.captured event: {}", message, e);
        }
    }
    
    /**
     * Consume payment.failed events.
     */
    @KafkaListener(topics = "payment.failed", groupId = "notification-group")
    public void handlePaymentFailed(String message) {
        log.info("Received payment.failed event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long paymentIntentId = json.get("paymentIntentId").asLong();
            Long orderId = json.get("orderId").asLong();
            String errorCode = json.has("errorCode") ? json.get("errorCode").asText() : "UNKNOWN";
            String errorMessage = json.has("errorMessage") ? json.get("errorMessage").asText() : "Payment failed";
            
            notificationService.sendPaymentFailure(paymentIntentId, orderId, errorCode, errorMessage);
        } catch (Exception e) {
            log.error("Error processing payment.failed event: {}", message, e);
        }
    }
    
    /**
     * Consume payment.refunded events.
     */
    @KafkaListener(topics = "payment.refunded", groupId = "notification-group")
    public void handlePaymentRefunded(String message) {
        log.info("Received payment.refunded event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long paymentIntentId = json.get("paymentIntentId").asLong();
            Long orderId = json.get("orderId").asLong();
            String refundAmount = json.get("refundAmount").asText();
            String currency = json.get("currency").asText();
            
            notificationService.sendRefundConfirmation(paymentIntentId, orderId, refundAmount, currency);
        } catch (Exception e) {
            log.error("Error processing payment.refunded event: {}", message, e);
        }
    }
    
    /**
     * Consume shipment.created events.
     */
    @KafkaListener(topics = "shipment.created", groupId = "notification-group")
    public void handleShipmentCreated(String message) {
        log.info("Received shipment.created event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long shipmentId = json.get("shipmentId").asLong();
            Long orderId = json.get("orderId").asLong();
            String trackingNumber = json.get("trackingNumber").asText();
            
            notificationService.sendShipmentNotification(shipmentId, orderId, trackingNumber);
        } catch (Exception e) {
            log.error("Error processing shipment.created event: {}", message, e);
        }
    }
    
    /**
     * Consume order.delivered events.
     */
    @KafkaListener(topics = "order.delivered", groupId = "notification-group")
    public void handleOrderDelivered(String message) {
        log.info("Received order.delivered event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long orderId = json.get("orderId").asLong();
            Long shipmentId = json.get("shipmentId").asLong();
            
            notificationService.sendDeliveryConfirmation(orderId, shipmentId);
        } catch (Exception e) {
            log.error("Error processing order.delivered event: {}", message, e);
        }
    }
    
    /**
     * Consume return.requested events.
     */
    @KafkaListener(topics = "return.requested", groupId = "notification-group")
    public void handleReturnRequested(String message) {
        log.info("Received return.requested event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long returnId = json.get("returnId").asLong();
            Long orderId = json.get("orderId").asLong();
            String rmaNumber = json.get("rmaNumber").asText();
            
            notificationService.sendReturnRequestNotification(returnId, orderId, rmaNumber);
        } catch (Exception e) {
            log.error("Error processing return.requested event: {}", message, e);
        }
    }
    
    /**
     * Consume return.completed events.
     */
    @KafkaListener(topics = "return.completed", groupId = "notification-group")
    public void handleReturnCompleted(String message) {
        log.info("Received return.completed event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long returnId = json.get("returnId").asLong();
            String refundAmount = json.has("refundAmount") ? json.get("refundAmount").asText() : "0.00";
            
            notificationService.sendReturnCompletionNotification(returnId, refundAmount);
        } catch (Exception e) {
            log.error("Error processing return.completed event: {}", message, e);
        }
    }
}



