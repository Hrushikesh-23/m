package com.retailx.notification.controller;

import com.retailx.notification.dto.request.SendNotificationRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for NotificationController.
 */
@ExtendWith(MockitoExtension.class)
class NotificationControllerTest {
    
    @Mock
    private JavaMailSender mailSender;
    
    @InjectMocks
    private NotificationController notificationController;
    
    private SendNotificationRequest notificationRequest;
    
    @BeforeEach
    void setUp() {
        notificationRequest = new SendNotificationRequest();
        notificationRequest.setRecipientEmail("test@example.com");
        notificationRequest.setSubject("Test Subject");
        notificationRequest.setMessage("Test Message");
    }
    
    @Test
    void testSendNotification_EmailNotEnabled() {
        // Set emailEnabled to false using reflection
        try {
            java.lang.reflect.Field field = NotificationController.class.getDeclaredField("emailEnabled");
            field.setAccessible(true);
            field.setBoolean(notificationController, false);
        } catch (Exception e) {
            // Ignore
        }
        
        ResponseEntity<com.retailx.notification.dto.response.NotificationResponse> response = 
                notificationController.sendNotification(notificationRequest);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("QUEUED", response.getBody().getStatus());
        verify(mailSender, never()).send(any());
    }
    
    @Test
    void testSendNotification_Success() {
        // Set emailEnabled to true using reflection
        try {
            java.lang.reflect.Field field = NotificationController.class.getDeclaredField("emailEnabled");
            field.setAccessible(true);
            field.setBoolean(notificationController, true);
        } catch (Exception e) {
            // Ignore
        }
        doNothing().when(mailSender).send(any());
        
        ResponseEntity<com.retailx.notification.dto.response.NotificationResponse> response = 
                notificationController.sendNotification(notificationRequest);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("SENT", response.getBody().getStatus());
        verify(mailSender, times(1)).send(any());
    }
    
    @Test
    void testSendNotification_Failure() {
        // Set emailEnabled to true using reflection
        try {
            java.lang.reflect.Field field = NotificationController.class.getDeclaredField("emailEnabled");
            field.setAccessible(true);
            field.setBoolean(notificationController, true);
        } catch (Exception e) {
            // Ignore
        }
        doThrow(new RuntimeException("Mail server error")).when(mailSender).send(any());
        
        ResponseEntity<com.retailx.notification.dto.response.NotificationResponse> response = 
                notificationController.sendNotification(notificationRequest);
        
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("FAILED", response.getBody().getStatus());
        verify(mailSender, times(1)).send(any());
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = notificationController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Notification Service is running", response.getBody());
    }
    
    @Test
    void testGetServiceInfo() {
        ResponseEntity<NotificationController.ServiceInfo> response = 
                notificationController.getServiceInfo();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("RetailX Notification Service", response.getBody().name());
    }
}

