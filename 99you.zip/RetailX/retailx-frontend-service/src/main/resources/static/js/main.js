// Main JavaScript for RetailX frontend

document.addEventListener('DOMContentLoaded', function() {
    // Add any client-side functionality here
    console.log('RetailX frontend loaded');
    
    // Form validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!form.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            form.classList.add('was-validated');
        });
    });
});

