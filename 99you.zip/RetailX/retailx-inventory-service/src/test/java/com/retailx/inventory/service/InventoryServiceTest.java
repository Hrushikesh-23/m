package com.retailx.inventory.service;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.repository.InventoryRepository;
import com.retailx.inventory.repository.InventoryHoldRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for InventoryService.
 */
@ExtendWith(MockitoExtension.class)
class InventoryServiceTest {
    
    @Mock
    private InventoryRepository inventoryRepository;
    
    @Mock
    private InventoryHoldRepository inventoryHoldRepository;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private InventoryService inventoryService;
    
    private Inventory inventory;
    
    @BeforeEach
    void setUp() {
        // Set lowStockThreshold using reflection
        try {
            java.lang.reflect.Field field = InventoryService.class.getDeclaredField("lowStockThreshold");
            field.setAccessible(true);
            field.set(inventoryService, BigInteger.valueOf(10));
        } catch (Exception e) {
            // Ignore
        }
        
        inventory = Inventory.builder()
                .sku("PROD-001")
                .warehouseId("WH-001")
                .onHand(BigInteger.valueOf(100))
                .reserved(BigInteger.valueOf(10))
                .available(BigInteger.valueOf(90))
                .build();
    }
    
    @Test
    void testReserveInventory_Success() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "WH-001"))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
        // Mock Kafka send - returns CompletableFuture
        lenient().doAnswer(invocation -> java.util.concurrent.CompletableFuture.completedFuture(null))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        boolean result = inventoryService.reserveInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
        
        assertTrue(result);
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }
    
    @Test
    void testReserveInventory_InsufficientStock() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "WH-001"))
                .thenReturn(Optional.of(inventory));
        
        boolean result = inventoryService.reserveInventory("PROD-001", BigInteger.valueOf(200), "WH-001");
        
        assertFalse(result);
        verify(inventoryRepository, never()).save(any(Inventory.class));
    }
    
    @Test
    void testReleaseReservedInventory_Success() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "WH-001"))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
        
        boolean result = inventoryService.releaseReservedInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
        
        assertTrue(result);
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }
    
    @Test
    void testAdjustInventory_Success() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "WH-001"))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
        lenient().doAnswer(invocation -> java.util.concurrent.CompletableFuture.completedFuture(null))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        inventoryService.adjustInventory("PROD-001", "WH-001", BigInteger.valueOf(50));
        
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }
    
    @Test
    void testAdjustInventory_NegativeAvailable() {
        inventory.setOnHand(BigInteger.valueOf(10));
        inventory.setReserved(BigInteger.valueOf(15));
        inventory.setAvailable(BigInteger.valueOf(-5));
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "WH-001"))
                .thenReturn(Optional.of(inventory));
        
        assertThrows(RuntimeException.class, () -> 
                inventoryService.adjustInventory("PROD-001", "WH-001", BigInteger.valueOf(-20)));
        verify(inventoryRepository, never()).save(any(Inventory.class));
    }
    
    @Test
    void testGetLowStockItems_Success() {
        List<Inventory> lowStockItems = Arrays.asList(inventory);
        when(inventoryRepository.findLowStock(any())).thenReturn(lowStockItems);
        
        List<Inventory> result = inventoryService.getLowStockItems();
        
        assertNotNull(result);
        assertEquals(1, result.size());
        verify(inventoryRepository, times(1)).findLowStock(any());
    }
}
