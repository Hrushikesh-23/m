# RetailX - API Endpoint Diagram

## API Gateway (Port 8080)
**Base URL:** `http://localhost:8080`

All requests go through the API Gateway which:
- Validates JWT tokens
- Extracts user roles
- Routes to appropriate microservice
- Applies rate limiting

---

## 🔐 Auth Service (Port 8081)

### Base Path: `/api/auth`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/register` | ❌ | Public | Register new user (no token returned) |
| POST | `/login` | ❌ | Public | Login and get JWT token |
| PUT | `/email` | ✅ | Authenticated | Update user email |
| PUT | `/password` | ✅ | Authenticated | Update user password |
| POST | `/logout` | ✅ | Authenticated | Logout (invalidate session) |
| POST | `/forgot-password` | ❌ | Public | Request password reset (sends email) |
| POST | `/reset-password` | ❌ | Public | Reset password using token |

---

## 📦 Product Service (Port 8082)

### Base Path: `/api/products`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| GET | `/` | ❌ | Public | List products (paginated, filtered) |
| GET | `/{id}` | ❌ | Public | Get product by ID |
| GET | `/sku/{sku}` | ❌ | Public | Get product by SKU |
| GET | `/search/regex?pattern={pattern}` | ❌ | Public | Regex search on catalog path |
| GET | `/merchant/{merchantId}` | ❌ | Public | Get products by merchant |
| POST | `/` | ✅ | MERCHANT, ADMIN | Create product |
| PUT | `/{id}` | ✅ | MERCHANT, ADMIN | Update product |
| DELETE | `/{id}` | ✅ | MERCHANT, ADMIN | Delete product |

### Bulk Import: `/api/products/bulk`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/import/csv` | ✅ | MERCHANT, ADMIN | Bulk import from CSV |
| POST | `/import/xlsx` | ✅ | MERCHANT, ADMIN | Bulk import from XLSX |

### Reviews: `/api/reviews`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/products/{productId}?orderItemId={id}` | ✅ | CUSTOMER, ADMIN | Create review |
| GET | `/products/{productId}` | ❌ | Public | Get reviews by product |
| PUT | `/{reviewId}/moderate?action={action}` | ✅ | ADMIN, OPS | Moderate review (approve/hide) |
| GET | `/pending` | ✅ | ADMIN, OPS | Get pending reviews |

---

## 🛒 Order Service (Port 8083)

### Cart: `/api/carts`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| GET | `/` | ✅ | CUSTOMER, ADMIN | Get or create cart |
| POST | `/items` | ✅ | CUSTOMER, ADMIN | Add item to cart |
| PUT | `/items/{itemId}?quantity={qty}` | ✅ | CUSTOMER, ADMIN | Update cart item quantity |
| DELETE | `/items/{itemId}` | ✅ | CUSTOMER, ADMIN | Remove item from cart |
| DELETE | `/` | ✅ | CUSTOMER, ADMIN | Clear entire cart |

### Checkout: `/api/checkout`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/` | ✅ | CUSTOMER, ADMIN | Checkout (requires Idempotency-Key header) |

### Orders: `/api/orders`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| GET | `/{id}` | ✅ | Authenticated | Get order by ID |
| GET | `/number/{orderNumber}` | ✅ | Authenticated | Get order by order number |
| GET | `/customer` | ✅ | CUSTOMER, ADMIN | Get customer's orders |
| GET | `/merchant` | ✅ | MERCHANT, ADMIN, OPS | Get merchant's orders |
| GET | `/history` | ✅ | CUSTOMER, ADMIN | Get order history (paginated) |
| GET | `/{id}/audit` | ✅ | Authenticated | Get order audit log |
| PUT | `/{id}/status?status={status}` | ✅ | Authenticated | Update order status (role-based restrictions) |
| PUT | `/{id}/cancel?reason={reason}` | ✅ | Authenticated | Cancel order |

### Shipments: `/api/shipments`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/orders/{orderId}` | ✅ | OPS, ADMIN, MERCHANT | Create shipment |
| PUT | `/{shipmentId}/delivered` | ✅ | OPS, ADMIN | Mark shipment as delivered |
| GET | `/orders/{orderId}` | ✅ | CUSTOMER, MERCHANT, OPS, ADMIN | Get shipments by order |

### Returns: `/api/returns`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/orders/{orderId}` | ✅ | CUSTOMER, ADMIN | Request return |
| PUT | `/{returnId}/approve` | ✅ | OPS, ADMIN, MERCHANT | Approve return |
| PUT | `/{returnId}/reject?reason={reason}` | ✅ | OPS, ADMIN, MERCHANT | Reject return |
| GET | `/orders/{orderId}` | ✅ | CUSTOMER, MERCHANT, OPS, ADMIN | Get returns by order |

### Reports: `/api/reports`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| GET | `/sales?startDate={date}&endDate={date}` | ✅ | MERCHANT, ADMIN, OPS | Get sales report |
| GET | `/order-status` | ✅ | MERCHANT, ADMIN, OPS | Get order status counts |

---

## 💳 Payment Service (Port 8084)

**Note:** Payment Service and Inventory Service both use port 8084. This may need to be resolved in production.

### Base Path: `/api/payments`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/intents?orderId={id}&amount={amt}&currency={curr}` | ✅ | Authenticated | Create payment intent (amount must match order total) |
| POST | `/{paymentIntentId}/authorize` | ✅ | Authenticated | Authorize payment (requires Idempotency-Key) |
| POST | `/{paymentIntentId}/capture` | ✅ | Authenticated | Capture payment (requires Idempotency-Key, auto-updates order to PAID) |
| POST | `/{paymentIntentId}/fail?errorCode={code}&errorMessage={msg}` | ✅ | Authenticated | Mark payment as failed (auto-cancels order) |
| POST | `/{paymentIntentId}/refund?amount={amt}` | ✅ | OPS, ADMIN | Refund payment (requires Idempotency-Key, auto-cancels order) |
| POST | `/refund?orderId={id}&amount={amt}` | ✅ | OPS, ADMIN, MERCHANT | Refund payment by order ID (for returns) |

---

## 📊 Inventory Service (Port 8084)

### Base Path: `/api/inventory`

| Method | Endpoint | Auth Required | Roles | Description |
|--------|----------|---------------|-------|-------------|
| POST | `/reserve?sku={sku}&quantity={qty}&warehouseId={id}` | ✅ | Authenticated | Reserve inventory (used during checkout) |
| GET | `/low-stock` | ✅ | MERCHANT, ADMIN, OPS | Get low stock items (below threshold) |
| POST | `/adjust?sku={sku}&warehouseId={id}&quantity={qty}` | ✅ | OPS, ADMIN | Adjust inventory quantity (positive=add, negative=remove) |
| POST | `/release?sku={sku}&quantity={qty}&warehouseId={id}` | ✅ | Authenticated | Release reserved inventory (internal use) |

---

## 📱 Frontend Service (Port 8087)

### Base Path: `/` (Thymeleaf Pages)

| Method | Endpoint | Auth Required | Description |
|--------|----------|---------------|-------------|
| GET | `/` | ❌ | Redirect to catalog |
| GET | `/catalog` | ❌ | Product catalog page |
| GET | `/products/{id}` | ❌ | Product detail page |
| GET | `/cart` | ✅ | Shopping cart page |
| POST | `/cart/add` | ✅ | Add to cart (form) |
| POST | `/cart/remove/{id}` | ✅ | Remove from cart |
| GET | `/checkout` | ✅ | Checkout page |
| POST | `/checkout` | ✅ | Process checkout |
| GET | `/orders` | ✅ | Order history page |
| GET | `/merchant/dashboard` | ✅ | Merchant dashboard |
| GET | `/login` | ❌ | Login page |
| POST | `/login` | ❌ | Process login |
| GET | `/register` | ❌ | Registration page |
| POST | `/register` | ❌ | Process registration |

---

## 🔑 Authentication Headers

All authenticated endpoints require:
```
Authorization: Bearer <JWT_TOKEN>
X-User-Id: <user_id>
```

Idempotent endpoints also require:
```
Idempotency-Key: <unique_key>
```

---

## 📊 Request/Response Examples

### Create Product (MERCHANT/ADMIN)
```http
POST /api/products
Authorization: Bearer <token>
X-User-Id: 123
Content-Type: application/json

{
  "sku": "PROD-001",
  "name": "Laptop",
  "description": "High-performance laptop",
  "basePrice": 999.99,
  "currency": "USD",
  "categoryPath": "/electronics/computers",
  "status": "ACTIVE"
}
```

### Checkout (CUSTOMER/ADMIN)
```http
POST /api/checkout
Authorization: Bearer <token>
X-User-Id: 456
Idempotency-Key: abc-123-def-456
Content-Type: application/json

{
  "shippingAddress": "123 Main St, City, State 12345",
  "shippingMethod": "STANDARD",
  "giftNote": "Happy Birthday!"
}
```

### Create Shipment (OPS/ADMIN/MERCHANT)
```http
POST /api/shipments/orders/1
Authorization: Bearer <token>
Content-Type: application/json

{
  "carrier": "UPS",
  "trackingNumber": "1Z999AA10123456784",
  "skus": ["PROD-001", "PROD-002"]
}
```

### Request Return (CUSTOMER/ADMIN)
```http
POST /api/returns/orders/1
Authorization: Bearer <token>
X-User-Id: 456
Content-Type: application/json

{
  "reason": "Defective item",
  "items": [
    {
      "sku": "PROD-001",
      "quantity": 1
    }
  ]
}
```

---

## 🎯 Role-Based Access Summary

| Role | Can Access |
|------|------------|
| **CUSTOMER** | Browse products, manage cart, checkout, view own orders, request returns, create reviews, update email/password, logout, forgot/reset password |
| **MERCHANT** | All customer access + create/manage products, bulk import, view own orders/reports, approve returns (auto-refund), create shipments |
| **OPS** | All merchant access + view all orders, process refunds, adjust inventory, moderate reviews, mark orders as delivered |
| **ADMIN** | Full access to all endpoints |

---

## 📝 Notes

- Public endpoints (❌) don't require authentication
- All POST/PUT/DELETE operations require authentication
- Idempotency keys are required for: checkout, payment authorize/capture/refund
- Rate limiting is applied at API Gateway level (10 req/sec default)
- All timestamps use ISO 8601 format
- Pagination defaults: page=0, size=20

