# Role-Based Authorization (RBAC) Implementation

## Overview

RetailX implements role-based access control (RBAC) at multiple levels:
1. **API Gateway** - JWT token validation and role extraction
2. **Service Level** - Spring Security with method-level authorization
3. **Controller Level** - @PreAuthorize annotations

## Roles

- **CUSTOMER** - Can access own cart, orders, checkout, returns, reviews, profile management
- **MERCHANT** - Can manage own products, view own orders, reports, approve returns, create shipments
- **OPS** - Can view all orders, adjust inventory, moderate reviews, process refunds, mark orders as delivered
- **ADMIN** - Full administrative access to all endpoints

## Implementation Details

### 1. API Gateway Level

**File:** `retailx-api-gateway/src/main/java/com/retailx/gateway/filter/JwtAuthenticationFilter.java`

- Validates JWT token from Authorization header
- Extracts user ID, email, and roles from token
- Adds headers to downstream requests:
  - `X-User-Id` - User ID
  - `X-User-Email` - User email
  - `X-User-Role` - Comma-separated roles

**Flow:**
```
Client Request → API Gateway → JwtAuthenticationFilter → 
Extract JWT → Validate → Extract Roles → Add Headers → 
Forward to Service
```

### 2. Service Level Security

#### Order Service

**File:** `retailx-order-service/src/main/java/com/retailx/order/config/SecurityConfig.java`

```java
// CUSTOMER can access:
- /api/carts/** (own cart)
- /api/checkout (checkout)
- /api/orders/customer/** (own orders)

// MERCHANT/ADMIN/OPS can access:
- /api/orders/merchant/** (merchant orders)
- /api/reports/** (reports)

// All authenticated users:
- /api/orders/** (general order endpoints)
```

#### Product Service

**File:** `retailx-product-service/src/main/java/com/retailx/product/config/SecurityConfig.java`

```java
// Public read access:
- GET /api/products/** (anyone can browse)

// MERCHANT/ADMIN can:
- POST /api/products (create)
- PUT /api/products/{id} (update)
- DELETE /api/products/{id} (delete)
- POST /api/products/bulk/import/** (bulk import)
```

### 3. Method-Level Authorization

**Example:** `@PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")`

Used in:
- `ProductController.createProduct()` - Only MERCHANT/ADMIN
- `BulkImportController.importCsv()` - Only MERCHANT/ADMIN
- `BulkImportController.importXlsx()` - Only MERCHANT/ADMIN

## Authorization Flow

```
1. Client sends request with JWT token
   ↓
2. API Gateway validates JWT
   ↓
3. Gateway extracts roles and adds to headers
   ↓
4. Request forwarded to service
   ↓
5. Service SecurityConfig checks path patterns
   ↓
6. @PreAuthorize checks method-level permissions
   ↓
7. If authorized → Process request
   If not → 403 Forbidden
```

## Testing Authorization

### Test as CUSTOMER:
```bash
# Login as customer
POST /api/auth/login
{
  "email": "customer@example.com",
  "password": "Customer@123"
}

# Access own cart (should work)
GET /api/carts
Headers: Authorization: Bearer <token>

# Try to create product (should fail - 403)
POST /api/products
Headers: Authorization: Bearer <token>
```

### Test as MERCHANT:
```bash
# Login as merchant
POST /api/auth/login
{
  "email": "merchant@example.com",
  "password": "Merchant@123"
}

# Create product (should work)
POST /api/products
Headers: Authorization: Bearer <token>

# Access reports (should work)
GET /api/reports/sales
Headers: Authorization: Bearer <token>
```

## Rate Limiting by Role

**File:** `retailx-api-gateway/src/main/java/com/retailx/gateway/filter/RateLimitFilter.java`

- **CUSTOMER:** 60 requests/minute
- **MERCHANT:** 90 requests/minute
- **OPS/ADMIN:** 120 requests/minute

When limit exceeded:
- HTTP 429 Too Many Requests
- `Retry-After: 60` header

## Security Best Practices

1. ✅ JWT tokens validated at gateway
2. ✅ Roles extracted from token (not from database on each request)
3. ✅ Method-level authorization for sensitive operations
4. ✅ Path-based authorization for service-level access
5. ✅ Rate limiting per role
6. ✅ No role information in URLs or query parameters

## Common Authorization Scenarios

### Scenario 1: Customer Browsing Products
- **Role:** CUSTOMER (or unauthenticated)
- **Access:** ✅ GET /api/products (public read)
- **Access:** ✅ GET /api/reviews/products/{id} (public read)
- **Access:** ❌ POST /api/products (requires MERCHANT/ADMIN)

### Scenario 2: Customer Checkout and Profile
- **Role:** CUSTOMER
- **Access:** ✅ POST /api/checkout
- **Access:** ✅ GET /api/carts
- **Access:** ✅ PUT /api/auth/email (update own email)
- **Access:** ✅ PUT /api/auth/password (update own password)
- **Access:** ✅ POST /api/auth/logout
- **Access:** ✅ POST /api/auth/forgot-password
- **Access:** ✅ POST /api/auth/reset-password
- **Access:** ❌ GET /api/reports/sales (requires MERCHANT/ADMIN/OPS)

### Scenario 3: Merchant Managing Products and Orders
- **Role:** MERCHANT
- **Access:** ✅ POST /api/products
- **Access:** ✅ POST /api/products/bulk/import/csv
- **Access:** ✅ GET /api/reports/sales
- **Access:** ✅ PUT /api/returns/{id}/approve (auto-refund)
- **Access:** ✅ POST /api/shipments/orders/{orderId}
- **Access:** ❌ GET /api/orders/customer (only own orders)
- **Access:** ❌ PUT /api/orders/{id}/status?status=DELIVERED (requires OPS/ADMIN)

### Scenario 4: OPS Operations
- **Role:** OPS
- **Access:** ✅ POST /api/inventory/adjust
- **Access:** ✅ GET /api/inventory/low-stock
- **Access:** ✅ PUT /api/orders/{id}/status?status=DELIVERED
- **Access:** ✅ POST /api/payments/{id}/refund
- **Access:** ✅ PUT /api/reviews/{id}/moderate
- **Access:** ✅ GET /api/reviews/pending
- **Access:** ❌ POST /api/products (requires MERCHANT/ADMIN)

### Scenario 5: Admin Full Access
- **Role:** ADMIN
- **Access:** ✅ All endpoints
- **Access:** ✅ User management
- **Access:** ✅ System configuration
- **Access:** ✅ All order status updates

## Troubleshooting

### 401 Unauthorized
- Check JWT token is valid
- Check token is not expired
- Verify Authorization header format: `Bearer <token>`

### 403 Forbidden
- Check user has required role
- Verify @PreAuthorize annotation allows role
- Check SecurityConfig path patterns

### 429 Too Many Requests
- Rate limit exceeded for role
- Wait for rate limit window to reset
- Check Retry-After header for wait time

