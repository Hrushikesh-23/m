# Service Ports and Access Guide

This guide explains how to access RetailX services through the API Gateway and directly on their individual ports.

## Service Ports

| Service | Port | Direct URL | Gateway Path |
|---------|------|------------|--------------|
| Eureka Server | 8761 | http://localhost:8761 | - |
| API Gateway | 8080 | http://localhost:8080 | All `/api/**` |
| Auth Service | 8081 | http://localhost:8081 | `/api/auth/**` |
| Product Service | 8082 | http://localhost:8082 | `/api/products/**`, `/api/catalog/**`, `/api/reviews/**` |
| Order Service | 8083 | http://localhost:8083 | `/api/orders/**`, `/api/carts/**`, `/api/checkout/**`, `/api/shipments/**`, `/api/returns/**`, `/api/reports/**` |
| Payment Service | 8084 | http://localhost:8084 | `/api/payments/**` |
| Inventory Service | 8084 | http://localhost:8084 | `/api/inventory/**` |

**Note:** Both Payment Service and Inventory Service currently use port 8084. This should be resolved in production by assigning Inventory Service to a different port (e.g., 8085).
| Notification Service | 8086 | http://localhost:8086 | - |
| Frontend Service | 8087 | http://localhost:8087 | `/` |

## Access Methods

### Method 1: Through API Gateway (Recommended)

**Base URL:** `http://localhost:8080`

**Benefits:**
- ✅ Single entry point
- ✅ JWT authentication handled automatically
- ✅ Rate limiting applied
- ✅ Request routing and load balancing
- ✅ Consistent API structure

**Example:**
```bash
# Get products through gateway
curl http://localhost:8080/api/products

# Login through gateway
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'
```

### Method 2: Direct Service Access

**Base URLs:** Individual service ports (8081-8087)

**Benefits:**
- ✅ Direct access for development/debugging
- ✅ Bypass gateway for testing
- ✅ Access service-specific endpoints
- ✅ Health checks and metrics

**Example:**
```bash
# Get products directly from Product Service
curl http://localhost:8082/api/products

# Health check directly
curl http://localhost:8082/actuator/health
```

## Important Notes

### Authentication

**Through Gateway (Port 8080):**
- JWT token validation is automatic
- Headers are forwarded to services
- Use: `Authorization: Bearer <token>`

**Direct Access (Ports 8081-8087):**
- Services still require authentication
- JWT tokens must be valid
- Services validate tokens independently
- Use: `Authorization: Bearer <token>`

### Security Configuration

Services are configured to:
- ✅ Accept requests through the API Gateway
- ✅ Accept direct requests on their ports
- ✅ Validate JWT tokens in both cases
- ✅ Enforce role-based access control

### Service Discovery

All services register with Eureka Server (port 8761):
- Services discover each other through Eureka
- Gateway routes requests using service names
- Direct access uses port numbers

## Testing Service Accessibility

### Check if services are running:

```powershell
# Check all service ports
netstat -ano | findstr ":8080 :8081 :8082 :8083 :8084 :8085 :8086 :8087"

# Test health endpoints
curl http://localhost:8080/actuator/health  # Gateway
curl http://localhost:8081/actuator/health  # Auth
curl http://localhost:8082/actuator/health  # Product
curl http://localhost:8083/actuator/health  # Order
curl http://localhost:8084/actuator/health  # Payment
curl http://localhost:8085/actuator/health  # Inventory
```

### PowerShell Test Script:

```powershell
$services = @(
    @{Port=8080; Name="API Gateway"},
    @{Port=8081; Name="Auth Service"},
    @{Port=8082; Name="Product Service"},
    @{Port=8083; Name="Order Service"},
    @{Port=8084; Name="Payment Service"},
    @{Port=8085; Name="Inventory Service"}
)

foreach ($svc in $services) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$($svc.Port)/actuator/health" -Method GET -TimeoutSec 3
        Write-Host "✅ $($svc.Name) (Port $($svc.Port)): Accessible" -ForegroundColor Green
    } catch {
        Write-Host "❌ $($svc.Name) (Port $($svc.Port)): Not accessible" -ForegroundColor Red
    }
}
```

## Common Use Cases

### Development/Debugging

Use direct service access to:
- Test individual services in isolation
- Debug service-specific issues
- Access service logs and metrics
- Bypass gateway for faster iteration

### Production/Integration

Use API Gateway to:
- Centralize authentication
- Apply rate limiting
- Route requests efficiently
- Monitor API usage

### Health Checks

Both methods work for health checks:
```bash
# Through gateway
curl http://localhost:8080/actuator/health

# Direct access
curl http://localhost:8082/actuator/health
```

## Troubleshooting

### Service Not Accessible on Direct Port

**Possible Causes:**
1. Service not running
2. Port blocked by firewall
3. Service binding to wrong interface
4. Port already in use

**Solutions:**
1. Check if service is running: `Get-Process | Where-Object {$_.ProcessName -like "*java*"}`
2. Check port binding: `netstat -ano | findstr ":8082"`
3. Restart the service
4. Check service logs for errors

### Gateway Returns 404

**Possible Causes:**
1. Service not registered with Eureka
2. Incorrect route configuration
3. Service name mismatch

**Solutions:**
1. Check Eureka dashboard: http://localhost:8761
2. Verify service is registered
3. Check gateway route configuration
4. Verify service name matches route

### Authentication Fails on Direct Access

**Possible Causes:**
1. JWT token expired
2. Token not properly formatted
3. Service security configuration issue

**Solutions:**
1. Get a fresh token from Auth Service
2. Verify token format: `Bearer <token>`
3. Check service SecurityConfig
4. Verify JWT secret matches across services

## Best Practices

1. **Use Gateway for Production:** Always use port 8080 for production traffic
2. **Use Direct Access for Development:** Use individual ports for debugging
3. **Monitor Both:** Check health on both gateway and direct ports
4. **Consistent Authentication:** Use same JWT tokens for both methods
5. **Service Discovery:** Ensure all services register with Eureka

## Summary

- **Gateway (8080):** Recommended for all client requests
- **Direct Ports (8081-8087):** Available for development and debugging
- **Both Methods:** Require valid JWT authentication
- **Health Checks:** Available on both gateway and direct ports
- **Service Discovery:** All services register with Eureka (8761)


