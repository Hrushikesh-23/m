package com.retailx.order.controller;

import com.retailx.order.domain.Return;
import com.retailx.order.domain.ReturnItem;
import com.retailx.order.dto.request.ReturnRequest;
import com.retailx.order.service.ReturnService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ReturnController.
 */
@ExtendWith(MockitoExtension.class)
class ReturnControllerTest {
    
    @Mock
    private ReturnService returnService;
    
    @InjectMocks
    private ReturnController returnController;
    
    private Return returnEntity;
    private ReturnRequest returnRequest;
    
    @BeforeEach
    void setUp() {
        returnEntity = Return.builder()
                .orderId(1L)
                .rmaNumber("RMA-001")
                .status("REQUESTED")
                .reason("Defective item")
                .requestedAt(LocalDateTime.now())
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(returnEntity, 1L);
        } catch (Exception e) {
            // Ignore
        }
        
        ReturnItem item = ReturnItem.builder()
                .returnEntity(returnEntity)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(1))
                .build();
        returnEntity.setItems(Arrays.asList(item));
        
        returnRequest = new ReturnRequest();
        returnRequest.setReason("Defective item");
        com.retailx.order.dto.request.ReturnRequest.ReturnItemRequest itemRequest = 
                new com.retailx.order.dto.request.ReturnRequest.ReturnItemRequest();
        itemRequest.setSku("PROD-001");
        itemRequest.setQuantity(BigInteger.valueOf(1));
        returnRequest.setItems(Arrays.asList(itemRequest));
    }
    
    @Test
    void testRequestReturn_Success() {
        when(returnService.requestReturn(anyLong(), anyLong(), anyString(), anyList()))
                .thenReturn(returnEntity);
        
        ResponseEntity<com.retailx.order.dto.response.ReturnResponse> response = 
                returnController.requestReturn(1L, 1L, returnRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("RMA-001", response.getBody().getRmaNumber());
        verify(returnService, times(1)).requestReturn(eq(1L), eq(1L), eq("Defective item"), anyList());
    }
    
    @Test
    void testApproveReturn_Success() {
        returnEntity.setStatus("APPROVED");
        returnEntity.setApprovedAt(LocalDateTime.now());
        returnEntity.setRefundAmount(new BigDecimal("50.00"));
        when(returnService.approveReturn(anyLong(), anyString())).thenReturn(returnEntity);
        
        ResponseEntity<com.retailx.order.dto.response.ReturnResponse> response = 
                returnController.approveReturn(1L, "1");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("APPROVED", response.getBody().getStatus());
        verify(returnService, times(1)).approveReturn(1L, "1");
    }
    
    @Test
    void testRejectReturn_Success() {
        returnEntity.setStatus("REJECTED");
        when(returnService.rejectReturn(anyLong(), anyString(), anyString()))
                .thenReturn(returnEntity);
        
        ResponseEntity<com.retailx.order.dto.response.ReturnResponse> response = 
                returnController.rejectReturn(1L, "Not eligible", "1");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("REJECTED", response.getBody().getStatus());
        verify(returnService, times(1)).rejectReturn(1L, "Not eligible", "1");
    }
    
    @Test
    void testGetReturnsByOrder_Success() {
        List<Return> returns = Arrays.asList(returnEntity);
        when(returnService.getReturnsByOrder(anyLong())).thenReturn(returns);
        
        ResponseEntity<List<com.retailx.order.dto.response.ReturnResponse>> response = 
                returnController.getReturnsByOrder(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(returnService, times(1)).getReturnsByOrder(1L);
    }
}

