package com.retailx.order.controller;

import com.retailx.order.domain.Shipment;
import com.retailx.order.domain.ShipmentItem;
import com.retailx.order.dto.request.CreateShipmentRequest;
import com.retailx.order.service.ShipmentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ShipmentController.
 */
@ExtendWith(MockitoExtension.class)
class ShipmentControllerTest {
    
    @Mock
    private ShipmentService shipmentService;
    
    @InjectMocks
    private ShipmentController shipmentController;
    
    private Shipment shipment;
    private CreateShipmentRequest createShipmentRequest;
    
    @BeforeEach
    void setUp() {
        shipment = Shipment.builder()
                .orderId(1L)
                .shipmentNumber("SHIP-001")
                .carrier("FedEx")
                .trackingNumber("TRACK123")
                .shippedAt(LocalDateTime.now())
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(shipment, 1L);
        } catch (Exception e) {
            // Ignore
        }
        
        ShipmentItem item = ShipmentItem.builder()
                .shipment(shipment)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .build();
        shipment.setItems(Arrays.asList(item));
        
        createShipmentRequest = new CreateShipmentRequest();
        createShipmentRequest.setCarrier("FedEx");
        createShipmentRequest.setTrackingNumber("TRACK123");
        createShipmentRequest.setSkus(Arrays.asList("PROD-001"));
    }
    
    @Test
    void testCreateShipment_Success() {
        when(shipmentService.createShipment(anyLong(), anyString(), anyString(), anyList()))
                .thenReturn(shipment);
        
        ResponseEntity<com.retailx.order.dto.response.ShipmentResponse> response = 
                shipmentController.createShipment(1L, createShipmentRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("SHIP-001", response.getBody().getShipmentNumber());
        verify(shipmentService, times(1)).createShipment(1L, "FedEx", "TRACK123", 
                createShipmentRequest.getSkus());
    }
    
    @Test
    void testMarkDelivered_Success() {
        shipment.setDeliveredAt(LocalDateTime.now());
        when(shipmentService.markDelivered(anyLong())).thenReturn(shipment);
        
        ResponseEntity<com.retailx.order.dto.response.ShipmentResponse> response = 
                shipmentController.markDelivered(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getDeliveredAt());
        verify(shipmentService, times(1)).markDelivered(1L);
    }
    
    @Test
    void testGetShipmentsByOrder_Success() {
        List<Shipment> shipments = Arrays.asList(shipment);
        when(shipmentService.getShipmentsByOrder(anyLong())).thenReturn(shipments);
        
        ResponseEntity<List<com.retailx.order.dto.response.ShipmentResponse>> response = 
                shipmentController.getShipmentsByOrder(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(shipmentService, times(1)).getShipmentsByOrder(1L);
    }
}

