package com.retailx.order.service;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.IdempotencyKey;
import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.request.CheckoutRequest;
import com.retailx.order.dto.response.CheckoutResponse;
import com.retailx.order.repository.CartRepository;
import com.retailx.order.repository.IdempotencyKeyRepository;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.util.IdempotencyUtil;
import com.retailx.order.util.OrderNumberGenerator;
import com.retailx.order.annotation.Auditable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * Checkout operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class CheckoutService {
    
    private final CartRepository cartRepository;
    private final OrderRepository orderRepository;
    private final IdempotencyKeyRepository idempotencyKeyRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final ProductServiceClient productServiceClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @org.springframework.beans.factory.annotation.Value("${retailx.cart.max-quantity-per-item:100}")
    private int maxQuantityPerItem;
    
    @org.springframework.beans.factory.annotation.Value("${retailx.cart.max-total-value:10000}")
    private BigDecimal maxTotalValue;
    
    @org.springframework.beans.factory.annotation.Value("${retailx.cart.max-items:50}")
    private int maxItems;
    
    @Transactional
    @Auditable
    public CheckoutResponse checkout(Long customerId, CheckoutRequest request, String idempotencyKey) {
        log.info("Checkout: customer {} key {}", customerId, idempotencyKey);
        
        if (idempotencyKey != null && !IdempotencyUtil.isValidKey(idempotencyKey)) {
            log.warn("Invalid idempotency key: {}", idempotencyKey);
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid idempotency key format");
        }
        
        if (idempotencyKey == null) {
            idempotencyKey = java.util.UUID.randomUUID().toString();
            log.info("Generated idempotency key: {}", idempotencyKey);
        }
        
        // Check for existing idempotency key
        String requestHash = IdempotencyUtil.hashRequest(request.toString());
        IdempotencyKey existingKey = idempotencyKeyRepository.findByKeyValue(idempotencyKey)
                .orElse(null);
        
        if (existingKey != null) {
            if (existingKey.getUsed()) {
                // Same request - return cached response
                if (existingKey.getRequestHash().equals(requestHash)) {
                    log.info("Idempotent request detected, returning cached response");
                    return parseCachedResponse(existingKey.getResponseSummary());
                } else {
                    // Different payload with same key - conflict
                    throw new ResponseStatusException(HttpStatus.CONFLICT, 
                            "Idempotency key already used with different payload");
                }
            }
        }
        
        // Get cart
        Cart cart = cartRepository.findByCustomerIdAndDeletedFalse(customerId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                        "Cart not found or empty for customer: " + customerId));
        
        if (cart.getItems().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Cart is empty");
        }
        
        // Validate cart limits
        if (cart.getItems().size() > maxItems) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                    String.format("Cart exceeds maximum items limit (%d)", maxItems));
        }
        
        if (cart.getTotal().compareTo(maxTotalValue) > 0) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                    String.format("Cart total exceeds maximum value (%.2f)", maxTotalValue.doubleValue()));
        }
        
        // Validate product availability and prices before checkout
        List<ReservationRecord> reservations = new java.util.ArrayList<>();
        String warehouseId = null;
        
        for (var item : cart.getItems()) {
            // Validate quantity per item
            if (item.getQuantity().compareTo(BigInteger.valueOf(maxQuantityPerItem)) > 0) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                        String.format("Quantity for SKU %s exceeds maximum (%d)", item.getSku(), maxQuantityPerItem));
            }
            
            // Re-validate product exists and is active
            try {
                Map<String, Object> productDetails = productServiceClient.getProductBySku(item.getSku());
                if (productDetails == null || !"ACTIVE".equals(productDetails.get("status"))) {
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                            "Product not found or not active: " + item.getSku());
                }
                
                // Validate price hasn't changed
                BigDecimal currentPrice = new BigDecimal(productDetails.get("basePrice").toString());
                if (item.getUnitPrice().compareTo(currentPrice) != 0) {
                    log.warn("Price changed for SKU {}: cart price={}, current price={}", 
                            item.getSku(), item.getUnitPrice(), currentPrice);
                    throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                            String.format("Product price has changed for SKU %s. Please refresh your cart.", item.getSku()));
                }
            } catch (ResponseStatusException e) {
                throw e;
            } catch (Exception e) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                        "Failed to validate product: " + item.getSku() + " - " + e.getMessage());
            }
            
            // Reserve inventory with rollback tracking
            warehouseId = "WH-001"; // Try WH-001 first
            boolean reserved = inventoryServiceClient.reserveInventory(
                    item.getSku(), item.getQuantity(), warehouseId);
            if (!reserved) {
                // Fallback to default-warehouse if WH-001 doesn't have inventory
                warehouseId = "default-warehouse";
                reserved = inventoryServiceClient.reserveInventory(
                        item.getSku(), item.getQuantity(), warehouseId);
            }
            if (!reserved) {
                // Rollback all previous reservations
                log.error("Failed to reserve inventory for SKU: {}, rolling back previous reservations", item.getSku());
                rollbackReservations(reservations);
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, 
                        "Insufficient inventory for SKU: " + item.getSku());
            }
            
            // Track reservation for rollback
            reservations.add(new ReservationRecord(item.getSku(), item.getQuantity(), warehouseId));
        }
        
        // Create order with retry logic for duplicate order numbers
        Order order = null;
        int maxRetries = 5;
        int retryCount = 0;
        
        try {
            while (order == null && retryCount < maxRetries) {
                try {
                    order = createOrderFromCart(cart, request);
                    order = orderRepository.save(order);
                } catch (org.springframework.dao.DataIntegrityViolationException e) {
                    if (e.getMessage() != null && e.getMessage().contains("order_number")) {
                        retryCount++;
                        log.warn("Duplicate order number detected, retrying (attempt {}/{})", retryCount, maxRetries);
                        if (retryCount >= maxRetries) {
                            // Rollback reservations before throwing error
                            rollbackReservations(reservations);
                            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, 
                                    "Failed to create order after multiple attempts. Please try again.");
                        }
                        // Wait a bit before retrying
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            rollbackReservations(reservations);
                            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, 
                                    "Order creation interrupted");
                        }
                    } else {
                        rollbackReservations(reservations);
                        throw e;
                    }
                } catch (Exception e) {
                    // Rollback reservations on any error
                    rollbackReservations(reservations);
                    throw e;
                }
            }
        } catch (ResponseStatusException e) {
            rollbackReservations(reservations);
            throw e;
        } catch (Exception e) {
            rollbackReservations(reservations);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, 
                    "Failed to create order: " + e.getMessage(), e);
        }
        
        if (order == null) {
            rollbackReservations(reservations);
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, 
                    "Failed to create order after multiple attempts");
        }
        
        // Clear cart
        cart.getItems().clear();
        cartRepository.save(cart);
        
        // Save idempotency key
        IdempotencyKey key = IdempotencyKey.builder()
                .keyValue(idempotencyKey)
                .requestHash(requestHash)
                .responseSummary(String.format("{\"orderNumber\":\"%s\",\"orderId\":\"%d\"}", 
                        order.getOrderNumber(), order.getId()))
                .expiresAt(LocalDateTime.now().plusHours(24))
                .used(true)
                .build();
        idempotencyKeyRepository.save(key);
        
        // Publish event (non-blocking)
        try {
            kafkaTemplate.send("order.created", order.getOrderNumber(), 
                    String.format("{\"orderId\":%d,\"orderNumber\":\"%s\",\"customerId\":%d}", 
                            order.getId(), order.getOrderNumber(), customerId));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for order creation: {}", e.getMessage());
        }
        
        return CheckoutResponse.builder()
                .orderNumber(order.getOrderNumber())
                .orderId(String.valueOf(order.getId()))
                .status(order.getStatus().name())
                .message("Order created successfully")
                .build();
    }
    
    private Order createOrderFromCart(Cart cart, CheckoutRequest request) {
        Order order = Order.builder()
                .orderNumber(OrderNumberGenerator.generate())
                .customerId(cart.getCustomerId())
                // merchantId will be set per item or derived from the first item
                .status(OrderStatus.PENDING)
                .subtotal(cart.getSubtotal())
                .tax(cart.getTax())
                .shipping(cart.getShipping())
                .discount(cart.getDiscount())
                .total(cart.getTotal())
                .shippingAddress(request.getShippingAddress())
                .shippingMethod(request.getShippingMethod())
                .giftNote(request.getGiftNote())
                .version(1)
                .build();

        // Create order items
        List<OrderItem> orderItems = new java.util.ArrayList<>();
        Long firstMerchantId = null;
        
        for (var cartItem : cart.getItems()) {
            try {
                // Fetch product details to get merchantId and actual product name
                Map<String, Object> productDetails = productServiceClient.getProductBySku(cartItem.getSku());
                Long merchantId = ((Number) productDetails.get("merchantId")).longValue();
                String productName = (String) productDetails.get("name");

                // Set the order's merchantId from the first item
                if (firstMerchantId == null) {
                    firstMerchantId = merchantId;
                    order.setMerchantId(merchantId);
                }

                OrderItem orderItem = OrderItem.builder()
                        .order(order)
                        .sku(cartItem.getSku())
                        .productName(productName)
                        .quantity(cartItem.getQuantity())
                        .unitPrice(cartItem.getUnitPrice())
                        .lineTotal(cartItem.getLineTotal())
                        .build();
                orderItems.add(orderItem);
            } catch (Exception e) {
                log.warn("Failed to fetch product details for SKU: {}, using defaults. Error: {}", 
                        cartItem.getSku(), e.getMessage());
                // Fallback to defaults if product service is unavailable
                if (firstMerchantId == null) {
                    firstMerchantId = 1L;
                    order.setMerchantId(1L);
                }
                
                OrderItem orderItem = OrderItem.builder()
                        .order(order)
                        .sku(cartItem.getSku())
                        .productName("Product " + cartItem.getSku())
                        .quantity(cartItem.getQuantity())
                        .unitPrice(cartItem.getUnitPrice())
                        .lineTotal(cartItem.getLineTotal())
                        .build();
                orderItems.add(orderItem);
            }
        }

        // Ensure merchantId is set (fallback default)
        if (order.getMerchantId() == null) {
            order.setMerchantId(1L); // Fallback default
        }

        order.setItems(orderItems);
        return order;
    }
    
    /**
     * Rollback all inventory reservations in case of order creation failure.
     */
    private void rollbackReservations(List<ReservationRecord> reservations) {
        log.info("Rolling back {} inventory reservations", reservations.size());
        for (ReservationRecord reservation : reservations) {
            try {
                boolean released = inventoryServiceClient.releaseReservedInventory(
                        reservation.sku, reservation.quantity, reservation.warehouseId);
                if (!released) {
                    log.error("Failed to release reserved inventory: sku={}, quantity={}, warehouseId={}", 
                            reservation.sku, reservation.quantity, reservation.warehouseId);
                }
            } catch (Exception e) {
                log.error("Error releasing reserved inventory: sku={}, error={}", 
                        reservation.sku, e.getMessage());
            }
        }
    }
    
    /**
     * Record of inventory reservation for rollback purposes.
     */
    private static class ReservationRecord {
        final String sku;
        final BigInteger quantity;
        final String warehouseId;
        
        ReservationRecord(String sku, BigInteger quantity, String warehouseId) {
            this.sku = sku;
            this.quantity = quantity;
            this.warehouseId = warehouseId;
        }
    }
    
    private CheckoutResponse parseCachedResponse(String responseSummary) {
        // Simple parsing - in production use JSON parser
        String orderNumber = responseSummary.substring(
                responseSummary.indexOf("\"orderNumber\":\"") + 15,
                responseSummary.indexOf("\"", responseSummary.indexOf("\"orderNumber\":\"") + 15));
        String orderId = responseSummary.substring(
                responseSummary.indexOf("\"orderId\":\"") + 11,
                responseSummary.indexOf("\"", responseSummary.indexOf("\"orderId\":\"") + 11));
        
        return CheckoutResponse.builder()
                .orderNumber(orderNumber)
                .orderId(orderId)
                .status("PENDING")
                .message("Idempotent response")
                .build();
    }
}

