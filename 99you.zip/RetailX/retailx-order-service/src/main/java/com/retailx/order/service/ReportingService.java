package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Service for reporting and analytics.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReportingService {
    
    private final OrderRepository orderRepository;
    
    public Map<String, Object> getSalesReport(Long merchantId, LocalDateTime startDate, LocalDateTime endDate) {
        // Get all orders for the merchant (not deleted)
        Page<Order> allMerchantOrders = orderRepository.findByMerchantIdAndDeletedFalse(merchantId, Pageable.unpaged());
        
        // Filter by date range and exclude cancelled orders
        List<Order> validOrders = allMerchantOrders.getContent().stream()
                .filter(o -> {
                    // Check date range
                    boolean inDateRange = (startDate == null || !o.getCreatedOn().isBefore(startDate)) &&
                                        (endDate == null || !o.getCreatedOn().isAfter(endDate));
                    // Exclude cancelled orders
                    boolean notCancelled = o.getStatus() != OrderStatus.CANCELLED;
                    return inDateRange && notCancelled;
                })
                .toList();
        
        long totalOrders = validOrders.size();
        BigDecimal totalSales = validOrders.stream()
                .filter(o -> o.getStatus() != OrderStatus.RETURNED && o.getStatus() != OrderStatus.CANCELLED)
                .map(Order::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        BigDecimal totalRefunds = validOrders.stream()
                .filter(o -> o.getStatus() == OrderStatus.RETURNED)
                .map(Order::getTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        Map<String, Object> report = new HashMap<>();
        report.put("merchantId", merchantId);
        report.put("period", Map.of("start", startDate != null ? startDate.toString() : "N/A", 
                                    "end", endDate != null ? endDate.toString() : "N/A"));
        report.put("totalOrders", totalOrders);
        report.put("totalSales", totalSales);
        report.put("totalRefunds", totalRefunds);
        report.put("netSales", totalSales.subtract(totalRefunds));
        
        return report;
    }
    
    public Map<String, Long> getOrderStatusCounts(Long merchantId) {
        // Get all orders for the merchant (not deleted)
        Page<Order> allOrders = orderRepository.findByMerchantIdAndDeletedFalse(merchantId, Pageable.unpaged());
        
        Map<String, Long> counts = new HashMap<>();
        for (OrderStatus status : OrderStatus.values()) {
            long count = allOrders.getContent().stream()
                    .filter(o -> o.getStatus() == status)
                    .count();
            counts.put(status.name(), count);
        }
        return counts;
    }
}

