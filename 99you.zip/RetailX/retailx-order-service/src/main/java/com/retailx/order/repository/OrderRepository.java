package com.retailx.order.repository;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.enums.OrderStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Order entity.
 */
@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {
    
    Optional<Order> findByOrderNumberAndDeletedFalse(String orderNumber);
    
    Page<Order> findByCustomerIdAndDeletedFalse(Long customerId, Pageable pageable);
    
    Page<Order> findByMerchantIdAndDeletedFalse(Long merchantId, Pageable pageable);
    
    Page<Order> findByStatusAndDeletedFalse(OrderStatus status, Pageable pageable);
    
    List<Order> findByStatusAndCreatedOnBeforeAndDeletedFalse(OrderStatus status, LocalDateTime createdOn);
    
    @Query("SELECT o FROM Order o WHERE " +
           "(:customerId IS NULL OR o.customerId = :customerId) " +
           "AND (:status IS NULL OR o.status = :status) " +
           "AND (:startDate IS NULL OR o.createdOn >= :startDate) " +
           "AND (:endDate IS NULL OR o.createdOn <= :endDate) " +
           "AND (:minTotal IS NULL OR o.total >= :minTotal) " +
           "AND (:maxTotal IS NULL OR o.total <= :maxTotal) " +
           "AND o.deleted = false")
    Page<Order> searchOrders(
        @Param("customerId") Long customerId,
        @Param("status") OrderStatus status,
        @Param("startDate") LocalDateTime startDate,
        @Param("endDate") LocalDateTime endDate,
        @Param("minTotal") BigDecimal minTotal,
        @Param("maxTotal") BigDecimal maxTotal,
        Pageable pageable
    );
}

