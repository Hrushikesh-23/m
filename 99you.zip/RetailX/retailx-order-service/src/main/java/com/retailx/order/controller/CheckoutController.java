package com.retailx.order.controller;

import com.retailx.order.dto.request.CheckoutRequest;
import com.retailx.order.dto.response.CheckoutResponse;
import com.retailx.order.service.CheckoutService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for checkout operations.
 * Handles order creation from cart with idempotency support.
 */
@Slf4j
@RestController
@RequestMapping("/api/checkout")
@RequiredArgsConstructor
public class CheckoutController {
    
    private final CheckoutService checkoutService;
    
    /**
     * Process checkout - converts cart to order with idempotency support.
     * Only CUSTOMER or ADMIN can access.
     */
    @PostMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CheckoutResponse> checkout(
            @RequestHeader("X-User-Id") Long customerId,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey,
            @Valid @RequestBody CheckoutRequest request) {
        
        log.info("Processing checkout: customerId={}, idempotencyKey={}, shippingMethod={}", 
                customerId, idempotencyKey, request.getShippingMethod());
        CheckoutResponse response = checkoutService.checkout(customerId, request, idempotencyKey);
        log.info("Checkout completed successfully: orderNumber={}, orderId={}", 
                response.getOrderNumber(), response.getOrderId());
        return ResponseEntity.ok(response);
    }
}

