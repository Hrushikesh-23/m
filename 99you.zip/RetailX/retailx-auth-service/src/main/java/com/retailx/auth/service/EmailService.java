package com.retailx.auth.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Service for sending emails.
 */
@Slf4j
@Service
public class EmailService {
    
    private final JavaMailSender mailSender;
    
    @Autowired(required = false)
    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
        if (mailSender == null) {
            log.warn("JavaMailSender not configured - emails will be logged to console only");
        }
    }
    
    @Value("${spring.mail.username:noreply@retailx.com}")
    private String fromEmail;
    
    @Value("${email.notifications.enabled:false}")
    private boolean emailEnabled;
    
    @Value("${retailx.auth.password-reset.base-url:http://localhost:8080}")
    private String baseUrl;
    
    /**
     * Send password reset email with token.
     */
    public void sendPasswordResetEmail(String toEmail, String resetToken) {
        String subject = "Password Reset Request - RetailX";
        String resetUrl = baseUrl + "/api/auth/reset-password?token=" + resetToken;
        String message = String.format(
            "You have requested to reset your password.\n\n" +
            "Click the link below to reset your password:\n" +
            "%s\n\n" +
            "This link will expire in 1 hour.\n\n" +
            "If you did not request this password reset, please ignore this email.\n\n" +
            "Best regards,\n" +
            "RetailX Team",
            resetUrl);
        
        sendEmail(toEmail, subject, message);
    }
    
    /**
     * Send email notification.
     */
    private void sendEmail(String toEmail, String subject, String text) {
        if (!emailEnabled || mailSender == null) {
            log.info("=== EMAIL NOTIFICATION (Email disabled or not configured) ===");
            log.info("To: {}", toEmail);
            log.info("Subject: {}", subject);
            log.info("Message: {}", text);
            log.info("===============================================================");
            return;
        }
        
        try {
            SimpleMailMessage emailMessage = new SimpleMailMessage();
            emailMessage.setFrom(fromEmail);
            emailMessage.setTo(toEmail);
            emailMessage.setSubject(subject);
            emailMessage.setText(text);
            
            mailSender.send(emailMessage);
            log.info("Password reset email sent successfully to: {}", toEmail);
            
        } catch (Exception e) {
            log.error("Failed to send password reset email to: {}", toEmail, e);
            // Don't throw - email failure shouldn't break the flow
            // Log to console as fallback
            log.info("=== EMAIL NOTIFICATION (Email failed, logged to console) ===");
            log.info("To: {}", toEmail);
            log.info("Subject: {}", subject);
            log.info("Message: {}", text);
            log.info("=============================================================");
        }
    }
}

