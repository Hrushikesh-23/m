package com.retailx.payment.controller;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.service.PaymentService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PaymentController.
 */
@ExtendWith(MockitoExtension.class)
class PaymentControllerTest {
    
    @Mock
    private PaymentService paymentService;
    
    @InjectMocks
    private PaymentController paymentController;
    
    private PaymentIntent paymentIntent;
    
    @BeforeEach
    void setUp() {
        paymentIntent = PaymentIntent.builder()
                .id(1L)
                .orderId(1L)
                .amount(new BigDecimal("100.00"))
                .currency("USD")
                .status(PaymentStatus.PENDING)
                .build();
    }
    
    @Test
    void testCreatePaymentIntent_Success() {
        when(paymentService.createPaymentIntent(anyLong(), any(), anyString(), anyString()))
                .thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = paymentController.createPaymentIntent(
                1L, new BigDecimal("100.00"), "USD", "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getId());
        verify(paymentService, times(1)).createPaymentIntent(1L, new BigDecimal("100.00"), "USD", "idempotency-key-123");
    }
    
    @Test
    void testAuthorize_Success() {
        paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        when(paymentService.authorize(anyLong(), anyString())).thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = 
                paymentController.authorize(1L, "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(PaymentStatus.AUTHORIZED, response.getBody().getStatus());
        verify(paymentService, times(1)).authorize(1L, "idempotency-key-123");
    }
    
    @Test
    void testCapture_Success() {
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        when(paymentService.capture(anyLong(), anyString())).thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = 
                paymentController.capture(1L, "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(PaymentStatus.CAPTURED, response.getBody().getStatus());
        verify(paymentService, times(1)).capture(1L, "idempotency-key-123");
    }
    
    @Test
    void testRefund_Success() {
        paymentIntent.setStatus(PaymentStatus.REFUNDED);
        when(paymentService.refund(anyLong(), any(), anyString())).thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = 
                paymentController.refund(1L, new BigDecimal("50.00"), "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(PaymentStatus.REFUNDED, response.getBody().getStatus());
        verify(paymentService, times(1)).refund(1L, new BigDecimal("50.00"), "idempotency-key-123");
    }
    
    @Test
    void testRefundByOrderId_Success() {
        paymentIntent.setStatus(PaymentStatus.REFUNDED);
        when(paymentService.refundByOrderId(anyLong(), any(), anyString())).thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = 
                paymentController.refundByOrderId(1L, new BigDecimal("50.00"), "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(paymentService, times(1)).refundByOrderId(1L, new BigDecimal("50.00"), "idempotency-key-123");
    }
    
    @Test
    void testFailPayment_Success() {
        paymentIntent.setStatus(PaymentStatus.FAILED);
        paymentIntent.setErrorCode("PAYMENT_DECLINED");
        paymentIntent.setErrorMessage("Insufficient funds");
        when(paymentService.failPayment(anyLong(), anyString(), anyString(), anyString()))
                .thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = paymentController.failPayment(
                1L, "PAYMENT_DECLINED", "Insufficient funds", "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(PaymentStatus.FAILED, response.getBody().getStatus());
        verify(paymentService, times(1)).failPayment(1L, "PAYMENT_DECLINED", "Insufficient funds", "idempotency-key-123");
    }
    
    @Test
    void testFailPayment_WithDefaultValues() {
        paymentIntent.setStatus(PaymentStatus.FAILED);
        paymentIntent.setErrorCode("PAYMENT_FAILED");
        paymentIntent.setErrorMessage("Payment failed");
        when(paymentService.failPayment(anyLong(), anyString(), anyString(), anyString()))
                .thenReturn(paymentIntent);
        
        ResponseEntity<PaymentIntent> response = 
                paymentController.failPayment(1L, null, null, "idempotency-key-123");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(paymentService, times(1)).failPayment(1L, "PAYMENT_FAILED", "Payment failed", "idempotency-key-123");
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = paymentController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Payment Service is running", response.getBody());
    }
}

