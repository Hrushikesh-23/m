package com.retailx.payment.service;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;

import java.math.BigDecimal;
import java.util.concurrent.CompletableFuture;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PaymentService.
 */
@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
    
    @Mock
    private PaymentIntentRepository paymentIntentRepository;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @Mock
    private com.retailx.payment.service.OrderServiceClient orderServiceClient;
    
    @InjectMocks
    private PaymentService paymentService;
    
    private PaymentIntent paymentIntent;
    
    @BeforeEach
    void setUp() {
        paymentIntent = PaymentIntent.builder()
                .orderId(1L)
                .paymentIntentId("pi_test123")
                .amount(new BigDecimal("100.00"))
                .currency("USD")
                .status(PaymentStatus.PENDING)
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.payment.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(paymentIntent, 1L);
        } catch (Exception e) {
            // Ignore
        }
    }
    
    @Test
    void testCreatePaymentIntent_Success() {
        Map<String, Object> orderDetails = Map.of(
                "id", 1L,
                "status", "PENDING",
                "total", "100.00",
                "currency", "USD"
        );
        when(orderServiceClient.getOrderById(1L)).thenReturn(orderDetails);
        when(paymentIntentRepository.findByCorrelationId(anyString())).thenReturn(Optional.empty());
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenReturn(paymentIntent);
        // Mock Kafka send - only called if Kafka is used (may not be called in all paths)
        lenient().doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        PaymentIntent response = paymentService.createPaymentIntent(1L, new BigDecimal("100.00"), "USD", "corr-123");
        
        assertNotNull(response);
        assertEquals(PaymentStatus.PENDING, response.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testCreatePaymentIntent_AmountMismatch() {
        Map<String, Object> orderDetails = Map.of(
                "id", 1L,
                "status", "PENDING",
                "total", "150.00",
                "currency", "USD"
        );
        when(orderServiceClient.getOrderById(1L)).thenReturn(orderDetails);
        
        assertThrows(RuntimeException.class, () -> 
                paymentService.createPaymentIntent(1L, new BigDecimal("100.00"), "USD", "corr-123"));
        verify(paymentIntentRepository, never()).save(any(PaymentIntent.class));
    }
    
    @Test
    void testAuthorizePayment_Success() {
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenAnswer(invocation -> {
            PaymentIntent pi = invocation.getArgument(0);
            // Mock payment provider returns success for amounts < 1000
            if (pi.getAmount().compareTo(new BigDecimal("1000.00")) < 0) {
                pi.setStatus(PaymentStatus.AUTHORIZED);
            } else {
                pi.setStatus(PaymentStatus.FAILED);
            }
            return pi;
        });
        // Mock Kafka send - may be called if payment fails
        lenient().doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        PaymentIntent response = paymentService.authorize(1L, "corr-123");
        
        assertNotNull(response);
        // Status depends on mockPaymentProvider logic (amount < 1000 = success)
        assertTrue(response.getStatus() == PaymentStatus.AUTHORIZED || response.getStatus() == PaymentStatus.FAILED);
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testAuthorizePayment_AlreadyAuthorized() {
        paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        // Mock Kafka send - may or may not be called
        lenient().doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        // Payment is already authorized - should return existing without saving
        PaymentIntent response = paymentService.authorize(1L, "corr-123");
        assertNotNull(response);
        assertEquals(PaymentStatus.AUTHORIZED, response.getStatus());
        // Should not save since it's already authorized
        verify(paymentIntentRepository, never()).save(any(PaymentIntent.class));
    }
    
    @Test
    void testCapturePayment_Success() {
        paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenAnswer(invocation -> {
            PaymentIntent pi = invocation.getArgument(0);
            pi.setStatus(PaymentStatus.CAPTURED);
            return pi;
        });
        // Mock Kafka send - returns CompletableFuture<SendResult<String, String>>
        // Since the code doesn't await the future and handles exceptions, we can use doAnswer
        doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        PaymentIntent response = paymentService.capture(1L, "corr-123");
        
        assertNotNull(response);
        assertEquals(PaymentStatus.CAPTURED, response.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testFailPayment_Success() {
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenAnswer(invocation -> {
            PaymentIntent pi = invocation.getArgument(0);
            pi.setStatus(PaymentStatus.FAILED);
            return pi;
        });
        // Mock Kafka send - returns CompletableFuture<SendResult<String, String>>
        // Since the code doesn't await the future and handles exceptions, we can use doAnswer
        doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        PaymentIntent response = paymentService.failPayment(1L, "ERROR_CODE", "Error message", "corr-123");
        
        assertNotNull(response);
        assertEquals(PaymentStatus.FAILED, response.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testRefundPayment_Success() {
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        paymentIntent.setAmount(new BigDecimal("100.00"));
        paymentIntent.setTotalRefundedAmount(BigDecimal.ZERO);
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenAnswer(invocation -> {
            PaymentIntent pi = invocation.getArgument(0);
            return pi;
        });
        // Mock Kafka send - returns CompletableFuture<SendResult<String, String>>
        // Since the code doesn't await the future and handles exceptions, we can use doAnswer
        doAnswer(invocation -> CompletableFuture.completedFuture(mock(SendResult.class)))
                .when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        PaymentIntent response = paymentService.refund(1L, new BigDecimal("50.00"), "corr-123");
        
        assertNotNull(response);
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testRefundPayment_ExceedsCaptured() {
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        paymentIntent.setAmount(new BigDecimal("100.00"));
        paymentIntent.setTotalRefundedAmount(BigDecimal.ZERO);
        when(paymentIntentRepository.findById(1L)).thenReturn(Optional.of(paymentIntent));
        
        assertThrows(RuntimeException.class, () -> 
                paymentService.refund(1L, new BigDecimal("150.00"), "corr-123"));
        verify(paymentIntentRepository, never()).save(any(PaymentIntent.class));
    }
}
