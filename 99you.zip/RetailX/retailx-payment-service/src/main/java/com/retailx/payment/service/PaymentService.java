package com.retailx.payment.service;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

/**
 * Payment processing.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {
    
    private final PaymentIntentRepository paymentIntentRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final OrderServiceClient orderServiceClient;
    private final Random random = new Random();
    
    @Transactional
    public PaymentIntent createPaymentIntent(Long orderId, BigDecimal amount, String currency, String correlationId) {
        log.info("Creating payment intent: orderId={}, amount={}, correlationId={}", 
                orderId, amount, correlationId);
        
        // Validate order exists and is in valid state
        try {
            Map<String, Object> orderDetails = orderServiceClient.getOrderById(orderId);
            if (orderDetails == null) {
                throw new RuntimeException("Order not found: " + orderId);
            }
            
            // Validate order status
            String orderStatus = orderDetails.get("status") != null ? 
                    orderDetails.get("status").toString() : "";
            if ("CANCELLED".equals(orderStatus) || "RETURNED".equals(orderStatus)) {
                throw new RuntimeException(
                    String.format("Cannot create payment intent for order in %s status", orderStatus));
            }
            
            // Validate payment amount matches order total
            if (orderDetails.containsKey("total")) {
                BigDecimal orderTotal = new BigDecimal(orderDetails.get("total").toString());
                if (amount.compareTo(orderTotal) != 0) {
                    throw new RuntimeException(
                        String.format("Payment amount (%.2f) must exactly match order total (%.2f). Payment intent creation rejected.", 
                            amount.doubleValue(), orderTotal.doubleValue()));
                }
                log.info("Payment amount validated: amount={} matches order total={}", amount, orderTotal);
            } else {
                log.warn("Could not fetch order total for validation, proceeding without validation");
            }
            
            // Validate currency matches order currency (if available)
            if (orderDetails.containsKey("currency")) {
                String orderCurrency = orderDetails.get("currency").toString();
                if (!currency.equals(orderCurrency)) {
                    throw new RuntimeException(
                        String.format("Payment currency (%s) must match order currency (%s)", 
                            currency, orderCurrency));
                }
            }
        } catch (RuntimeException e) {
            if (e.getMessage() != null && (e.getMessage().contains("must exactly match") || 
                    e.getMessage().contains("must match") || e.getMessage().contains("Cannot create"))) {
                throw e; // Re-throw validation errors
            }
            log.warn("Failed to validate payment intent creation: {}. Proceeding without validation.", e.getMessage());
        }
        
        // Check idempotency
        if (correlationId != null) {
            PaymentIntent existing = paymentIntentRepository.findByCorrelationId(correlationId)
                    .orElse(null);
            if (existing != null) {
                log.info("Idempotent payment intent creation, returning existing: {}", existing.getId());
                return existing;
            }
        }
        
        PaymentIntent paymentIntent = PaymentIntent.builder()
                .orderId(orderId)
                .paymentIntentId("pi_" + UUID.randomUUID().toString().replace("-", ""))
                .amount(amount)
                .currency(currency)
                .status(PaymentStatus.PENDING)
                .correlationId(correlationId)
                .build();
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "authorizeFallback")
    @Retry(name = "paymentService")
    public PaymentIntent authorize(Long paymentIntentId, String correlationId) {
        log.info("Authorizing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() == PaymentStatus.AUTHORIZED 
                || paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already authorized/captured, returning existing payment intent");
            return paymentIntent;
        }
        
        // Must be in PENDING state to authorize
        if (paymentIntent.getStatus() != PaymentStatus.PENDING) {
            throw new RuntimeException(
                String.format("Payment must be in PENDING state to authorize. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Cannot authorize if already in terminal states
        if (paymentIntent.getStatus() == PaymentStatus.FAILED) {
            throw new RuntimeException("Cannot authorize a failed payment. Please create a new payment intent.");
        }
        
        if (paymentIntent.getStatus() == PaymentStatus.REFUNDED 
                || paymentIntent.getStatus() == PaymentStatus.PARTIALLY_REFUNDED) {
            throw new RuntimeException("Cannot authorize a refunded payment. Please create a new payment intent.");
        }
        
        // Mock payment provider - simulate success/failure
        boolean success = mockPaymentProvider(paymentIntent.getAmount());
        
        if (success) {
            paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        } else {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_DECLINED");
            paymentIntent.setErrorMessage("Payment was declined by the provider");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                paymentIntent.getErrorCode(), paymentIntent.getErrorMessage()));
            } catch (Exception e) {
                log.warn("Failed to send Kafka event for payment failure: {}", e.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "captureFallback")
    @Retry(name = "paymentService")
    public PaymentIntent capture(Long paymentIntentId, String correlationId) {
        log.info("Capturing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already captured");
            return paymentIntent;
        }
        
        if (paymentIntent.getStatus() != PaymentStatus.AUTHORIZED) {
            throw new RuntimeException(
                String.format("Payment must be AUTHORIZED before capture. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        paymentIntent = paymentIntentRepository.save(paymentIntent);
        
        // Publish payment captured event (non-blocking)
        try {
            kafkaTemplate.send("payment.captured", String.valueOf(paymentIntent.getOrderId()),
                    String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"amount\":%s,\"currency\":\"%s\"}",
                            paymentIntent.getId(), paymentIntent.getOrderId(),
                            paymentIntent.getAmount(), paymentIntent.getCurrency()));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for payment capture: {}", e.getMessage());
        }
        
        // Synchronously update order status to PAID (fallback if Kafka fails)
        try {
            // Call Order Service directly to update status
            // This ensures order status is updated even if Kafka fails
            // Note: This requires OrderServiceClient - will be added if needed
            log.info("Payment captured, order status should be updated via Kafka event");
        } catch (Exception e) {
            log.warn("Failed to synchronously update order status: {}", e.getMessage());
            // Continue - Kafka event will handle it
        }
        
        return paymentIntent;
    }
    
    @Transactional
    public PaymentIntent refund(Long paymentIntentId, BigDecimal amount, String correlationId) {
        log.info("Refunding payment: paymentIntentId={}, amount={}, correlationId={}", 
                paymentIntentId, amount, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() != PaymentStatus.CAPTURED 
                && paymentIntent.getStatus() != PaymentStatus.PARTIALLY_REFUNDED) {
            throw new RuntimeException(
                String.format("Payment must be CAPTURED or PARTIALLY_REFUNDED before refund. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Cannot refund if already fully refunded
        if (paymentIntent.getStatus() == PaymentStatus.REFUNDED) {
            throw new RuntimeException("Payment is already fully refunded. Cannot refund again.");
        }
        
        // Validate refund amount doesn't exceed captured amount minus already refunded
        BigDecimal maxRefundable = paymentIntent.getAmount().subtract(paymentIntent.getTotalRefundedAmount());
        if (amount.compareTo(maxRefundable) > 0) {
            throw new RuntimeException(
                String.format("Refund amount (%.2f) exceeds refundable amount (%.2f). " +
                        "Total refunded: %.2f, Payment amount: %.2f", 
                        amount.doubleValue(), maxRefundable.doubleValue(),
                        paymentIntent.getTotalRefundedAmount().doubleValue(), 
                        paymentIntent.getAmount().doubleValue()));
        }
        
        // Update total refunded amount
        paymentIntent.setTotalRefundedAmount(paymentIntent.getTotalRefundedAmount().add(amount));
        
        // Update status based on refund amount
        if (paymentIntent.getTotalRefundedAmount().compareTo(paymentIntent.getAmount()) >= 0) {
            paymentIntent.setStatus(PaymentStatus.REFUNDED);
            paymentIntent.setTotalRefundedAmount(paymentIntent.getAmount()); // Cap at payment amount
        } else {
            paymentIntent.setStatus(PaymentStatus.PARTIALLY_REFUNDED);
        }
        
        paymentIntent = paymentIntentRepository.save(paymentIntent);
        
        // Publish payment refunded event (non-blocking)
        try {
            kafkaTemplate.send("payment.refunded", String.valueOf(paymentIntent.getOrderId()),
                    String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"refundAmount\":%s,\"currency\":\"%s\"}",
                            paymentIntent.getId(), paymentIntent.getOrderId(),
                            amount, paymentIntent.getCurrency()));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for payment refund: {}", e.getMessage());
        }
        
        return paymentIntent;
    }
    
    /**
     * Refund payment by order ID - finds the payment intent for the order and processes refund.
     */
    @Transactional
    public PaymentIntent refundByOrderId(Long orderId, BigDecimal amount, String correlationId) {
        log.info("Refunding payment by orderId: orderId={}, amount={}, correlationId={}", 
                orderId, amount, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findByOrderId(orderId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found for order: " + orderId));
        
        // Use the existing refund method
        return refund(paymentIntent.getId(), amount, correlationId);
    }
    
    /**
     * Mark a payment as failed - allows explicit failure marking.
     */
    @Transactional
    public PaymentIntent failPayment(Long paymentIntentId, String errorCode, String errorMessage, String correlationId) {
        log.info("Marking payment as failed: paymentIntentId={}, errorCode={}, errorMessage={}, correlationId={}", 
                paymentIntentId, errorCode, errorMessage, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        // Can only fail if in PENDING or AUTHORIZED state
        if (paymentIntent.getStatus() != PaymentStatus.PENDING 
                && paymentIntent.getStatus() != PaymentStatus.AUTHORIZED) {
            throw new RuntimeException(
                String.format("Cannot mark payment as failed. Payment must be PENDING or AUTHORIZED. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        paymentIntent.setStatus(PaymentStatus.FAILED);
        paymentIntent.setErrorCode(errorCode);
        paymentIntent.setErrorMessage(errorMessage);
        paymentIntent = paymentIntentRepository.save(paymentIntent);
        
        // Publish payment failed event (non-blocking)
        try {
            kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                    String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                            paymentIntent.getId(), paymentIntent.getOrderId(),
                            errorCode, errorMessage));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for payment failure: {}", e.getMessage());
        }
        
        return paymentIntent;
    }
    
    private boolean mockPaymentProvider(BigDecimal amount) {
        // Simulate 90% success rate
        // Simulate timeout for large amounts (>1000)
        if (amount.compareTo(new BigDecimal("1000")) > 0) {
            // 50% chance of timeout for large amounts
            if (random.nextDouble() < 0.5) {
                throw new RuntimeException("PAYMENT_PROVIDER_TIMEOUT");
            }
        }
        
        // 10% decline rate
        return random.nextDouble() > 0.1;
    }
    
    private PaymentIntent authorizeFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment authorization failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Only set to FAILED if not already in a terminal state
        if (paymentIntent.getStatus() != PaymentStatus.FAILED 
                && paymentIntent.getStatus() != PaymentStatus.CAPTURED 
                && paymentIntent.getStatus() != PaymentStatus.REFUNDED) {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
            paymentIntent.setErrorMessage("Payment provider unavailable");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                "PAYMENT_PROVIDER_TIMEOUT", "Payment provider unavailable"));
            } catch (Exception ex) {
                log.warn("Failed to send Kafka event for payment failure: {}", ex.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    private PaymentIntent captureFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment capture failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Only set to FAILED if currently AUTHORIZED (can't capture)
        if (paymentIntent.getStatus() == PaymentStatus.AUTHORIZED) {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
            paymentIntent.setErrorMessage("Payment provider unavailable");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                "PAYMENT_PROVIDER_TIMEOUT", "Payment provider unavailable"));
            } catch (Exception ex) {
                log.warn("Failed to send Kafka event for payment failure: {}", ex.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
}

