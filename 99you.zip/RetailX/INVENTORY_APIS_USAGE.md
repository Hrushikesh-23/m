# Inventory APIs Usage Guide

## Overview
The Inventory Service provides three main APIs for managing inventory: Reserve, Adjust, and Get Low Stock. This document explains when and how each API is used.

---

## 1. Reserve Inventory (`POST /api/inventory/reserve`)

### Purpose
**Reserves inventory items for an order during checkout.** This prevents other customers from purchasing items that are already allocated to a pending order.

### When is it used?
- **During Checkout Process**: When a customer completes checkout, the Order Service calls this API to reserve the items in their cart
- **Before Order Creation**: Inventory is reserved BEFORE the order is created to ensure items are available
- **Automatic Process**: This is called internally by the Order Service, not directly by customers

### How it works:
1. Customer adds items to cart
2. Customer proceeds to checkout
3. Order Service calls `POST /api/inventory/reserve` for each item in the cart
4. If reservation succeeds → Order is created
5. If reservation fails → Checkout fails with "Insufficient inventory" error

### Example Flow:
```
Customer Checkout Request
  ↓
Order Service: CheckoutService.checkout()
  ↓
For each cart item:
  Order Service → Inventory Service: POST /api/inventory/reserve
    - sku: "PROD-001"
    - quantity: 2
    - warehouseId: "WH-001"
  ↓
If all reservations succeed:
  Order created with status PENDING
  Cart cleared
```

### Parameters:
- `sku` (String): Product SKU identifier
- `quantity` (BigInteger): Number of items to reserve
- `warehouseId` (String): Warehouse identifier (e.g., "WH-001", "default-warehouse")

### Response:
- `true`: Inventory successfully reserved
- `false`: Insufficient inventory available

---

## 2. Adjust Inventory (`POST /api/inventory/adjust`)

### Purpose
**Manually adjust inventory quantities** for restocking, corrections, or return processing.

### When is it used?

#### A. **Return Processing** (Automatic)
- When a return is approved, the Order Service automatically calls this API to restock items
- Example: Customer returns 2 items → Inventory is adjusted by +2

#### B. **Manual Restocking** (Manual - OPS/ADMIN)
- Warehouse staff receives new stock
- OPS/ADMIN manually adjusts inventory to reflect new stock levels
- Example: Received 100 units → Adjust inventory by +100

#### C. **Inventory Corrections** (Manual - OPS/ADMIN)
- Fix discrepancies found during inventory audits
- Correct data entry errors
- Example: Found 5 extra units → Adjust by +5

### Who can use it?
- **OPS**: Operations team for daily inventory management
- **ADMIN**: Administrators for system-wide adjustments
- **MERCHANT**: Only when approving returns (automatic via ReturnService)

### Example Flow (Return Approval):
```
MERCHANT approves return
  ↓
ReturnService.approveReturn()
  ↓
Order Service → Inventory Service: POST /api/inventory/adjust
    - sku: "PROD-001"
    - warehouseId: "WH-001"
    - quantity: +2 (positive for restocking)
  ↓
Inventory restocked
Order status → RETURNED
Refund processed
```

### Parameters:
- `sku` (String): Product SKU identifier
- `warehouseId` (String): Warehouse identifier
- `quantity` (BigInteger): 
  - **Positive value** (+10): Add inventory (restocking)
  - **Negative value** (-5): Remove inventory (correction)

### Important Notes:
- This API **adds** the quantity to existing inventory
- Use positive values to increase stock
- Use negative values to decrease stock
- Only OPS/ADMIN can manually call this API
- MERCHANT can only trigger it indirectly through return approval

---

## 3. Get Low Stock Items (`GET /api/inventory/low-stock`)

### Purpose
**Get a list of products that are running low on inventory** to help merchants and operations team manage stock levels.

### When is it used?
- **Daily Operations**: OPS team checks low stock items to plan restocking
- **Merchant Dashboard**: Merchants view their low stock items
- **Inventory Alerts**: Can be integrated into monitoring systems
- **Restocking Planning**: Before placing orders with suppliers

### Who can use it?
- **MERCHANT**: View low stock items for their products
- **ADMIN**: View all low stock items across all merchants
- **OPS**: View all low stock items for warehouse management

### How it works:
1. System checks all inventory items
2. Compares `available` quantity against threshold (typically 10 units)
3. Returns list of items where `available < threshold`

### Example Response:
```json
[
  {
    "id": 1,
    "sku": "PROD-001",
    "warehouseId": "WH-001",
    "onHand": 15,
    "reserved": 8,
    "available": 7,
    "lowStockThreshold": 10
  },
  {
    "id": 2,
    "sku": "PROD-002",
    "warehouseId": "WH-001",
    "onHand": 5,
    "reserved": 2,
    "available": 3,
    "lowStockThreshold": 10
  }
]
```

### Use Cases:
1. **Restocking Workflow**:
   ```
   OPS checks low stock → Identifies items → Places order with supplier → Adjusts inventory
   ```

2. **Merchant Alerts**:
   ```
   Merchant views dashboard → Sees low stock items → Decides to restock or discontinue
   ```

3. **Automated Notifications**:
   ```
   System monitors inventory → Detects low stock → Sends alert to merchant/OPS
   ```

---

## Summary Table

| API | Purpose | When Used | Who Uses It | Automatic/Manual |
|-----|---------|-----------|--------------|------------------|
| **Reserve Inventory** | Reserve items for order | During checkout | Order Service (internal) | Automatic |
| **Adjust Inventory** | Change inventory quantity | Returns, restocking, corrections | OPS, ADMIN, MERCHANT (returns only) | Both |
| **Get Low Stock** | View low stock items | Daily operations, planning | MERCHANT, ADMIN, OPS | Manual |

---

## Common Workflows

### Workflow 1: Customer Purchase
```
1. Customer adds items to cart
2. Customer checks out
3. Reserve Inventory API called (automatic)
4. Order created
5. Payment processed
6. Order shipped
```

### Workflow 2: Return Processing
```
1. Customer requests return
2. MERCHANT approves return
3. Adjust Inventory API called (automatic, +quantity)
4. Order status → RETURNED
5. Refund processed
```

### Workflow 3: Restocking
```
1. OPS checks Get Low Stock API
2. Identifies items to restock
3. Receives new stock from supplier
4. Adjust Inventory API called (manual, +quantity)
5. Inventory updated
```

---

## Best Practices

1. **Reserve Inventory**: Always reserve before creating order to prevent overselling
2. **Adjust Inventory**: Use positive values for restocking, negative for corrections
3. **Get Low Stock**: Check regularly (daily/weekly) to maintain optimal stock levels
4. **Error Handling**: Always check reservation result before proceeding with order creation
5. **Idempotency**: Use idempotency keys for critical operations to prevent duplicates

