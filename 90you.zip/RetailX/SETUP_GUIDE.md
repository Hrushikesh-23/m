# RetailX Setup Guide

## Prerequisites Installation

### 1. Java 21 JDK
- Download from: https://adoptium.net/temurin/releases/?version=21
- Or: https://www.oracle.com/java/technologies/downloads/#java21
- Verify: `java -version`

### 2. Maven 3.8+
- Download from: https://maven.apache.org/download.cgi
- Add to PATH
- Verify: `mvn -version`

### 3. MySQL 8.0+
- Download from: https://dev.mysql.com/downloads/mysql/
- Or use Docker: `docker run -d -p 3306:3306 -e MYSQL_ROOT_PASSWORD=root mysql:8.0`
- Create databases:
  ```sql
  CREATE DATABASE retailx_auth;
  CREATE DATABASE retailx_product;
  CREATE DATABASE retailx_order;
  CREATE DATABASE retailx_payment;
  CREATE DATABASE retailx_inventory;
  ```

### 4. Docker Desktop (Optional but Recommended)
- Download from: https://www.docker.com/products/docker-desktop
- Used for: MySQL, Kafka, Zookeeper

### 5. Kafka (If not using Docker)
- Download from: https://kafka.apache.org/downloads
- Start Zookeeper: `bin/zookeeper-server-start.sh config/zookeeper.properties`
- Start Kafka: `bin/kafka-server-start.sh config/server.properties`

## Quick Start with Docker

1. **Start Infrastructure Services:**
   ```bash
   docker-compose up -d
   ```
   This starts MySQL, Zookeeper, and Kafka.

2. **Build All Services:**
   ```bash
   mvn clean install
   ```

3. **Start Services in Order:**
   
   **Terminal 1 - Eureka Server:**
   ```bash
   cd retailx-eureka-server
   mvn spring-boot:run
   ```
   Wait for: "Started EurekaServerApplication" (Port 8761)
   
   **Terminal 2 - API Gateway:**
   ```bash
   cd retailx-api-gateway
   mvn spring-boot:run
   ```
   (Port 8080)
   
   **Terminal 3 - Auth Service:**
   ```bash
   cd retailx-auth-service
   mvn spring-boot:run
   ```
   (Port 8081)
   
   **Terminal 4 - Product Service:**
   ```bash
   cd retailx-product-service
   mvn spring-boot:run
   ```
   (Port 8082)
   
   **Terminal 5 - Order Service:**
   ```bash
   cd retailx-order-service
   mvn spring-boot:run
   ```
   (Port 8083)
   
   **Terminal 6 - Payment Service:**
   ```bash
   cd retailx-payment-service
   mvn spring-boot:run
   ```
   (Port 8084)
   
   **Terminal 7 - Inventory Service:**
   ```bash
   cd retailx-inventory-service
   mvn spring-boot:run
   ```
   (Port 8085)
   
   **Terminal 8 - Frontend Service:**
   ```bash
   cd retailx-frontend-service
   mvn spring-boot:run
   ```
   (Port 8087)

## Service URLs

- **Eureka Dashboard:** http://localhost:8761
- **API Gateway:** http://localhost:8080
- **Auth Service:** http://localhost:8081
- **Product Service:** http://localhost:8082
- **Order Service:** http://localhost:8083
- **Payment Service:** http://localhost:8084
- **Inventory Service:** http://localhost:8085
- **Frontend Service:** http://localhost:8087

## API Endpoints (via Gateway)

- **Register:** POST http://localhost:8080/api/auth/register
- **Login:** POST http://localhost:8080/api/auth/login
- **Products:** GET http://localhost:8080/api/products
- **Orders:** GET http://localhost:8080/api/orders

## Default Credentials

- **Admin:** admin@retailx.com / Admin@123

## Testing

```bash
# Run all tests
mvn test

# Run tests for specific service
cd retailx-auth-service
mvn test

# Generate coverage report
mvn test jacoco:report
```

## Troubleshooting

### Port Already in Use
- Change port in `application.yml` of the service
- Or stop the service using that port

### Database Connection Failed
- Ensure MySQL is running: `docker ps` or check MySQL service
- Verify credentials in `application.yml`
- Check database exists: `SHOW DATABASES;`

### Kafka Connection Failed
- Ensure Zookeeper and Kafka are running
- Check `docker ps` for containers
- Verify Kafka port 9092 is accessible

### Service Not Registering with Eureka
- Ensure Eureka Server is running first
- Check service `application.yml` has correct Eureka URL
- Wait 30-60 seconds for registration

## Development Tips

1. **Use IDE:** Import as Maven project in IntelliJ IDEA or Eclipse
2. **Hot Reload:** Use Spring Boot DevTools (add dependency)
3. **Logs:** Check `logs/` directory or console output
4. **Database:** Use MySQL Workbench or DBeaver for database inspection

