package com.retailx.auth.service;

import com.retailx.auth.domain.User;
import com.retailx.auth.domain.enums.Role;
import com.retailx.auth.dto.request.LoginRequest;
import com.retailx.auth.dto.request.RegisterRequest;
import com.retailx.auth.repository.UserRepository;
import com.retailx.auth.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for AuthService.
 */
@ExtendWith(MockitoExtension.class)
class AuthServiceTest {
    
    @Mock
    private UserRepository userRepository;
    
    @Mock
    private PasswordEncoder passwordEncoder;
    
    @Mock
    private JwtUtil jwtUtil;
    
    @InjectMocks
    private AuthService authService;
    
    private User testUser;
    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;
    
    @BeforeEach
    void setUp() {
        Set<Role> roles = new HashSet<>();
        roles.add(Role.CUSTOMER);
        
        testUser = User.builder()
                .email("test@example.com")
                .passwordHash("$2a$10$hashed")
                .roles(roles)
                .active(true)
                .build();
        // Set ID using reflection since it's inherited from BaseEntity
        try {
            java.lang.reflect.Field idField = com.retailx.auth.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(testUser, 1L);
        } catch (Exception e) {
            // Ignore if reflection fails
        }
        
        registerRequest = new RegisterRequest();
        registerRequest.setEmail("newuser@example.com");
        registerRequest.setPassword("Password@123");
        registerRequest.setName("New User");
        registerRequest.setRole("CUSTOMER");
        
        loginRequest = new LoginRequest();
        loginRequest.setEmail("test@example.com");
        loginRequest.setPassword("Password@123");
    }
    
    @Test
    void testRegister_Success() {
        when(userRepository.existsByEmailAndDeletedFalse(registerRequest.getEmail()))
                .thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("$2a$10$hashed");
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        when(jwtUtil.generateToken(anyLong(), anyString(), any())).thenReturn("token123");
        when(jwtUtil.getExpirationDateFromToken(anyString())).thenReturn(new java.util.Date(System.currentTimeMillis() + 3600000));
        
        var response = authService.register(registerRequest);
        
        assertNotNull(response);
        assertNotNull(response.getToken());
        verify(userRepository, times(1)).save(any(User.class));
    }
    
    @Test
    void testRegister_DuplicateEmail() {
        when(userRepository.existsByEmailAndDeletedFalse(registerRequest.getEmail()))
                .thenReturn(true);
        
        assertThrows(RuntimeException.class, () -> {
            authService.register(registerRequest);
        });
    }
    
    @Test
    void testLogin_Success() {
        when(userRepository.findActiveByEmail(loginRequest.getEmail()))
                .thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches(loginRequest.getPassword(), testUser.getPasswordHash()))
                .thenReturn(true);
        when(userRepository.save(any(User.class))).thenReturn(testUser);
        when(jwtUtil.generateToken(anyLong(), anyString(), any())).thenReturn("token123");
        when(jwtUtil.getExpirationDateFromToken(anyString())).thenReturn(new java.util.Date(System.currentTimeMillis() + 3600000));
        
        var response = authService.login(loginRequest);
        
        assertNotNull(response);
        assertNotNull(response.getToken());
        verify(userRepository, times(1)).save(any(User.class));
    }
    
    @Test
    void testLogin_InvalidCredentials() {
        when(userRepository.findActiveByEmail(loginRequest.getEmail()))
                .thenReturn(Optional.of(testUser));
        when(passwordEncoder.matches(loginRequest.getPassword(), testUser.getPasswordHash()))
                .thenReturn(false);
        
        assertThrows(RuntimeException.class, () -> {
            authService.login(loginRequest);
        });
    }
}

