package com.retailx.order.controller;

import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Order management endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {
    
    private final OrderService orderService;
    
    /**
     * Get order by ID.
     */
    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id) {
        log.info("Getting order: {}", id);
        OrderResponse response = orderService.getOrderById(id);
        log.debug("Order {} status: {}", response.getOrderNumber(), response.getStatus());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get order by order number.
     */
    @GetMapping("/number/{orderNumber}")
    public ResponseEntity<OrderResponse> getOrderByNumber(@PathVariable String orderNumber) {
        log.info("Getting order: {}", orderNumber);
        OrderResponse response = orderService.getOrderByNumber(orderNumber);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get customer orders.
     */
    @GetMapping("/customer")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Page<OrderResponse>> getCustomerOrders(
            @RequestHeader("X-User-Id") Long customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Getting orders for customer: {} page={}", customerId, page);
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderResponse> response = orderService.getOrdersByCustomer(customerId, pageable);
        log.debug("Found {} orders", response.getTotalElements());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get merchant orders.
     */
    @GetMapping("/merchant")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<Page<OrderResponse>> getMerchantOrders(
            @RequestHeader("X-User-Id") Long merchantId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Getting orders for merchant: {} page={}", merchantId, page);
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderResponse> response = orderService.getOrdersByMerchant(merchantId, pageable);
        log.debug("Found {} orders", response.getTotalElements());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Update order status.
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<OrderResponse> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam OrderStatus status,
            @RequestHeader("X-User-Id") String actorId,
            @RequestHeader(value = "X-User-Role", required = false) String userRole,
            @RequestParam(required = false) String reason) {
        log.info("Updating order {} to {} by {} ({})", id, status, actorId, userRole);
        
        OrderResponse order = orderService.getOrderById(id);
        validateOrderStatusUpdateAuthorization(order, status, Long.parseLong(actorId), userRole);
        
        OrderResponse response = orderService.updateOrderStatus(id, status, actorId, reason);
        log.info("Order {} status updated to {}", id, status);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Cancel an order - accessible to authenticated users (ownership checked in service).
     */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<OrderResponse> cancelOrder(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String actorId,
            @RequestHeader(value = "X-User-Role", required = false) String userRole,
            @RequestParam(required = false) String reason) {
        log.info("Cancelling order: orderId={}, actor={}, role={}, reason={}", id, actorId, userRole, reason);
        
        // Validate authorization: Only CUSTOMER can cancel their own order (before payment)
        // ADMIN/OPS can cancel any order
        OrderResponse order = orderService.getOrderById(id);
        if (userRole == null || !userRole.contains("ADMIN") && !userRole.contains("OPS")) {
            if (!order.getCustomerId().equals(Long.parseLong(actorId))) {
                throw new RuntimeException("Only order owner, ADMIN, or OPS can cancel orders");
            }
        }
        
        OrderResponse response = orderService.cancelOrder(id, actorId, reason);
        log.info("Order {} cancelled", id);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get order history for customer - accessible to CUSTOMER or ADMIN.
     */
    @GetMapping("/history")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Page<OrderResponse>> getOrderHistory(
            @RequestHeader("X-User-Id") Long customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Fetching order history for customer: {}, page={}, size={}", customerId, page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderResponse> response = orderService.getOrdersByCustomer(customerId, pageable);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get audit log for an order - accessible to authenticated users who own the order or have admin/ops role.
     */
    @GetMapping("/{id}/audit")
    public ResponseEntity<List<com.retailx.order.domain.AuditLog>> getOrderAuditLog(@PathVariable Long id) {
        log.info("Fetching audit log for order: {}", id);
        List<com.retailx.order.domain.AuditLog> auditLog = orderService.getOrderAuditLog(id);
        return ResponseEntity.ok(auditLog);
    }
    
    /**
     * Validate authorization for order status updates.
     */
    private void validateOrderStatusUpdateAuthorization(OrderResponse order, OrderStatus newStatus, 
                                                       Long actorId, String userRole) {
        // Only MERCHANT/OPS/ADMIN can mark as SHIPPED
        if (newStatus == OrderStatus.SHIPPED) {
            if (userRole == null || (!userRole.contains("MERCHANT") && !userRole.contains("OPS") 
                    && !userRole.contains("ADMIN"))) {
                throw new RuntimeException("Only MERCHANT, OPS, or ADMIN can mark order as SHIPPED");
            }
        }
        
        // Only OPS/ADMIN can mark as DELIVERED
        if (newStatus == OrderStatus.DELIVERED) {
            if (userRole == null || (!userRole.contains("OPS") && !userRole.contains("ADMIN"))) {
                throw new RuntimeException("Only OPS or ADMIN can mark order as DELIVERED");
            }
        }
        
        // Only MERCHANT/OPS/ADMIN can approve returns (status change to RETURNED)
        if (newStatus == OrderStatus.RETURNED) {
            if (userRole == null || (!userRole.contains("MERCHANT") && !userRole.contains("OPS") 
                    && !userRole.contains("ADMIN"))) {
                throw new RuntimeException("Only MERCHANT, OPS, or ADMIN can mark order as RETURNED");
            }
        }
        
        // CUSTOMER can only cancel their own order (handled in cancelOrder method)
        // For other status changes, CUSTOMER is not allowed
        if (newStatus != OrderStatus.CANCELLED && 
            (userRole == null || userRole.contains("CUSTOMER") && !userRole.contains("ADMIN"))) {
            // Allow if it's their own order and status is appropriate
            if (!order.getCustomerId().equals(actorId)) {
                throw new RuntimeException("Only order owner, MERCHANT, OPS, or ADMIN can update order status");
            }
        }
    }
}

