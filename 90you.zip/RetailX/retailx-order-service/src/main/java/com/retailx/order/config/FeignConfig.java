package com.retailx.order.config;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Feign client configuration.
 */
@Slf4j
@Configuration
@EnableFeignClients(basePackages = "com.retailx.order.service")
public class FeignConfig {
    
    /**
     * Request interceptor to forward headers from incoming request to Feign client calls.
     * This ensures service-to-service calls include authentication headers.
     */
    @Bean
    public RequestInterceptor requestInterceptor() {
        return new RequestInterceptor() {
            @Override
            public void apply(RequestTemplate template) {
                ServletRequestAttributes attributes = 
                    (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                
                if (attributes != null) {
                    HttpServletRequest request = attributes.getRequest();
                    
                    // Forward authentication headers
                    String userId = request.getHeader("X-User-Id");
                    String userEmail = request.getHeader("X-User-Email");
                    String userRole = request.getHeader("X-User-Role");
                    String authorization = request.getHeader("Authorization");
                    
                    if (userId != null) {
                        template.header("X-User-Id", userId);
                    }
                    if (userEmail != null) {
                        template.header("X-User-Email", userEmail);
                    }
                    if (userRole != null) {
                        template.header("X-User-Role", userRole);
                    }
                    if (authorization != null) {
                        template.header("Authorization", authorization);
                    }
                    
                    // If no headers from request, try to get from SecurityContext
                    if (userId == null) {
                        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
                        if (authentication != null && authentication.isAuthenticated()) {
                            String principal = authentication.getName();
                            template.header("X-User-Id", principal);
                            
                            // Get roles from authorities
                            String roles = authentication.getAuthorities().stream()
                                .map(auth -> auth.getAuthority().replace("ROLE_", ""))
                                .reduce((a, b) -> a + "," + b)
                                .orElse("");
                            if (!roles.isEmpty()) {
                                template.header("X-User-Role", roles);
                            }
                        }
                    }
                    
                    // Special handling: For inventory adjustment calls from ReturnService,
                    // if the user is MERCHANT, we need OPS role for inventory operations
                    // Check if this is an inventory adjust call and user is MERCHANT
                    if (userRole != null && userRole.contains("MERCHANT")) {
                        // Check if this is an inventory service call
                        String requestUrl = request != null ? request.getRequestURI() : "";
                        if (requestUrl.contains("/api/returns") || 
                            (template.url() != null && template.url().contains("/api/inventory/adjust"))) {
                            // Add OPS role for inventory operations (MERCHANT can approve returns but needs OPS for inventory)
                            String enhancedRoles = userRole + ",OPS";
                            template.header("X-User-Role", enhancedRoles);
                        }
                    }
                    
                    // Special handling for inventory service calls from ReturnService
                    // If calling inventory service and user is MERCHANT, also include OPS role for inventory operations
                    if (template.url().contains("/api/inventory/adjust") && userRole != null && userRole.contains("MERCHANT")) {
                        // Keep MERCHANT role but add OPS for inventory operations
                        String enhancedRoles = userRole + ",OPS";
                        template.header("X-User-Role", enhancedRoles);
                    }
                }
            }
        };
    }
}

