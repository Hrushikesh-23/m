package com.retailx.order.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Shipment response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ShipmentResponse {
    
    private Long id;
    private Long orderId;
    private String shipmentNumber;
    private String carrier;
    private String trackingNumber;
    private LocalDateTime shippedAt;
    private LocalDateTime deliveredAt;
    private List<ShipmentItemResponse> items;
}

