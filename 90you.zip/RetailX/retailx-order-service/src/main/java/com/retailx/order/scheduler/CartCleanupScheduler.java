package com.retailx.order.scheduler;

import com.retailx.order.domain.Cart;
import com.retailx.order.repository.CartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Scheduled job to clean up expired carts.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CartCleanupScheduler {
    
    private final CartRepository cartRepository;
    
    /**
     * Run every 6 hours to clean up expired carts.
     */
    @Scheduled(fixedRate = 21600000) // 6 hours in milliseconds
    @Transactional
    public void cleanupExpiredCarts() {
        log.info("Cleaning up expired carts");
        
        LocalDateTime now = LocalDateTime.now();
        List<Cart> expiredCarts = cartRepository.findByExpiresAtBeforeAndDeletedFalse(now);
        
        log.info("Found {} expired carts to clean up", expiredCarts.size());
        
        for (Cart cart : expiredCarts) {
            try {
                // Release any inventory holds for this cart
                // Note: This would require InventoryServiceClient - for now just log
                log.info("Cleaning up expired cart: cartId={}, customerId={}, expiresAt={}", 
                        cart.getId(), cart.getCustomerId(), cart.getExpiresAt());
                
                // Mark cart as deleted
                cart.setDeleted(true);
                cartRepository.save(cart);
                
                log.info("Successfully cleaned up expired cart: cartId={}", cart.getId());
            } catch (Exception e) {
                log.error("Failed to clean up expired cart {}: {}", cart.getId(), e.getMessage());
            }
        }
    }
}

