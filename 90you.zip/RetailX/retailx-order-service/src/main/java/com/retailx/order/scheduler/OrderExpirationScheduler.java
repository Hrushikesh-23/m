package com.retailx.order.scheduler;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.service.InventoryServiceClient;
import com.retailx.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Scheduled job to auto-cancel expired orders (orders in PENDING status for too long).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class OrderExpirationScheduler {
    
    private final OrderRepository orderRepository;
    private final OrderService orderService;
    private final InventoryServiceClient inventoryServiceClient;
    
    @Value("${retailx.order.expiration-hours:24}")
    private int orderExpirationHours;
    
    /**
     * Run every hour to check for expired orders.
     */
    @Scheduled(fixedRate = 3600000) // 1 hour in milliseconds
    @Transactional
    public void cancelExpiredOrders() {
        log.info("Checking for expired orders (older than {} hours)", orderExpirationHours);
        
        LocalDateTime expirationThreshold = LocalDateTime.now().minusHours(orderExpirationHours);
        
        List<Order> expiredOrders = orderRepository.findByStatusAndCreatedOnBeforeAndDeletedFalse(
                OrderStatus.PENDING, expirationThreshold);
        
        log.info("Found {} expired orders to cancel", expiredOrders.size());
        
        for (Order order : expiredOrders) {
            try {
                log.info("Auto-cancelling expired order: orderId={}, createdOn={}", 
                        order.getId(), order.getCreatedOn());
                
                // Release reserved inventory
                releaseOrderInventory(order);
                
                // Cancel order
                orderService.cancelOrder(order.getId(), "SYSTEM", 
                        String.format("Order expired after %d hours without payment", orderExpirationHours));
                
                log.info("Successfully cancelled expired order: orderId={}", order.getId());
            } catch (Exception e) {
                log.error("Failed to cancel expired order {}: {}", order.getId(), e.getMessage());
            }
        }
    }
    
    private void releaseOrderInventory(Order order) {
        for (var item : order.getItems()) {
            try {
                boolean released = inventoryServiceClient.releaseReservedInventory(
                        item.getSku(), item.getQuantity(), "WH-001");
                if (!released) {
                    released = inventoryServiceClient.releaseReservedInventory(
                            item.getSku(), item.getQuantity(), "default-warehouse");
                }
                if (!released) {
                    log.warn("Failed to release reserved inventory: sku={}, quantity={}", 
                            item.getSku(), item.getQuantity());
                }
            } catch (Exception e) {
                log.error("Error releasing reserved inventory: sku={}, error={}", 
                        item.getSku(), e.getMessage());
            }
        }
    }
}

