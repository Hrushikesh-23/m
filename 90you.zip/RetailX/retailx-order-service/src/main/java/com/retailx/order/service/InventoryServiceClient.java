package com.retailx.order.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Feign client for Inventory Service.
 */
@FeignClient(name = "retailx-inventory-service", path = "/api/inventory")
public interface InventoryServiceClient {
    
    @PostMapping("/reserve")
    boolean reserveInventory(@RequestParam String sku, 
                            @RequestParam java.math.BigInteger quantity,
                            @RequestParam String warehouseId);
    
    @PostMapping("/adjust")
    void adjustInventory(@RequestParam String sku,
                        @RequestParam String warehouseId,
                        @RequestParam java.math.BigInteger quantity);
    
    @PostMapping("/release")
    boolean releaseReservedInventory(@RequestParam String sku,
                                    @RequestParam java.math.BigInteger quantity,
                                    @RequestParam String warehouseId);
}

