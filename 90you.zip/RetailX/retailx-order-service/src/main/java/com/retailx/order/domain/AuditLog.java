package com.retailx.order.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Audit log entity for tracking all order operations.
 */
@Entity
@Table(name = "audit_logs", indexes = {
    @Index(name = "idx_audit_order", columnList = "orderId"),
    @Index(name = "idx_audit_actor", columnList = "actorId"),
    @Index(name = "idx_audit_timestamp", columnList = "timestamp")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column
    private Long orderId;
    
    @Column(length = 50)
    private String action; // CREATED, STATUS_CHANGED, CANCELLED, UPDATED, etc.
    
    @Column(length = 50)
    private String actorId; // User ID who performed the action
    
    @Column(length = 100)
    private String actorRole; // Role of the actor
    
    @Column(length = 50)
    private String oldStatus; // Previous status (for status changes)
    
    @Column(length = 50)
    private String newStatus; // New status (for status changes)
    
    @Column(length = 500)
    private String reason; // Reason for the action
    
    @Column(length = 1000)
    private String details; // Additional details (JSON)
    
    @Column(nullable = false)
    @Builder.Default
    private LocalDateTime timestamp = LocalDateTime.now();
}

