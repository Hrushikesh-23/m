package com.retailx.order.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

/**
 * Request DTO for return.
 */
@Data
public class ReturnRequest {
    
    @NotBlank(message = "Reason is required")
    private String reason;
    
    @NotEmpty(message = "At least one item is required")
    private List<ReturnItemRequest> items;
    
    public static class ReturnItemRequest {
        private String sku;
        private java.math.BigInteger quantity;
        
        public String getSku() { return sku; }
        public void setSku(String sku) { this.sku = sku; }
        public java.math.BigInteger getQuantity() { return quantity; }
        public void setQuantity(java.math.BigInteger quantity) { this.quantity = quantity; }
    }
}

