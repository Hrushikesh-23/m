package com.retailx.order.repository;

import com.retailx.order.domain.Cart;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Cart entity.
 */
@Repository
public interface CartRepository extends JpaRepository<Cart, Long> {
    
    Optional<Cart> findByCustomerIdAndDeletedFalse(Long customerId);
    
    @Query("SELECT c FROM Cart c WHERE c.expiresAt < :now AND c.abandoned = false AND c.deleted = false")
    List<Cart> findAbandonedCarts(@Param("now") LocalDateTime now);
    
    List<Cart> findByExpiresAtBeforeAndDeletedFalse(LocalDateTime expiresAt);
}

