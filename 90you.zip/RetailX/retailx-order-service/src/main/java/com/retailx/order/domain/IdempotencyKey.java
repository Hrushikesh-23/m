package com.retailx.order.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Idempotency key storage for safe retries.
 */
@Entity
@Table(name = "idempotency_keys", indexes = {
    @Index(name = "idx_idempotency_key", columnList = "keyValue", unique = true),
    @Index(name = "idx_idempotency_expiry", columnList = "expiresAt")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class IdempotencyKey extends BaseEntity {
    
    @Column(nullable = false, unique = true, length = 64)
    private String keyValue;
    
    @Column(nullable = false, length = 64)
    private String requestHash; // Hash of request payload
    
    @Column(columnDefinition = "TEXT")
    private String responseSummary; // Cached response
    
    @Column(nullable = false)
    private LocalDateTime expiresAt;
    
    @Column(nullable = false)
    @Builder.Default
    private Boolean used = false;
}

