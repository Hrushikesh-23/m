# Testing Guide - RetailX

## Test Coverage Target: 70%

## Test Structure

### Unit Tests
Located in: `src/test/java/com/retailx/{service}/service/` and `util/`

**Coverage:**
- ✅ Service layer business logic
- ✅ Utility classes
- ✅ DTOs and validators
- ✅ Mock dependencies with Mockito

**Example:** `CartServiceTest.java`, `ProductServiceTest.java`

### Integration Tests
Located in: `src/test/java/com/retailx/{service}/integration/`

**Coverage:**
- ✅ Repository layer with @DataJpaTest
- ✅ Database operations
- ✅ End-to-end flows

**Example:** `OrderIntegrationTest.java`, `ProductIntegrationTest.java`

### Testcontainers Tests
Located in: `src/test/java/com/retailx/{service}/integration/`

**Coverage:**
- ✅ Real database integration
- ✅ Requires Docker running
- ✅ Tests with actual MySQL container

**Example:** `TestcontainersIntegrationTest.java`

## Running Tests

### Run All Tests
```bash
# From project root
mvn test

# For specific service
cd retailx-order-service
mvn test
```

### Run with Coverage Report
```bash
mvn test jacoco:report

# View report
# Open: target/site/jacoco/index.html
```

### Check Coverage Threshold
```bash
mvn test jacoco:check

# Fails if coverage < 70%
```

### Run Only Unit Tests
```bash
mvn test -Dtest=*Test
```

### Run Only Integration Tests
```bash
mvn test -Dtest=*IntegrationTest
```

## Test Configuration

### Test Profiles
- `application-test.yml` - Test-specific configuration
- Uses H2 in-memory database for fast unit tests
- Testcontainers for integration tests with MySQL

### Test Dependencies
All services include:
- JUnit 5
- Mockito
- Spring Boot Test
- Spring Security Test
- Testcontainers
- H2 Database (for unit tests)

## Test Examples

### Service Unit Test
```java
@ExtendWith(MockitoExtension.class)
class CartServiceTest {
    @Mock
    private CartRepository cartRepository;
    
    @InjectMocks
    private CartService cartService;
    
    @Test
    void testAddToCart() {
        // Test implementation
    }
}
```

### Repository Integration Test
```java
@DataJpaTest
@ActiveProfiles("test")
class OrderIntegrationTest {
    @Autowired
    private OrderRepository orderRepository;
    
    @Test
    void testCreateOrder() {
        // Test with real database
    }
}
```

### Testcontainers Test
```java
@Testcontainers
@DataJpaTest
class TestcontainersIntegrationTest {
    @Container
    static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0");
    
    @Test
    void testWithRealMySQL() {
        // Test with containerized MySQL
    }
}
```

## Coverage Reports

After running `mvn test jacoco:report`:

1. **HTML Report:** `target/site/jacoco/index.html`
   - Line coverage
   - Branch coverage
   - Method coverage
   - Class coverage

2. **Coverage by Package:**
   - Service layer: Target 80%+
   - Controller layer: Target 70%+
   - Repository layer: Target 60%+ (mostly Spring Data)

3. **Coverage Rules:**
   - Minimum 70% line coverage
   - Build fails if below threshold
   - Configured in `pom.xml` with JaCoCo plugin

## Test Best Practices

1. ✅ Test all business logic
2. ✅ Test error cases
3. ✅ Test edge cases
4. ✅ Use meaningful test names
5. ✅ One assertion per test (when possible)
6. ✅ Mock external dependencies
7. ✅ Use @BeforeEach for setup
8. ✅ Clean up after tests

## Current Test Coverage

### Auth Service
- ✅ AuthServiceTest - Registration, login
- ✅ JwtUtilTest - Token generation, validation

### Product Service
- ✅ ProductServiceTest - CRUD operations
- ✅ SkuUtilTest - SKU validation, normalization
- ✅ ProductIntegrationTest - Repository tests
- ✅ TestcontainersProductTest - Real DB tests

### Order Service
- ✅ CartServiceTest - Cart operations
- ✅ CheckoutServiceTest - Checkout with idempotency
- ✅ OrderIntegrationTest - Repository tests
- ✅ TestcontainersIntegrationTest - Real DB tests

### Payment Service
- ✅ PaymentServiceTest - Payment operations

### Inventory Service
- ✅ InventoryServiceTest - Inventory operations

## Adding New Tests

When adding new features:

1. **Write unit tests first** (TDD approach)
2. **Add integration tests** for repository operations
3. **Use Testcontainers** for complex integration scenarios
4. **Ensure 70% coverage** minimum
5. **Run `mvn test jacoco:check`** before committing

## Troubleshooting

### Tests Fail with "Docker not running"
- Start Docker Desktop
- Or skip Testcontainers tests: `mvn test -DskipTests=false -Dtest=!*Testcontainers*`

### Coverage Below 70%
- Add more test cases
- Test error paths
- Test edge cases
- Review coverage report for gaps

### H2 Database Issues
- Check `application-test.yml` configuration
- Ensure H2 dependency in POM
- Use Testcontainers for MySQL-specific tests

