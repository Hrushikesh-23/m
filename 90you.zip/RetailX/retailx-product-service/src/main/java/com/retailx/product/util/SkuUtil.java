package com.retailx.product.util;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Utility class for SKU validation, normalization, and deduplication.
 * Implements Core Java Collections and Generics requirements.
 */
public class SkuUtil {
    
    private static final int MAX_SKU_LENGTH = 100;
    private static final String SKU_PATTERN = "^[A-Z0-9-]+$";
    
    /**
     * Validates a single SKU.
     * 
     * @param sku SKU to validate
     * @return true if valid, false otherwise
     */
    public static boolean isValidSku(String sku) {
        if (sku == null || sku.trim().isEmpty()) {
            return false;
        }
        String normalized = normalizeSku(sku);
        return normalized.length() <= MAX_SKU_LENGTH 
            && normalized.matches(SKU_PATTERN);
    }
    
    /**
     * Normalizes a SKU (uppercase, trim).
     * 
     * @param sku SKU to normalize
     * @return normalized SKU
     */
    public static String normalizeSku(String sku) {
        if (sku == null) {
            return "";
        }
        return sku.trim().toUpperCase();
    }
    
    /**
     * Validates a collection of SKUs.
     * 
     * @param skus Collection of SKUs to validate
     * @return Set of invalid SKUs
     */
    public static <T extends Collection<String>> Set<String> validateSkus(T skus) {
        if (skus == null || skus.isEmpty()) {
            return Collections.emptySet();
        }
        return skus.stream()
            .filter(sku -> !isValidSku(sku))
            .collect(Collectors.toSet());
    }
    
    /**
     * Deduplicates and normalizes a collection of SKUs.
     * 
     * @param skus Collection of SKUs
     * @return Set of unique, normalized SKUs
     */
    public static <T extends Collection<String>> Set<String> deduplicateSkus(T skus) {
        if (skus == null || skus.isEmpty()) {
            return Collections.emptySet();
        }
        return skus.stream()
            .map(SkuUtil::normalizeSku)
            .filter(sku -> !sku.isEmpty())
            .collect(Collectors.toSet());
    }
    
    /**
     * Groups SKUs by validity.
     * 
     * @param skus Collection of SKUs
     * @return Map with "valid" and "invalid" keys
     */
    public static <T extends Collection<String>> Map<String, Set<String>> groupSkusByValidity(T skus) {
        Map<String, Set<String>> result = new HashMap<>();
        result.put("valid", new HashSet<>());
        result.put("invalid", new HashSet<>());
        
        if (skus == null || skus.isEmpty()) {
            return result;
        }
        
        for (String sku : skus) {
            String normalized = normalizeSku(sku);
            if (isValidSku(normalized)) {
                result.get("valid").add(normalized);
            } else {
                result.get("invalid").add(sku);
            }
        }
        
        return result;
    }
}

