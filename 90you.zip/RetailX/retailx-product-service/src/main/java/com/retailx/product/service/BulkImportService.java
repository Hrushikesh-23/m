package com.retailx.product.service;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.repository.ProductRepository;
import com.retailx.product.util.SkuUtil;
import com.opencsv.CSVReader;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.*;

/**
 * Service for bulk product import/export operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BulkImportService {
    
    private final ProductRepository productRepository;
    private final ProductService productService;
    
    /**
     * Import products from CSV file.
     */
    @Transactional
    public BulkImportResult importFromCsv(MultipartFile file, Long merchantId) {
        List<ImportRowResult> results = new ArrayList<>();
        int lineNumber = 0;
        
        try (CSVReader reader = new CSVReader(new InputStreamReader(file.getInputStream()))) {
            String[] headers = reader.readNext(); // Skip header row
            if (headers == null) {
                return new BulkImportResult(0, 0, Collections.emptyList());
            }
            
            String[] row;
            while ((row = reader.readNext()) != null) {
                lineNumber++;
                ImportRowResult result = processCsvRow(row, lineNumber, merchantId);
                results.add(result);
            }
        } catch (Exception e) {
            log.error("Error importing CSV", e);
            results.add(new ImportRowResult(lineNumber, false, "Error reading file: " + e.getMessage()));
        }
        
        long successCount = results.stream().filter(ImportRowResult::isSuccess).count();
        return new BulkImportResult(successCount, results.size() - successCount, results);
    }
    
    /**
     * Import products from XLSX file.
     */
    @Transactional
    public BulkImportResult importFromXlsx(MultipartFile file, Long merchantId) {
        List<ImportRowResult> results = new ArrayList<>();
        
        try (Workbook workbook = new XSSFWorkbook(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            Row headerRow = sheet.getRow(0);
            
            if (headerRow == null) {
                return new BulkImportResult(0, 0, Collections.emptyList());
            }
            
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                
                ImportRowResult result = processXlsxRow(row, i + 1, merchantId);
                results.add(result);
            }
        } catch (Exception e) {
            log.error("Error importing XLSX", e);
            results.add(new ImportRowResult(0, false, "Error reading file: " + e.getMessage()));
        }
        
        long successCount = results.stream().filter(ImportRowResult::isSuccess).count();
        return new BulkImportResult(successCount, results.size() - successCount, results);
    }
    
    private ImportRowResult processCsvRow(String[] row, int lineNumber, Long merchantId) {
        try {
            if (row.length < 6) {
                return new ImportRowResult(lineNumber, false, "Insufficient columns");
            }
            
            String sku = row[0].trim();
            String name = row[1].trim();
            String description = row[2].trim();
            String basePriceStr = row[3].trim();
            String currency = row.length > 4 ? row[4].trim() : "USD";
            String categoryPath = row.length > 5 ? row[5].trim() : "/default";
            String statusStr = row.length > 6 ? row[6].trim() : "DRAFT";
            
            // Validate SKU
            if (!SkuUtil.isValidSku(sku)) {
                return new ImportRowResult(lineNumber, false, "Invalid SKU format");
            }
            
            // Check if product already exists (idempotent)
            String normalizedSku = SkuUtil.normalizeSku(sku);
            if (productRepository.findBySkuAndDeletedFalse(normalizedSku).isPresent()) {
                return new ImportRowResult(lineNumber, true, "Product already exists (skipped)");
            }
            
            // Create product
            ProductRequest request = new ProductRequest();
            request.setSku(sku);
            request.setName(name);
            request.setDescription(description);
            request.setBasePrice(new BigDecimal(basePriceStr));
            request.setCurrency(currency);
            request.setCategoryPath(categoryPath);
            request.setStatus(ProductStatus.valueOf(statusStr.toUpperCase()));
            request.setMerchantId(merchantId);
            
            productService.createProduct(request);
            
            return new ImportRowResult(lineNumber, true, "Product imported successfully");
        } catch (Exception e) {
            return new ImportRowResult(lineNumber, false, "Error: " + e.getMessage());
        }
    }
    
    private ImportRowResult processXlsxRow(Row row, int lineNumber, Long merchantId) {
        try {
            String sku = getCellValue(row.getCell(0));
            String name = getCellValue(row.getCell(1));
            String description = getCellValue(row.getCell(2));
            String basePriceStr = getCellValue(row.getCell(3));
            String currency = row.getCell(4) != null ? getCellValue(row.getCell(4)) : "USD";
            String categoryPath = row.getCell(5) != null ? getCellValue(row.getCell(5)) : "/default";
            String statusStr = row.getCell(6) != null ? getCellValue(row.getCell(6)) : "DRAFT";
            
            if (sku == null || sku.isEmpty()) {
                return new ImportRowResult(lineNumber, false, "SKU is required");
            }
            
            // Validate SKU
            if (!SkuUtil.isValidSku(sku)) {
                return new ImportRowResult(lineNumber, false, "Invalid SKU format");
            }
            
            // Check if product already exists (idempotent)
            String normalizedSku = SkuUtil.normalizeSku(sku);
            if (productRepository.findBySkuAndDeletedFalse(normalizedSku).isPresent()) {
                return new ImportRowResult(lineNumber, true, "Product already exists (skipped)");
            }
            
            // Create product
            ProductRequest request = new ProductRequest();
            request.setSku(sku);
            request.setName(name);
            request.setDescription(description);
            request.setBasePrice(new BigDecimal(basePriceStr));
            request.setCurrency(currency);
            request.setCategoryPath(categoryPath);
            request.setStatus(ProductStatus.valueOf(statusStr.toUpperCase()));
            request.setMerchantId(merchantId);
            
            productService.createProduct(request);
            
            return new ImportRowResult(lineNumber, true, "Product imported successfully");
        } catch (Exception e) {
            return new ImportRowResult(lineNumber, false, "Error: " + e.getMessage());
        }
    }
    
    private String getCellValue(Cell cell) {
        if (cell == null) return "";
        
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                if (DateUtil.isCellDateFormatted(cell)) {
                    return cell.getDateCellValue().toString();
                } else {
                    return String.valueOf(cell.getNumericCellValue());
                }
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue());
            case FORMULA:
                return cell.getCellFormula();
            default:
                return "";
        }
    }
    
    // Result classes
    public static class BulkImportResult {
        private long successCount;
        private long failureCount;
        private List<ImportRowResult> rowResults;
        
        public BulkImportResult(long successCount, long failureCount, List<ImportRowResult> rowResults) {
            this.successCount = successCount;
            this.failureCount = failureCount;
            this.rowResults = rowResults;
        }
        
        // Getters
        public long getSuccessCount() { return successCount; }
        public long getFailureCount() { return failureCount; }
        public List<ImportRowResult> getRowResults() { return rowResults; }
    }
    
    public static class ImportRowResult {
        private int lineNumber;
        private boolean success;
        private String message;
        
        public ImportRowResult(int lineNumber, boolean success, String message) {
            this.lineNumber = lineNumber;
            this.success = success;
            this.message = message;
        }
        
        // Getters
        public int getLineNumber() { return lineNumber; }
        public boolean isSuccess() { return success; }
        public String getMessage() { return message; }
    }
}

