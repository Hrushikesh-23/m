package com.retailx.product.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Filter to extract user information from headers set by API Gateway
 * and set up Spring Security authentication context.
 */
@Slf4j
@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, 
                                    FilterChain filterChain) throws ServletException, IOException {
        
        String userId = request.getHeader("X-User-Id");
        String userEmail = request.getHeader("X-User-Email");
        String userRoles = request.getHeader("X-User-Role");
        
        // Extract and set authentication from headers
        String path = request.getRequestURI();
        log.debug("JWT Filter - Path: {}, X-User-Id: {}, X-User-Role: {}", path, userId, userRoles);
        
        if (userId != null) {
            List<SimpleGrantedAuthority> authorities = new java.util.ArrayList<>();
            
            if (userRoles != null && !userRoles.trim().isEmpty()) {
                // Parse roles from comma-separated string
                authorities = Arrays.stream(userRoles.split(","))
                        .map(String::trim)
                        .filter(role -> !role.isEmpty())
                        .map(role -> "ROLE_" + role.toUpperCase())
                        .map(SimpleGrantedAuthority::new)
                        .collect(Collectors.toList());
            }
            
            if (!authorities.isEmpty()) {
                // Create authentication token
                UsernamePasswordAuthenticationToken authentication = 
                        new UsernamePasswordAuthenticationToken(userId, null, authorities);
                
                // Set in security context
                SecurityContextHolder.getContext().setAuthentication(authentication);
                
                log.info("✅ Authenticated user: {} with roles: {} for path: {}", userId, userRoles, path);
            } else {
                log.warn("⚠️ No valid roles found for user: {}, roles header: {}. Request path: {}", 
                        userId, userRoles, path);
                // Still set authentication even without roles, let @PreAuthorize handle authorization
                // This ensures authenticated() check passes, but @PreAuthorize will deny if no roles
                UsernamePasswordAuthenticationToken authentication = 
                        new UsernamePasswordAuthenticationToken(userId, null, java.util.Collections.emptyList());
                SecurityContextHolder.getContext().setAuthentication(authentication);
                log.debug("Set authentication without roles for path: {}", path);
            }
        } else {
            log.debug("Missing userId header. Request path: {}", path);
        }
        
        filterChain.doFilter(request, response);
    }
}


