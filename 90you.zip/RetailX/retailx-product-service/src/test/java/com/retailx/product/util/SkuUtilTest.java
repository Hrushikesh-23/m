package com.retailx.product.util;

import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SkuUtil.
 */
class SkuUtilTest {
    
    @Test
    void testIsValidSku_Valid() {
        assertTrue(SkuUtil.isValidSku("PROD-001"));
        assertTrue(SkuUtil.isValidSku("ABC123"));
        assertTrue(SkuUtil.isValidSku("SKU-2024-001"));
    }
    
    @Test
    void testIsValidSku_Invalid() {
        assertFalse(SkuUtil.isValidSku(null));
        assertFalse(SkuUtil.isValidSku(""));
        // Note: "prod-001" becomes "PROD-001" after normalization, so it's valid
        assertFalse(SkuUtil.isValidSku("PROD 001")); // space
        assertFalse(SkuUtil.isValidSku("PROD@001")); // invalid character
    }
    
    @Test
    void testNormalizeSku() {
        assertEquals("PROD-001", SkuUtil.normalizeSku("prod-001"));
        assertEquals("PROD-001", SkuUtil.normalizeSku("  PROD-001  "));
        assertEquals("", SkuUtil.normalizeSku(null));
    }
    
    @Test
    void testValidateSkus() {
        List<String> skus = Arrays.asList("PROD-001", "invalid@sku", "PROD-002", "");
        Set<String> invalid = SkuUtil.validateSkus(skus);
        
        assertEquals(2, invalid.size());
        assertTrue(invalid.contains("invalid@sku"));
        assertTrue(invalid.contains(""));
    }
    
    @Test
    void testDeduplicateSkus() {
        List<String> skus = Arrays.asList("PROD-001", "prod-001", "PROD-002", "PROD-001");
        Set<String> deduplicated = SkuUtil.deduplicateSkus(skus);
        
        assertEquals(2, deduplicated.size());
        assertTrue(deduplicated.contains("PROD-001"));
        assertTrue(deduplicated.contains("PROD-002"));
    }
    
    @Test
    void testGroupSkusByValidity() {
        List<String> skus = Arrays.asList("PROD-001", "invalid@sku", "PROD-002");
        Map<String, Set<String>> grouped = SkuUtil.groupSkusByValidity(skus);
        
        assertEquals(2, grouped.get("valid").size());
        assertEquals(1, grouped.get("invalid").size());
        assertTrue(grouped.get("valid").contains("PROD-001"));
        assertTrue(grouped.get("valid").contains("PROD-002"));
        assertTrue(grouped.get("invalid").contains("invalid@sku"));
    }
}

