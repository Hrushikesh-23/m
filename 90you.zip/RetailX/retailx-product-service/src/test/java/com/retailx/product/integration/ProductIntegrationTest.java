package com.retailx.product.integration;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for Product repository.
 * Note: This test requires a database to be configured.
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
@org.junit.jupiter.api.Disabled("Requires database configuration")
class ProductIntegrationTest {
    
    @Autowired
    private TestEntityManager entityManager;
    
    @Autowired
    private ProductRepository productRepository;
    
    private Product testProduct;
    
    @BeforeEach
    void setUp() {
        testProduct = Product.builder()
                .sku("TEST-001")
                .name("Test Product")
                .description("Test Description")
                .basePrice(new BigDecimal("99.99"))
                .currency("USD")
                .categoryPath("/electronics")
                .catalogPath("/catalog/electronics/TEST-001")
                .status(ProductStatus.ACTIVE)
                .merchantId(1L)
                .build();
        testProduct = entityManager.persistAndFlush(testProduct);
    }
    
    @Test
    void testFindBySku() {
        Optional<Product> found = productRepository.findBySkuAndDeletedFalse("TEST-001");
        
        assertTrue(found.isPresent());
        assertEquals("TEST-001", found.get().getSku());
    }
    
    @Test
    void testFindByStatus() {
        Page<Product> products = productRepository.findByStatusAndDeletedFalse(
                ProductStatus.ACTIVE, PageRequest.of(0, 10));
        
        assertTrue(products.getTotalElements() > 0);
    }
    
    @Test
    void testSearchProducts() {
        Page<Product> products = productRepository.searchProducts(
                ProductStatus.ACTIVE,
                BigDecimal.ZERO,
                new BigDecimal("1000"),
                null,
                "Test",
                PageRequest.of(0, 10)
        );
        
        assertTrue(products.getTotalElements() > 0);
    }
}

