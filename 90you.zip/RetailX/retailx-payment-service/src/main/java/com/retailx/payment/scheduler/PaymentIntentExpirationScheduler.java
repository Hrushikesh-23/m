package com.retailx.payment.scheduler;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import com.retailx.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Scheduled job to expire payment intents that haven't been authorized.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentIntentExpirationScheduler {
    
    private final PaymentIntentRepository paymentIntentRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${retailx.payment.intent.expiration-minutes:30}")
    private int paymentIntentExpirationMinutes;
    
    /**
     * Run every 10 minutes to check for expired payment intents.
     */
    @Scheduled(fixedRate = 600000) // 10 minutes in milliseconds
    @Transactional
    public void expirePaymentIntents() {
        log.info("Checking for expired payment intents (older than {} minutes)", paymentIntentExpirationMinutes);
        
        LocalDateTime expirationThreshold = LocalDateTime.now().minusMinutes(paymentIntentExpirationMinutes);
        
        List<PaymentIntent> expiredIntents = paymentIntentRepository
                .findByStatusAndCreatedOnBefore(PaymentStatus.PENDING, expirationThreshold);
        
        log.info("Found {} expired payment intents to mark as failed", expiredIntents.size());
        
        for (PaymentIntent intent : expiredIntents) {
            try {
                log.info("Expiring payment intent: paymentIntentId={}, orderId={}, createdOn={}", 
                        intent.getId(), intent.getOrderId(), intent.getCreatedOn());
                
                // Mark as failed
                intent.setStatus(PaymentStatus.FAILED);
                intent.setErrorCode("PAYMENT_INTENT_EXPIRED");
                intent.setErrorMessage("Payment intent expired after " + paymentIntentExpirationMinutes + " minutes");
                paymentIntentRepository.save(intent);
                
                // Publish payment failed event
                try {
                    kafkaTemplate.send("payment.failed", String.valueOf(intent.getOrderId()),
                            String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                    intent.getId(), intent.getOrderId(),
                                    "PAYMENT_INTENT_EXPIRED", "Payment intent expired"));
                } catch (Exception e) {
                    log.warn("Failed to send Kafka event for expired payment intent: {}", e.getMessage());
                }
                
                log.info("Successfully expired payment intent: paymentIntentId={}", intent.getId());
            } catch (Exception e) {
                log.error("Failed to expire payment intent {}: {}", intent.getId(), e.getMessage());
            }
        }
    }
}

