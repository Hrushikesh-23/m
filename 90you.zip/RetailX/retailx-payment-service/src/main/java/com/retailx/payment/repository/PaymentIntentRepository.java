package com.retailx.payment.repository;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for PaymentIntent entity.
 */
@Repository
public interface PaymentIntentRepository extends JpaRepository<PaymentIntent, Long> {
    
    Optional<PaymentIntent> findByOrderId(Long orderId);
    
    Optional<PaymentIntent> findByCorrelationId(String correlationId);
    
    Optional<PaymentIntent> findByPaymentIntentId(String paymentIntentId);
    
    List<PaymentIntent> findByStatusAndCreatedOnBefore(PaymentStatus status, LocalDateTime createdOn);
}

