package com.retailx.payment.domain;

import com.retailx.payment.domain.enums.PaymentStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Payment intent entity (mock provider).
 */
@Entity
@Table(name = "payment_intents", indexes = {
    @Index(name = "idx_payment_order", columnList = "orderId", unique = true),
    @Index(name = "idx_payment_status", columnList = "status"),
    @Index(name = "idx_payment_correlation", columnList = "correlationId")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentIntent extends BaseEntity {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private Long orderId; // Reference to order service
    
    @Column(nullable = false, length = 100)
    private String paymentIntentId; // External provider ID
    
    @Column(nullable = false, precision = 19, scale = 2)
    private BigDecimal amount;
    
    @Column(nullable = false, length = 3)
    private String currency;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private PaymentStatus status = PaymentStatus.PENDING;
    
    @Column(length = 100)
    private String correlationId; // For idempotency
    
    @Column(length = 50)
    private String paymentMethod; // CARD, PAYPAL, etc.
    
    @Column(length = 500)
    private String errorCode; // PAYMENT_DECLINED, INSUFFICIENT_FUNDS, etc.
    
    @Column(length = 1000)
    private String errorMessage;
    
    @Column(nullable = false, precision = 19, scale = 2)
    @Builder.Default
    private BigDecimal totalRefundedAmount = BigDecimal.ZERO; // Track cumulative refunded amount
}

