package com.retailx.frontend.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;

/**
 * Feign client for Product Service.
 */
@FeignClient(name = "retailx-api-gateway", path = "/api/products")
public interface ProductServiceClient {
    
    @GetMapping
    Map<String, Object> getProducts(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size);
    
    @GetMapping("/{id}")
    Map<String, Object> getProductById(@PathVariable Long id);
}

