package com.retailx.frontend.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.Map;

/**
 * Feign client for Auth Service.
 */
@FeignClient(name = "retailx-api-gateway", path = "/api/auth")
public interface AuthServiceClient {
    
    @PostMapping("/register")
    Map<String, Object> register(@RequestBody Map<String, String> request);
    
    @PostMapping("/login")
    Map<String, Object> login(@RequestBody Map<String, String> request);
}

