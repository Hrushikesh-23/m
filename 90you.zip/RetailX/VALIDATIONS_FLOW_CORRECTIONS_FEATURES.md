# Validations, Flow Corrections, and Features Analysis

This document lists all identified validations, flow corrections, and features that should be considered for the RetailX platform.

---

## 🔴 CRITICAL VALIDATIONS (High Priority)

### 1. **Inventory Reservation Rollback on Order Failure**
**Issue**: If inventory is reserved but order creation fails, inventory remains reserved forever.
**Current State**: Inventory is reserved before order creation, but if order creation fails, reserved inventory is not released.
**Fix Needed**: 
- Implement rollback mechanism to release reserved inventory if order creation fails
- Use distributed transaction or Saga pattern
- Or implement compensation transaction on failure

### 2. **Inventory Release on Order Cancellation**
**Issue**: When order is cancelled, reserved inventory is not released back to available stock.
**Current State**: Order cancellation doesn't release reserved inventory.
**Fix Needed**: 
- When order is cancelled, release all reserved inventory for that order
- Call inventory service to adjust reserved quantity (subtract reserved, add to available)

### 3. **Cart Price Validation**
**Issue**: Product prices in cart may become stale if product price changes after adding to cart.
**Current State**: Cart stores unit price at time of adding, but doesn't validate on checkout.
**Fix Needed**: 
- On checkout, re-validate product prices against current prices
- If price changed, either update cart or reject checkout with price mismatch error
- Option: Show price change warning to customer

### 4. **Product Availability Check Before Checkout**
**Issue**: Product may become unavailable (out of stock or inactive) after adding to cart.
**Current State**: Cart doesn't check product availability before checkout.
**Fix Needed**: 
- On checkout, validate all products are still active and available
- Remove unavailable items from cart or reject checkout

### 5. **Return Quantity Validation**
**Issue**: Return quantity validation exists but doesn't check for already returned quantities.
**Current State**: Can return same item multiple times if not tracked.
**Fix Needed**: 
- Track total returned quantity per order item
- Prevent returning more than ordered quantity across all return requests
- Validate: `totalReturnedQty + newReturnQty <= orderedQty`

### 6. **Refund Amount Validation**
**Issue**: Refund amount should not exceed captured amount minus already refunded amount.
**Current State**: Basic validation exists but doesn't track partial refunds properly.
**Fix Needed**: 
- Track total refunded amount per payment intent
- Validate: `newRefundAmount + totalRefundedAmount <= capturedAmount`
- Prevent double refunding

### 7. **Order Expiration (Auto-Cancel)**
**Issue**: Orders in PENDING status can remain forever if payment is never processed.
**Current State**: No automatic cancellation of unpaid orders.
**Fix Needed**: 
- Implement scheduled job to cancel orders in PENDING status after X hours (e.g., 24 hours)
- Release reserved inventory when auto-cancelling
- Send notification to customer before cancellation

### 8. **Payment Intent Expiration**
**Issue**: Payment intents in PENDING status can remain forever.
**Current State**: No expiration mechanism for payment intents.
**Fix Needed**: 
- Auto-expire payment intents after X hours (e.g., 30 minutes)
- Mark as FAILED if not authorized within time window
- Cancel associated order if payment intent expires

### 9. **Concurrent Inventory Reservation (Race Condition)**
**Issue**: Multiple checkout requests for same product can cause overselling.
**Current State**: No locking mechanism for inventory reservations.
**Fix Needed**: 
- Implement optimistic locking or pessimistic locking
- Use database row-level locks or distributed locks (Redis)
- Retry mechanism for failed reservations due to concurrency

### 10. **Shipping Address Validation**
**Issue**: No validation of shipping address format or completeness.
**Current State**: Accepts any string as shipping address.
**Fix Needed**: 
- Validate address format (required fields: street, city, state, zip)
- Validate zip code format
- Optional: Integrate with address validation service

---

## 🟡 IMPORTANT VALIDATIONS (Medium Priority)

### 11. **Email Format Validation**
**Issue**: Basic email validation may not be strict enough.
**Current State**: Uses `@Email` annotation but may allow invalid formats.
**Fix Needed**: 
- Strict email regex validation
- Check for valid TLD
- Prevent disposable email addresses (optional)

### 12. **Password Strength Validation**
**Issue**: No password strength requirements enforced.
**Current State**: Accepts any password.
**Fix Needed**: 
- Minimum 8 characters
- At least one uppercase, one lowercase, one number, one special character
- Common password blacklist check

### 13. **Account Lockout After Failed Login Attempts**
**Issue**: Failed login attempts are tracked but account is not locked.
**Current State**: Tracks failed attempts but doesn't lock account.
**Fix Needed**: 
- Lock account after 5 failed attempts
- Lock duration: 30 minutes or until admin unlock
- Send email notification on lockout

### 14. **SKU Uniqueness Validation**
**Issue**: Multiple products can have same SKU (if not enforced at DB level).
**Current State**: May allow duplicate SKUs.
**Fix Needed**: 
- Enforce unique SKU constraint at database level
- Validate SKU format (e.g., must start with "PROD-")
- Check SKU uniqueness before product creation

### 15. **Product Price Validation**
**Issue**: Product price can be zero or negative.
**Current State**: No validation for price > 0.
**Fix Needed**: 
- Validate price > 0
- Validate price has max 2 decimal places
- Validate price is not unreasonably high (optional: max limit)

### 16. **Cart Quantity Limits**
**Issue**: No maximum quantity per item or total cart value limit.
**Current State**: Can add unlimited quantity to cart.
**Fix Needed**: 
- Maximum quantity per item (e.g., 100)
- Maximum total cart value (e.g., $10,000)
- Maximum number of unique items in cart (e.g., 50)

### 17. **Return Window Validation**
**Issue**: Return window is checked but uses wrong date (uses `updatedOn` instead of delivery date).
**Current State**: Uses `order.getUpdatedOn()` which may not be delivery date.
**Fix Needed**: 
- Store actual delivery date in order
- Use delivery date for return window calculation
- Validate return window from delivery date, not order update date

### 18. **Multiple Merchant Orders**
**Issue**: Order can contain items from multiple merchants, but merchantId is set from first item only.
**Current State**: Order has single merchantId, but items can be from different merchants.
**Fix Needed**: 
- Either: Split order into multiple orders per merchant
- Or: Support multi-merchant orders with proper handling
- Validate all items belong to same merchant (if single-merchant policy)

### 19. **Shipment Item Validation**
**Issue**: Shipment items are created from order items but not validated.
**Current State**: Shipment items may not match order items exactly.
**Fix Needed**: 
- Validate all shipment items exist in order
- Validate shipment quantities don't exceed order quantities
- Validate SKUs match order items

### 20. **Tracking Number Format Validation**
**Issue**: No validation of tracking number format.
**Current State**: Accepts any string as tracking number.
**Fix Needed**: 
- Validate tracking number format based on carrier
- Carrier-specific format validation (e.g., FedEx: 12 digits, UPS: 18 alphanumeric)

### 21. **Currency Validation**
**Issue**: Payment currency may not match order currency.
**Current State**: No validation that payment currency matches order currency.
**Fix Needed**: 
- Store currency in order
- Validate payment currency matches order currency
- Reject payment intent if currency mismatch

### 22. **Partial Return Handling**
**Issue**: Multiple return requests for same order item can exceed ordered quantity.
**Current State**: Each return request validates independently, but doesn't check against total returned.
**Fix Needed**: 
- Track cumulative returned quantity per order item
- Prevent multiple return requests from exceeding ordered quantity
- Validate: `sum(allReturnedQuantities) + newReturnQty <= orderedQty`

### 23. **Order Status Transition Authorization**
**Issue**: No role-based validation for who can change order status.
**Current State**: Any authenticated user can change order status (if they have order access).
**Fix Needed**: 
- Only CUSTOMER can cancel their own order (before payment)
- Only MERCHANT/OPS/ADMIN can mark as SHIPPED
- Only OPS/ADMIN can mark as DELIVERED
- Only MERCHANT/OPS/ADMIN can approve returns

### 24. **Inventory Adjustment Validation**
**Issue**: Inventory adjustment can result in negative available quantity.
**Current State**: No validation that adjustment won't make available negative.
**Fix Needed**: 
- Validate: `onHand + adjustment >= reserved`
- Prevent negative available quantity
- Validate adjustment quantity is reasonable (not too large)

### 25. **Cart Expiration Cleanup**
**Issue**: Expired carts are not automatically cleaned up.
**Current State**: Carts have expiration but no cleanup job.
**Fix Needed**: 
- Scheduled job to delete expired carts
- Release any inventory holds for expired carts
- Send abandoned cart email before expiration (optional)

---

## 🟢 FLOW CORRECTIONS (Medium Priority)

### 26. **Checkout Flow: Inventory Reservation Failure Handling**
**Issue**: If one item fails reservation, all previous reservations remain (partial reservation).
**Current State**: Reservations are done in loop, but if later item fails, earlier reservations are not rolled back.
**Fix Needed**: 
- Implement Saga pattern or compensation transactions
- Rollback all reservations if any reservation fails
- Or: Reserve all items atomically (all-or-nothing)

### 27. **Payment Flow: Order Status Update Timing**
**Issue**: Order status is updated to PAID via Kafka event, but if Kafka fails, order stays PENDING.
**Current State**: Relies on Kafka event for order status update.
**Fix Needed**: 
- Implement synchronous status update (call Order Service directly)
- Or: Implement retry mechanism for Kafka events
- Or: Polling mechanism to check payment status and update order

### 28. **Return Flow: Inventory Restocking Failure**
**Issue**: If inventory restocking fails during return approval, return is still approved but inventory not restocked.
**Current State**: Return approval continues even if inventory adjustment fails.
**Fix Needed**: 
- Make inventory restocking mandatory for return approval
- Fail return approval if inventory adjustment fails
- Or: Queue inventory adjustment for retry

### 29. **Shipment Flow: Order Status Update**
**Issue**: Order status is updated to SHIPPED in ShipmentService, but should be in OrderService.
**Current State**: ShipmentService directly updates order status.
**Fix Needed**: 
- ShipmentService should call OrderService to update status
- Maintain separation of concerns
- OrderService validates status transition

### 30. **Cart Price Refresh**
**Issue**: Cart prices are not refreshed when product prices change.
**Current State**: Cart stores prices at time of adding, never updates.
**Fix Needed**: 
- Option 1: Refresh prices on cart retrieval (show current prices)
- Option 2: Lock prices at checkout (use cart prices)
- Option 3: Show both old and new prices, let customer decide

### 31. **Order Cancellation: Payment Refund**
**Issue**: When order is cancelled after payment, refund is not automatically processed.
**Current State**: Order cancellation doesn't trigger refund.
**Fix Needed**: 
- If order is PAID and cancelled, automatically process refund
- Call Payment Service to refund payment
- Update payment status to REFUNDED

### 32. **Return Approval: Order Status Update**
**Issue**: Order status is updated to RETURNED in ReturnService, but should be in OrderService.
**Current State**: ReturnService directly updates order status.
**Fix Needed**: 
- ReturnService should call OrderService to update status
- Maintain separation of concerns
- OrderService validates status transition

### 33. **Inventory Reservation: Warehouse Selection**
**Issue**: Warehouse is hardcoded ("WH-001" or "default-warehouse") instead of intelligent selection.
**Current State**: Tries WH-001 first, then default-warehouse.
**Fix Needed**: 
- Query inventory service for available warehouses
- Select warehouse with sufficient inventory
- Consider shipping address for warehouse proximity (optional)

### 34. **Payment Intent: Order Validation**
**Issue**: Payment intent can be created for non-existent or cancelled orders.
**Current State**: No validation that order exists and is in valid state.
**Fix Needed**: 
- Validate order exists
- Validate order status is PENDING or PAID (if retry)
- Reject payment intent creation for CANCELLED orders

### 35. **Checkout: Product Validation**
**Issue**: Products in cart are not re-validated on checkout (may be deleted or inactive).
**Current State**: Only checks if cart is not empty.
**Fix Needed**: 
- Re-validate all products exist and are active
- Remove inactive/deleted products from cart
- Reject checkout if critical products are unavailable

---

## 🔵 FEATURES TO ADD (Lower Priority but Valuable)

### 36. **Order History and Tracking**
**Feature**: Customer should see order history with status timeline.
**Current State**: Can get order by ID, but no history view.
**Implementation**: 
- Add endpoint: `GET /api/orders/history` for customer's order history
- Include status change timeline
- Include shipment tracking information

### 37. **Email Notifications**
**Feature**: Send email notifications for order events.
**Current State**: Notification service exists but may not be fully integrated.
**Implementation**: 
- Order created → Confirmation email
- Payment captured → Payment confirmation
- Order shipped → Shipping notification with tracking
- Order delivered → Delivery confirmation
- Return approved → Refund confirmation

### 38. **Order Search and Filtering**
**Feature**: Advanced search and filtering for orders.
**Current State**: Basic search exists but limited.
**Implementation**: 
- Filter by status, date range, merchant, customer
- Search by order number, SKU, product name
- Pagination and sorting

### 39. **Inventory Alerts**
**Feature**: Automatic alerts when inventory is low or out of stock.
**Current State**: Can get low stock items, but no alerts.
**Implementation**: 
- Email/SMS alerts to merchants when stock is low
- Alert when product goes out of stock
- Daily inventory summary report

### 40. **Promotion and Discount System**
**Feature**: Support for promotions, coupons, and discounts.
**Current State**: Discount field exists but not used.
**Implementation**: 
- Coupon code validation
- Percentage or fixed amount discounts
- Minimum order value requirements
- Expiration dates for promotions

### 41. **Multi-Warehouse Support**
**Feature**: Proper multi-warehouse inventory management.
**Current State**: Basic warehouse support but not fully utilized.
**Implementation**: 
- Warehouse selection based on customer location
- Inventory allocation across warehouses
- Warehouse-specific shipping costs

### 42. **Order Notes and Comments**
**Feature**: Add notes/comments to orders for internal use.
**Current State**: No notes system.
**Implementation**: 
- Add notes field to orders
- Track who added note and when
- Notes visible to MERCHANT/OPS/ADMIN only

### 43. **Bulk Operations**
**Feature**: Bulk operations for orders, products, inventory.
**Current State**: Individual operations only.
**Implementation**: 
- Bulk order status update
- Bulk product import/update
- Bulk inventory adjustment

### 44. **Audit Logging**
**Feature**: Comprehensive audit logging for all operations.
**Current State**: Basic logging exists but not comprehensive.
**Implementation**: 
- Log all order status changes with actor and timestamp
- Log all payment operations
- Log all inventory adjustments
- Queryable audit trail

### 45. **Rate Limiting**
**Feature**: Rate limiting to prevent abuse.
**Current State**: No rate limiting.
**Implementation**: 
- Rate limit login attempts
- Rate limit API calls per user
- Rate limit checkout attempts

### 46. **Order Export**
**Feature**: Export orders to CSV/Excel for reporting.
**Current State**: No export functionality.
**Implementation**: 
- Export orders by date range
- Include all order details
- Support CSV and Excel formats

### 47. **Product Reviews Integration**
**Feature**: Allow customers to review products after delivery.
**Current State**: Review service exists but may not be integrated with orders.
**Implementation**: 
- Allow review only after order is DELIVERED
- Link reviews to order items
- Prevent duplicate reviews

### 48. **Wishlist Feature**
**Feature**: Allow customers to save products to wishlist.
**Current State**: No wishlist functionality.
**Implementation**: 
- Add/remove products from wishlist
- Move wishlist items to cart
- Share wishlist (optional)

### 49. **Order Splitting**
**Feature**: Split orders into multiple shipments.
**Current State**: Single shipment per order.
**Implementation**: 
- Create multiple shipments for one order
- Track each shipment separately
- Partial delivery support

### 50. **Refund Reason Tracking**
**Feature**: Track reasons for refunds for analytics.
**Current State**: Basic refund tracking.
**Implementation**: 
- Require reason for refund
- Categorize refund reasons
- Analytics dashboard for refund reasons

---

## 📊 SUMMARY BY PRIORITY

### **CRITICAL (Must Fix)**
1. Inventory reservation rollback on order failure
2. Inventory release on order cancellation
3. Cart price validation
4. Product availability check before checkout
5. Return quantity validation (cumulative)
6. Refund amount validation (track partial refunds)
7. Order expiration (auto-cancel)
8. Payment intent expiration
9. Concurrent inventory reservation (race condition)
10. Shipping address validation

### **IMPORTANT (Should Fix)**
11-25: Email validation, password strength, account lockout, SKU uniqueness, price validation, cart limits, return window fix, multi-merchant orders, shipment validation, tracking number validation, currency validation, partial return handling, order status authorization, inventory adjustment validation, cart expiration cleanup

### **FLOW CORRECTIONS (Should Improve)**
26-35: Checkout flow improvements, payment flow improvements, return flow improvements, shipment flow improvements, cart price refresh, order cancellation refund, return approval flow, warehouse selection, payment intent validation, checkout product validation

### **FEATURES (Nice to Have)**
36-50: Order history, email notifications, order search, inventory alerts, promotions, multi-warehouse, order notes, bulk operations, audit logging, rate limiting, order export, product reviews, wishlist, order splitting, refund reason tracking

---

## 🎯 RECOMMENDED IMPLEMENTATION ORDER

1. **Phase 1 (Critical)**: Fix inventory rollback, order cancellation inventory release, cart price validation
2. **Phase 2 (Important)**: Add validations for email, password, SKU, prices, quantities
3. **Phase 3 (Flow)**: Improve checkout flow, payment flow, return flow
4. **Phase 4 (Features)**: Add order history, notifications, search, export

---

**Note**: This is a comprehensive list. Prioritize based on business requirements and impact on data integrity and user experience.

