# Bulk Product Import Guide

This guide explains how to use the bulk import feature to import multiple products at once using CSV or XLSX files.

## Endpoints

- **CSV Import:** `POST /api/products/bulk/import/csv`
- **XLSX Import:** `POST /api/products/bulk/import/xlsx`

## Authentication

Both endpoints require **MERCHANT** or **ADMIN** role.

**Headers Required:**
```
Authorization: Bearer <your-jwt-token>
X-User-Id: <your-user-id>
```

## File Format

### CSV Format

The CSV file must have the following columns (in order):

1. **SKU** (Required) - Product SKU, must be unique
2. **Name** (Required) - Product name
3. **Description** (Required) - Product description
4. **BasePrice** (Required) - Product price as decimal (e.g., 99.99)
5. **Currency** (Optional) - Currency code (default: USD)
6. **CategoryPath** (Optional) - Category path (default: /default)
7. **Status** (Optional) - Product status: ACTIVE, DRAFT, INACTIVE (default: DRAFT)

**Example CSV:**
```csv
SKU,Name,Description,BasePrice,Currency,CategoryPath,Status
PROD-100,Laptop Computer,High-performance laptop,1299.99,USD,/electronics/computers,ACTIVE
PROD-101,Wireless Mouse,Ergonomic wireless mouse,29.99,USD,/electronics/accessories,ACTIVE
```

### XLSX Format

The XLSX file must have the same columns as CSV, with the first row as headers:

| SKU | Name | Description | BasePrice | Currency | CategoryPath | Status |
|-----|------|-------------|-----------|----------|--------------|--------|
| PROD-100 | Laptop Computer | High-performance laptop | 1299.99 | USD | /electronics/computers | ACTIVE |
| PROD-101 | Wireless Mouse | Ergonomic wireless mouse | 29.99 | USD | /electronics/accessories | ACTIVE |

## Template Files

Two template files are provided:

1. **`bulk-import-template.csv`** - CSV template with sample data
2. **`bulk-import-template.xlsx`** - XLSX template with sample data

You can use these as starting points for your own imports.

## Using cURL

### CSV Import
```bash
curl -X POST "http://localhost:8080/api/products/bulk/import/csv" \
  -H "Authorization: Bearer <your-token>" \
  -H "X-User-Id: <your-user-id>" \
  -F "file=@bulk-import-template.csv"
```

### XLSX Import
```bash
curl -X POST "http://localhost:8080/api/products/bulk/import/xlsx" \
  -H "Authorization: Bearer <your-token>" \
  -H "X-User-Id: <your-user-id>" \
  -F "file=@bulk-import-template.xlsx"
```

## Using PowerShell

### CSV Import
```powershell
$headers = @{
    "Authorization" = "Bearer <your-token>"
    "X-User-Id" = "<your-user-id>"
}

$filePath = "bulk-import-template.csv"
$formData = @{
    file = Get-Item -Path $filePath
}

$response = Invoke-RestMethod -Uri "http://localhost:8080/api/products/bulk/import/csv" `
    -Method POST `
    -Headers $headers `
    -Form $formData

Write-Host "Success: $($response.successCount), Failed: $($response.failureCount)"
```

### XLSX Import
```powershell
$headers = @{
    "Authorization" = "Bearer <your-token>"
    "X-User-Id" = "<your-user-id>"
}

$filePath = "bulk-import-template.xlsx"
$formData = @{
    file = Get-Item -Path $filePath
}

$response = Invoke-RestMethod -Uri "http://localhost:8080/api/products/bulk/import/xlsx" `
    -Method POST `
    -Headers $headers `
    -Form $formData

Write-Host "Success: $($response.successCount), Failed: $($response.failureCount)"
```

## Response Format

```json
{
  "successCount": 10,
  "failureCount": 0,
  "rowResults": [
    {
      "lineNumber": 1,
      "success": true,
      "message": "Product imported successfully"
    },
    {
      "lineNumber": 2,
      "success": true,
      "message": "Product already exists (skipped)"
    }
  ]
}
```

## Validation Rules

1. **SKU Format:** Must match SKU validation rules (alphanumeric, hyphens, underscores)
2. **SKU Uniqueness:** Duplicate SKUs will be skipped (idempotent import)
3. **Price:** Must be a valid decimal number
4. **Status:** Must be one of: ACTIVE, DRAFT, INACTIVE
5. **Currency:** Standard currency codes (USD, EUR, GBP, etc.)

## Common Issues

### 1. "Insufficient columns"
- **Cause:** CSV/XLSX file has fewer than 4 columns
- **Solution:** Ensure your file has at least SKU, Name, Description, and BasePrice columns

### 2. "Invalid SKU format"
- **Cause:** SKU doesn't match validation rules
- **Solution:** Use alphanumeric characters, hyphens, or underscores only

### 3. "Access Denied" (403)
- **Cause:** User doesn't have MERCHANT or ADMIN role
- **Solution:** Use a token from a user with MERCHANT or ADMIN role

### 4. "Product already exists (skipped)"
- **Cause:** Product with same SKU already exists
- **Solution:** This is expected behavior - duplicate SKUs are skipped (idempotent)

## Best Practices

1. **Test with small files first** - Import 5-10 products to verify format
2. **Use unique SKUs** - Ensure SKUs don't conflict with existing products
3. **Validate data before import** - Check prices, descriptions, etc.
4. **Keep backups** - Save your import files for reference
5. **Review results** - Check the `rowResults` array for any failures

## Example Workflow

1. **Prepare your file:**
   - Use the template files as reference
   - Fill in your product data
   - Validate SKUs are unique

2. **Get authentication token:**
   ```bash
   # Register/Login as Merchant
   curl -X POST http://localhost:8080/api/auth/register \
     -H "Content-Type: application/json" \
     -d '{
       "name": "My Merchant",
       "email": "merchant@example.com",
       "password": "Test123!@$",
       "role": "MERCHANT"
     }'
   ```

3. **Import products:**
   ```bash
   curl -X POST "http://localhost:8080/api/products/bulk/import/csv" \
     -H "Authorization: Bearer <token>" \
     -H "X-User-Id: <user-id>" \
     -F "file=@my-products.csv"
   ```

4. **Verify import:**
   ```bash
   curl http://localhost:8080/api/products?page=0&size=100
   ```

## Notes

- **Idempotent:** Re-importing the same file will skip existing products
- **Transactional:** All products in a file are processed, but failures don't rollback successes
- **Performance:** Large files (1000+ products) may take several seconds
- **Merchant ID:** Products are automatically assigned to the authenticated merchant


