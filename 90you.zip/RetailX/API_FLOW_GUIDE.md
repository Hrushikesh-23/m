# RetailX API Flow Guide for Postman Testing

This guide provides step-by-step instructions for testing all RetailX APIs in Postman, following the correct business flow.

---

## 📋 Prerequisites

1. **All Services Running**: Ensure all microservices are running (Eureka, Gateway, Auth, Product, Order, Payment, Inventory, Notification)
2. **Postman Installed**: Download and install Postman
3. **Import Collection**: Import `POSTMAN_COLLECTION.json` into Postman
4. **Set Variables**: Configure collection variables:
   - `baseUrl`: `http://localhost:8080` (API Gateway)
   - `token`: Will be set automatically after login
   - `userId`: Will be set automatically after login
   - `idempotencyKey`: Generate UUID for each request (optional but recommended)

---

## 🔐 Step 1: Authentication Setup

### 1.1 Register Users (Optional - Only if needed)

**Note**: Registration no longer returns a token. You must login after registration to get a JWT token.

#### Register Customer
```
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "email": "customer@example.com",
  "password": "Customer@123",
  "name": "John Doe",
  "role": "CUSTOMER"
}
```

**Headers**: None required (public endpoint)

**Response**: 
- Status: 201 Created
- Body: `{ "userId": 1, "email": "customer@example.com", "roles": ["CUSTOMER"], "token": null }`

#### Register Merchant
```
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "email": "merchant@example.com",
  "password": "Merchant@123",
  "name": "Jane Merchant",
  "role": "MERCHANT"
}
```

#### Register OPS
```
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "email": "ops@retailx.com",
  "password": "Ops@123",
  "name": "Ops User",
  "role": "OPS"
}
```

#### Register ADMIN
```
POST http://localhost:8080/api/auth/register
Content-Type: application/json

{
  "email": "admin@retailx.com",
  "password": "Admin@123",
  "name": "Admin User",
  "role": "ADMIN"
}
```

---

### 1.2 Login to Get Token

**Important**: You must login after registration to get a JWT token.

#### Login as Customer
```
POST http://localhost:8080/api/auth/login
Content-Type: application/json

{
  "email": "customer@example.com",
  "password": "Customer@123"
}
```

**Response**:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": 1,
  "email": "customer@example.com",
  "roles": ["CUSTOMER"],
  "expiresIn": 3600000
}
```

**Save the token**: Copy the `token` value and set it in Postman collection variable `{{token}}`
**Save the userId**: Copy the `userId` value and set it in Postman collection variable `{{userId}}`

**Repeat for other roles**: Login as Merchant, OPS, and ADMIN to get their tokens.

---

## 🛍️ Step 2: Product & Catalog Setup

### 2.1 Create Products (MERCHANT/ADMIN/OPS)

**Headers Required**:
```
Authorization: Bearer {{token}}
X-User-Id: {{userId}}
X-User-Email: customer@example.com
X-User-Role: MERCHANT
```

#### Create Product
```
POST http://localhost:8080/api/products
Content-Type: application/json

{
  "name": "Laptop",
  "description": "High-performance laptop",
  "sku": "PROD-001",
  "price": 999.99,
  "category": "Electronics",
  "merchantId": 2
}
```

**Response**: Product created with ID

#### Create More Products
Create 2-3 more products with different SKUs (PROD-002, PROD-003, etc.)

---

### 2.2 Add Inventory (OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{opsToken}}
X-User-Id: {{opsId}}
X-User-Role: OPS
```

#### Adjust Inventory (Add Stock)
```
POST http://localhost:8080/api/inventory/adjust?sku=PROD-001&warehouseId=WH-001&quantity=100
```

**Note**: This adds inventory. Use positive quantity to increase stock.

**Repeat for all products** to ensure they have inventory.

---

## 🛒 Step 3: Customer Shopping Flow

### 3.1 Add Items to Cart (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Add Item to Cart
```
POST http://localhost:8080/api/carts/items
Content-Type: application/json

{
  "sku": "PROD-001",
  "quantity": 2
}
```

**Response**: Item added to cart

#### Add More Items
Add 1-2 more items to the cart.

#### View Cart
```
GET http://localhost:8080/api/carts
```

**Response**: Cart with items, subtotal, tax, shipping, total

**Note the total amount** - you'll need this for payment.

---

### 3.2 Checkout (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
Idempotency-Key: {{$guid}} (Generate UUID)
```

#### Checkout
```
POST http://localhost:8080/api/checkout
Content-Type: application/json

{
  "shippingAddress": "123 Main St, City, State, ZIP",
  "shippingMethod": "STANDARD",
  "giftNote": "Happy Birthday!"
}
```

**Response**:
```json
{
  "orderNumber": "ORD-20241213-000001-abc12345",
  "orderId": "1",
  "status": "PENDING",
  "message": "Order created successfully"
}
```

**Save the orderId** - you'll need it for payment.

**What happens automatically**:
- Inventory is reserved for the order
- Cart is cleared
- Order is created with status PENDING

---

## 💳 Step 4: Payment Processing

### 4.1 Create Payment Intent (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
Idempotency-Key: {{$guid}}
```

**Important**: The payment amount MUST exactly match the order total from Step 3.1.

#### Create Payment Intent
```
POST http://localhost:8080/api/payments/intents?orderId=1&amount=224.97&currency=USD
```

**Response**:
```json
{
  "id": 1,
  "paymentIntentId": "pi_abc123",
  "orderId": 1,
  "amount": 224.97,
  "currency": "USD",
  "status": "PENDING"
}
```

**Save the paymentIntentId** for next steps.

**Validation**: If amount doesn't match order total, you'll get an error:
```
"Payment amount (999.99) must exactly match order total (224.97). Payment intent creation rejected."
```

---

### 4.2 Authorize Payment (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
Idempotency-Key: {{$guid}}
```

#### Authorize Payment
```
POST http://localhost:8080/api/payments/1/authorize
```

**Response**: Payment status changes to `AUTHORIZED`

**Note**: Payment must be in PENDING state to authorize.

---

### 4.3 Capture Payment (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
Idempotency-Key: {{$guid}}
```

#### Capture Payment
```
POST http://localhost:8080/api/payments/1/capture
```

**Response**: Payment status changes to `CAPTURED`

**What happens automatically**:
- Order status is updated to `PAID` (via Kafka event)
- Payment confirmation notification is sent

**Verify Order Status**:
```
GET http://localhost:8080/api/orders/1
```

**Expected**: `"status": "PAID"`

---

### 4.4 Alternative: Fail Payment (Testing)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
Idempotency-Key: {{$guid}}
```

#### Mark Payment as Failed
```
POST http://localhost:8080/api/payments/1/fail?errorCode=PAYMENT_DECLINED&errorMessage=Insufficient funds
```

**What happens automatically**:
- Payment status changes to `FAILED`
- `payment.failed` event is published to Kafka
- Order Service consumes event and automatically cancels order
- Order status changes to `CANCELLED`
- Reserved inventory is released

---

## 📦 Step 5: Shipment & Fulfillment

### 5.1 Create Shipment (OPS/ADMIN/MERCHANT)

**Headers Required**:
```
Authorization: Bearer {{opsToken}}
X-User-Id: {{opsId}}
X-User-Role: OPS
```

**Prerequisite**: Order must be in `PAID` or `FULFILLING` status.

#### Create Shipment
```
POST http://localhost:8080/api/shipments/orders/1
Content-Type: application/json

{
  "carrier": "FedEx",
  "trackingNumber": "TRACK123456",
  "estimatedDeliveryDate": "2024-12-20"
}
```

**Response**: Shipment created

**What happens automatically**:
- Order status changes to `SHIPPED`
- Shipment notification is sent

---

### 5.2 Mark Order as Delivered (OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{opsToken}}
X-User-Id: {{opsId}}
X-User-Role: OPS
```

#### Update Order Status to Delivered
```
PUT http://localhost:8080/api/orders/1/status?status=DELIVERED&reason=Package delivered
```

**Response**: Order status updated to `DELIVERED`

---

## 🔄 Step 6: Returns & Refunds

### 6.1 Request Return (CUSTOMER)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Request Return
```
POST http://localhost:8080/api/returns/orders/1
Content-Type: application/json

{
  "reason": "Product damaged",
  "items": [
    {
      "sku": "PROD-001",
      "quantity": 1,
      "reason": "Defective"
    }
  ],
  "refundAmount": 112.48
}
```

**Response**: Return request created with status `PENDING`

---

### 6.2 Approve Return (MERCHANT/OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{merchantToken}}
X-User-Id: {{merchantId}}
X-User-Role: MERCHANT
```

#### Approve Return
```
PUT http://localhost:8080/api/returns/1/approve
```

**What happens automatically**:
- Refund is processed (Payment Service)
- Inventory is restocked (Inventory Service)
- Order status changes to `RETURNED`
- Return status changes to `COMPLETED`

**Verify**:
```
GET http://localhost:8080/api/orders/1
```
**Expected**: `"status": "RETURNED"`

---

### 6.3 Refund Payment Directly (OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{opsToken}}
X-User-Id: {{opsId}}
X-User-Role: OPS
Idempotency-Key: {{$guid}}
```

#### Refund Payment
```
POST http://localhost:8080/api/payments/1/refund?amount=224.97
```

**Validation**: 
- Payment must be `CAPTURED` before refund
- Refund amount cannot exceed `capturedAmount - refundedAmount`
- Supports partial refunds (tracks cumulative `refundedAmount`)

**What happens automatically**:
- Payment status changes to `REFUNDED` (or remains `CAPTURED` for partial refunds)
- `payment.refunded` event is published to Kafka
- Order Service consumes event and automatically cancels order
- Order status changes to `CANCELLED`
- Reserved inventory is released

**Note**: Payment must be `CAPTURED` before refund.

---

## 📊 Step 7: Reporting & Analytics

### 7.1 Sales Report (MERCHANT/ADMIN/OPS)

**Headers Required**:
```
Authorization: Bearer {{merchantToken}}
X-User-Id: {{merchantId}}
X-User-Role: MERCHANT
```

#### Get Sales Report
```
GET http://localhost:8080/api/reports/sales?startDate=2024-01-01T00:00:00&endDate=2024-12-31T23:59:59
```

**Response**:
```json
{
  "merchantId": 2,
  "period": {
    "start": "2024-01-01T00:00:00",
    "end": "2024-12-31T23:59:59"
  },
  "totalOrders": 10,
  "totalSales": 2249.70,
  "totalRefunds": 224.97,
  "netSales": 2024.73
}
```

---

### 7.2 Order Status Counts (MERCHANT/ADMIN/OPS)

**Headers Required**:
```
Authorization: Bearer {{merchantToken}}
X-User-Id: {{merchantId}}
X-User-Role: MERCHANT
```

#### Get Order Status Counts
```
GET http://localhost:8080/api/reports/order-status
```

**Response**:
```json
{
  "PENDING": 2,
  "PAID": 5,
  "SHIPPED": 3,
  "DELIVERED": 10,
  "CANCELLED": 1,
  "RETURNED": 1
}
```

---

## 📦 Step 8: Inventory Management

### 8.1 Get Low Stock Items (MERCHANT/ADMIN/OPS)

**Headers Required**:
```
Authorization: Bearer {{merchantToken}}
X-User-Id: {{merchantId}}
X-User-Role: MERCHANT
```

#### Get Low Stock Items
```
GET http://localhost:8080/api/inventory/low-stock
```

**Response**: List of items with available quantity below threshold

---

### 8.2 Adjust Inventory (OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{opsToken}}
X-User-Id: {{opsId}}
X-User-Role: OPS
```

#### Adjust Inventory (Restock)
```
POST http://localhost:8080/api/inventory/adjust?sku=PROD-001&warehouseId=WH-001&quantity=50
```

**Note**: Positive quantity adds inventory, negative removes.

---

## 🔍 Step 9: View Order Details

### 9.1 Get Order by ID (CUSTOMER/MERCHANT/OPS/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Get Order Details
```
GET http://localhost:8080/api/orders/1
```

**Response**: Complete order details including items, status, totals, etc.

### 9.2 Get Order by Order Number

```
GET http://localhost:8080/api/orders/number/ORD-20241213-000001-abc12345
```

**Response**: Order details by order number

### 9.3 Get Order Audit Log

```
GET http://localhost:8080/api/orders/1/audit
```

**Response**: List of audit log entries showing all status changes and operations on the order

---

## 🔐 Step 10: User Profile Management

### 10.1 Update Email (CUSTOMER/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Update Email
```
PUT http://localhost:8080/api/auth/email
Content-Type: application/json

{
  "newEmail": "newemail@example.com"
}
```

**Response**: `{ "message": "Email updated successfully" }`

### 10.2 Update Password (CUSTOMER/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Update Password
```
PUT http://localhost:8080/api/auth/password
Content-Type: application/json

{
  "currentPassword": "OldPassword@123",
  "newPassword": "NewPassword@123"
}
```

**Response**: `{ "message": "Password updated successfully" }`

### 10.3 Logout (CUSTOMER/ADMIN)

**Headers Required**:
```
Authorization: Bearer {{customerToken}}
X-User-Id: {{customerId}}
X-User-Role: CUSTOMER
```

#### Logout
```
POST http://localhost:8080/api/auth/logout
```

**Response**: `{ "message": "Logged out successfully" }`

**Note**: JWT tokens are stateless. This endpoint is for client-side session management. In production, you might want to maintain a token blacklist.

---

## 🔑 Step 11: Password Reset Flow

### 11.1 Forgot Password (Public)

**Headers Required**: None (public endpoint)

#### Request Password Reset
```
POST http://localhost:8080/api/auth/forgot-password
Content-Type: application/json

{
  "email": "customer@example.com"
}
```

**Response**: `{ "message": "If the email exists, a password reset link has been sent" }`

**What happens**:
- System generates a secure reset token
- Token is saved to database (expires in 1 hour)
- Email is sent with reset link (if email service is configured)
- Token is single-use

### 11.2 Reset Password (Public)

**Headers Required**: None (public endpoint)

#### Reset Password with Token
```
POST http://localhost:8080/api/auth/reset-password
Content-Type: application/json

{
  "token": "reset-token-from-email",
  "newPassword": "NewPassword@123"
}
```

**Response**: `{ "message": "Password reset successfully" }`

**What happens**:
- Token is validated (not expired, not used)
- Password is updated
- Token is marked as used
- User can now login with new password

---

## 📝 Complete Flow Summary

### Happy Path (Successful Purchase)
1. Register/Login → Get Token
2. Create Products → Add Inventory
3. Add to Cart → Checkout → Order Created (PENDING)
4. Create Payment Intent → Authorize → Capture → Order PAID
5. Create Shipment → Order SHIPPED
6. Mark Delivered → Order DELIVERED

### Return Flow
1. Request Return → Return PENDING
2. Approve Return → Refund Processed → Inventory Restocked → Order RETURNED

### Refund Flow
1. Refund Payment → Order CANCELLED (automatic)

### Payment Failure Flow
1. Fail Payment → Order CANCELLED (automatic)

---

## ⚠️ Important Notes

1. **Headers**: Always include:
   - `Authorization: Bearer {{token}}`
   - `X-User-Id: {{userId}}`
   - `X-User-Role: {{role}}` (CUSTOMER, MERCHANT, OPS, ADMIN)

2. **Idempotency**: Use `Idempotency-Key` header for:
   - Checkout
   - Payment operations (create, authorize, capture, refund)
   - Generate UUID: `{{$guid}}` in Postman

3. **Payment Amount**: Must exactly match order total

4. **Order Status Flow**:
   - PENDING → PAID → FULFILLING → SHIPPED → DELIVERED
   - Can be cancelled at any time
   - Can be returned after delivery

5. **Automatic Actions**:
   - Payment captured → `payment.captured` event → Order status → PAID
   - Payment failed → `payment.failed` event → Order status → CANCELLED
   - Payment refunded → `payment.refunded` event → Order status → CANCELLED
   - Return approved → Order status → RETURNED + Refund processed + Inventory restocked
   - Order expiration (scheduled) → PENDING orders older than 24h → CANCELLED
   - Payment intent expiration (scheduled) → PENDING intents older than 30min → FAILED
   - Cart cleanup (scheduled) → Expired carts → Deleted + Inventory released

---

## 🎯 Testing Checklist

- [ ] Register users (Customer, Merchant, OPS, Admin)
- [ ] Login and get tokens for all roles
- [ ] Create products
- [ ] Add inventory
- [ ] Add items to cart
- [ ] Checkout (creates order)
- [ ] Create payment intent (with correct amount)
- [ ] Authorize payment
- [ ] Capture payment (order becomes PAID)
- [ ] Create shipment (order becomes SHIPPED)
- [ ] Mark delivered (order becomes DELIVERED)
- [ ] Request return
- [ ] Approve return (order becomes RETURNED)
- [ ] Test payment failure (order becomes CANCELLED automatically)
- [ ] Test refund (order becomes CANCELLED automatically)
- [ ] Update email
- [ ] Update password
- [ ] Logout
- [ ] Forgot password (request reset)
- [ ] Reset password (with token)
- [ ] Get order by order number
- [ ] Get order audit log
- [ ] View sales reports
- [ ] View order status counts
- [ ] Check low stock items
- [ ] Adjust inventory

---

## 🐛 Troubleshooting

### 403 Forbidden
- Check that you're using the correct role token
- Verify `X-User-Role` header matches the token's role

### 400 Bad Request
- Payment amount doesn't match order total
- Order status doesn't allow the operation
- Missing required parameters

### 404 Not Found
- Order/Product/Payment doesn't exist
- Check IDs are correct

### 500 Internal Server Error
- Service might be down
- Check service logs
- Verify database connection

---

## 📚 Additional Resources

- **Inventory APIs Usage**: See `INVENTORY_APIS_USAGE.md`
- **API Documentation**: Access Swagger UI at `http://localhost:8080/swagger-ui.html` (if configured)
- **Service Ports**: 
  - Gateway: 8080
  - Auth: 8081
  - Product: 8082
  - Order: 8083
  - Payment: 8084
  - Inventory: 8085
  - Notification: 8086

---

**Last Updated**: December 2024

## 📝 Additional Notes

### Scheduled Jobs

The system includes several scheduled jobs that run automatically:

1. **Order Expiration Scheduler** (Order Service)
   - Runs every hour
   - Cancels PENDING orders older than 24 hours
   - Releases reserved inventory

2. **Payment Intent Expiration Scheduler** (Payment Service)
   - Runs every 30 minutes
   - Expires PENDING payment intents older than 30 minutes
   - Marks as FAILED and cancels associated order

3. **Cart Cleanup Scheduler** (Order Service)
   - Runs daily
   - Deletes abandoned carts (older than 7 days)
   - Releases inventory holds

4. **Password Reset Token Cleanup Scheduler** (Auth Service)
   - Runs daily
   - Deletes expired password reset tokens

### Event-Driven Updates

The following operations trigger automatic updates via Kafka events:

- **Payment Captured** → Order status updated to PAID
- **Payment Failed** → Order cancelled automatically
- **Payment Refunded** → Order cancelled automatically
- **Return Approved** → Refund processed, inventory restocked, order marked as RETURNED

