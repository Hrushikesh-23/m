# RetailX - High-Level Design (HLD) Diagram

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           CLIENT LAYER                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │ Web Browser  │  │ Mobile App   │  │  Postman     │  │  Admin UI    │  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  │
└─────────┼──────────────────┼──────────────────┼──────────────────┼──────────┘
          │                  │                  │                  │
          └──────────────────┴──────────────────┴──────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        API GATEWAY LAYER                                    │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Spring Cloud Gateway (Port 8080)                  │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │  JWT Authentication Filter                                     │   │  │
│  │  │  - Validates JWT tokens                                       │   │  │
│  │  │  - Extracts user roles                                        │   │  │
│  │  │  - Adds X-User-Id, X-User-Email, X-User-Role headers        │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │  Rate Limiting Filter                                         │   │  │
│  │  │  - Role-based rate limiting                                   │   │  │
│  │  │  - Default: 10 req/sec                                       │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │  Route Configuration                                          │   │  │
│  │  │  - /api/auth/** → Auth Service                                │   │  │
│  │  │  - /api/products/** → Product Service                        │   │  │
│  │  │  - /api/orders/** → Order Service                             │   │  │
│  │  │  - /api/payments/** → Payment Service                         │   │  │
│  │  │  - /api/inventory/** → Inventory Service                      │   │  │
│  │  │  - /** → Frontend Service                                     │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                      SERVICE DISCOVERY LAYER                                 │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    Netflix Eureka Server (Port 8761)                  │  │
│  │  - Service Registration                                               │  │
│  │  - Service Discovery                                                  │  │
│  │  - Health Monitoring                                                  │  │
│  │  - Load Balancing                                                     │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
                             │
          ┌──────────────────┼──────────────────┐
          │                  │                  │
          ▼                  ▼                  ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│  MICROSERVICES  │ │  MICROSERVICES  │ │  MICROSERVICES  │
│     LAYER       │ │     LAYER       │ │     LAYER       │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

## Microservices Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         MICROSERVICES LAYER                                  │
│                                                                               │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐        │
│  │  Auth Service    │  │ Product Service   │  │  Order Service    │        │
│  │  Port: 8081      │  │ Port: 8082        │  │ Port: 8083        │        │
│  │                  │  │                   │  │                   │        │
│  │  - Registration  │  │ - Product CRUD   │  │ - Cart Mgmt      │        │
│  │  - Login         │  │ - Search/Filter  │  │ - Checkout        │        │
│  │  - JWT Gen       │  │ - Bulk Import    │  │ - Order Mgmt      │        │
│  │  - User Mgmt     │  │ - Reviews        │  │ - Shipments       │        │
│  │  - Email/Pass    │  │                   │  │ - Returns         │        │
│  │    Update        │  │                   │  │ - Audit Logs      │        │
│  │  - Password      │  │                   │  │ - Scheduled Jobs  │        │
│  │    Reset         │  │                   │  │   (Order Expiry)  │        │
│  │  - Account       │  │                   │  │                   │        │
│  │    Lockout       │  │                   │  │                   │        │
│  │                  │  │                   │  │                   │        │
│  │  DB: retailx_auth│  │ DB: retailx_product│ │ DB: retailx_order│        │
│  └────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘        │
│           │                      │                      │                   │
│  ┌────────┴─────────┐  ┌────────┴─────────┐  ┌────────┴─────────┐        │
│  │ Payment Service  │  │Inventory Service │  │Notification Svc  │        │
│  │ Port: 8084       │  │ Port: 8084       │  │ Port: 8086       │        │
│  │                  │  │                  │  │                  │        │
│  │ - Payment Intent │  │ - Stock Mgmt     │  │ - Email/SMS      │        │
│  │ - Authorize      │  │ - Reservations   │  │ - Push Notif     │        │
│  │ - Capture        │  │ - Low Stock Alert│  │ - Event Consumer │        │
│  │ - Fail           │  │ - Optimistic     │  │ - REST Endpoints │        │
│  │ - Refund         │  │   Locking        │  │                  │        │
│  │ - Scheduled Jobs │  │                  │  │                  │        │
│  │   (Intent Expiry)│  │                  │  │                  │        │
│  │                  │  │                  │  │                  │        │
│  │ DB: retailx_     │  │ DB: retailx_     │  │ (Stateless)      │        │
│  │     payment      │  │     inventory    │  │                  │        │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘        │
│                                                                               │
│  ┌──────────────────┐                                                        │
│  │ Frontend Service │                                                        │
│  │ Port: 8087      │                                                        │
│  │                  │                                                        │
│  │ - Thymeleaf UI  │                                                        │
│  │ - Catalog Page  │                                                        │
│  │ - Cart/Checkout │                                                        │
│  │ - Order History │                                                        │
│  │ - Merchant Dash│                                                        │
│  └──────────────────┘                                                        │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Data Flow Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         REQUEST FLOW                                        │
│                                                                               │
│  Client Request                                                               │
│       │                                                                       │
│       ▼                                                                       │
│  API Gateway (JWT Validation, Rate Limiting)                                  │
│       │                                                                       │
│       ▼                                                                       │
│  Eureka (Service Discovery)                                                  │
│       │                                                                       │
│       ▼                                                                       │
│  Target Microservice                                                          │
│       │                                                                       │
│       ├─► Database (MySQL)                                                   │
│       │                                                                       │
│       ├─► Feign Client (Inter-service call)                                  │
│       │                                                                       │
│       └─► Kafka (Event Publishing)                                            │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                         EVENT-DRIVEN FLOW                                    │
│                                                                               │
│  Order Service                                                                │
│       │                                                                       │
│       ├─► Publishes: order.created                                           │
│       │                                                                       │
│  Kafka Broker                                                                 │
│       │                                                                       │
│       ├─► Inventory Service (Consumes: order.created)                        │
│       │   └─► Reserves inventory                                             │
│       │                                                                       │
│       ├─► Notification Service (Consumes: order.created)                      │
│       │   └─► Sends confirmation email                                       │
│       │                                                                       │
│       └─► Analytics Service (Future)                                          │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Infrastructure Layer

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      INFRASTRUCTURE LAYER                                    │
│                                                                               │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐         │
│  │   MySQL 8.0      │  │  Apache Kafka    │  │   Zipkin          │         │
│  │   Port: 3306     │  │  Port: 9092      │  │   Port: 9411      │         │
│  │                  │  │                  │  │                   │         │
│  │  - retailx_auth  │  │  - Topics:       │  │  - Distributed    │         │
│  │  - retailx_      │  │    * order.*     │  │    Tracing        │         │
│  │    product       │  │    * inventory.* │  │                   │         │
│  │  - retailx_order │  │    * payment.*   │  │                   │         │
│  │  - retailx_      │  │    * shipment.*  │  │                   │         │
│  │    payment       │  │    * return.*    │  │                   │         │
│  │  - retailx_      │  │                  │  │                   │         │
│  │    inventory     │  │  - Zookeeper     │  │                   │         │
│  │                  │  │    Port: 2181    │  │                   │         │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘         │
│                                                                               │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐         │
│  │   Prometheus     │  │   Actuator        │  │   Resilience4j    │         │
│  │   Metrics        │  │   Health Checks   │  │   Circuit Breaker │         │
│  │                  │  │                   │  │                   │         │
│  │  - HTTP Metrics  │  │  - /actuator/     │  │  - Payment       │         │
│  │  - JVM Metrics   │  │    health         │  │    Service       │         │
│  │  - DB Metrics    │  │  - /actuator/     │  │  - Retry Logic   │         │
│  │  - Kafka Metrics │  │    metrics         │  │  - Fallback      │         │
│  │                  │  │  - /actuator/     │  │                   │         │
│  │                  │  │    prometheus     │  │                   │         │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘         │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Security Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        SECURITY LAYERS                                       │
│                                                                               │
│  Layer 1: API Gateway                                                         │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  - JWT Token Validation                                              │   │
│  │  - Role Extraction                                                   │   │
│  │  - Rate Limiting (Role-based)                                        │   │
│  │  - Request Filtering                                                  │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Layer 2: Service Level                                                       │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  - Spring Security Configuration                                      │   │
│  │  - Path-based Authorization                                           │   │
│  │  - Method Security (@PreAuthorize)                                    │   │
│  │  - Role-based Access Control (RBAC)                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Layer 3: Data Level                                                          │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  - PII Encryption (AES GCM)                                          │   │
│  │  - Password Hashing (BCrypt)                                         │   │
│  │  - Data Masking                                                      │   │
│  │  - Audit Trail (AOP)                                                 │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      DEPLOYMENT ARCHITECTURE                                  │
│                                                                               │
│  Development Environment                                                      │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  Local Machine                                                        │   │
│  │  - All services run on localhost                                      │   │
│  │  - Docker Compose for infrastructure                                  │   │
│  │  - MySQL, Kafka, Zookeeper in containers                             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Production Environment (Future)                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  Kubernetes Cluster                                                  │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  Pod: Eureka │  │  Pod: Gateway│  │  Pod: Auth   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  Pod: Product│  │  Pod: Order  │  │  Pod: Payment│              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  Pod: Inventory│ │  Pod: Notify│  │  Pod: Frontend│             │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │                                                                      │   │
│  │  - Auto-scaling based on metrics                                     │   │
│  │  - Load balancing                                                    │   │
│  │  - Health checks                                                     │   │
│  │  - Rolling updates                                                   │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Technology Stack

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      TECHNOLOGY STACK                                        │
│                                                                               │
│  Backend Framework                                                            │
│  - Java 21                                                                    │
│  - Spring Boot 3.2.0                                                         │
│  - Spring Cloud 2023.0.0                                                     │
│                                                                               │
│  Service Discovery                                                            │
│  - Netflix Eureka                                                             │
│                                                                               │
│  API Gateway                                                                  │
│  - Spring Cloud Gateway                                                       │
│                                                                               │
│  Database                                                                     │
│  - MySQL 8.0                                                                  │
│  - JPA/Hibernate                                                              │
│                                                                               │
│  Message Broker                                                               │
│  - Apache Kafka                                                               │
│  - Zookeeper                                                                  │
│                                                                               │
│  Security                                                                     │
│  - Spring Security                                                            │
│  - JWT (JJWT 0.12.3)                                                          │
│  - BCrypt                                                                     │
│                                                                               │
│  Resilience                                                                   │
│  - Resilience4j (Circuit Breaker, Retry)                                     │
│                                                                               │
│  Observability                                                                │
│  - Micrometer                                                                 │
│  - Prometheus                                                                 │
│  - Zipkin                                                                     │
│                                                                               │
│  Testing                                                                      │
│  - JUnit 5                                                                    │
│  - Mockito                                                                    │
│  - Testcontainers                                                             │
│                                                                               │
│  Build Tool                                                                   │
│  - Maven 3.8+                                                                 │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Key Design Patterns

1. **Microservices Architecture** - Service per domain
2. **API Gateway Pattern** - Single entry point
3. **Service Discovery** - Eureka for dynamic service location
4. **Database per Service** - Data isolation
5. **Event-Driven Architecture** - Kafka for async communication
6. **Circuit Breaker** - Resilience4j for fault tolerance
7. **CQRS** - Separate read/write models (implicit)
8. **Idempotency** - Key-based duplicate prevention
9. **Audit Trail** - AOP-based logging
10. **Rate Limiting** - Role-based throttling

## Scalability Considerations

- **Horizontal Scaling**: Each service can scale independently
- **Load Balancing**: Eureka provides client-side load balancing
- **Database Scaling**: Read replicas for read-heavy services
- **Caching**: Redis (future) for product catalog
- **CDN**: For static assets (future)
- **Message Queue**: Kafka handles high throughput

## High Availability

- **Service Replication**: Multiple instances per service
- **Health Checks**: Actuator endpoints
- **Circuit Breakers**: Prevent cascade failures
- **Retry Logic**: Automatic retry with exponential backoff
- **Graceful Degradation**: Fallback mechanisms

