# RetailX Entity Relationship Diagram

## Database Schema Overview

RetailX uses a **database per service** pattern. Each microservice has its own database schema.

## Database Schemas

### 1. retailx_auth (Auth Service)
- **users** - User accounts with authentication
- **user_roles** - User role mappings
- **password_reset_tokens** - Password reset tokens (expires in 1 hour)

### 2. retailx_product (Product Service)
- **products** - Product catalog
- **variants** - Product variants (size, color, etc.)
- **product_media** - Product images/media URLs
- **reviews** - Product reviews and ratings

### 3. retailx_order (Order Service)
- **orders** - Customer orders
- **order_items** - Order line items (includes returnedQuantity field)
- **order_versions** - Order version history
- **carts** - Shopping carts
- **cart_items** - Cart line items
- **shipments** - Shipment tracking
- **shipment_items** - Shipment line items
- **returns** - Return requests and refunds
- **return_items** - Return line items
- **idempotency_keys** - Idempotency key storage
- **audit_logs** - Audit trail for order operations

### 4. retailx_payment (Payment Service)
- **payment_intents** - Payment transactions (includes refundedAmount field for partial refunds)

### 5. retailx_inventory (Inventory Service)
- **inventory** - Stock levels per SKU/warehouse
- **inventory_holds** - Inventory reservations

## Entity Relationships

### Auth Service Schema

```
users
├── id (PK)
├── email (UNIQUE)
├── password_hash
├── active
├── last_login_at
├── password_changed_at
├── failed_login_attempts
├── locked_until (account lockout after failed attempts)
├── created_on
├── updated_on
└── deleted

user_roles
├── user_id (FK -> users.id)
└── role (CUSTOMER, MERCHANT, OPS, ADMIN)

password_reset_tokens
├── id (PK)
├── user_id (FK -> users.id)
├── token (UNIQUE, secure random)
├── expires_at (1 hour from creation)
├── used (boolean)
├── used_at
├── created_on
└── updated_on
```

### Product Service Schema

```
products
├── id (PK)
├── sku (UNIQUE)
├── name
├── description
├── base_price
├── currency
├── category_path
├── catalog_path (for regex search)
├── status (DRAFT, ACTIVE, DISCONTINUED)
├── attributes (JSON)
├── merchant_id (reference to auth service)
├── created_on
├── updated_on
└── deleted

variants
├── id (PK)
├── variant_sku (UNIQUE)
├── product_id (FK -> products.id)
├── options (JSON: size, color, etc.)
├── price_override
├── created_on
├── updated_on
└── deleted

product_media
├── product_id (FK -> products.id)
└── url

reviews
├── id (PK)
├── product_id (FK -> products.id)
├── customer_id (reference to auth service)
├── order_item_id (reference to order service)
├── rating (1-5)
├── text
├── status (PENDING, APPROVED, HIDDEN)
├── moderated
├── created_on
├── updated_on
└── deleted
```

### Order Service Schema

```
orders
├── id (PK)
├── order_number (UNIQUE)
├── customer_id (reference to auth service)
├── merchant_id (reference to auth service)
├── status (PENDING, PAID, FULFILLING, SHIPPED, DELIVERED, CANCELLED, etc.)
├── subtotal
├── tax
├── shipping
├── discount
├── total
├── shipping_address (JSON/encrypted)
├── shipping_method
├── gift_note
├── version
├── created_on
├── updated_on
└── deleted

order_items
├── id (PK)
├── order_id (FK -> orders.id)
├── sku
├── product_name
├── quantity
├── unit_price
├── line_total
├── returned_quantity (cumulative returned quantity)
├── created_on
├── updated_on
└── deleted

order_versions
├── id (PK)
├── order_id (FK -> orders.id)
├── version_number
├── shipping_address
├── shipping_method
├── gift_note
├── shipping
├── changed_by
├── change_reason
├── created_on
└── updated_on

carts
├── id (PK)
├── customer_id (reference to auth service)
├── subtotal
├── tax
├── shipping
├── discount
├── total
├── expires_at
├── abandoned
├── created_on
├── updated_on
└── deleted

cart_items
├── id (PK)
├── cart_id (FK -> carts.id)
├── sku
├── quantity
├── unit_price
├── line_total
├── created_on
├── updated_on
└── deleted

shipments
├── id (PK)
├── order_id (reference to orders)
├── shipment_number (UNIQUE)
├── carrier
├── tracking_number
├── shipped_at
├── delivered_at
├── created_on
├── updated_on
└── deleted

shipment_items
├── id (PK)
├── shipment_id (FK -> shipments.id)
├── sku
├── quantity
├── created_on
├── updated_on
└── deleted

returns
├── id (PK)
├── order_id (reference to orders)
├── rma_number (UNIQUE)
├── status (REQUESTED, APPROVED, REJECTED, COMPLETED)
├── reason
├── refund_amount
├── restocked
├── requested_at
├── approved_at
├── completed_at
├── created_on
├── updated_on
└── deleted

return_items
├── id (PK)
├── return_id (FK -> returns.id)
├── sku
├── quantity
├── created_on
├── updated_on
└── deleted

idempotency_keys
├── id (PK)
├── key_value (UNIQUE)
├── request_hash
├── response_summary
├── expires_at
├── used
├── created_on
└── updated_on
```

### Payment Service Schema

```
payment_intents
├── id (PK)
├── order_id (UNIQUE, reference to order service)
├── payment_intent_id
├── amount
├── currency
├── status (PENDING, AUTHORIZED, CAPTURED, FAILED, REFUNDED)
├── correlation_id (for idempotency)
├── payment_method
├── error_code
├── error_message
├── refunded_amount (cumulative refunded amount for partial refunds)
├── created_on
├── updated_on
└── deleted
```

### Inventory Service Schema

```
inventory
├── id (PK)
├── sku (product SKU or variant SKU)
├── warehouse_id
├── on_hand
├── reserved
├── available (computed: on_hand - reserved)
├── version (for optimistic locking)
├── created_on
├── updated_on
└── deleted
UNIQUE(sku, warehouse_id)

inventory_holds
├── id (PK)
├── sku
├── quantity
├── warehouse_id
├── cart_id (for cart holds)
├── order_id (for order holds)
├── expires_at
├── released
├── created_on
├── updated_on
└── deleted
```

## Key Relationships

1. **User → Orders**: One user can have many orders
2. **Order → OrderItems**: One order has many line items
3. **Order → OrderVersions**: One order can have up to 10 versions
4. **Order → Shipments**: One order can have multiple shipments
5. **Shipment → ShipmentItems**: One shipment has many items
6. **Order → Returns**: One order can have multiple returns
7. **Return → ReturnItems**: One return has many items
8. **Product → Variants**: One product can have many variants
9. **Product → Reviews**: One product can have many reviews
10. **Cart → CartItems**: One cart has many items
11. **Inventory → InventoryHolds**: One inventory record can have many holds
12. **Order → PaymentIntent**: One-to-one relationship

## Indexes

### Critical Indexes
- `users.email` (UNIQUE)
- `products.sku` (UNIQUE)
- `products.category_path`
- `products.catalog_path` (for regex search)
- `orders.order_number` (UNIQUE)
- `orders.customer_id`
- `orders.status`
- `shipments.shipment_number` (UNIQUE)
- `shipments.order_id`
- `shipments.tracking_number`
- `returns.rma_number` (UNIQUE)
- `returns.order_id`
- `reviews.product_id`
- `reviews.customer_id`
- `reviews.status`
- `idempotency_keys.key_value` (UNIQUE)
- `inventory.sku, warehouse_id` (UNIQUE)
- `inventory_holds.cart_id`
- `inventory_holds.order_id`
- `inventory_holds.expires_at`

## Data Flow Between Services

```
Auth Service (User) 
    ↓ (user_id reference)
Order Service (Order) 
    ↓ (order_id reference)
Payment Service (PaymentIntent)
    ↓ (order_id reference)
Inventory Service (Reserve inventory)
```

## New Entities

### audit_logs (Order Service)
├── id (PK)
├── order_id (FK -> orders.id)
├── action (STATUS_CHANGED, CANCELLED, etc.)
├── actor_id (user who performed action)
├── old_value
├── new_value
├── reason
├── created_on
└── updated_on

## Notes

- All tables have `created_on`, `updated_on`, and `deleted` fields for audit and soft delete
- Cross-service references use IDs (not foreign keys) due to microservices architecture
- PII fields (email, phone, addresses) are encrypted at rest using AES GCM
- Order versions are limited to 10 per order
- Inventory holds expire and are automatically released
- Inventory uses optimistic locking (version field) to prevent race conditions
- Shipments can be created for orders in PAID or FULFILLING status
- Returns can only be requested for DELIVERED orders within 30 days
- Return quantities are tracked cumulatively per order item
- Reviews require a valid order item and are moderated before being visible
- Reviews can only be created for DELIVERED orders
- Idempotency keys expire after 24 hours and prevent duplicate operations
- Password reset tokens expire after 1 hour and are single-use
- Account lockout after 5 failed login attempts (locked for 30 minutes)
- Payment intents track cumulative refunded amount for partial refunds
- Orders automatically cancelled when payment fails or is refunded (via Kafka events)
- Orders automatically updated to PAID when payment is captured (via Kafka events)

