package com.retailx.inventory.service;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.domain.InventoryHold;
import com.retailx.inventory.repository.InventoryHoldRepository;
import com.retailx.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for inventory management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryService {
    
    private final InventoryRepository inventoryRepository;
    private final InventoryHoldRepository inventoryHoldRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${retailx.inventory.low-stock-threshold:10}")
    private BigInteger lowStockThreshold;
    
    @Transactional
    public boolean reserveInventory(String sku, BigInteger quantity, String warehouseId) {
        log.info("Reserving inventory: sku={}, quantity={}, warehouseId={}", 
                sku, quantity, warehouseId);
        
        // Retry mechanism for optimistic locking conflicts
        int maxRetries = 3;
        int retryCount = 0;
        
        while (retryCount < maxRetries) {
            try {
                Inventory inventory = inventoryRepository.findBySkuAndWarehouseId(sku, warehouseId)
                        .orElseThrow(() -> new RuntimeException("Inventory not found for SKU: " + sku));
                
                // Re-check available quantity (may have changed due to concurrent updates)
                inventory.getAvailable(); // Trigger recalculation
                if (inventory.getAvailable().compareTo(quantity) < 0) {
                    log.warn("Insufficient inventory: available={}, requested={}", 
                            inventory.getAvailable(), quantity);
                    return false;
                }
                
                inventory.setReserved(inventory.getReserved().add(quantity));
                inventoryRepository.save(inventory);
                
                // Success - break out of retry loop
                break;
            } catch (org.springframework.orm.ObjectOptimisticLockingFailureException e) {
                retryCount++;
                if (retryCount >= maxRetries) {
                    log.error("Failed to reserve inventory after {} retries due to concurrent updates: sku={}", 
                            maxRetries, sku);
                    return false;
                }
                log.warn("Optimistic locking conflict on inventory reservation, retrying (attempt {}/{}): sku={}", 
                        retryCount, maxRetries, sku);
                try {
                    Thread.sleep(50 * retryCount); // Exponential backoff
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return false;
                }
            }
        }
        
        // Publish event (async, non-blocking)
        try {
            kafkaTemplate.send("inventory.reserved", sku, 
                    String.format("{\"sku\":\"%s\",\"quantity\":%s,\"warehouseId\":\"%s\"}", 
                            sku, quantity, warehouseId));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for inventory reservation: {}", e.getMessage());
            // Don't fail the reservation if Kafka is unavailable
        }
        
        return true;
    }
    
    @Transactional
    public void createHold(String sku, BigInteger quantity, String warehouseId, 
                          String cartId, Long orderId, LocalDateTime expiresAt) {
        InventoryHold hold = InventoryHold.builder()
                .sku(sku)
                .quantity(quantity)
                .warehouseId(warehouseId)
                .cartId(cartId)
                .orderId(orderId)
                .expiresAt(expiresAt)
                .released(false)
                .build();
        
        inventoryHoldRepository.save(hold);
    }
    
    @Transactional
    public void releaseHold(String cartId) {
        log.info("Releasing holds for cart: {}", cartId);
        List<InventoryHold> holds = inventoryHoldRepository.findByCartId(cartId);
        releaseHolds(holds);
    }
    
    @Transactional
    public void releaseHoldByOrder(Long orderId) {
        log.info("Releasing holds for order: {}", orderId);
        List<InventoryHold> holds = inventoryHoldRepository.findByOrderId(orderId);
        releaseHolds(holds);
    }
    
    private void releaseHolds(List<InventoryHold> holds) {
        for (InventoryHold hold : holds) {
            if (!hold.getReleased()) {
                Inventory inventory = inventoryRepository
                        .findBySkuAndWarehouseId(hold.getSku(), hold.getWarehouseId())
                        .orElse(null);
                
                if (inventory != null) {
                    inventory.setReserved(inventory.getReserved().subtract(hold.getQuantity()));
                    inventoryRepository.save(inventory);
                }
                
                hold.setReleased(true);
                inventoryHoldRepository.save(hold);
            }
        }
    }
    
    @Transactional
    public void releaseExpiredHolds() {
        log.info("Releasing expired holds");
        List<InventoryHold> expiredHolds = inventoryHoldRepository
                .findExpiredHolds(LocalDateTime.now());
        releaseHolds(expiredHolds);
    }
    
    public List<Inventory> getLowStockItems() {
        return inventoryRepository.findLowStock(lowStockThreshold);
    }
    
    @Transactional
    public void adjustInventory(String sku, String warehouseId, BigInteger quantity) {
        log.info("Adjusting inventory: sku={}, warehouseId={}, quantity={}", sku, warehouseId, quantity);
        
        Inventory inventory = inventoryRepository.findBySkuAndWarehouseId(sku, warehouseId)
                .orElse(null);
        
        if (inventory == null) {
            // Create new inventory record
            inventory = new Inventory();
            inventory.setSku(sku);
            inventory.setWarehouseId(warehouseId);
            inventory.setOnHand(BigInteger.ZERO);
            inventory.setReserved(BigInteger.ZERO);
            inventory.setAvailable(BigInteger.ZERO);
            inventory.setDeleted(false);
        }
        
        // Ensure fields are not null
        if (inventory.getOnHand() == null) inventory.setOnHand(BigInteger.ZERO);
        if (inventory.getReserved() == null) inventory.setReserved(BigInteger.ZERO);
        
        // Validation: Reasonable adjustment limit (prevent accidental large adjustments)
        if (quantity.abs().compareTo(BigInteger.valueOf(10000)) > 0) {
            throw new RuntimeException("Adjustment quantity exceeds maximum allowed (10000)");
        }
        
        // Validation: Prevent negative available quantity
        BigInteger newOnHand = inventory.getOnHand().add(quantity);
        if (newOnHand.compareTo(inventory.getReserved()) < 0) {
            throw new RuntimeException(
                String.format("Inventory adjustment would result in negative available quantity. " +
                        "onHand: %s, reserved: %s, adjustment: %s", 
                        inventory.getOnHand(), inventory.getReserved(), quantity));
        }
        
        inventory.setOnHand(newOnHand);
        inventory = inventoryRepository.save(inventory);
        
        // Check for low stock (available is calculated on save)
        BigInteger available = inventory.getOnHand().subtract(inventory.getReserved());
        log.info("Inventory adjusted: sku={}, newOnHand={}, available={}", sku, newOnHand, available);
        
        if (available.compareTo(lowStockThreshold) < 0) {
            try {
                kafkaTemplate.send("inventory.low-stock", sku,
                        String.format("{\"sku\":\"%s\",\"available\":%s,\"warehouseId\":\"%s\"}", 
                                sku, available, warehouseId));
            } catch (Exception e) {
                log.warn("Failed to send low stock Kafka event: {}", e.getMessage());
            }
        }
    }
    
    /**
     * Release reserved inventory back to available stock.
     * Used when order is cancelled or order creation fails.
     */
    @Transactional
    public boolean releaseReservedInventory(String sku, BigInteger quantity, String warehouseId) {
        log.info("Releasing reserved inventory: sku={}, quantity={}, warehouseId={}", 
                sku, quantity, warehouseId);
        
        Inventory inventory = inventoryRepository.findBySkuAndWarehouseId(sku, warehouseId)
                .orElseThrow(() -> new RuntimeException("Inventory not found for SKU: " + sku));
        
        if (inventory.getReserved().compareTo(quantity) < 0) {
            log.warn("Cannot release more than reserved: reserved={}, requested={}", 
                    inventory.getReserved(), quantity);
            return false;
        }
        
        inventory.setReserved(inventory.getReserved().subtract(quantity));
        inventoryRepository.save(inventory);
        
        log.info("Reserved inventory released: sku={}, quantity={}", sku, quantity);
        return true;
    }
}

