package com.retailx.repository;

import com.retailx.domain.Promotion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Promotion entity.
 */
@Repository
public interface PromotionRepository extends JpaRepository<Promotion, Long> {
    
    Optional<Promotion> findByCode(String code);
    
    @Query("SELECT p FROM Promotion p WHERE p.code = :code " +
           "AND p.active = true " +
           "AND p.validFrom <= :now " +
           "AND p.validTo >= :now " +
           "AND (p.maxUses IS NULL OR p.usedCount < p.maxUses)")
    Optional<Promotion> findValidPromotion(@Param("code") String code, @Param("now") LocalDateTime now);
    
    List<Promotion> findByActiveTrue();
}

