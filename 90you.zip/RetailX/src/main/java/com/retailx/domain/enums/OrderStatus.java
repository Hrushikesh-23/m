package com.retailx.domain.enums;

/**
 * Order lifecycle statuses.
 */
public enum OrderStatus {
    PENDING,
    PAID,
    FULFILLING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    RETURN_REQUESTED,
    RETURNED,
    REJECTED
}

