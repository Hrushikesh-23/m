package com.retailx.payment.controller;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * REST controller for payment processing endpoints.
 * Handles payment intent creation, authorization, capture, and refunds with idempotency.
 */
@Slf4j
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
    
    private final PaymentService paymentService;
    
    /**
     * Create a payment intent for an order - accessible to authenticated users.
     */
    @PostMapping("/intents")
    public ResponseEntity<PaymentIntent> createPaymentIntent(
            @RequestParam Long orderId,
            @RequestParam BigDecimal amount,
            @RequestParam String currency,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Creating payment intent: orderId={}, amount={}, currency={}, idempotencyKey={}", 
                orderId, amount, currency, correlationId);
        PaymentIntent paymentIntent = paymentService.createPaymentIntent(
                orderId, amount, currency, correlationId);
        log.info("Payment intent created: id={}, status={}", 
                paymentIntent.getId(), paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Authorize a payment - accessible to authenticated users.
     */
    @PostMapping("/{paymentIntentId}/authorize")
    public ResponseEntity<PaymentIntent> authorize(
            @PathVariable Long paymentIntentId,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Authorizing payment: paymentIntentId={}, idempotencyKey={}", 
                paymentIntentId, correlationId);
        PaymentIntent paymentIntent = paymentService.authorize(paymentIntentId, correlationId);
        log.info("Payment authorized: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Capture an authorized payment - accessible to authenticated users.
     */
    @PostMapping("/{paymentIntentId}/capture")
    public ResponseEntity<PaymentIntent> capture(
            @PathVariable Long paymentIntentId,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Capturing payment: paymentIntentId={}, idempotencyKey={}", 
                paymentIntentId, correlationId);
        PaymentIntent paymentIntent = paymentService.capture(paymentIntentId, correlationId);
        log.info("Payment captured: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Refund a payment - accessible to authenticated users (typically OPS/ADMIN).
     */
    @PostMapping("/{paymentIntentId}/refund")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN')")
    public ResponseEntity<PaymentIntent> refund(
            @PathVariable Long paymentIntentId,
            @RequestParam BigDecimal amount,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Processing refund: paymentIntentId={}, amount={}, idempotencyKey={}", 
                paymentIntentId, amount, correlationId);
        PaymentIntent paymentIntent = paymentService.refund(paymentIntentId, amount, correlationId);
        log.info("Refund processed: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Payment Service is running");
    }
}

