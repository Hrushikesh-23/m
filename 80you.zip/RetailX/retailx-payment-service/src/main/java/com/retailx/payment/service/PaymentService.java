package com.retailx.payment.service;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Random;
import java.util.UUID;

/**
 * Service for payment processing (mock provider).
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {
    
    private final PaymentIntentRepository paymentIntentRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final Random random = new Random();
    
    @Transactional
    public PaymentIntent createPaymentIntent(Long orderId, BigDecimal amount, String currency, String correlationId) {
        log.info("Creating payment intent: orderId={}, amount={}, correlationId={}", 
                orderId, amount, correlationId);
        
        // Check idempotency
        if (correlationId != null) {
            PaymentIntent existing = paymentIntentRepository.findByCorrelationId(correlationId)
                    .orElse(null);
            if (existing != null) {
                log.info("Idempotent payment intent creation, returning existing: {}", existing.getId());
                return existing;
            }
        }
        
        PaymentIntent paymentIntent = PaymentIntent.builder()
                .orderId(orderId)
                .paymentIntentId("pi_" + UUID.randomUUID().toString().replace("-", ""))
                .amount(amount)
                .currency(currency)
                .status(PaymentStatus.PENDING)
                .correlationId(correlationId)
                .build();
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "authorizeFallback")
    @Retry(name = "paymentService")
    public PaymentIntent authorize(Long paymentIntentId, String correlationId) {
        log.info("Authorizing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() == PaymentStatus.AUTHORIZED 
                || paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already authorized/captured, returning existing payment intent");
            return paymentIntent;
        }
        
        // Must be in PENDING state to authorize
        if (paymentIntent.getStatus() != PaymentStatus.PENDING) {
            throw new RuntimeException(
                String.format("Payment must be in PENDING state to authorize. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Cannot authorize if already in terminal states
        if (paymentIntent.getStatus() == PaymentStatus.FAILED) {
            throw new RuntimeException("Cannot authorize a failed payment. Please create a new payment intent.");
        }
        
        if (paymentIntent.getStatus() == PaymentStatus.REFUNDED 
                || paymentIntent.getStatus() == PaymentStatus.PARTIALLY_REFUNDED) {
            throw new RuntimeException("Cannot authorize a refunded payment. Please create a new payment intent.");
        }
        
        // Mock payment provider - simulate success/failure
        boolean success = mockPaymentProvider(paymentIntent.getAmount());
        
        if (success) {
            paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        } else {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_DECLINED");
            paymentIntent.setErrorMessage("Payment was declined by the provider");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                paymentIntent.getErrorCode(), paymentIntent.getErrorMessage()));
            } catch (Exception e) {
                log.warn("Failed to send Kafka event for payment failure: {}", e.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    @Transactional
    @CircuitBreaker(name = "paymentProvider", fallbackMethod = "captureFallback")
    @Retry(name = "paymentService")
    public PaymentIntent capture(Long paymentIntentId, String correlationId) {
        log.info("Capturing payment: paymentIntentId={}, correlationId={}", 
                paymentIntentId, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
            log.info("Payment already captured");
            return paymentIntent;
        }
        
        if (paymentIntent.getStatus() != PaymentStatus.AUTHORIZED) {
            throw new RuntimeException(
                String.format("Payment must be AUTHORIZED before capture. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Check idempotency
        if (correlationId != null && paymentIntent.getCorrelationId() != null 
                && !paymentIntent.getCorrelationId().equals(correlationId)) {
            throw new RuntimeException("Idempotency key mismatch");
        }
        
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        paymentIntent = paymentIntentRepository.save(paymentIntent);
        
        // Publish payment captured event (non-blocking)
        try {
            kafkaTemplate.send("payment.captured", String.valueOf(paymentIntent.getOrderId()),
                    String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"amount\":%s,\"currency\":\"%s\"}",
                            paymentIntent.getId(), paymentIntent.getOrderId(),
                            paymentIntent.getAmount(), paymentIntent.getCurrency()));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for payment capture: {}", e.getMessage());
        }
        
        return paymentIntent;
    }
    
    @Transactional
    public PaymentIntent refund(Long paymentIntentId, BigDecimal amount, String correlationId) {
        log.info("Refunding payment: paymentIntentId={}, amount={}, correlationId={}", 
                paymentIntentId, amount, correlationId);
        
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Validate current status - prevent invalid transitions
        if (paymentIntent.getStatus() != PaymentStatus.CAPTURED 
                && paymentIntent.getStatus() != PaymentStatus.PARTIALLY_REFUNDED) {
            throw new RuntimeException(
                String.format("Payment must be CAPTURED or PARTIALLY_REFUNDED before refund. Current status: %s", 
                    paymentIntent.getStatus()));
        }
        
        // Cannot refund if already fully refunded
        if (paymentIntent.getStatus() == PaymentStatus.REFUNDED) {
            throw new RuntimeException("Payment is already fully refunded. Cannot refund again.");
        }
        
        if (amount.compareTo(paymentIntent.getAmount()) > 0) {
            throw new RuntimeException("Refund amount cannot exceed payment amount");
        }
        
        // Calculate remaining amount that can be refunded
        // For simplicity, assuming we track refunded amount (would need to add this field)
        // For now, check against original amount
        
        if (amount.compareTo(paymentIntent.getAmount()) < 0) {
            paymentIntent.setStatus(PaymentStatus.PARTIALLY_REFUNDED);
        } else {
            paymentIntent.setStatus(PaymentStatus.REFUNDED);
        }
        
        paymentIntent = paymentIntentRepository.save(paymentIntent);
        
        // Publish payment refunded event (non-blocking)
        try {
            kafkaTemplate.send("payment.refunded", String.valueOf(paymentIntent.getOrderId()),
                    String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"refundAmount\":%s,\"currency\":\"%s\"}",
                            paymentIntent.getId(), paymentIntent.getOrderId(),
                            amount, paymentIntent.getCurrency()));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for payment refund: {}", e.getMessage());
        }
        
        return paymentIntent;
    }
    
    private boolean mockPaymentProvider(BigDecimal amount) {
        // Simulate 90% success rate
        // Simulate timeout for large amounts (>1000)
        if (amount.compareTo(new BigDecimal("1000")) > 0) {
            // 50% chance of timeout for large amounts
            if (random.nextDouble() < 0.5) {
                throw new RuntimeException("PAYMENT_PROVIDER_TIMEOUT");
            }
        }
        
        // 10% decline rate
        return random.nextDouble() > 0.1;
    }
    
    private PaymentIntent authorizeFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment authorization failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Only set to FAILED if not already in a terminal state
        if (paymentIntent.getStatus() != PaymentStatus.FAILED 
                && paymentIntent.getStatus() != PaymentStatus.CAPTURED 
                && paymentIntent.getStatus() != PaymentStatus.REFUNDED) {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
            paymentIntent.setErrorMessage("Payment provider unavailable");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                "PAYMENT_PROVIDER_TIMEOUT", "Payment provider unavailable"));
            } catch (Exception ex) {
                log.warn("Failed to send Kafka event for payment failure: {}", ex.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
    
    private PaymentIntent captureFallback(Long paymentIntentId, String correlationId, Exception e) {
        log.error("Payment capture failed, circuit breaker open: {}", e.getMessage());
        PaymentIntent paymentIntent = paymentIntentRepository.findById(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment intent not found"));
        
        // Only set to FAILED if currently AUTHORIZED (can't capture)
        if (paymentIntent.getStatus() == PaymentStatus.AUTHORIZED) {
            paymentIntent.setStatus(PaymentStatus.FAILED);
            paymentIntent.setErrorCode("PAYMENT_PROVIDER_TIMEOUT");
            paymentIntent.setErrorMessage("Payment provider unavailable");
            
            // Publish payment failed event (non-blocking)
            try {
                kafkaTemplate.send("payment.failed", String.valueOf(paymentIntent.getOrderId()),
                        String.format("{\"paymentIntentId\":%d,\"orderId\":%d,\"errorCode\":\"%s\",\"errorMessage\":\"%s\"}",
                                paymentIntent.getId(), paymentIntent.getOrderId(),
                                "PAYMENT_PROVIDER_TIMEOUT", "Payment provider unavailable"));
            } catch (Exception ex) {
                log.warn("Failed to send Kafka event for payment failure: {}", ex.getMessage());
            }
        }
        
        return paymentIntentRepository.save(paymentIntent);
    }
}

