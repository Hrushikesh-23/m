# Login Troubleshooting Guide

## Current Status
- ✅ Registration is working (user successfully created)
- ❌ Login is failing after registration

## Possible Causes

### 1. Password Mismatch
**Symptom:** Login fails with "Invalid credentials" even with correct password

**Possible Reasons:**
- Password not hashed correctly during registration
- Password comparison failing in login
- Character encoding issues

**Check:**
- Verify password meets requirements (uppercase, lowercase, digit, special char)
- Check if password is being trimmed or modified
- Verify BCrypt encoding is working

### 2. User Not Found
**Symptom:** Login fails with "Invalid credentials" (user not found)

**Possible Reasons:**
- User not actually saved to database during registration
- Email case sensitivity issues
- Database connection issues

**Check:**
- Verify user exists in database after registration
- Check email is stored correctly
- Verify database connection

### 3. Feign Client Error
**Symptom:** Login throws exception, no clear error message

**Possible Reasons:**
- Network/connection issues
- API Gateway not routing correctly
- Auth service not responding
- Response format mismatch

**Check:**
- Check if auth service is running
- Check API Gateway logs
- Check Feign client logs (now enabled with DEBUG level)

## Debugging Steps

### Step 1: Check Server Logs

After attempting login, check frontend service logs for:

```
Login failed (FeignException) for: <email>, status: <status_code>
Feign error response body: <response_body>
```

This will show:
- HTTP status code (400, 401, 500, etc.)
- Actual error message from auth service

### Step 2: Check Auth Service Logs

Look for:
```
Login attempt for email: <email>
RuntimeException: Invalid credentials
```

This confirms:
- Request reached auth service
- What error occurred

### Step 3: Verify User in Database

Check if user was actually created:
```sql
SELECT * FROM users WHERE email = '<registered_email>';
```

Verify:
- User exists
- Email matches exactly (case-sensitive)
- Password hash is set (not null)
- User is active (active = true)

### Step 4: Test Password Hash

If user exists, verify password was hashed correctly. The password in database should be a BCrypt hash starting with `$2a$`, `$2b$`, or `$2y$`.

## Quick Fixes

### Fix 1: Try Different Email Format
- Try lowercase email if you used mixed case
- Try exact email as registered

### Fix 2: Verify Password Requirements
Password must contain:
- At least 8 characters
- At least 1 uppercase letter (A-Z)
- At least 1 lowercase letter (a-z)
- At least 1 digit (0-9)
- At least 1 special character from: @$!%*?&

Example valid passwords:
- `Test123!@$`
- `MyPass1@test`
- `Password123$`

### Fix 3: Check Services Are Running
Ensure all services are up:
1. Eureka Server (port 8761)
2. API Gateway (port 8080)
3. Auth Service (port 8081)
4. Frontend Service (port 8087)

### Fix 4: Check Logs for Actual Error

The improved error handling now logs:
- Feign exception status code
- Full response body from auth service
- Parsed error message

Look for these in logs to see the actual issue.

## Enhanced Error Handling

The frontend now:
1. ✅ Catches `FeignException` separately
2. ✅ Extracts error message from response body
3. ✅ Shows user-friendly error messages:
   - "Invalid email or password" for 400/401
   - "Server error. Please try again later." for 500
   - Actual error message for other cases
4. ✅ Logs full error details for debugging

## Testing

### Test Registration
1. Go to `/register`
2. Fill all fields:
   - Name: Test User
   - Email: test@example.com
   - Password: Test123!@$ (meets requirements)
   - Role: CUSTOMER
3. Submit
4. Should redirect to login page

### Test Login
1. Go to `/login`
2. Enter registered email and password
3. Submit
4. Check:
   - Browser: Shows error message or redirects
   - Server logs: Shows detailed error information
   - Database: Verify user exists

### Manual Database Check
```sql
-- Check user exists
SELECT id, email, active, password_hash FROM users WHERE email = 'test@example.com';

-- Check user roles
SELECT * FROM user_roles WHERE user_id = (SELECT id FROM users WHERE email = 'test@example.com');
```

## Common Issues and Solutions

### Issue: "Invalid email or password"
**Solution:**
- Verify password is correct
- Check password meets all requirements
- Try resetting password (if feature exists)
- Check if account is active in database

### Issue: "Server error"
**Solution:**
- Check auth service is running
- Check auth service logs for errors
- Verify database connection
- Check API Gateway is routing correctly

### Issue: No error message shown
**Solution:**
- Check browser console for errors
- Check server logs for exceptions
- Verify error template is displaying correctly

## Next Steps

1. **Check Logs First** - The enhanced logging will show exactly what's failing
2. **Verify Database** - Confirm user was created correctly
3. **Test with Simple Password** - Use `Test123!@$` to ensure password requirements are met
4. **Check Service Status** - Ensure all services are running
5. **Try Direct API Call** - Test login API directly via curl/Postman to isolate frontend vs backend issue

## Direct API Test

Test login directly to see if issue is frontend or backend:

```bash
# Test login directly
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"Test123!@$"}'
```

Expected success response:
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "userId": 1,
  "email": "test@example.com",
  "roles": ["CUSTOMER"],
  "expiresIn": 3600000
}
```

Expected error response (invalid credentials):
```json
{
  "status": 400,
  "error": "Bad Request",
  "message": "Invalid credentials",
  "timestamp": "2024-..."
}
```

