# Business Logic Validations

This document outlines the business logic validations implemented to prevent invalid state transitions and ensure data consistency across all services.

## Payment Service Validations

### Payment Status States
- `PENDING` - Initial state when payment intent is created
- `AUTHORIZED` - Payment has been authorized by provider
- `CAPTURED` - Payment has been captured (funds transferred)
- `FAILED` - Payment authorization or capture failed
- `REFUNDED` - Full refund processed
- `PARTIALLY_REFUNDED` - Partial refund processed

### Authorization Validations

**✅ Valid Transitions:**
- `PENDING` → `AUTHORIZED` (successful authorization)
- `PENDING` → `FAILED` (authorization failed)

**❌ Invalid Transitions Prevented:**
- Cannot authorize if status is already `AUTHORIZED` or `CAPTURED` → Returns existing payment
- Cannot authorize if status is `FAILED` → **Error**: "Cannot authorize a failed payment. Please create a new payment intent."
- Cannot authorize if status is `REFUNDED` or `PARTIALLY_REFUNDED` → **Error**: "Cannot authorize a refunded payment. Please create a new payment intent."

**Implementation:**
```java
// In PaymentService.authorize()
if (paymentIntent.getStatus() == PaymentStatus.FAILED) {
    throw new RuntimeException("Cannot authorize a failed payment. Please create a new payment intent.");
}
if (paymentIntent.getStatus() == PaymentStatus.REFUNDED 
        || paymentIntent.getStatus() == PaymentStatus.PARTIALLY_REFUNDED) {
    throw new RuntimeException("Cannot authorize a refunded payment. Please create a new payment intent.");
}
```

### Capture Validations

**✅ Valid Transitions:**
- `AUTHORIZED` → `CAPTURED` (capture authorized payment)

**❌ Invalid Transitions Prevented:**
- Cannot capture if status is not `AUTHORIZED` → **Error**: "Payment must be AUTHORIZED before capture. Current status: {status}"
- Cannot capture if already `CAPTURED` → Returns existing payment (idempotent)

**Implementation:**
```java
// In PaymentService.capture()
if (paymentIntent.getStatus() == PaymentStatus.CAPTURED) {
    log.info("Payment already captured");
    return paymentIntent; // Idempotent
}
if (paymentIntent.getStatus() != PaymentStatus.AUTHORIZED) {
    throw new RuntimeException(
        String.format("Payment must be AUTHORIZED before capture. Current status: %s", 
            paymentIntent.getStatus()));
}
```

### Refund Validations

**✅ Valid Transitions:**
- `CAPTURED` → `PARTIALLY_REFUNDED` (partial refund)
- `CAPTURED` → `REFUNDED` (full refund)
- `PARTIALLY_REFUNDED` → `REFUNDED` (remaining refund)

**❌ Invalid Transitions Prevented:**
- Cannot refund if status is not `CAPTURED` or `PARTIALLY_REFUNDED` → **Error**: "Payment must be CAPTURED or PARTIALLY_REFUNDED before refund. Current status: {status}"
- Cannot refund if already fully `REFUNDED` → **Error**: "Payment is already fully refunded. Cannot refund again."
- Cannot refund more than payment amount → **Error**: "Refund amount cannot exceed payment amount"

**Implementation:**
```java
// In PaymentService.refund()
if (paymentIntent.getStatus() != PaymentStatus.CAPTURED 
        && paymentIntent.getStatus() != PaymentStatus.PARTIALLY_REFUNDED) {
    throw new RuntimeException(
        String.format("Payment must be CAPTURED or PARTIALLY_REFUNDED before refund. Current status: %s", 
            paymentIntent.getStatus()));
}
if (paymentIntent.getStatus() == PaymentStatus.REFUNDED) {
    throw new RuntimeException("Payment is already fully refunded. Cannot refund again.");
}
```

### Circuit Breaker Fallback Validations

**Authorize Fallback:**
- Only sets status to `FAILED` if not already in terminal state
- Publishes `payment.failed` event only when actually failing
- Prevents overwriting `CAPTURED` or `REFUNDED` states

**Capture Fallback:**
- Only sets status to `FAILED` if currently `AUTHORIZED`
- Prevents invalid state transitions from other states

## Order Service Validations

### Order Status States
- `PENDING` - Order created, awaiting payment
- `PAID` - Payment confirmed
- `FULFILLING` - Order being prepared for shipment
- `SHIPPED` - Order has been shipped
- `DELIVERED` - Order delivered to customer
- `CANCELLED` - Order cancelled
- `RETURN_REQUESTED` - Customer requested return
- `RETURNED` - Return completed
- `REJECTED` - Order rejected

### Status Transition Validations

**✅ Valid State Transitions:**
```
PENDING → PAID → FULFILLING → SHIPPED → DELIVERED
PENDING → CANCELLED
PAID → CANCELLED (before shipping)
PAID → RETURN_REQUESTED → RETURNED
SHIPPED → RETURN_REQUESTED → RETURNED
DELIVERED → RETURN_REQUESTED → RETURNED
```

**❌ Invalid Transitions Prevented:**

1. **Terminal States (No Changes Allowed):**
   - Cannot change status from `CANCELLED` → **Error**: "Cannot change status from CANCELLED. Current: CANCELLED, Requested: {newStatus}"
   - Cannot change status from `DELIVERED` → **Error**: "Cannot change status from DELIVERED. Current: DELIVERED, Requested: {newStatus}"
   - Cannot change status from `RETURNED` → **Error**: "Cannot change status from RETURNED. Current: RETURNED, Requested: {newStatus}"

2. **Backward Transitions:**
   - Cannot revert from `PAID`, `FULFILLING`, `SHIPPED`, or `DELIVERED` to `PENDING` → **Error**: "Cannot revert order from {currentStatus} to PENDING"

3. **Shipping Validations:**
   - Cannot mark as `DELIVERED` if not `SHIPPED` → **Error**: "Cannot mark order as DELIVERED. Order must be SHIPPED first. Current: {status}"
   - Cannot mark as `SHIPPED` if not `PAID` or `FULFILLING` → **Error**: "Cannot mark order as SHIPPED. Order must be PAID or FULFILLING first. Current: {status}"

4. **Payment Validations:**
   - Cannot mark as `PAID` if status is `CANCELLED` → **Error**: "Cannot mark cancelled order as PAID"

**Implementation:**
```java
// In OrderService.validateOrderStatusTransition()
// Terminal state checks
if (currentStatus == OrderStatus.CANCELLED || 
    currentStatus == OrderStatus.DELIVERED || 
    currentStatus == OrderStatus.RETURNED) {
    throw new RuntimeException(
        String.format("Cannot change status from %s. Current: %s, Requested: %s", 
            currentStatus, currentStatus, newStatus));
}

// Backward transition checks
if (newStatus == OrderStatus.PENDING && 
    (currentStatus == OrderStatus.PAID || currentStatus == OrderStatus.FULFILLING 
     || currentStatus == OrderStatus.SHIPPED || currentStatus == OrderStatus.DELIVERED)) {
    throw new RuntimeException(
        String.format("Cannot revert order from %s to PENDING", currentStatus));
}
```

### Cancellation Validations

**✅ Valid Cancellations:**
- Can cancel from `PENDING`, `PAID`, or `FULFILLING` states

**❌ Invalid Cancellations Prevented:**
- Cannot cancel if already `CANCELLED` → **Error**: "Order is already cancelled"
- Cannot cancel if `DELIVERED` → **Error**: "Cannot cancel a delivered order. Please process a return instead."
- Cannot cancel if `RETURNED` → **Error**: "Cannot cancel a returned order"
- Cannot cancel if `SHIPPED` or later → **Error**: "Cannot cancel order after it has been shipped. Current status: {status}"

**Implementation:**
```java
// In OrderService.cancelOrder()
if (order.getStatus() == OrderStatus.CANCELLED) {
    throw new RuntimeException("Order is already cancelled");
}
if (order.getStatus() == OrderStatus.DELIVERED) {
    throw new RuntimeException("Cannot cancel a delivered order. Please process a return instead.");
}
if (order.getStatus().ordinal() >= OrderStatus.SHIPPED.ordinal()) {
    throw new RuntimeException(
        String.format("Cannot cancel order after it has been shipped. Current status: %s", 
            order.getStatus()));
}
```

### Pre-Fulfillment Update Validations

**✅ Valid Updates:**
- Can update shipping address, method, and gift note before shipment

**❌ Invalid Updates Prevented:**
- Cannot update if `CANCELLED` → **Error**: "Cannot update a cancelled order"
- Cannot update if `DELIVERED` → **Error**: "Cannot update a delivered order"
- Cannot update if `RETURNED` → **Error**: "Cannot update a returned order"
- Cannot update if `SHIPPED` or later → **Error**: "Cannot update order after it has been shipped. Current status: {status}"

## Shipment Service Validations

### Shipment Creation
- **✅ Valid**: Can create shipment if order status is `PAID` or `FULFILLING`
- **❌ Invalid**: Cannot create shipment otherwise → **Error**: "Order must be PAID or FULFILLING to create shipment"

## Summary of Protection Rules

### Payment Service
1. ✅ Cannot authorize failed/refunded payments (must create new intent)
2. ✅ Cannot capture non-authorized payments
3. ✅ Cannot refund non-captured payments
4. ✅ Cannot refund fully refunded payments
5. ✅ Cannot refund more than payment amount
6. ✅ Circuit breaker fallbacks respect state transitions

### Order Service
1. ✅ Cannot change terminal states (CANCELLED, DELIVERED, RETURNED)
2. ✅ Cannot revert to PENDING from later states
3. ✅ Cannot skip states (must follow lifecycle)
4. ✅ Cannot cancel after shipping
5. ✅ Cannot update after shipping
6. ✅ Cannot mark as DELIVERED without SHIPPING first
7. ✅ Cannot mark as SHIPPED without payment confirmation

### Benefits

1. **Data Integrity**: Prevents invalid state transitions at the service layer
2. **Consistency**: Ensures all services follow the same business rules
3. **Error Prevention**: Catches invalid operations early with clear error messages
4. **Idempotency**: Handles duplicate operations gracefully (returns existing state)
5. **Audit Trail**: All state changes logged with actor and reason
6. **User Experience**: Clear error messages guide correct usage

## Testing Recommendations

### Payment Service Tests
- Test authorization of failed payment (should fail)
- Test capture of non-authorized payment (should fail)
- Test refund of non-captured payment (should fail)
- Test double refund attempt (should fail)
- Test idempotent operations (should succeed)

### Order Service Tests
- Test status change from CANCELLED (should fail)
- Test cancellation of shipped order (should fail)
- Test marking as DELIVERED without SHIPPED (should fail)
- Test reverting to PENDING (should fail)
- Test valid transitions (should succeed)


