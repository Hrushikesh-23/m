# Step-by-Step Login Testing Guide

## Quick Test Steps

### 1. Verify User Was Created
After registration, verify the user exists in the database:

```sql
-- Connect to MySQL
mysql -u root -p

-- Use auth database
USE retailx_auth;

-- Check if user exists
SELECT id, email, active, deleted, password_hash 
FROM users 
WHERE email = 'your-registered-email@example.com';

-- Check user roles
SELECT ur.user_id, ur.role 
FROM user_roles ur 
JOIN users u ON ur.user_id = u.id 
WHERE u.email = 'your-registered-email@example.com';
```

**Expected:**
- User should exist with `active = 1` and `deleted = 0`
- Password hash should start with `$2a$` or `$2b$` (BCrypt)
- At least one role should exist (CUSTOMER or MERCHANT)

### 2. Check Logs During Login Attempt

When you try to login, watch the logs for:

**Frontend Service Logs:**
```
Login attempt for email: <email>
Login failed (FeignException) for: <email>
FeignException status: <code>, message: <message>
Feign error response body (raw): <json_response>
Extracted error message: <message>
Final error message for user: <message>
```

**Auth Service Logs:**
```
Login attempt for email: <email>
RuntimeException: Invalid credentials
```

### 3. Test Direct API Call

Test login directly to bypass frontend:

```powershell
# Test login via API Gateway
$body = @{
    email = "your-email@example.com"
    password = "YourPassword123!@$"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" `
    -Method POST `
    -ContentType "application/json" `
    -Body $body
```

**Expected Success Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "userId": 1,
  "email": "your-email@example.com",
  "roles": ["CUSTOMER"],
  "expiresIn": 3600000
}
```

**Expected Error Response (invalid credentials):**
```json
{
  "status": 400,
  "error": "Bad Request",
  "message": "Invalid credentials",
  "timestamp": "2024-12-12T..."
}
```

### 4. Common Issues and Fixes

#### Issue: "Invalid credentials" but user exists
**Possible Causes:**
- Password doesn't match
- Password not hashed correctly during registration
- Email case mismatch

**Solution:**
1. Verify password in database is BCrypt hashed (starts with `$2a$`)
2. Try registering again with a simple password: `Test123!@$`
3. Use exact same email (case-sensitive)

#### Issue: "Service not found" or connection error
**Possible Causes:**
- Auth service not running
- API Gateway not routing correctly
- Network connectivity issues

**Solution:**
1. Check Eureka dashboard: http://localhost:8761
2. Verify `retailx-auth-service` is registered
3. Check API Gateway is running on port 8080
4. Verify services can communicate

#### Issue: No error message, just fails silently
**Possible Causes:**
- Exception not being caught
- Response body not accessible

**Solution:**
- Check full stack trace in logs
- Look for any exceptions before login method
- Verify Feign client is configured correctly

## Password Requirements Reminder

Password **must** contain:
- ✅ At least 8 characters
- ✅ At least 1 uppercase letter (A-Z)
- ✅ At least 1 lowercase letter (a-z)
- ✅ At least 1 digit (0-9)
- ✅ At least 1 special character from: `@$!%*?&`

**Valid Examples:**
- `Test123!@$`
- `MyPass1@test`
- `Password123$`

**Invalid Examples:**
- `test123!@$` ❌ (no uppercase)
- `Test123@#` ❌ (`#` not allowed, use `@$!%*?&`)
- `Test!@$` ❌ (no digit)
- `test1234` ❌ (no uppercase, no special char)

## Debugging Checklist

- [ ] User exists in database
- [ ] Email matches exactly (case-sensitive)
- [ ] Password is BCrypt hashed
- [ ] User is active (`active = 1`)
- [ ] User is not deleted (`deleted = 0`)
- [ ] User has at least one role
- [ ] Password meets all requirements
- [ ] Using exact same password as registered
- [ ] Auth service is running
- [ ] API Gateway is running
- [ ] Services are registered in Eureka
- [ ] Check logs for actual error messages

## Next Steps

1. **Try logging in** and check the server logs
2. **Look for** "Feign error response body (raw)" in logs
3. **Check** what the actual error message is
4. **Verify** user exists in database
5. **Test** direct API call to isolate frontend vs backend issue

The enhanced logging will show you exactly what's failing!

