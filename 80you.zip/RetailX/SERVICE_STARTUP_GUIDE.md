# RetailX Service Startup and Testing Guide

## Services Status

Based on the startup process, here's the status of all services:

### Service Ports
- **Eureka Server**: 8761
- **API Gateway**: 8080
- **Auth Service**: 8081
- **Product Service**: 8082
- **Order Service**: 8083
- **Payment Service**: 8084
- **Inventory Service**: 8085
- **Notification Service**: 8086
- **Frontend Service**: 8087

## Starting Services

All services have been started in separate PowerShell windows. You should see multiple PowerShell windows open, one for each service.

### Check Service Status

1. **Check if services are listening on ports:**
   ```powershell
   netstat -ano | findstr ":8761 :8080 :8081 :8082 :8083 :8084 :8085 :8086 :8087"
   ```

2. **Check Java processes:**
   ```powershell
   Get-Process | Where-Object {$_.ProcessName -like "*java*"} | Select-Object ProcessName, Id
   ```

3. **Test individual service health:**
   ```powershell
   # Eureka Server
   curl http://localhost:8761
   
   # API Gateway
   curl http://localhost:8080/actuator/health
   
   # Auth Service
   curl http://localhost:8081/actuator/health
   
   # Product Service
   curl http://localhost:8082/actuator/health
   
   # Order Service
   curl http://localhost:8083/actuator/health
   
   # Payment Service
   curl http://localhost:8084/actuator/health
   
   # Inventory Service
   curl http://localhost:8085/actuator/health
   
   # Notification Service
   curl http://localhost:8086/actuator/health
   
   # Frontend Service
   curl http://localhost:8087/actuator/health
   ```

## Prerequisites

Before services can start successfully, ensure:

1. **MySQL is running:**
   ```powershell
   # Check MySQL service
   Get-Service | Where-Object {$_.Name -like "*mysql*"}
   
   # Start MySQL if needed (as Administrator)
   net start MySQL80
   ```

2. **Kafka is running:**
   - Option 1: Use Docker (recommended):
     ```powershell
     docker-compose up -d zookeeper kafka
     ```
   - Option 2: Start Kafka locally if installed

3. **Databases are created:**
   ```sql
   CREATE DATABASE retailx_auth;
   CREATE DATABASE retailx_product;
   CREATE DATABASE retailx_order;
   CREATE DATABASE retailx_payment;
   CREATE DATABASE retailx_inventory;
   ```

## Testing APIs

### 1. Test Public Endpoints (No Authentication)

```powershell
# Get all products
Invoke-WebRequest -Uri "http://localhost:8080/api/products" -Method GET

# Get products with pagination
Invoke-WebRequest -Uri "http://localhost:8080/api/products?page=0&size=10" -Method GET

# Get catalog
Invoke-WebRequest -Uri "http://localhost:8080/api/catalog" -Method GET

# Get product by ID
Invoke-WebRequest -Uri "http://localhost:8080/api/products/1" -Method GET

# Get reviews for a product
Invoke-WebRequest -Uri "http://localhost:8080/api/reviews/products/1" -Method GET
```

### 2. Test Auth Endpoints

```powershell
# Register a new user
$registerBody = @{
    username = "testuser"
    email = "test@example.com"
    password = "Test123!"
    role = "CUSTOMER"
} | ConvertTo-Json

$registerResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/register" `
    -Method POST `
    -Body $registerBody `
    -ContentType "application/json"

# Login
$loginBody = @{
    username = "testuser"
    password = "Test123!"
} | ConvertTo-Json

$loginResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" `
    -Method POST `
    -Body $loginBody `
    -ContentType "application/json"

# Extract token
$loginData = $loginResponse.Content | ConvertFrom-Json
$token = $loginData.token
```

### 3. Test Protected Endpoints (With Authentication)

```powershell
# Set headers
$headers = @{
    "Authorization" = "Bearer $token"
    "X-User-Id" = "1"
}

# Get user cart
Invoke-WebRequest -Uri "http://localhost:8080/api/carts" `
    -Method GET `
    -Headers $headers

# Add item to cart
$cartBody = @{
    sku = "PROD-001"
    quantity = 2
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:8080/api/carts" `
    -Method POST `
    -Headers $headers `
    -Body $cartBody `
    -ContentType "application/json"

# Get user orders
Invoke-WebRequest -Uri "http://localhost:8080/api/orders" `
    -Method GET `
    -Headers $headers

# Create a product (Admin only)
$productBody = @{
    name = "Test Product"
    description = "Test Description"
    price = 99.99
    sku = "TEST-001"
    category = "Electronics"
    stock = 100
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:8080/api/products" `
    -Method POST `
    -Headers $headers `
    -Body $productBody `
    -ContentType "application/json"
```

### 4. Test Checkout Flow

```powershell
# Create checkout request
$checkoutBody = @{
    shippingAddress = @{
        street = "123 Main St"
        city = "New York"
        state = "NY"
        zipCode = "10001"
        country = "USA"
    }
    paymentMethod = "CREDIT_CARD"
} | ConvertTo-Json

$idempotencyKey = [System.Guid]::NewGuid().ToString()

$checkoutHeaders = @{
    "Authorization" = "Bearer $token"
    "X-User-Id" = "1"
    "Idempotency-Key" = $idempotencyKey
}

Invoke-WebRequest -Uri "http://localhost:8080/api/checkout" `
    -Method POST `
    -Headers $checkoutHeaders `
    -Body $checkoutBody `
    -ContentType "application/json"
```

## Using the Test Script

A PowerShell test script has been created: `test-apis.ps1`

Run it with:
```powershell
powershell -ExecutionPolicy Bypass -File test-apis.ps1
```

## Troubleshooting

### Services Not Starting

1. **Check service logs in the PowerShell windows** - Look for error messages
2. **Verify MySQL is running:**
   ```powershell
   mysql -u root -p -e "SHOW DATABASES;"
   ```
3. **Verify Kafka is running:**
   ```powershell
   docker ps | findstr kafka
   ```
4. **Check for port conflicts:**
   ```powershell
   netstat -ano | findstr ":8080"
   ```

### Common Errors

1. **"Connection refused"** - Service hasn't started yet or crashed
2. **"Bean definition error"** - Check application.yml for `spring.main.allow-bean-definition-overriding: true`
3. **"Database connection error"** - Verify MySQL is running and databases exist
4. **"Kafka connection error"** - Verify Kafka is running

### View Service Logs

Each service is running in its own PowerShell window. Check those windows for:
- Startup messages
- Error messages
- Connection issues
- Database errors

## Accessing Services

- **Eureka Dashboard**: http://localhost:8761
- **API Gateway Swagger**: http://localhost:8080/swagger-ui.html
- **Frontend UI**: http://localhost:8087
- **Service Health**: http://localhost:PORT/actuator/health

## Next Steps

1. Wait for all services to fully start (may take 1-2 minutes)
2. Verify all services are registered in Eureka: http://localhost:8761
3. Test APIs through the gateway at http://localhost:8080
4. Use the frontend at http://localhost:8087 for UI testing

