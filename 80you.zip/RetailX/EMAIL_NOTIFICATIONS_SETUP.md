# Email Notifications Setup Guide

## Overview

The Notification Service now supports email notifications via Spring Mail. Email notifications are **disabled by default** and must be explicitly enabled via configuration.

## Current Status

✅ **Email infrastructure implemented**
- Spring Mail dependency added
- Email configuration added to `application.yml`
- NotificationService sends emails when enabled
- Console logging always active (for testing/development)

⚠️ **Email notifications disabled by default**
- Set `EMAIL_NOTIFICATIONS_ENABLED=true` to enable
- Requires SMTP server configuration

## Configuration

### 1. Enable Email Notifications

Set environment variable:
```bash
export EMAIL_NOTIFICATIONS_ENABLED=true
```

Or add to `application.yml` (not recommended for production):
```yaml
EMAIL_NOTIFICATIONS_ENABLED: true
```

### 2. Configure SMTP Server

The default configuration uses Gmail SMTP. Update in `retailx-notification-service/src/main/resources/application.yml`:

```yaml
spring:
  mail:
    host: smtp.gmail.com
    port: 587
    username: ${MAIL_USERNAME:your-email@gmail.com}
    password: ${MAIL_PASSWORD:your-app-password}
    properties:
      mail:
        smtp:
          auth: true
          starttls:
            enable: true
            required: true
```

### 3. Gmail Setup (Example)

1. **Enable 2-Factor Authentication** on your Gmail account
2. **Generate App Password**:
   - Go to Google Account → Security → 2-Step Verification → App passwords
   - Generate password for "Mail"
   - Use this password (not your regular Gmail password)

3. **Set Environment Variables**:
   ```bash
   export MAIL_USERNAME=your-email@gmail.com
   export MAIL_PASSWORD=your-app-password
   export EMAIL_NOTIFICATIONS_ENABLED=true
   ```

### 4. Other SMTP Providers

#### SendGrid:
```yaml
spring:
  mail:
    host: smtp.sendgrid.net
    port: 587
    username: apikey
    password: ${SENDGRID_API_KEY}
```

#### AWS SES:
```yaml
spring:
  mail:
    host: email-smtp.us-east-1.amazonaws.com
    port: 587
    username: ${AWS_SES_USERNAME}
    password: ${AWS_SES_PASSWORD}
```

#### Custom SMTP:
```yaml
spring:
  mail:
    host: smtp.yourdomain.com
    port: 587
    username: ${MAIL_USERNAME}
    password: ${MAIL_PASSWORD}
```

## Email Notifications

The following notifications are sent when email is enabled:

1. **Order Confirmation** - When order is created
2. **Payment Confirmation** - When payment is captured
3. **Payment Failure** - When payment fails
4. **Refund Confirmation** - When refund is processed
5. **Shipment Notification** - When order is shipped (includes tracking number)
6. **Delivery Confirmation** - When order is delivered
7. **Return Request** - When return is requested (to merchant/ops)
8. **Return Completion** - When return is processed

## Email Address Resolution

Currently, the service attempts to retrieve customer email from the Auth Service via Feign client. **Note**: The Auth Service endpoint `/api/auth/users/{userId}/email` needs to be implemented for full email functionality.

For now, emails are logged to console with the notification details.

## Testing Email Notifications

### 1. Console Logging (Always Active)

All notifications are logged to console regardless of email settings:
```
=== ORDER CONFIRMATION NOTIFICATION ===
Order ID: 123
Customer ID: 456
Subject: Your Order #ORD-123 has been confirmed!
Message: Thank you for your order!...
```

### 2. Test Email Sending

1. **Enable email notifications**:
   ```bash
   export EMAIL_NOTIFICATIONS_ENABLED=true
   export MAIL_USERNAME=your-email@gmail.com
   export MAIL_PASSWORD=your-app-password
   ```

2. **Restart Notification Service**

3. **Trigger an event** (e.g., place an order)

4. **Check logs** for:
   - "Email sent successfully to: customer@example.com"
   - Or error messages if email sending fails

## Troubleshooting

### Emails Not Sending

1. **Check email is enabled**:
   ```bash
   echo $EMAIL_NOTIFICATIONS_ENABLED  # Should be "true"
   ```

2. **Check SMTP configuration**:
   - Verify `MAIL_USERNAME` and `MAIL_PASSWORD` are set
   - For Gmail, ensure you're using App Password, not regular password
   - Check firewall/network allows SMTP connections

3. **Check logs**:
   ```
   Failed to send email notification to customer: {customerId}
   ```
   - Look for specific error messages

4. **Verify customer email retrieval**:
   - Auth Service endpoint must be accessible
   - Customer must exist in Auth Service

### Common Errors

- **"Authentication failed"**: Wrong username/password or App Password required
- **"Connection timeout"**: SMTP server unreachable or firewall blocking
- **"Could not retrieve email"**: Auth Service endpoint not implemented/accessible

## Future Enhancements

- [ ] Store customer email in order/payment events (reduce dependency on Auth Service)
- [ ] Email templates (HTML) instead of plain text
- [ ] Email queue/retry mechanism
- [ ] Support for email providers (SendGrid, Mailgun, AWS SES) as primary
- [ ] Email preferences/permissions
- [ ] Bounce/complaint handling

## Security Notes

- **Never commit** email credentials to version control
- Use environment variables or secret management (Vault, AWS Secrets Manager)
- Use App Passwords (not main account passwords) for Gmail
- Consider using dedicated email service accounts
- Enable SMTP over TLS/SSL only


