package com.retailx.order.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.math.BigDecimal;
import java.util.Map;

/**
 * Feign client for Product Service.
 */
@FeignClient(name = "retailx-product-service", path = "/api/products")
public interface ProductServiceClient {
    
    @GetMapping("/sku/{sku}")
    Map<String, Object> getProductBySku(@PathVariable String sku);
}

