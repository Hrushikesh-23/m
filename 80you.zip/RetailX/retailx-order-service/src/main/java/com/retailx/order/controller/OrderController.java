package com.retailx.order.controller;

import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for order management endpoints.
 * Handles order retrieval, status updates, and cancellation.
 */
@Slf4j
@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {
    
    private final OrderService orderService;
    
    /**
     * Get order by ID - accessible to authenticated users who own the order or have admin/ops role.
     */
    @GetMapping("/{id}")
    public ResponseEntity<OrderResponse> getOrderById(@PathVariable Long id) {
        log.info("Fetching order by ID: {}", id);
        OrderResponse response = orderService.getOrderById(id);
        log.debug("Order retrieved: orderNumber={}, status={}", response.getOrderNumber(), response.getStatus());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get order by order number - accessible to authenticated users.
     */
    @GetMapping("/number/{orderNumber}")
    public ResponseEntity<OrderResponse> getOrderByNumber(@PathVariable String orderNumber) {
        log.info("Fetching order by number: {}", orderNumber);
        OrderResponse response = orderService.getOrderByNumber(orderNumber);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get customer's own orders - only CUSTOMER or ADMIN can access.
     */
    @GetMapping("/customer")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Page<OrderResponse>> getCustomerOrders(
            @RequestHeader("X-User-Id") Long customerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Fetching orders for customer: {}, page={}, size={}", customerId, page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderResponse> response = orderService.getOrdersByCustomer(customerId, pageable);
        log.debug("Found {} orders for customer: {}", response.getTotalElements(), customerId);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Get merchant's orders - only MERCHANT, ADMIN, or OPS can access.
     */
    @GetMapping("/merchant")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<Page<OrderResponse>> getMerchantOrders(
            @RequestHeader("X-User-Id") Long merchantId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        log.info("Fetching orders for merchant: {}, page={}, size={}", merchantId, page, size);
        Pageable pageable = PageRequest.of(page, size);
        Page<OrderResponse> response = orderService.getOrdersByMerchant(merchantId, pageable);
        log.debug("Found {} orders for merchant: {}", response.getTotalElements(), merchantId);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Update order status - accessible to authenticated users (enforced by business logic).
     */
    @PutMapping("/{id}/status")
    public ResponseEntity<OrderResponse> updateOrderStatus(
            @PathVariable Long id,
            @RequestParam OrderStatus status,
            @RequestHeader("X-User-Id") String actorId,
            @RequestParam(required = false) String reason) {
        log.info("Updating order status: orderId={}, newStatus={}, actor={}", id, status, actorId);
        OrderResponse response = orderService.updateOrderStatus(id, status, actorId, reason);
        log.info("Order status updated successfully: orderId={}, status={}", id, status);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Cancel an order - accessible to authenticated users (ownership checked in service).
     */
    @PutMapping("/{id}/cancel")
    public ResponseEntity<OrderResponse> cancelOrder(
            @PathVariable Long id,
            @RequestHeader("X-User-Id") String actorId,
            @RequestParam(required = false) String reason) {
        log.info("Cancelling order: orderId={}, actor={}, reason={}", id, actorId, reason);
        OrderResponse response = orderService.cancelOrder(id, actorId, reason);
        log.info("Order cancelled successfully: orderId={}", id);
        return ResponseEntity.ok(response);
    }
}

