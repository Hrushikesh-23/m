package com.retailx.order.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Checkout request DTO.
 */
@Data
public class CheckoutRequest {
    
    @NotBlank(message = "Shipping address is required")
    private String shippingAddress;
    
    private String shippingMethod;
    
    private String giftNote;
    
    private String promotionCode;
}

