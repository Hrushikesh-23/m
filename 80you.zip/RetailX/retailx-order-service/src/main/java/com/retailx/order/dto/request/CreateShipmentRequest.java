package com.retailx.order.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

/**
 * Request DTO for creating shipment.
 */
@Data
public class CreateShipmentRequest {
    
    @NotBlank(message = "Carrier is required")
    private String carrier;
    
    @NotBlank(message = "Tracking number is required")
    private String trackingNumber;
    
    private List<String> skus; // Optional: specific SKUs to ship
}

