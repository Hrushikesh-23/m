package com.retailx.notification.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response DTO for notification operations.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NotificationResponse {
    
    private Long id;
    private String recipientEmail;
    private String subject;
    private String message;
    private String status;
    private LocalDateTime sentAt;
    private String errorMessage;
}

