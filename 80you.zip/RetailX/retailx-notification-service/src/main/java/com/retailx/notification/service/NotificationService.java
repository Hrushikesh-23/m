package com.retailx.notification.service;

import com.retailx.notification.client.AuthServiceClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Service for sending notifications via email and console.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class NotificationService {
    
    private final JavaMailSender mailSender;
    private final AuthServiceClient authServiceClient;
    
    @Value("${spring.mail.username:noreply@retailx.com}")
    private String fromEmail;
    
    @Value("${EMAIL_NOTIFICATIONS_ENABLED:false}")
    private boolean emailEnabled;
    
    /**
     * Send order confirmation notification to customer.
     */
    public void sendOrderConfirmation(Long orderId, String orderNumber, Long customerId) {
        String subject = String.format("Your Order #%s has been confirmed!", orderNumber);
        String message = String.format(
            "Thank you for your order! We're processing it and will send you updates.\n\n" +
            "Order Number: %s\n" +
            "Order ID: %d\n\n" +
            "We'll notify you once your order ships.",
            orderNumber, orderId);
        
        logNotification("ORDER CONFIRMATION", orderId, customerId, subject, message);
        sendEmail(customerId, subject, message);
    }
    
    /**
     * Send payment confirmation notification.
     */
    public void sendPaymentConfirmation(Long paymentIntentId, Long orderId, String amount, String currency) {
        String subject = String.format("Payment Successful for Order #%d", orderId);
        String message = String.format(
            "Your payment has been successfully processed.\n\n" +
            "Order ID: %d\n" +
            "Amount: %s %s\n\n" +
            "Thank you for your purchase!",
            orderId, amount, currency);
        
        logNotification("PAYMENT CONFIRMATION", orderId, null, subject, message);
        // Note: Would need order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Send payment failure notification.
     */
    public void sendPaymentFailure(Long paymentIntentId, Long orderId, String errorCode, String errorMessage) {
        String subject = String.format("Payment Failed for Order #%d", orderId);
        String message = String.format(
            "We're sorry, but your payment could not be processed.\n\n" +
            "Order ID: %d\n" +
            "Error: %s\n\n" +
            "Please try again or contact support if the problem persists.",
            orderId, errorMessage);
        
        log.warn("=== {} ===", "PAYMENT FAILURE NOTIFICATION");
        log.warn("Payment Intent ID: {}", paymentIntentId);
        log.warn("Order ID: {}", orderId);
        log.warn("Error Code: {}", errorCode);
        log.warn("Subject: {}", subject);
        log.warn("Message: {}", message);
        log.warn("====================================");
        
        // Note: Would need order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Send payment refund notification.
     */
    public void sendRefundConfirmation(Long paymentIntentId, Long orderId, String refundAmount, String currency) {
        String subject = String.format("Refund Processed for Order #%d", orderId);
        String message = String.format(
            "A refund has been processed for your order.\n\n" +
            "Order ID: %d\n" +
            "Refund Amount: %s %s\n\n" +
            "The refund should appear in your account within 5-7 business days.",
            orderId, refundAmount, currency);
        
        logNotification("REFUND CONFIRMATION", orderId, null, subject, message);
        // Note: Would need order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Send shipment notification with tracking number.
     */
    public void sendShipmentNotification(Long shipmentId, Long orderId, String trackingNumber) {
        String subject = String.format("Your Order #%d has been shipped!", orderId);
        String message = String.format(
            "Great news! Your order has been shipped.\n\n" +
            "Order ID: %d\n" +
            "Tracking Number: %s\n\n" +
            "You can track your shipment using the tracking number above.",
            orderId, trackingNumber);
        
        logNotification("SHIPMENT", orderId, null, subject, message);
        // Note: Would need order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Send delivery confirmation notification.
     */
    public void sendDeliveryConfirmation(Long orderId, Long shipmentId) {
        String subject = String.format("Your Order #%d has been delivered!", orderId);
        String message = String.format(
            "Your order has been delivered!\n\n" +
            "Order ID: %d\n\n" +
            "We hope you enjoy your purchase. If you have any questions, please contact us.",
            orderId);
        
        logNotification("DELIVERY CONFIRMATION", orderId, null, subject, message);
        // Note: Would need order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Send return request notification to merchant/ops.
     */
    public void sendReturnRequestNotification(Long returnId, Long orderId, String rmaNumber) {
        String subject = String.format("New Return Request - RMA #%s", rmaNumber);
        String message = String.format(
            "A return request has been submitted.\n\n" +
            "Return ID: %d\n" +
            "Order ID: %d\n" +
            "RMA Number: %s\n\n" +
            "Please review and process the return.",
            returnId, orderId, rmaNumber);
        
        logNotification("RETURN REQUEST", orderId, null, subject, message);
        // Would send to merchant/ops email instead of customer
    }
    
    /**
     * Send return completion notification to customer.
     */
    public void sendReturnCompletionNotification(Long returnId, String refundAmount) {
        String subject = "Return Processed - Refund Issued";
        String message = String.format(
            "Your return has been processed.\n\n" +
            "Return ID: %d\n" +
            "Refund Amount: %s\n\n" +
            "The refund should appear in your account within 5-7 business days.",
            returnId, refundAmount);
        
        logNotification("RETURN COMPLETION", null, null, subject, message);
        // Note: Would need return/order to get customerId - ideally include in event payload
        // sendEmail(customerId, subject, message);
    }
    
    /**
     * Log notification to console.
     */
    private void logNotification(String type, Long orderId, Long customerId, String subject, String message) {
        log.info("=== {} NOTIFICATION ===", type);
        if (orderId != null) {
            log.info("Order ID: {}", orderId);
        }
        if (customerId != null) {
            log.info("Customer ID: {}", customerId);
        }
        log.info("Subject: {}", subject);
        log.info("Message: {}", message);
        log.info("======================");
    }
    
    /**
     * Send email notification if enabled.
     */
    private void sendEmail(Long customerId, String subject, String text) {
        if (!emailEnabled || customerId == null) {
            return;
        }
        
        try {
            // Get customer email from auth service
            Map<String, String> userInfo = authServiceClient.getUserEmail(customerId);
            String toEmail = userInfo != null ? userInfo.get("email") : null;
            
            if (toEmail == null || toEmail.isEmpty()) {
                log.warn("Could not retrieve email for customer: {}", customerId);
                return;
            }
            
            SimpleMailMessage emailMessage = new SimpleMailMessage();
            emailMessage.setFrom(fromEmail);
            emailMessage.setTo(toEmail);
            emailMessage.setSubject(subject);
            emailMessage.setText(text);
            
            mailSender.send(emailMessage);
            log.info("Email sent successfully to: {}", toEmail);
            
        } catch (Exception e) {
            log.error("Failed to send email notification to customer: {}", customerId, e);
            // Don't throw - email failure shouldn't break the flow
        }
    }
}
