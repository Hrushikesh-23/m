package com.retailx.inventory.repository;

import com.retailx.inventory.domain.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Inventory entity.
 */
@Repository
public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    
    Optional<Inventory> findBySkuAndWarehouseId(String sku, String warehouseId);
    
    List<Inventory> findBySku(String sku);
    
    @Query("SELECT i FROM Inventory i WHERE i.available < :threshold")
    List<Inventory> findLowStock(@Param("threshold") BigInteger threshold);
}

