# Notification System Documentation

## Overview

The RetailX application uses an event-driven notification system built on Kafka. Events are published when important actions occur (order creation, payment processing, shipping, etc.), and the Notification Service consumes these events to send notifications to users.

## Architecture

```
Service Actions → Kafka Events → Notification Service → User Notifications
```

### Event Flow

1. **Service performs action** (e.g., order checkout, payment capture)
2. **Service publishes event** to Kafka topic
3. **Notification Service consumes event** via Kafka listener
4. **Notification sent** to user (currently logged to console, can be extended to email/SMS)

## Published Events

### Order Service Events

| Event Topic | Trigger | Payload |
|------------|---------|---------|
| `order.created` | Order placed via checkout | `{orderId, orderNumber, customerId}` |
| `shipment.created` | Shipment created for order | `{shipmentId, orderId, trackingNumber}` |
| `order.delivered` | Order marked as delivered | `{orderId, shipmentId}` |
| `return.requested` | Customer requests return | `{returnId, orderId, rmaNumber}` |
| `return.completed` | Return processed and refunded | `{returnId, refundAmount}` |

### Payment Service Events

| Event Topic | Trigger | Payload |
|------------|---------|---------|
| `payment.captured` | Payment successfully captured | `{paymentIntentId, orderId, amount, currency}` |
| `payment.failed` | Payment authorization/processing failed | `{paymentIntentId, orderId, errorCode, errorMessage}` |
| `payment.refunded` | Payment refunded (full or partial) | `{paymentIntentId, orderId, refundAmount, currency}` |

## Notification Service

### Location
- **Service**: `retailx-notification-service` (Port 8086)
- **Kafka Consumer Group**: `notification-group`

### Consumers

The `NotificationConsumer` class listens to all event topics and processes notifications:

```java
@KafkaListener(topics = "order.created", groupId = "notification-group")
public void handleOrderCreated(String message)
```

### Notification Types

1. **Order Confirmation** - Sent when order is created
   - Subject: "Your Order #[orderNumber] has been confirmed!"
   - Message: Order confirmation details

2. **Payment Confirmation** - Sent when payment is captured
   - Subject: "Payment Successful for Order #[orderId]"
   - Message: Payment amount and confirmation

3. **Payment Failure** - Sent when payment fails
   - Subject: "Payment Failed for Order #[orderId]"
   - Message: Error details and next steps

4. **Refund Confirmation** - Sent when refund is processed
   - Subject: "Refund Processed for Order #[orderId]"
   - Message: Refund amount details

5. **Shipment Notification** - Sent when order is shipped
   - Subject: "Your Order #[orderId] has been shipped!"
   - Message: Tracking number and shipping details

6. **Delivery Confirmation** - Sent when order is delivered
   - Subject: "Your Order #[orderId] has been delivered!"
   - Message: Delivery confirmation

7. **Return Request** - Sent to merchant/ops when return is requested
   - Subject: "New Return Request - RMA #[rmaNumber]"
   - Message: Return details for review

8. **Return Completion** - Sent to customer when return is processed
   - Subject: "Return Processed - Refund Issued"
   - Message: Refund amount confirmation

## Current Implementation

### Console Logging (Current)

Notifications are currently logged to the console with formatted messages:

```
=== ORDER CONFIRMATION NOTIFICATION ===
Order ID: 123
Order Number: ORD-20241211-ABC123
Customer ID: 456
Subject: Your Order #ORD-20241211-ABC123 has been confirmed!
Message: Thank you for your order! We're processing it...
=======================================
```

### Future Extensions

The notification service is designed to be easily extended. TODO comments indicate where to add:

- **Email Notifications**: Use Spring Mail or SendGrid API
- **SMS Notifications**: Use Twilio or similar service
- **Push Notifications**: Use Firebase Cloud Messaging
- **In-App Notifications**: Store in database for UI display

## Configuration

### Kafka Configuration

All services use Kafka at `localhost:9092` (configured in `application.yml`):

```yaml
spring:
  kafka:
    bootstrap-servers: localhost:9092
```

### Notification Service Configuration

```yaml
spring:
  kafka:
    consumer:
      group-id: notification-group
      auto-offset-reset: earliest
```

## Testing Notifications

### Check Notification Logs

When actions occur, check the Notification Service logs for notification messages:

```bash
# Example: After checkout
# Look for: "=== ORDER CONFIRMATION NOTIFICATION ==="

# Example: After payment capture
# Look for: "=== PAYMENT CONFIRMATION NOTIFICATION ==="
```

### Event Flow Example

1. **Customer checks out** → Order Service publishes `order.created`
2. **Notification Service logs**: "Order Confirmation Notification"
3. **Payment is captured** → Payment Service publishes `payment.captured`
4. **Notification Service logs**: "Payment Confirmation Notification"
5. **Order is shipped** → Order Service publishes `shipment.created`
6. **Notification Service logs**: "Shipment Notification" with tracking number

## Integration Points

### When Notifications Are Sent

1. **Cart/Checkout**:
   - ❌ No notification (order not yet confirmed)
   - ✅ After checkout: `order.created` event → Order Confirmation

2. **Payment**:
   - ✅ After capture: `payment.captured` event → Payment Confirmation
   - ✅ On failure: `payment.failed` event → Payment Failure Notification
   - ✅ After refund: `payment.refunded` event → Refund Confirmation

3. **Shipping**:
   - ✅ When shipment created: `shipment.created` event → Shipment Notification
   - ✅ When delivered: `order.delivered` event → Delivery Confirmation

4. **Returns**:
   - ✅ When return requested: `return.requested` event → Return Request (to merchant)
   - ✅ When return completed: `return.completed` event → Return Completion (to customer)

## Setup Requirements

1. **Kafka must be running** on `localhost:9092`
2. **Notification Service must be running** (Port 8086)
3. **All services must be connected to Kafka**

## Extending Notifications

To add email notifications, update `NotificationService.java`:

```java
@Autowired
private JavaMailSender mailSender;

public void sendOrderConfirmation(...) {
    // Current: log to console
    log.info("=== ORDER CONFIRMATION NOTIFICATION ===");
    
    // Add: Send email
    SimpleMailMessage message = new SimpleMailMessage();
    message.setTo(customerEmail);
    message.setSubject("Your Order #" + orderNumber + " has been confirmed!");
    message.setText("Thank you for your order!...");
    mailSender.send(message);
}
```

## Summary

The notification system provides:
- ✅ **Event-driven architecture** - Loose coupling via Kafka
- ✅ **Real-time notifications** - Events trigger immediate notifications
- ✅ **Scalable** - Multiple notification service instances can consume events
- ✅ **Extensible** - Easy to add new notification channels (email, SMS, push)
- ✅ **Comprehensive coverage** - All major events (order, payment, shipping, returns)


