# Test Data Creation Script for RetailX
# This script creates test data for all services

param(
    [switch]$SkipAuth = $false
)

Write-Host "=== RetailX Test Data Creation ===" -ForegroundColor Magenta
Write-Host ""

# Colors for output
$successColor = "Green"
$errorColor = "Red"
$infoColor = "Cyan"

# Base URLs
$gatewayUrl = "http://localhost:8080"
$authUrl = "http://localhost:8081"

# Function to make API calls
function Invoke-API {
    param(
        [string]$Method,
        [string]$Url,
        [object]$Body = $null,
        [hashtable]$Headers = @{},
        [string]$Description
    )
    
    try {
        $params = @{
            Method = $Method
            Uri = $Url
            ContentType = "application/json"
            TimeoutSec = 10
        }
        
        if ($Body) {
            $params.Body = ($Body | ConvertTo-Json -Depth 10)
        }
        
        if ($Headers.Count -gt 0) {
            $params.Headers = $Headers
        }
        
        $response = Invoke-RestMethod @params
        
        Write-Host "  [OK] $Description" -ForegroundColor $successColor
        return $response
    }
    catch {
        $statusCode = if ($_.Exception.Response) { 
            [int]$_.Exception.Response.StatusCode.value__ 
        } else { 
            "N/A" 
        }
        Write-Host "  [FAIL] $Description - Status: $statusCode" -ForegroundColor $errorColor
        if ($_.Exception.Response) {
            $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
            $errorBody = $reader.ReadToEnd()
            Write-Host "    Error: $($errorBody.Substring(0, [Math]::Min(100, $errorBody.Length)))" -ForegroundColor Gray
        }
        return $null
    }
}

# Step 1: Register Users
Write-Host "1. REGISTERING USERS" -ForegroundColor $infoColor

$users = @(
    @{name="Test Customer"; email="testcustomer@example.com"; password="Test123!@$"; role="CUSTOMER"},
    @{name="Test Merchant"; email="testmerchant@example.com"; password="Test123!@$"; role="MERCHANT"},
    @{name="Test OPS"; email="testops@example.com"; password="Test123!@$"; role="OPS"},
    @{name="Test Admin"; email="testadmin@example.com"; password="Test123!@$"; role="ADMIN"}
)

$tokens = @{}
$userIds = @{}

foreach ($user in $users) {
    $response = Invoke-API -Method "POST" `
        -Url "$gatewayUrl/api/auth/register" `
        -Body $user `
        -Description "Register $($user.role) - $($user.email)"
    
    if ($response) {
        $tokens[$user.role] = $response.token
        $userIds[$user.role] = $response.userId
        Write-Host "    User ID: $($response.userId), Token obtained" -ForegroundColor Gray
    }
}

Write-Host ""

# Step 2: Create Products (as Merchant)
Write-Host "2. CREATING PRODUCTS" -ForegroundColor $infoColor

if ($tokens["MERCHANT"] -and $userIds["MERCHANT"]) {
    $merchantToken = $tokens["MERCHANT"]
    $merchantId = $userIds["MERCHANT"]
    
    $products = @(
        @{
            sku = "PROD-001"
            name = "Laptop Computer"
            description = "High-performance laptop with 16GB RAM, 512GB SSD"
            basePrice = 1299.99
            currency = "USD"
            categoryPath = "/electronics/computers"
            status = "ACTIVE"
            media = @("https://example.com/laptop1.jpg", "https://example.com/laptop2.jpg")
            attributes = '{"brand":"TechBrand","model":"Laptop Pro","warranty":"2 years"}'
        },
        @{
            sku = "PROD-002"
            name = "Wireless Mouse"
            description = "Ergonomic wireless mouse with long battery life"
            basePrice = 29.99
            currency = "USD"
            categoryPath = "/electronics/accessories"
            status = "ACTIVE"
            media = @("https://example.com/mouse1.jpg")
            attributes = '{"brand":"TechBrand","connectivity":"Bluetooth","battery":"6 months"}'
        },
        @{
            sku = "PROD-003"
            name = "Mechanical Keyboard"
            description = "RGB mechanical keyboard with Cherry MX switches"
            basePrice = 149.99
            currency = "USD"
            categoryPath = "/electronics/accessories"
            status = "ACTIVE"
            media = @("https://example.com/keyboard1.jpg")
            attributes = '{"brand":"TechBrand","switchType":"Cherry MX Red","backlight":"RGB"}'
        },
        @{
            sku = "PROD-004"
            name = "USB-C Cable"
            description = "High-speed USB-C cable, 6 feet"
            basePrice = 19.99
            currency = "USD"
            categoryPath = "/electronics/accessories"
            status = "ACTIVE"
            media = @()
            attributes = '{"length":"6 feet","speed":"10Gbps"}'
        },
        @{
            sku = "PROD-005"
            name = "Monitor Stand"
            description = "Adjustable monitor stand with cable management"
            basePrice = 79.99
            currency = "USD"
            categoryPath = "/furniture/office"
            status = "ACTIVE"
            media = @("https://example.com/stand1.jpg")
            attributes = '{"material":"Aluminum","adjustable":"Yes","maxWeight":"15kg"}'
        }
    )
    
    $productIds = @()
    $headers = @{
        "Authorization" = "Bearer $merchantToken"
    }
    
    foreach ($product in $products) {
        $response = Invoke-API -Method "POST" `
            -Url "$gatewayUrl/api/products" `
            -Body $product `
            -Headers $headers `
            -Description "Create Product: $($product.name) ($($product.sku))"
        
        if ($response) {
            $productIds += $response.id
            Write-Host "    Product ID: $($response.id), SKU: $($response.sku)" -ForegroundColor Gray
        }
    }
    
    Write-Host ""
    
    # Step 3: Create Inventory (as OPS/ADMIN)
    Write-Host "3. CREATING INVENTORY" -ForegroundColor $infoColor
    
    if ($tokens["OPS"] -or $tokens["ADMIN"]) {
        $opsToken = if ($tokens["OPS"]) { $tokens["OPS"] } else { $tokens["ADMIN"] }
        $headers = @{
            "Authorization" = "Bearer $opsToken"
        }
        
        $inventoryItems = @(
            @{sku="PROD-001"; warehouseId="WH-001"; quantity=50; reservedQuantity=0},
            @{sku="PROD-002"; warehouseId="WH-001"; quantity=100; reservedQuantity=0},
            @{sku="PROD-003"; warehouseId="WH-001"; quantity=30; reservedQuantity=0},
            @{sku="PROD-004"; warehouseId="WH-001"; quantity=200; reservedQuantity=0},
            @{sku="PROD-005"; warehouseId="WH-001"; quantity=25; reservedQuantity=0}
        )
        
        foreach ($item in $inventoryItems) {
            $url = "$gatewayUrl/api/inventory/adjust?sku=$($item.sku)&warehouseId=$($item.warehouseId)&quantity=$($item.quantity)"
            $response = Invoke-API -Method "POST" `
                -Url $url `
                -Headers $headers `
                -Description "Create Inventory: $($item.sku) - Qty: $($item.quantity)"
        }
    }
    
    Write-Host ""
    
    # Step 4: Create Orders (as Customer)
    Write-Host "4. CREATING ORDERS" -ForegroundColor $infoColor
    
    if ($tokens["CUSTOMER"] -and $userIds["CUSTOMER"] -and $productIds.Count -gt 0) {
        $customerToken = $tokens["CUSTOMER"]
        $customerId = $userIds["CUSTOMER"]
        $headers = @{
            "Authorization" = "Bearer $customerToken"
        }
        
        # Add items to cart
        Write-Host "  Adding items to cart..." -ForegroundColor Gray
        
        $cartItems = @(
            @{sku="PROD-001"; quantity=1},
            @{sku="PROD-002"; quantity=2}
        )
        
        foreach ($item in $cartItems) {
            $cartBody = @{
                sku = $item.sku
                quantity = $item.quantity
            }
            
            $response = Invoke-API -Method "POST" `
                -Url "$gatewayUrl/api/carts/items" `
                -Body $cartBody `
                -Headers $headers `
                -Description "Add to Cart: $($item.sku) x$($item.quantity)"
        }
        
        Write-Host ""
    }
    
    # Summary
    Write-Host "=== TEST DATA SUMMARY ===" -ForegroundColor Magenta
    Write-Host ""
    Write-Host "Users Created:" -ForegroundColor $infoColor
    foreach ($role in $tokens.Keys) {
        $userEmail = ($users | Where-Object { $_.role -eq $role } | Select-Object -First 1).email
        Write-Host "  - $role : User ID $($userIds[$role]), Email: $userEmail" -ForegroundColor Gray
    }
    Write-Host ""
    Write-Host "Products Created: $($productIds.Count)" -ForegroundColor $infoColor
    Write-Host "  Product IDs: $($productIds -join ', ')" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Credentials:" -ForegroundColor $infoColor
    Write-Host "  All users use password: Test123!@$" -ForegroundColor Gray
    Write-Host ""
    Write-Host "You can now:" -ForegroundColor Yellow
    Write-Host "  1. Login with any user: POST $gatewayUrl/api/auth/login" -ForegroundColor White
    Write-Host "  2. Use the tokens to access protected endpoints" -ForegroundColor White
    Write-Host "  3. Test product endpoints with SKUs: PROD-001, PROD-002, etc." -ForegroundColor White
    Write-Host ""
}
else {
    Write-Host "  [SKIP] Cannot create products - Merchant registration failed" -ForegroundColor $errorColor
}

Write-Host "=== DONE ===" -ForegroundColor Magenta

