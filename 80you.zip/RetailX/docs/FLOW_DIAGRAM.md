# RetailX - System Flow Diagrams

## 1. User Registration & Authentication Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/auth/register
     ▼
┌─────────────────┐
│  API Gateway    │
│  (Port 8080)    │
└────┬────────────┘
     │
     │ 2. Forward to Auth Service
     ▼
┌─────────────────┐
│  Auth Service   │
│  (Port 8081)    │
└────┬────────────┘
     │
     │ 3. Hash password (BCrypt)
     │ 4. Save user to DB
     │ 5. Generate JWT token
     │
     ▼
┌─────────────┐
│   MySQL    │
│ retailx_auth│
└─────────────┘
     │
     │ 6. Return JWT token
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 2. Product Browsing Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. GET /api/products?category=/electronics
     ▼
┌─────────────────┐
│  API Gateway    │
│  (JWT Validate) │
└────┬────────────┘
     │
     │ 2. Extract roles, add headers
     ▼
┌─────────────────┐
│ Product Service │
│  (Port 8082)    │
└────┬────────────┘
     │
     │ 3. Query products from cache/DB
     │ 4. Apply filters (category, price, search)
     │ 5. Paginate results
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_product│
└─────────────┘
     │
     │ 6. Return paginated products
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 3. Shopping Cart & Checkout Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/carts/items
     │    {sku, quantity}
     ▼
┌─────────────────┐
│  API Gateway    │
└────┬────────────┘
     │
     ▼
┌─────────────────┐
│  Order Service  │
│  (Port 8083)    │
└────┬────────────┘
     │
     │ 2. Validate product (Feign → Product Service)
     │ 3. Check inventory (Feign → Inventory Service)
     │ 4. Add to cart
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_order│
└─────────────┘
     │
     │ 5. POST /api/checkout
     │    (with Idempotency-Key)
     │
     ▼
┌─────────────────┐
│ CheckoutService │
└────┬────────────┘
     │
     │ 6. Reserve inventory
     │ 7. Create order
     │ 8. Clear cart
     │ 9. Publish order.created event (Kafka)
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
     │
     │ 10. Return order details
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 4. Payment Processing Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/payments/intents
     │    {orderId, amount, currency}
     ▼
┌─────────────────┐
│  API Gateway    │
└────┬────────────┘
     │
     ▼
┌─────────────────┐
│ Payment Service │
│  (Port 8084)    │
└────┬────────────┘
     │
     │ 2. Create payment intent
     │ 3. POST /api/payments/{id}/authorize
     │    (with Circuit Breaker)
     │
     ▼
┌─────────────────┐
│ Mock Provider   │
│ (Resilience4j)  │
└────┬────────────┘
     │
     │ 4. Authorize payment
     │ 5. POST /api/payments/{id}/capture
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_payment│
└─────────────┘
     │
     │ 6. Update order status to PAID
     │ 7. Publish payment.captured event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
```

## 5. Shipping & Fulfillment Flow

```
┌─────────┐
│  OPS    │
└────┬────┘
     │
     │ 1. POST /api/shipments/orders/{orderId}
     │    {carrier, trackingNumber}
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 2. Create shipment
     │ 3. Update order status to SHIPPED
     │ 4. Publish shipment.created event
     │
     ▼
┌─────────────┐
│   Kafka    │
└────┬───────┘
     │
     │ 5. Notification Service consumes event
     │ 6. Send shipping notification
     │
     ▼
┌─────────────────┐
│Notification Svc │
│  (Port 8086)    │
└─────────────────┘
     │
     │ 7. PUT /api/shipments/{id}/delivered
     │
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 8. Mark shipment as delivered
     │ 9. Update order status to DELIVERED
     │ 10. Publish order.delivered event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
```

## 6. Return & Refund Flow

```
┌─────────┐
│Customer │
└────┬────┘
     │
     │ 1. POST /api/returns/orders/{orderId}
     │    {reason, items: [{sku, quantity}]}
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 2. Validate return window (30 days)
     │ 3. Validate return quantities
     │ 4. Create return request (status: REQUESTED)
     │ 5. Publish return.requested event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
     │
     │ 6. PUT /api/returns/{id}/approve
     │    (OPS/ADMIN/MERCHANT)
     │
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 7. Restock inventory (Feign → Inventory Service)
     │ 8. Process refund (Feign → Payment Service)
     │ 9. Update return status to COMPLETED
     │ 10. Publish return.completed event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
```

## 7. Review & Moderation Flow

```
┌─────────┐
│Customer │
└────┬────┘
     │
     │ 1. POST /api/reviews/products/{productId}
     │    {rating, text, orderItemId}
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 2. Validate order item ownership
     │ 3. Check if review already exists
     │ 4. Create review (status: PENDING)
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_product│
└─────────────┘
     │
     │ 5. GET /api/reviews/pending
     │    (ADMIN/OPS)
     │
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 6. PUT /api/reviews/{id}/moderate?action=approve
     │
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 7. Update review status to APPROVED
     │ 8. GET /api/reviews/products/{id} (public)
     │    Returns only APPROVED reviews
     │
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 8. Event-Driven Architecture Flow

```
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ order.created
     │ inventory.reserved
     │ shipment.created
     │ order.delivered
     │ return.requested
     │ return.completed
     │
     ▼
┌─────────────┐
│   Kafka     │
│  (Broker)   │
└────┬────────┘
     │
     ├─────────────────┬─────────────────┐
     │                 │                 │
     ▼                 ▼                 ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ Inventory   │  │Notification │  │  Analytics  │
│  Service    │  │  Service    │  │  (Future)   │
└─────────────┘  └─────────────┘  └─────────────┘
```

## 9. Service Discovery Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ Request to API Gateway
     ▼
┌─────────────────┐
│  API Gateway    │
│  (Port 8080)    │
└────┬────────────┘
     │
     │ 1. Query Eureka for service
     │ 2. Get service instance
     │ 3. Load balance request
     │
     ▼
┌─────────────────┐
│ Eureka Server   │
│  (Port 8761)    │
└────┬────────────┘
     │
     │ Service Registry:
     │ - retailx-auth-service
     │ - retailx-product-service
     │ - retailx-order-service
     │ - retailx-payment-service
     │ - retailx-inventory-service
     │ - retailx-notification-service
     │ - retailx-frontend-service
     │
     ▼
┌─────────────────┐
│ Target Service  │
└─────────────────┘
```

## 10. Idempotency Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ POST /api/checkout
     │ Headers: Idempotency-Key: abc123
     │
     ▼
┌─────────────────┐
│ CheckoutService │
└────┬────────────┘
     │
     │ 1. Check idempotency_keys table
     │    WHERE key_value = 'abc123'
     │
     ├─ Key exists? ──┐
     │                 │
     ▼                 ▼
┌─────────────┐  ┌─────────────┐
│   Yes       │  │    No       │
│             │  │             │
│ 2. Compare │  │ 2. Process  │
│    request │  │    checkout  │
│    hash    │  │             │
│             │  │ 3. Save key │
│ 3. Same?   │  │    & result │
│    └─Yes───┼──┼─Return cached│
│    └─No────┼──┼─Return 409   │
│            │  │   Conflict   │
└────────────┘  └─────────────┘
```

## Notes

- All flows use JWT authentication via API Gateway
- Services communicate via Feign clients (synchronous) or Kafka (asynchronous)
- Idempotency keys expire after 24 hours
- Circuit breakers protect external service calls
- All events are published to Kafka for eventual consistency
- Database per service pattern ensures service independence

