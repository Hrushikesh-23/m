# RetailX - Low-Level Design (LLD) Diagram

## Class Diagram - Auth Service

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          AUTH SERVICE                                       │
│                                                                               │
│  ┌──────────────────────┐                                                   │
│  │   AuthController     │                                                   │
│  ├──────────────────────┤                                                   │
│  │ + register()         │                                                   │
│  │ + login()            │                                                   │
│  └──────────┬───────────┘                                                   │
│             │                                                                 │
│             ▼                                                                 │
│  ┌──────────────────────┐                                                   │
│  │    AuthService       │                                                   │
│  ├──────────────────────┤                                                   │
│  │ + register()         │                                                   │
│  │ + login()            │                                                   │
│  │ + validateToken()   │                                                   │
│  └──────────┬───────────┘                                                   │
│             │                                                                 │
│    ┌────────┴────────┐                                                       │
│    │                 │                                                       │
│    ▼                 ▼                                                       │
│  ┌──────────┐  ┌──────────┐                                                 │
│  │ JwtUtil  │  │UserRepo  │                                                 │
│  ├──────────┤  ├──────────┤                                                 │
│  │+generate │  │+findBy   │                                                 │
│  │+validate │  │+save()   │                                                 │
│  └──────────┘  └────┬─────┘                                                 │
│                     │                                                         │
│                     ▼                                                         │
│              ┌──────────┐                                                    │
│              │   User   │                                                    │
│              ├──────────┤                                                    │
│              │-email    │                                                    │
│              │-password │                                                    │
│              │-roles    │                                                    │
│              └──────────┘                                                    │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Class Diagram - Product Service

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       PRODUCT SERVICE                                        │
│                                                                               │
│  ┌──────────────────────┐  ┌──────────────────────┐                         │
│  │ ProductController    │  │ ReviewController    │                         │
│  ├──────────────────────┤  ├──────────────────────┤                         │
│  │ + create()          │  │ + create()          │                         │
│  │ + update()          │  │ + getByProduct()    │                         │
│  │ + search()          │  │ + moderate()        │                         │
│  │ + bulkImport()      │  └──────────┬───────────┘                         │
│  └──────────┬───────────┘             │                                     │
│             │                          │                                     │
│             ▼                          ▼                                     │
│  ┌──────────────────────┐  ┌──────────────────────┐                         │
│  │  ProductService      │  │  ReviewService      │                         │
│  ├──────────────────────┤  ├──────────────────────┤                         │
│  │ + create()          │  │ + create()          │                         │
│  │ + search()          │  │ + getByProduct()    │                         │
│  │ + update()          │  │ + moderate()        │                         │
│  └──────────┬───────────┘  └──────────┬───────────┘                         │
│             │                          │                                     │
│             ▼                          ▼                                     │
│  ┌──────────────────────┐  ┌──────────────────────┐                         │
│  │ ProductRepository    │  │ ReviewRepository     │                         │
│  ├──────────────────────┤  ├──────────────────────┤                         │
│  │ + findBySku()       │  │ + findByProductId()  │                         │
│  │ + search()          │  │ + findByStatus()    │                         │
│  └──────────┬───────────┘  └──────────┬───────────┘                         │
│             │                          │                                     │
│             ▼                          ▼                                     │
│      ┌──────────┐                ┌──────────┐                                │
│      │ Product  │                │  Review  │                                │
│      ├──────────┤                ├──────────┤                                │
│      │-sku      │                │-rating   │                                │
│      │-name     │                │-text     │                                │
│      │-price    │                │-status   │                                │
│      └──────────┘                └──────────┘                                │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Class Diagram - Order Service

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         ORDER SERVICE                                       │
│                                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │CartController│  │OrderController│ │CheckoutCtrl │                      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘                      │
│         │                  │                  │                              │
│         ▼                  ▼                  ▼                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │ CartService  │  │ OrderService │  │CheckoutService│                      │
│  ├──────────────┤  ├──────────────┤  ├──────────────┤                      │
│  │+addToCart()  │  │+getOrder()   │  │+checkout()   │                      │
│  │+updateItem() │  │+updateStatus()│ │+validate()   │                      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘                      │
│         │                  │                  │                              │
│         └──────────────────┼──────────────────┘                              │
│                           │                                                   │
│         ┌─────────────────┼─────────────────┐                              │
│         │                 │                 │                              │
│         ▼                 ▼                 ▼                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │CartRepository│  │OrderRepository│ │IdempotencyUtil│                     │
│  └──────────────┘  └──────────────┘  └──────────────┘                      │
│                                                                               │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐                      │
│  │ShipmentService│ │ReturnService │ │ReportingService│                     │
│  ├──────────────┤  ├──────────────┤  ├──────────────┤                      │
│  │+create()     │  │+request()    │  │+getSales()   │                      │
│  │+deliver()    │  │+approve()    │  │+getStatus()  │                      │
│  └──────────────┘  └──────────────┘  └──────────────┘                      │
│                                                                               │
│  ┌──────────────┐                                                           │
│  │ Feign Clients│                                                           │
│  ├──────────────┤                                                           │
│  │ProductService│                                                           │
│  │InventorySvc  │                                                           │
│  │PaymentService│                                                           │
│  └──────────────┘                                                           │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Sequence Diagram - Checkout Flow

```
┌──────┐  ┌──────────┐  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌─────────┐
│Client│  │  Gateway │  │  Order  │  │ Product  │  │Inventory │  │ Payment │
└───┬──┘  └────┬─────┘  └────┬────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘
    │          │             │            │             │             │
    │ POST /checkout         │            │             │             │
    │──────────>│            │            │             │             │
    │          │ Validate JWT│            │             │             │
    │          │────────────>│            │             │             │
    │          │<────────────│            │             │             │
    │          │             │            │             │             │
    │          │ Forward     │            │             │             │
    │          │────────────>│            │             │             │
    │          │             │ Check Idempotency Key    │             │
    │          │             │───────────>│             │             │
    │          │             │<───────────│             │             │
    │          │             │            │             │             │
    │          │             │ Validate Cart            │             │
    │          │             │───────────>│             │             │
    │          │             │<───────────│             │             │
    │          │             │            │             │             │
    │          │             │ Reserve Inventory        │             │
    │          │             │─────────────────────────>│             │
    │          │             │<─────────────────────────│             │
    │          │             │            │             │             │
    │          │             │ Create Order             │             │
    │          │             │───────────>│             │             │
    │          │             │<───────────│             │             │
    │          │             │            │             │             │
    │          │             │ Create Payment Intent    │             │
    │          │             │───────────────────────────────────────>│
    │          │             │<───────────────────────────────────────│
    │          │             │            │             │             │
    │          │             │ Publish order.created event           │
    │          │             │───────────>│             │             │
    │          │             │            │             │             │
    │          │             │ Return Order Response    │             │
    │          │<────────────│            │             │             │
    │<──────────│            │            │             │             │
```

## Sequence Diagram - Payment Flow

```
┌──────┐  ┌──────────┐  ┌─────────┐  ┌──────────┐  ┌──────────┐
│Client│  │  Gateway │  │ Payment │  │ External │  │   Kafka  │
└───┬──┘  └────┬─────┘  └────┬────┘  └────┬─────┘  └────┬─────┘
    │          │             │            │             │
    │ POST /payments/{id}/authorize       │             │
    │──────────>│            │            │             │
    │          │ Validate   │            │             │
    │          │────────────>│            │             │
    │          │             │            │             │
    │          │             │ Check Idempotency        │
    │          │             │───────────>│             │
    │          │             │<───────────│             │
    │          │             │            │             │
    │          │             │ Authorize Payment        │
    │          │             │───────────>│             │
    │          │             │            │             │
    │          │             │ [Circuit Breaker]       │
    │          │             │ [Retry Logic]            │
    │          │             │            │             │
    │          │             │<───────────│             │
    │          │             │            │             │
    │          │             │ Publish payment.authorized│
    │          │             │─────────────────────────>│
    │          │             │            │             │
    │          │             │ Return Response          │
    │          │<────────────│            │             │
    │<──────────│            │            │             │
```

## Database Schema Relationships

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    DATABASE RELATIONSHIPS                                   │
│                                                                               │
│  retailx_auth                                                                │
│  ┌──────────┐                                                                │
│  │  users   │                                                                │
│  │──────────│                                                                │
│  │ id (PK)  │────────┐                                                       │
│  │ email    │        │                                                       │
│  │ password │        │                                                       │
│  └──────────┘        │                                                       │
│                      │                                                       │
│  retailx_order       │                                                       │
│  ┌──────────┐        │                                                       │
│  │  orders  │        │                                                       │
│  │──────────│        │                                                       │
│  │ id (PK) │        │                                                       │
│  │customer │────────┘ (Reference)                                           │
│  │_id      │                                                               │
│  │order_   │                                                               │
│  │number   │                                                               │
│  └────┬────┘                                                               │
│       │                                                                      │
│       │ 1:N                                                                 │
│       │                                                                      │
│       ▼                                                                      │
│  ┌──────────┐                                                                │
│  │order_items│                                                               │
│  │──────────│                                                                │
│  │ id (PK)  │                                                                │
│  │order_id  │ (FK)                                                          │
│  │ sku      │                                                                │
│  │quantity  │                                                                │
│  └──────────┘                                                                │
│                                                                               │
│  retailx_product                                                              │
│  ┌──────────┐                                                                │
│  │ products │                                                                │
│  │──────────│                                                                │
│  │ id (PK)  │                                                                │
│  │ sku      │                                                                │
│  │ name     │                                                                │
│  │ price    │                                                                │
│  └────┬─────┘                                                                │
│       │                                                                      │
│       │ 1:N                                                                 │
│       │                                                                      │
│       ▼                                                                      │
│  ┌──────────┐                                                                │
│  │ variants │                                                                │
│  │──────────│                                                                │
│  │ id (PK)  │                                                                │
│  │product_id│ (FK)                                                          │
│  │options   │                                                                │
│  └──────────┘                                                                │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Component Interaction - Order Processing

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                  ORDER PROCESSING COMPONENTS                                │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    CheckoutService                                   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │ 1. Validate Idempotency Key                                 │   │  │
│  │  │ 2. Get Cart                                                  │   │  │
│  │  │ 3. Validate Products (Feign → ProductService)                │   │  │
│  │  │ 4. Reserve Inventory (Feign → InventoryService)              │   │  │
│  │  │ 5. Create Order                                               │   │  │
│  │  │ 6. Create Payment Intent (Feign → PaymentService)            │   │  │
│  │  │ 7. Clear Cart                                                 │   │  │
│  │  │ 8. Publish Event (Kafka)                                      │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    OrderService                                      │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │ 1. Create Order Entity                                       │   │  │
│  │  │ 2. Create Order Items                                        │   │  │
│  │  │ 3. Calculate Totals                                          │   │  │
│  │  │ 4. Generate Order Number                                      │   │  │
│  │  │ 5. Save to Database                                          │   │  │
│  │  │ 6. Create Order Version                                       │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
│                                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐  │
│  │                    IdempotencyUtil                                   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐   │  │
│  │  │ 1. Check if key exists                                       │   │  │
│  │  │ 2. Compare request hash                                      │   │  │
│  │  │ 3. Return cached response if same                            │   │  │
│  │  │ 4. Store new key and response                                │   │  │
│  │  │ 5. Set expiration (24 hours)                                 │   │  │
│  │  └──────────────────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────────┘
```

## State Machine - Order Lifecycle

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      ORDER STATE MACHINE                                     │
│                                                                               │
│         [PENDING]                                                            │
│            │                                                                 │
│            │ Payment Authorized                                              │
│            ▼                                                                 │
│         [PAID]                                                               │
│            │                                                                 │
│            │ Shipment Created                                                │
│            ▼                                                                 │
│      [FULFILLING]                                                            │
│            │                                                                 │
│            │ Shipped                                                         │
│            ▼                                                                 │
│         [SHIPPED]                                                            │
│            │                                                                 │
│            │ Delivered                                                       │
│            ▼                                                                 │
│       [DELIVERED]                                                            │
│            │                                                                 │
│            │ Return Requested                                                │
│            ▼                                                                 │
│      [RETURNED]                                                              │
│                                                                               │
│  [PENDING] ──Cancel──> [CANCELLED]                                           │
│  [PAID] ──Cancel──> [CANCELLED]                                              │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## State Machine - Payment Lifecycle

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                     PAYMENT STATE MACHINE                                   │
│                                                                               │
│         [PENDING]                                                            │
│            │                                                                 │
│            │ Authorize                                                       │
│            ▼                                                                 │
│      [AUTHORIZED]                                                            │
│            │                                                                 │
│            │ Capture                                                        │
│            ▼                                                                 │
│       [CAPTURED]                                                             │
│            │                                                                 │
│            │ Refund                                                         │
│            ▼                                                                 │
│       [REFUNDED]                                                             │
│                                                                               │
│  [PENDING] ──Fail──> [FAILED]                                                │
│  [AUTHORIZED] ──Fail──> [FAILED]                                             │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Design Patterns Used

### 1. Repository Pattern
```
Service → Repository → Entity
```
- Abstracts database access
- Provides clean API for data operations
- Enables easy testing with mocks

### 2. Service Layer Pattern
```
Controller → Service → Repository
```
- Business logic separation
- Transaction management
- Cross-cutting concerns

### 3. DTO Pattern
```
Entity → DTO → Response
```
- Decouples internal model from API
- Prevents data leakage
- Version compatibility

### 4. Builder Pattern
```
Entity.builder()
    .field1(value1)
    .field2(value2)
    .build()
```
- Immutable object creation
- Fluent API
- Optional fields handling

### 5. Strategy Pattern
```
PaymentStrategy
    ├─ CreditCardStrategy
    ├─ PayPalStrategy
    └─ BankTransferStrategy
```
- Payment method abstraction (future)

### 6. Observer Pattern
```
Event Publisher → Kafka → Event Consumers
```
- Loose coupling
- Event-driven architecture
- Scalability

### 7. Circuit Breaker Pattern
```
Service Call → Circuit Breaker → Fallback
```
- Fault tolerance
- Resilience
- Graceful degradation

## Data Flow - Complete Order Flow

```
1. Client Request
   │
   ▼
2. API Gateway (JWT Validation, Rate Limiting)
   │
   ▼
3. Order Service - CheckoutController
   │
   ▼
4. CheckoutService
   ├─► IdempotencyUtil (Check key)
   ├─► CartService (Get cart)
   ├─► ProductServiceClient (Validate products)
   ├─► InventoryServiceClient (Reserve inventory)
   ├─► OrderService (Create order)
   ├─► PaymentServiceClient (Create payment intent)
   └─► KafkaTemplate (Publish event)
   │
   ▼
5. Database (Save order, payment intent)
   │
   ▼
6. Kafka (Publish order.created)
   │
   ├─► Inventory Service (Consume, update inventory)
   ├─► Notification Service (Consume, send email)
   └─► Analytics Service (Future)
   │
   ▼
7. Response to Client
```

## Error Handling Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    ERROR HANDLING LAYERS                                    │
│                                                                               │
│  Layer 1: Controller                                                         │
│  - @ExceptionHandler                                                         │
│  - Custom error responses                                                    │
│  - HTTP status codes                                                         │
│                                                                               │
│  Layer 2: Service                                                             │
│  - Business logic validation                                                 │
│  - Custom exceptions                                                         │
│  - Transaction rollback                                                      │
│                                                                               │
│  Layer 3: Infrastructure                                                     │
│  - Circuit Breaker (Resilience4j)                                            │
│  - Retry with exponential backoff                                            │
│  - Fallback methods                                                          │
│                                                                               │
│  Layer 4: Global                                                             │
│  - @ControllerAdvice                                                         │
│  - Centralized error handling                                                │
│  - Logging and monitoring                                                    │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Caching Strategy

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CACHING LAYERS                                        │
│                                                                               │
│  Product Service                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  @Cacheable("products")                                              │   │
│  │  - Product by ID                                                     │   │
│  │  - Product by SKU                                                    │   │
│  │  - Search results (with TTL)                                         │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Order Service                                                                │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  @Cacheable("carts")                                                  │   │
│  │  - Cart by customer ID                                                │   │
│  │  - Order summaries                                                    │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Cache Eviction                                                               │
│  - On product update                                                         │
│  - On cart modification                                                      │
│  - TTL-based expiration                                                      │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Security Implementation Details

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SECURITY IMPLEMENTATION                                  │
│                                                                               │
│  Authentication                                                               │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. User submits credentials                                         │   │
│  │  2. AuthService validates                                            │   │
│  │  3. BCrypt password verification                                     │   │
│  │  4. JwtUtil generates token                                          │   │
│  │  5. Token includes: userId, email, roles                            │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Authorization                                                                │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. API Gateway validates JWT                                         │   │
│  │  2. Extracts roles from token                                         │   │
│  │  3. Adds headers to request                                           │   │
│  │  4. Service SecurityConfig validates path                              │   │
│  │  5. @PreAuthorize validates method access                             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
│  Data Protection                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │  1. PII fields use @EncryptedString                                 │   │
│  │  2. AES GCM encryption at rest                                       │   │
│  │  3. Password hashing with BCrypt                                     │   │
│  │  4. Audit trail with AOP                                             │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                               │
└─────────────────────────────────────────────────────────────────────────────┘
```

