package com.retailx.auth.util;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for JwtUtil.
 */
class JwtUtilTest {
    
    private JwtUtil jwtUtil;
    
    @BeforeEach
    void setUp() {
        jwtUtil = new JwtUtil();
        ReflectionTestUtils.setField(jwtUtil, "secret", 
                "RetailXSecretKeyForJWTTokenGeneration2024SecureAndLongEnough");
        ReflectionTestUtils.setField(jwtUtil, "expiration", 3600000L);
    }
    
    @Test
    void testGenerateToken() {
        Set<String> roles = new HashSet<>();
        roles.add("CUSTOMER");
        
        String token = jwtUtil.generateToken(1L, "test@example.com", roles);
        
        assertNotNull(token);
        assertFalse(token.isEmpty());
    }
    
    @Test
    void testGetUserIdFromToken() {
        Set<String> roles = new HashSet<>();
        roles.add("CUSTOMER");
        
        String token = jwtUtil.generateToken(1L, "test@example.com", roles);
        String userId = jwtUtil.getUserIdFromToken(token);
        
        assertEquals("1", userId);
    }
    
    @Test
    void testGetEmailFromToken() {
        Set<String> roles = new HashSet<>();
        roles.add("CUSTOMER");
        
        String token = jwtUtil.generateToken(1L, "test@example.com", roles);
        String email = jwtUtil.getEmailFromToken(token);
        
        assertEquals("test@example.com", email);
    }
    
    @Test
    void testValidateToken() {
        Set<String> roles = new HashSet<>();
        roles.add("CUSTOMER");
        
        String token = jwtUtil.generateToken(1L, "test@example.com", roles);
        boolean isValid = jwtUtil.validateToken(token);
        
        assertTrue(isValid);
    }
    
    @Test
    void testValidateToken_Invalid() {
        boolean isValid = jwtUtil.validateToken("invalid.token.here");
        
        assertFalse(isValid);
    }
}

