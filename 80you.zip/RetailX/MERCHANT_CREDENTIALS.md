# Merchant Credentials for Product Creation

## Role Required
**MERCHANT** or **ADMIN** role is required to create products.

## Test Script Credentials

The test script generates **random credentials** each time it runs:

### Email Pattern
- Format: `merchant[random]@example.com`
- Example: `merchant2301@example.com`, `merchant4567@example.com`
- The random number is between 1000-9999

### Password
- **Password:** `Test123!@$`
- This password meets the validation requirements:
  - At least 8 characters
  - Contains uppercase letter (T)
  - Contains lowercase letters (est)
  - Contains digit (123)
  - Contains special character (!@$)

### Role
- **Role:** `MERCHANT`

## How to Create a Product

### Step 1: Register a Merchant User

**Endpoint:** `POST http://localhost:8080/api/auth/register`

**Request Body:**
```json
{
  "name": "My Merchant",
  "email": "merchant@example.com",
  "password": "Test123!@$",
  "role": "MERCHANT"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": 22,
  "email": "merchant@example.com",
  "roles": ["MERCHANT"],
  "expiresIn": 3600000
}
```

### Step 2: Login (Optional - if you already have credentials)

**Endpoint:** `POST http://localhost:8080/api/auth/login`

**Request Body:**
```json
{
  "email": "merchant@example.com",
  "password": "Test123!@$"
}
```

**Response:**
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "userId": 22,
  "email": "merchant@example.com",
  "roles": ["MERCHANT"],
  "expiresIn": 3600000
}
```

### Step 3: Create Product

**Endpoint:** `POST http://localhost:8080/api/products`

**Headers:**
```
Authorization: Bearer <token_from_step_1_or_2>
```

**Request Body:**
```json
{
  "sku": "PROD-001",
  "name": "Test Product",
  "description": "Product description",
  "basePrice": 99.99,
  "currency": "USD",
  "categoryPath": "/electronics",
  "status": "ACTIVE"
}
```

**Note:** The `merchantId` is automatically extracted from the JWT token (X-User-Id header), so you don't need to provide it in the request.

## Example Using cURL

```bash
# 1. Register Merchant
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "My Merchant",
    "email": "merchant@example.com",
    "password": "Test123!@$",
    "role": "MERCHANT"
  }'

# 2. Create Product (use token from registration)
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <YOUR_TOKEN>" \
  -d '{
    "sku": "PROD-001",
    "name": "Test Product",
    "description": "Product description",
    "basePrice": 99.99,
    "currency": "USD",
    "categoryPath": "/electronics",
    "status": "ACTIVE"
  }'
```

## Example Using PowerShell

```powershell
# 1. Register Merchant
$registerBody = @{
    name = "My Merchant"
    email = "merchant@example.com"
    password = "Test123!@$"
    role = "MERCHANT"
} | ConvertTo-Json

$registerResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/register" `
    -Method POST `
    -Body $registerBody `
    -ContentType "application/json"

$token = $registerResponse.token
$userId = $registerResponse.userId

# 2. Create Product
$productBody = @{
    sku = "PROD-001"
    name = "Test Product"
    description = "Product description"
    basePrice = 99.99
    currency = "USD"
    categoryPath = "/electronics"
    status = "ACTIVE"
} | ConvertTo-Json

$headers = @{
    "Authorization" = "Bearer $token"
}

$productResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/products" `
    -Method POST `
    -Headers $headers `
    -Body $productBody `
    -ContentType "application/json"

Write-Host "Product created: $($productResponse.id)"
```

## Password Requirements

The password must meet these requirements:
- Minimum 8 characters
- At least 1 uppercase letter
- At least 1 lowercase letter
- At least 1 digit
- At least 1 special character from: `@$!%*?&`

**Valid Examples:**
- `Test123!@$` ✅
- `Merchant@123` ✅
- `MyPass123!` ✅

**Invalid Examples:**
- `test123` ❌ (no uppercase, no special char)
- `TEST123!` ❌ (no lowercase)
- `Test!@#` ❌ (no digit)

## Important Notes

1. **Email must be unique** - If you try to register with an email that already exists, you'll get an error.

2. **Token expires** - JWT tokens expire after 1 hour. You'll need to login again if the token expires.

3. **merchantId is automatic** - When creating a product, the `merchantId` is automatically set from your authenticated user ID. You don't need to provide it in the request.

4. **Role-based access** - Only users with `MERCHANT` or `ADMIN` role can create products. `CUSTOMER` and `OPS` roles will get a 403 Forbidden error.



