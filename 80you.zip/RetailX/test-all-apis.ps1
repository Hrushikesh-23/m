# API Testing Script for RetailX
Write-Host "=== Testing All RetailX APIs ===" -ForegroundColor Magenta

# 1. Health Checks
Write-Host "`n1. Health Checks" -ForegroundColor Cyan
$services = @(
    @{Port=8761; Name="Eureka"; Path=""},
    @{Port=8080; Name="API Gateway"; Path="/actuator/health"},
    @{Port=8081; Name="Auth"; Path="/actuator/health"},
    @{Port=8082; Name="Product"; Path="/actuator/health"},
    @{Port=8083; Name="Order"; Path="/actuator/health"},
    @{Port=8084; Name="Payment"; Path="/actuator/health"},
    @{Port=8085; Name="Inventory"; Path="/actuator/health"},
    @{Port=8086; Name="Notification"; Path="/actuator/health"},
    @{Port=8087; Name="Frontend"; Path="/actuator/health"}
)

foreach ($svc in $services) {
    try {
        $url = "http://localhost:$($svc.Port)$($svc.Path)"
        $r = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
        Write-Host "  [OK] $($svc.Name): UP" -ForegroundColor Green
    } catch {
        Write-Host "  [FAIL] $($svc.Name): $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 2. Auth Service - Registration
Write-Host "`n2. Auth Service - User Registration" -ForegroundColor Cyan
$randomNum = Get-Random
$registerBody = '{"name":"Test User' + $randomNum + '","email":"test' + $randomNum + '@example.com","password":"Test123!"}'
try {
    $registerResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/register" -Method POST -Body $registerBody -ContentType "application/json" -TimeoutSec 10
    Write-Host "  [OK] Registration: SUCCESS" -ForegroundColor Green
    Write-Host "    User ID: $($registerResponse.userId)" -ForegroundColor Gray
    $script:authToken = $registerResponse.token
    $script:userId = $registerResponse.userId
} catch {
    Write-Host "  [FAIL] Registration: $($_.Exception.Message)" -ForegroundColor Red
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $errorBody = $reader.ReadToEnd()
        Write-Host "    Error: $errorBody" -ForegroundColor Yellow
    }
}

# 3. Auth Service - User Login (using email)
Write-Host "`n3. Auth Service - User Login" -ForegroundColor Cyan
if ($script:userId) {
    $loginBody = '{"email":"test' + $randomNum + '@example.com","password":"Test123!"}'
} else {
    $loginBody = '{"email":"test@example.com","password":"Test123!"}'
}
try {
    $loginResponse = Invoke-RestMethod -Uri "http://localhost:8080/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -TimeoutSec 10
    Write-Host "  [OK] Login: SUCCESS" -ForegroundColor Green
    $script:authToken = $loginResponse.token
} catch {
    Write-Host "  [FAIL] Login: $($_.Exception.Message)" -ForegroundColor Red
}

# 4. Product Service - List Products
Write-Host "`n4. Product Service - List All Products" -ForegroundColor Cyan
try {
    $products = Invoke-RestMethod -Uri "http://localhost:8080/api/products" -Method GET -TimeoutSec 10
    Write-Host "  [OK] List Products: SUCCESS" -ForegroundColor Green
    Write-Host "    Found $($products.Count) products" -ForegroundColor Gray
} catch {
    Write-Host "  [FAIL] List Products: $($_.Exception.Message)" -ForegroundColor Red
}

# 5. Product Service - Get Product by ID
Write-Host "`n5. Product Service - Get Product by ID" -ForegroundColor Cyan
try {
    $product = Invoke-RestMethod -Uri "http://localhost:8080/api/products/1" -Method GET -TimeoutSec 10
    Write-Host "  [OK] Get Product: SUCCESS" -ForegroundColor Green
    Write-Host "    Product: $($product.name) - Price: $($product.price)" -ForegroundColor Gray
} catch {
    Write-Host "  [FAIL] Get Product: $($_.Exception.Message)" -ForegroundColor Red
}

# 6. Product Service - Search Products
Write-Host "`n6. Product Service - Search Products" -ForegroundColor Cyan
try {
    $searchResults = Invoke-RestMethod -Uri "http://localhost:8080/api/products/search?query=laptop" -Method GET -TimeoutSec 10
    Write-Host "  [OK] Search Products: SUCCESS" -ForegroundColor Green
    Write-Host "    Found $($searchResults.Count) results" -ForegroundColor Gray
} catch {
    Write-Host "  [FAIL] Search Products: $($_.Exception.Message)" -ForegroundColor Red
}

# 7. Order Service - Get Cart (requires auth)
Write-Host "`n7. Order Service - Get Cart" -ForegroundColor Cyan
if ($script:authToken) {
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $cart = Invoke-RestMethod -Uri "http://localhost:8080/api/carts" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Get Cart: SUCCESS" -ForegroundColor Green
        Write-Host "    Cart ID: $($cart.id), Items: $($cart.items.Count)" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Get Cart: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Get Cart: No auth token available" -ForegroundColor Yellow
}

# 8. Order Service - Add to Cart (requires auth)
Write-Host "`n8. Order Service - Add to Cart" -ForegroundColor Cyan
if ($script:authToken) {
    $addToCartBody = '{"productId":1,"quantity":2}'
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $cartItem = Invoke-RestMethod -Uri "http://localhost:8080/api/carts/items" -Method POST -Body $addToCartBody -ContentType "application/json" -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Add to Cart: SUCCESS" -ForegroundColor Green
        Write-Host "    Item added: Product $($cartItem.productId), Quantity: $($cartItem.quantity)" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Add to Cart: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Add to Cart: No auth token available" -ForegroundColor Yellow
}

# 9. Order Service - Get Orders (requires auth)
Write-Host "`n9. Order Service - Get Orders" -ForegroundColor Cyan
if ($script:authToken) {
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $orders = Invoke-RestMethod -Uri "http://localhost:8080/api/orders" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Get Orders: SUCCESS" -ForegroundColor Green
        Write-Host "    Found $($orders.Count) orders" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Get Orders: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Get Orders: No auth token available" -ForegroundColor Yellow
}

# 10. Payment Service - Get Payment Methods (requires auth)
Write-Host "`n10. Payment Service - Get Payment Methods" -ForegroundColor Cyan
if ($script:authToken) {
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $paymentMethods = Invoke-RestMethod -Uri "http://localhost:8080/api/payments/methods" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Get Payment Methods: SUCCESS" -ForegroundColor Green
        Write-Host "    Found $($paymentMethods.Count) methods" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Get Payment Methods: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Get Payment Methods: No auth token available" -ForegroundColor Yellow
}

# 11. Inventory Service - Get Inventory (requires auth)
Write-Host "`n11. Inventory Service - Get Inventory" -ForegroundColor Cyan
if ($script:authToken) {
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $inventory = Invoke-RestMethod -Uri "http://localhost:8080/api/inventory" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Get Inventory: SUCCESS" -ForegroundColor Green
        Write-Host "    Found $($inventory.Count) inventory items" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Get Inventory: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Get Inventory: No auth token available" -ForegroundColor Yellow
}

# 12. Inventory Service - Get Low Stock (requires auth)
Write-Host "`n12. Inventory Service - Get Low Stock" -ForegroundColor Cyan
if ($script:authToken) {
    $headers = @{"Authorization" = "Bearer $script:authToken"}
    try {
        $lowStock = Invoke-RestMethod -Uri "http://localhost:8080/api/inventory/low-stock" -Method GET -Headers $headers -TimeoutSec 10
        Write-Host "  [OK] Get Low Stock: SUCCESS" -ForegroundColor Green
        Write-Host "    Found $($lowStock.Count) low stock items" -ForegroundColor Gray
    } catch {
        Write-Host "  [FAIL] Get Low Stock: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "  [SKIP] Get Low Stock: No auth token available" -ForegroundColor Yellow
}

# 13. Product Service - Get Catalog
Write-Host "`n13. Product Service - Get Catalog" -ForegroundColor Cyan
try {
    $catalog = Invoke-RestMethod -Uri "http://localhost:8080/api/catalog" -Method GET -TimeoutSec 10
    Write-Host "  [OK] Get Catalog: SUCCESS" -ForegroundColor Green
    Write-Host "    Found $($catalog.Count) categories" -ForegroundColor Gray
} catch {
    Write-Host "  [FAIL] Get Catalog: $($_.Exception.Message)" -ForegroundColor Red
}

# 14. Product Service - Get Reviews
Write-Host "`n14. Product Service - Get Reviews" -ForegroundColor Cyan
try {
    $reviews = Invoke-RestMethod -Uri "http://localhost:8080/api/reviews/products/1" -Method GET -TimeoutSec 10
    Write-Host "  [OK] Get Reviews: SUCCESS" -ForegroundColor Green
    Write-Host "    Found $($reviews.Count) reviews" -ForegroundColor Gray
} catch {
    Write-Host "  [FAIL] Get Reviews: $($_.Exception.Message)" -ForegroundColor Red
}

# 15. Swagger/OpenAPI
Write-Host "`n15. Swagger/OpenAPI Endpoints" -ForegroundColor Cyan
try {
    $swagger = Invoke-WebRequest -Uri "http://localhost:8080/v3/api-docs" -UseBasicParsing -TimeoutSec 5
    Write-Host "  [OK] Swagger API Docs: ACCESSIBLE" -ForegroundColor Green
} catch {
    Write-Host "  [FAIL] Swagger API Docs: $($_.Exception.Message)" -ForegroundColor Red
}

try {
    $swaggerUI = Invoke-WebRequest -Uri "http://localhost:8080/swagger-ui.html" -UseBasicParsing -TimeoutSec 5
    Write-Host "  [OK] Swagger UI: ACCESSIBLE" -ForegroundColor Green
} catch {
    Write-Host "  [FAIL] Swagger UI: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== API Testing Complete ===" -ForegroundColor Magenta
Write-Host "Check the results above for any failures." -ForegroundColor Yellow

