package com.retailx.product.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Security configuration for Product Service with role-based access control.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {
    
    @Autowired
    private JwtAuthenticationFilter jwtAuthenticationFilter;
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/actuator/**")
                    .permitAll() // Allow actuator endpoints for health checks
                .requestMatchers("/api/products/bulk/**")
                    .hasAnyRole("MERCHANT", "ADMIN") // Bulk operations require auth (check before general products)
                // Public review endpoints (GET /api/reviews/products/**)
                .requestMatchers(HttpMethod.GET, "/api/reviews/products/**")
                    .permitAll() // Public read access for product reviews
                // All other review endpoints require authentication - @PreAuthorize handles role-based authorization
                // Explicitly match all review paths except the public ones above
                .requestMatchers("/api/reviews/**")
                    .authenticated() // Require authentication (authorization handled by @PreAuthorize at method level)
                .requestMatchers("/api/products/**", "/api/catalog/**")
                    .permitAll() // Public read access for products and catalog
                .anyRequest().authenticated() // Require authentication for all other requests
            );
        
        return http.build();
    }
}

