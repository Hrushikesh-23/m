﻿Write-Host '=== PASSWORD LOGIN TEST ==='
Write-Host ''
Write-Host 'Step 1: Register new user'
$regBody = @{
    email = 'diagtest@example.com'
    password = 'Test123!@$'
    name = 'Diagnostic Test'
    role = 'CUSTOMER'
} | ConvertTo-Json

try {
    $regResult = Invoke-RestMethod -Uri 'http://localhost:8080/api/auth/register' -Method POST -ContentType 'application/json' -Body $regBody
    Write-Host 'Registration SUCCESS - User ID:' $regResult.userId
    Write-Host ''
    Write-Host 'Step 2: Login with same credentials'
    $loginBody = @{
        email = 'diagtest@example.com'
        password = 'Test123!@$'
    } | ConvertTo-Json
    
    $loginResult = Invoke-RestMethod -Uri 'http://localhost:8080/api/auth/login' -Method POST -ContentType 'application/json' -Body $loginBody
    Write-Host 'Login SUCCESS - Token received!'
} catch {
    Write-Host 'FAILED:' $_.Exception.Message
    if ($_.Exception.Response) {
        $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
        $response = $reader.ReadToEnd()
        Write-Host 'Response:' $response
    }
}
