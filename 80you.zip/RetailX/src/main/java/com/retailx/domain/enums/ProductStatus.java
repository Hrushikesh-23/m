package com.retailx.domain.enums;

/**
 * Product status values.
 */
public enum ProductStatus {
    DRAFT,
    ACTIVE,
    DISCONTINUED
}

