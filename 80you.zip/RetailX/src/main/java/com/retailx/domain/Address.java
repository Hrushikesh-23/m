package com.retailx.domain;

import com.retailx.encryption.EncryptedString;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Customer address (PII encrypted).
 */
@Entity
@Table(name = "addresses")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Address extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
    
    @Column(nullable = false, length = 255)
    @Convert(converter = EncryptedString.class)
    private String street;
    
    @Column(nullable = false, length = 100)
    @Convert(converter = EncryptedString.class)
    private String city;
    
    @Column(nullable = false, length = 100)
    @Convert(converter = EncryptedString.class)
    private String state;
    
    @Column(nullable = false, length = 20)
    @Convert(converter = EncryptedString.class)
    private String postalCode;
    
    @Column(nullable = false, length = 100)
    @Convert(converter = EncryptedString.class)
    private String country;
    
    @Column
    @Builder.Default
    private Boolean isDefault = false;
}

