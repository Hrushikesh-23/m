# Checkout Validation Fix

## Issue

Checkout was returning 400 Bad Request due to inventory reservation failure.

## Root Cause

The checkout service was trying to reserve inventory from `"default-warehouse"`, but the test data (and likely production data) uses `"WH-001"` as the warehouse ID.

**Code Location:** `retailx-order-service/src/main/java/com/retailx/order/service/CheckoutService.java`

**Original Code:**
```java
boolean reserved = inventoryServiceClient.reserveInventory(
    item.getSku(), item.getQuantity(), "default-warehouse");
```

## Solution

Updated the checkout service to:
1. First try `"WH-001"` (common warehouse used in test data)
2. Fallback to `"default-warehouse"` if `WH-001` doesn't have inventory

**Fixed Code:**
```java
// Reserve inventory
for (var item : cart.getItems()) {
    // Try WH-001 first (common warehouse), fallback to default-warehouse
    boolean reserved = inventoryServiceClient.reserveInventory(
            item.getSku(), item.getQuantity(), "WH-001");
    if (!reserved) {
        // Fallback to default-warehouse if WH-001 doesn't have inventory
        reserved = inventoryServiceClient.reserveInventory(
                item.getSku(), item.getQuantity(), "default-warehouse");
    }
    if (!reserved) {
        throw new RuntimeException("Insufficient inventory for SKU: " + item.getSku());
    }
}
```

## Why This Works

1. **Test Data Compatibility:** Test data uses `WH-001`, so checkout will work with test data
2. **Backward Compatibility:** Still supports `default-warehouse` for existing data
3. **Flexibility:** Tries both warehouses, so it works in more scenarios

## Testing

After this fix, checkout should work when:
- ✅ Cart has items
- ✅ Inventory exists in `WH-001` or `default-warehouse`
- ✅ Valid idempotency key is provided
- ✅ Shipping address is provided

## Next Steps

For production, consider:
1. Making warehouse ID configurable
2. Using the warehouse from inventory records
3. Supporting multiple warehouses per product
4. Adding warehouse selection in checkout request

## Related Files

- `retailx-order-service/src/main/java/com/retailx/order/service/CheckoutService.java`
- `add-test-data.ps1` (creates inventory in WH-001)
- `test-all-apis-comprehensive.ps1` (tests checkout)


