package com.retailx.product.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

/**
 * Feign client for Order Service to validate order status for reviews.
 */
@FeignClient(name = "retailx-order-service", path = "/api/orders")
public interface OrderServiceClient {
    
    @GetMapping("/{orderId}")
    Map<String, Object> getOrderById(@PathVariable Long orderId);
}

