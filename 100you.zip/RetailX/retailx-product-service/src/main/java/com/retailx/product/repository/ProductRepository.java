package com.retailx.product.repository;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Repository for Product entity.
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
    
    Optional<Product> findBySkuAndDeletedFalse(String sku);
    
    Page<Product> findByStatusAndDeletedFalse(ProductStatus status, Pageable pageable);
    
    Page<Product> findByStatusAndCategoryPathStartingWithAndDeletedFalse(
        ProductStatus status, String categoryPrefix, Pageable pageable
    );
    
    @Query("SELECT p FROM Product p WHERE p.status = :status AND p.deleted = false " +
           "AND p.basePrice BETWEEN :minPrice AND :maxPrice " +
           "AND (:categoryPrefix IS NULL OR p.categoryPath LIKE CONCAT(:categoryPrefix, '%')) " +
           "AND (:searchText IS NULL OR LOWER(p.name) LIKE LOWER(CONCAT('%', :searchText, '%')) " +
           "OR LOWER(p.description) LIKE LOWER(CONCAT('%', :searchText, '%')))")
    Page<Product> searchProducts(
        @Param("status") ProductStatus status,
        @Param("minPrice") BigDecimal minPrice,
        @Param("maxPrice") BigDecimal maxPrice,
        @Param("categoryPrefix") String categoryPrefix,
        @Param("searchText") String searchText,
        Pageable pageable
    );
    
    @Query(value = "SELECT * FROM products WHERE catalog_path REGEXP :pattern AND deleted = false", nativeQuery = true)
    List<Product> findByCatalogPathRegex(@Param("pattern") String pattern);
    
    Page<Product> findByMerchantIdAndDeletedFalse(Long merchantId, Pageable pageable);
    
    List<Product> findByMerchantIdAndDeletedFalse(Long merchantId);
}

