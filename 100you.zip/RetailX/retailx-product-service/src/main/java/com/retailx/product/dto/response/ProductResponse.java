package com.retailx.product.dto.response;

import com.retailx.product.domain.enums.ProductStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Product response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductResponse {
    
    private Long id;
    private String sku;
    private String name;
    private String description;
    private BigDecimal basePrice;
    private String currency;
    private String categoryPath;
    private String catalogPath;
    private ProductStatus status;
    private List<String> media;
    private String attributes;
    private Long merchantId;
    private LocalDateTime createdOn;
    private LocalDateTime updatedOn;
}

