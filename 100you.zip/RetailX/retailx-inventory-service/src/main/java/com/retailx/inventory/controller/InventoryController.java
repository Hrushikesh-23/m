package com.retailx.inventory.controller;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.service.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

/**
 * Inventory management endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {
    
    private final InventoryService inventoryService;
    
    /**
     * Reserve inventory for an order.
     */
    @PostMapping("/reserve")
    public ResponseEntity<Boolean> reserveInventory(
            @RequestParam String sku,
            @RequestParam BigInteger quantity,
            @RequestParam String warehouseId) {
        
        log.info("Reserving inventory: SKU {} qty {} warehouse {}", sku, quantity, warehouseId);
        boolean reserved = inventoryService.reserveInventory(sku, quantity, warehouseId);
        log.info("Reservation result: SKU {} reserved={}", sku, reserved);
        return ResponseEntity.ok(reserved);
    }
    
    /**
     * Get low stock items.
     */
    @GetMapping("/low-stock")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<List<Inventory>> getLowStockItems() {
        log.info("Getting low stock items");
        List<Inventory> items = inventoryService.getLowStockItems();
        log.debug("Found {} items", items.size());
        return ResponseEntity.ok(items);
    }
    
    /**
     * Adjust inventory quantity.
     */
    @PostMapping("/adjust")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN', 'MERCHANT')")
    public ResponseEntity<Void> adjustInventory(
            @RequestParam String sku,
            @RequestParam String warehouseId,
            @RequestParam BigInteger quantity) {
        
        log.info("Adjusting inventory: SKU {} warehouse {} qty {}", sku, warehouseId, quantity);
        inventoryService.adjustInventory(sku, warehouseId, quantity);
        log.info("Inventory adjusted: SKU {}", sku);
        return ResponseEntity.ok().build();
    }
    
    /**
     * Release reserved inventory.
     */
    @PostMapping("/release")
    public ResponseEntity<Boolean> releaseReservedInventory(
            @RequestParam String sku,
            @RequestParam BigInteger quantity,
            @RequestParam String warehouseId) {
        
        log.info("Releasing inventory: SKU {} qty {} warehouse {}", sku, quantity, warehouseId);
        boolean released = inventoryService.releaseReservedInventory(sku, quantity, warehouseId);
        log.info("Release result: SKU {} released={}", sku, released);
        return ResponseEntity.ok(released);
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Inventory Service is running");
    }
}

