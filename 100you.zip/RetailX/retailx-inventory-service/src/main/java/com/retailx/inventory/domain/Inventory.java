package com.retailx.inventory.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigInteger;

/**
 * Inventory per SKU and warehouse.
 */
@Entity
@Table(name = "inventory", indexes = {
    @Index(name = "idx_inventory_sku_warehouse", columnList = "sku,warehouseId", unique = true),
    @Index(name = "idx_inventory_warehouse", columnList = "warehouseId")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Inventory extends BaseEntity {
    
    @Version
    private Long version; // Optimistic locking for concurrent inventory updates
    
    @Column(nullable = false, length = 100)
    private String sku; // Product SKU or Variant SKU
    
    @Column(nullable = false, length = 100)
    private String warehouseId;
    
    @Column(nullable = false)
    @Builder.Default
    private BigInteger onHand = BigInteger.ZERO;
    
    @Column(nullable = false)
    @Builder.Default
    private BigInteger reserved = BigInteger.ZERO;
    
    @Column(nullable = false)
    @Builder.Default
    private BigInteger available = BigInteger.ZERO; // Computed: onHand - reserved
    
    @PreUpdate
    @PrePersist
    private void onPersist() {
        if (onHand == null) onHand = BigInteger.ZERO;
        if (reserved == null) reserved = BigInteger.ZERO;
        this.available = onHand.subtract(reserved);
        if (getDeleted() == null) setDeleted(false);
    }
}

