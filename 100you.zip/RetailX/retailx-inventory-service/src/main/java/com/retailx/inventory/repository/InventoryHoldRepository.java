package com.retailx.inventory.repository;

import com.retailx.inventory.domain.InventoryHold;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Repository for InventoryHold entity.
 */
@Repository
public interface InventoryHoldRepository extends JpaRepository<InventoryHold, Long> {
    
    List<InventoryHold> findByCartId(String cartId);
    
    List<InventoryHold> findByOrderId(Long orderId);
    
    @Query("SELECT h FROM InventoryHold h WHERE h.expiresAt < :now AND h.released = false")
    List<InventoryHold> findExpiredHolds(@Param("now") LocalDateTime now);
}

