package com.retailx.inventory.controller;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.service.InventoryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for InventoryController.
 */
@ExtendWith(MockitoExtension.class)
class InventoryControllerTest {
    
    @Mock
    private InventoryService inventoryService;
    
    @InjectMocks
    private InventoryController inventoryController;
    
    private Inventory inventory;
    
    @BeforeEach
    void setUp() {
        inventory = Inventory.builder()
                .sku("PROD-001")
                .warehouseId("WH-001")
                .onHand(BigInteger.valueOf(100))
                .reserved(BigInteger.valueOf(10))
                .available(BigInteger.valueOf(90))
                .build();
    }
    
    @Test
    void testReserveInventory_Success() {
        when(inventoryService.reserveInventory(anyString(), any(), anyString()))
                .thenReturn(true);
        
        ResponseEntity<Boolean> response = 
                inventoryController.reserveInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody());
        verify(inventoryService, times(1)).reserveInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
    }
    
    @Test
    void testReserveInventory_Failure() {
        when(inventoryService.reserveInventory(anyString(), any(), anyString()))
                .thenReturn(false);
        
        ResponseEntity<Boolean> response = 
                inventoryController.reserveInventory("PROD-001", BigInteger.valueOf(200), "WH-001");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertFalse(response.getBody());
        verify(inventoryService, times(1)).reserveInventory("PROD-001", BigInteger.valueOf(200), "WH-001");
    }
    
    @Test
    void testGetLowStockItems_Success() {
        List<Inventory> lowStockItems = Arrays.asList(inventory);
        when(inventoryService.getLowStockItems()).thenReturn(lowStockItems);
        
        ResponseEntity<List<Inventory>> response = inventoryController.getLowStockItems();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(inventoryService, times(1)).getLowStockItems();
    }
    
    @Test
    void testAdjustInventory_Success() {
        doNothing().when(inventoryService).adjustInventory(anyString(), anyString(), any());
        
        ResponseEntity<Void> response = 
                inventoryController.adjustInventory("PROD-001", "WH-001", BigInteger.valueOf(50));
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNull(response.getBody());
        verify(inventoryService, times(1)).adjustInventory("PROD-001", "WH-001", BigInteger.valueOf(50));
    }
    
    @Test
    void testReleaseReservedInventory_Success() {
        when(inventoryService.releaseReservedInventory(anyString(), any(), anyString()))
                .thenReturn(true);
        
        ResponseEntity<Boolean> response = 
                inventoryController.releaseReservedInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody());
        verify(inventoryService, times(1)).releaseReservedInventory("PROD-001", BigInteger.valueOf(5), "WH-001");
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = inventoryController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Inventory Service is running", response.getBody());
    }
}

