package com.retailx.repository;

import com.retailx.domain.Merchant;
import com.retailx.domain.enums.OnboardingStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Merchant entity.
 */
@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Long> {
    
    Optional<Merchant> findByUserId(Long userId);
    
    List<Merchant> findByOnboardingStatus(OnboardingStatus status);
    
    @Query("SELECT m FROM Merchant m WHERE m.user.id = :userId AND m.deleted = false")
    Optional<Merchant> findActiveByUserId(@Param("userId") Long userId);
}

