package com.retailx.domain.enums;

/**
 * Audit action types.
 */
public enum AuditAction {
    CREATE,
    UPDATE,
    DELETE,
    READ,
    LOGIN,
    LOGOUT,
    APPROVE,
    REJECT,
    CANCEL,
    SHIP,
    DELIVER,
    REFUND
}

