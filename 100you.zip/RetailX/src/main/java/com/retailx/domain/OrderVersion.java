package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Order version history (up to 10 versions).
 */
@Entity
@Table(name = "order_versions", indexes = {
    @Index(name = "idx_order_version_order", columnList = "order_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderVersion extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "order_id", nullable = false)
    private Order order;
    
    @Column(nullable = false)
    private Integer versionNumber;
    
    @Column(length = 500)
    private String shippingAddress;
    
    @Column(length = 50)
    private String shippingMethod;
    
    @Column(length = 500)
    private String giftNote;
    
    @Column(precision = 19, scale = 2)
    private BigDecimal shipping;
    
    @Column(length = 100)
    private String changedBy; // Actor ID
    
    @Column(length = 500)
    private String changeReason;
}

