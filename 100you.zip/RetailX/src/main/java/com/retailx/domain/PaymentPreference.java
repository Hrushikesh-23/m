package com.retailx.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Customer payment preferences (mocked tokens).
 */
@Entity
@Table(name = "payment_preferences")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentPreference extends BaseEntity {
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private Customer customer;
    
    @Column(nullable = false, length = 50)
    private String token; // Mocked payment token
    
    @Column(nullable = false, length = 50)
    private String type; // CARD, PAYPAL, etc.
    
    @Column
    @Builder.Default
    private Boolean isDefault = false;
}

