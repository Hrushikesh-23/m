package com.retailx.domain;

import com.retailx.encryption.EncryptedString;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Customer entity with PII fields encrypted at rest.
 */
@Entity
@Table(name = "customers", indexes = {
    @Index(name = "idx_customer_user", columnList = "user_id")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Customer extends BaseEntity {
    
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false, unique = true)
    private User user;
    
    @Column(nullable = false, length = 255)
    private String name;
    
    @Column(nullable = false, length = 255)
    @Convert(converter = EncryptedString.class)
    private String email;
    
    @Column(length = 50)
    @Convert(converter = EncryptedString.class)
    private String phone;
    
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Address> addresses = new ArrayList<>();
    
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @Builder.Default
    private List<PaymentPreference> paymentPreferences = new ArrayList<>();
}

