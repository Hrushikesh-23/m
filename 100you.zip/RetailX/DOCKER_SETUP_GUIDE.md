# Docker Setup Guide for RetailX Microservices

## Problem: API Gateway Not Working in Docker

### Issue
When running the project in Docker, you can access services via their individual ports (8081, 8082, etc.) but cannot access them through the API Gateway (port 8080).

### Root Cause
All services are configured to use `localhost:8761` for Eureka service discovery. In Docker:
- `localhost` refers to the container itself, not other containers
- Services cannot find the Eureka server
- API Gateway cannot discover other services for routing

## Solution

### 1. Use Environment Variables for Configuration

All services now support environment variables that override default `localhost` values:

- `EUREKA_SERVER_URL` - Eureka server URL (default: `http://localhost:8761/eureka/`)
- `EUREKA_INSTANCE_HOSTNAME` - Service hostname for Eureka registration
- `SPRING_DATASOURCE_URL` - Database connection URL
- `SPRING_KAFKA_BOOTSTRAP_SERVERS` - Kafka bootstrap servers

### 2. Docker Service Names

In Docker Compose, services communicate using their service names:
- `eureka-server` instead of `localhost:8761`
- `mysql` instead of `localhost:3306`
- `kafka` instead of `localhost:9092`

### 3. Docker Compose Configuration

Use `docker-compose-full.yml` which includes:
- All microservices
- Proper service dependencies
- Environment variables for Docker networking
- Same Docker network for all services

## Setup Instructions

### Step 1: Create Dockerfiles

Each service needs a Dockerfile. Example for a Spring Boot service:

```dockerfile
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### Step 2: Build Docker Images

```bash
# Build all services
docker-compose -f docker-compose-full.yml build
```

### Step 3: Start Services

```bash
# Start all services
docker-compose -f docker-compose-full.yml up -d

# Check logs
docker-compose -f docker-compose-full.yml logs -f
```

### Step 4: Verify Services

1. **Eureka Dashboard**: http://localhost:8761
   - Verify all services are registered

2. **API Gateway**: http://localhost:8080
   - Test: `http://localhost:8080/api/auth/health`
   - Should route to Auth Service

3. **Individual Services**: 
   - Auth: http://localhost:8081/actuator/health
   - Product: http://localhost:8082/actuator/health
   - Order: http://localhost:8083/actuator/health
   - Payment: http://localhost:8084/actuator/health
   - Inventory: http://localhost:8085/actuator/health
   - Notification: http://localhost:8086/actuator/health

## Configuration Changes Made

### API Gateway (`retailx-api-gateway/src/main/resources/application.yml`)
```yaml
eureka:
  client:
    service-url:
      defaultZone: ${EUREKA_SERVER_URL:http://localhost:8761/eureka/}
  instance:
    hostname: ${EUREKA_INSTANCE_HOSTNAME:localhost}
```

### Eureka Server (`retailx-eureka-server/src/main/resources/application.yml`)
```yaml
eureka:
  instance:
    hostname: ${EUREKA_INSTANCE_HOSTNAME:localhost}
    prefer-ip-address: ${EUREKA_PREFER_IP:false}
```

## Environment Variables for Docker

### For Local Development (Default)
- Uses `localhost` for all connections
- Works when running services directly (not in Docker)

### For Docker (Override)
Set these environment variables in `docker-compose-full.yml`:
- `EUREKA_SERVER_URL=http://eureka-server:8761/eureka/`
- `EUREKA_INSTANCE_HOSTNAME=<service-name>`
- `SPRING_DATASOURCE_URL=jdbc:mysql://mysql:3306/...`
- `SPRING_KAFKA_BOOTSTRAP_SERVERS=kafka:9092`

## Troubleshooting

### Issue: Services not registering with Eureka
**Solution**: 
- Check Eureka dashboard: http://localhost:8761
- Verify `EUREKA_SERVER_URL` environment variable
- Ensure services are on the same Docker network

### Issue: API Gateway returns 503 Service Unavailable
**Solution**:
- Verify services are registered in Eureka
- Check service names match in `application.yml` routes
- Ensure services are healthy (check `/actuator/health`)

### Issue: Database connection errors
**Solution**:
- Verify MySQL container is running
- Check `SPRING_DATASOURCE_URL` uses `mysql` instead of `localhost`
- Ensure database name matches service requirements

### Issue: Kafka connection errors
**Solution**:
- Verify Kafka container is running
- Check `SPRING_KAFKA_BOOTSTRAP_SERVERS` uses `kafka:9092`
- Ensure Zookeeper is running (Kafka dependency)

## Quick Start Commands

```bash
# Build and start all services
docker-compose -f docker-compose-full.yml up -d --build

# View logs
docker-compose -f docker-compose-full.yml logs -f

# Stop all services
docker-compose -f docker-compose-full.yml down

# Stop and remove volumes
docker-compose -f docker-compose-full.yml down -v

# Restart a specific service
docker-compose -f docker-compose-full.yml restart api-gateway
```

## Notes

- **Local Development**: Use default `localhost` configuration
- **Docker**: Use `docker-compose-full.yml` with environment variables
- **Service Discovery**: All services must be on the same Docker network
- **Startup Order**: Eureka server must start first, then other services

