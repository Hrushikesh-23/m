# Comprehensive RetailX API Testing Script
# Tests all endpoints with proper role-based access control

$script:testResults = @()
$script:customerToken = $null
$script:merchantToken = $null
$script:opsToken = $null
$script:adminToken = $null
$script:customerId = $null
$script:merchantId = $null
$script:opsId = $null
$script:adminId = $null
$script:productId = $null
$script:productSku = $null
$script:orderId = $null
$script:orderNumber = $null
$script:paymentIntentId = $null
$script:paymentCaptured = $false
$script:returnId = $null
$script:shipmentId = $null

$randomNum = Get-Random

function Test-API {
    param(
        [string]$Name,
        [string]$Method,
        [string]$Url,
        [hashtable]$Headers = @{},
        [string]$Body = $null,
        [int]$ExpectedStatus = 200,
        [bool]$SkipOnFail = $false,
        [string]$Role = "N/A"
    )
    
    $result = @{
        Name = $Name
        Method = $Method
        Url = $Url
        Status = "FAIL"
        StatusCode = 0
        Error = ""
        Response = $null
        Role = $Role
        ExpectedStatus = $ExpectedStatus
    }
    
    try {
        $params = @{
            Uri = $Url
            Method = $Method
            Headers = $Headers
            TimeoutSec = 30
            ErrorAction = "Stop"
        }
        
        if ($Body) {
            $params.Body = $Body
            $params.ContentType = "application/json"
        }
        
        $response = Invoke-RestMethod @params
        $httpStatusCode = 200
        
        $result.Status = "PASS"
        $result.StatusCode = $httpStatusCode
        $result.Response = $response
        
        if ($result.StatusCode -eq $ExpectedStatus) {
            Write-Host "  [OK] $Name (Role: $Role)" -ForegroundColor Green
        } else {
            Write-Host "  [WARN] $Name (Role: $Role) - Expected $ExpectedStatus, got $($result.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        $statusCode = 0
        if ($_.Exception.Response) {
            $statusCode = [int]$_.Exception.Response.StatusCode.value__
            $result.StatusCode = $statusCode
            
            try {
                $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $errorBody = $reader.ReadToEnd()
                $result.Error = $errorBody
            } catch {
                $result.Error = $_.Exception.Message
            }
        } else {
            $result.Error = $_.Exception.Message
        }
        
        $statusColor = if ($statusCode -eq 401 -or $statusCode -eq 403) { "Yellow" } elseif ($statusCode -eq $ExpectedStatus) { "Green" } else { "Red" }
        if ($statusCode -eq $ExpectedStatus) {
            $result.Status = "PASS"
            Write-Host "  [OK] $Name (Role: $Role) - Got expected $ExpectedStatus" -ForegroundColor Green
        } else {
            if ($SkipOnFail) {
                $result.Status = "SKIP"
                Write-Host "  [SKIP] $Name (Role: $Role) - Status: $statusCode" -ForegroundColor Gray
            } else {
                $icon = if ($statusCode -eq 403 -and $ExpectedStatus -eq 200) { "[FORBIDDEN]" } else { "[FAIL]" }
                Write-Host "  $icon $Name (Role: $Role) - Status: $statusCode (Expected: $ExpectedStatus)" -ForegroundColor $statusColor
                if ($result.Error -and $statusCode -ne 403) {
                    Write-Host "    Error: $($result.Error.Substring(0, [Math]::Min(100, $result.Error.Length)))" -ForegroundColor Gray
                }
            }
        }
    }
    
    $script:testResults += $result
    return $result
}

Write-Host "`n=== Comprehensive RetailX API Testing (Role-Based) ===" -ForegroundColor Cyan
Write-Host "Testing all endpoints with proper role-based access control`n" -ForegroundColor Gray

# 1. Health Checks
Write-Host "1. HEALTH CHECKS" -ForegroundColor Cyan
$healthEndpoints = @(
    @{Port=8761; Name="Eureka Health"; Path="/"},
    @{Port=8080; Name="API Gateway Health"; Path="/actuator/health"},
    @{Port=8081; Name="Auth Service Health"; Path="/actuator/health"},
    @{Port=8082; Name="Product Service Health"; Path="/actuator/health"},
    @{Port=8083; Name="Order Service Health"; Path="/actuator/health"},
    @{Port=8085; Name="Payment Service Health"; Path="/actuator/health"},
    @{Port=8084; Name="Inventory Service Health"; Path="/actuator/health"},
    @{Port=8087; Name="Frontend Service Health"; Path="/actuator/health"}
)

foreach ($endpoint in $healthEndpoints) {
    try {
        $response = Invoke-WebRequest -Uri "http://localhost:$($endpoint.Port)$($endpoint.Path)" -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
        Write-Host "  [OK] $($endpoint.Name) (Role: PUBLIC)" -ForegroundColor Green
        $script:testResults += @{
            Name = $endpoint.Name
            Status = "PASS"
            StatusCode = 200
            Role = "PUBLIC"
        }
    } catch {
        if ($endpoint.Name -eq "Frontend Service Health") {
            # Frontend service may return HTML instead of JSON, which is OK
            $statusCode = if ($_.Exception.Response) { $_.Exception.Response.StatusCode.value__ } else { 0 }
            if ($statusCode -eq 200 -or $statusCode -eq 0) {
                # Try to check if service is responding (even with HTML)
                try {
                    $testResponse = Invoke-WebRequest -Uri "http://localhost:8087/" -UseBasicParsing -TimeoutSec 3 -ErrorAction Stop
                    Write-Host "  [OK] $($endpoint.Name) (Role: PUBLIC)" -ForegroundColor Green
                    $script:testResults += @{
                        Name = $endpoint.Name
                        Status = "PASS"
                        StatusCode = 200
                        Role = "PUBLIC"
                    }
                } catch {
                    Write-Host "  [SKIP] $($endpoint.Name) (Role: PUBLIC) - Status: 0" -ForegroundColor Gray
                    $script:testResults += @{
                        Name = $endpoint.Name
                        Status = "SKIP"
                        StatusCode = 0
                        Role = "PUBLIC"
                    }
                }
            } else {
                Write-Host "  [SKIP] $($endpoint.Name) (Role: PUBLIC) - Status: $statusCode" -ForegroundColor Gray
                $script:testResults += @{
                    Name = $endpoint.Name
                    Status = "SKIP"
                    StatusCode = $statusCode
                    Role = "PUBLIC"
                }
            }
        } else {
            Write-Host "  [FAIL] $($endpoint.Name) (Role: PUBLIC) - Status: $($_.Exception.Response.StatusCode.value__)" -ForegroundColor Red
            $script:testResults += @{
                Name = $endpoint.Name
                Status = "FAIL"
                StatusCode = $_.Exception.Response.StatusCode.value__
                Role = "PUBLIC"
            }
        }
    }
}

# 2. Auth Service - Register
Write-Host "`n2. AUTH SERVICE APIs (PUBLIC)" -ForegroundColor Cyan

# Register Customer
$regCustomerBody = @{
    email = "testcustomer$randomNum@example.com"
    password = "Test123@abc"
    name = "Test Customer $randomNum"
    role = "CUSTOMER"
} | ConvertTo-Json

$regCustomerResult = Test-API -Name "Register Customer" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $regCustomerBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regCustomerResult.Status -eq "PASS" -or $regCustomerResult.StatusCode -eq 200) {
    if ($regCustomerResult.Response) {
        $script:customerToken = $regCustomerResult.Response.token
        $script:customerId = $regCustomerResult.Response.userId
        Write-Host "    Customer Token obtained, User ID: $($script:customerId)" -ForegroundColor Gray
    }
}

# Register Merchant
$regMerchantBody = @{
    email = "testmerchant$randomNum@example.com"
    password = "Test123@abc"
    name = "Test Merchant $randomNum"
    role = "MERCHANT"
} | ConvertTo-Json

$regMerchantResult = Test-API -Name "Register Merchant" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $regMerchantBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regMerchantResult.Status -eq "PASS" -or $regMerchantResult.StatusCode -eq 200) {
    if ($regMerchantResult.Response) {
        $script:merchantToken = $regMerchantResult.Response.token
        $script:merchantId = $regMerchantResult.Response.userId
        Write-Host "    Merchant Token obtained, User ID: $($script:merchantId)" -ForegroundColor Gray
    }
}

# Register OPS
$regOpsBody = @{
    email = "testops$randomNum@example.com"
    password = "Test123@abc"
    name = "Test OPS $randomNum"
    role = "OPS"
} | ConvertTo-Json

$regOpsResult = Test-API -Name "Register OPS" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $regOpsBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regOpsResult.Status -eq "PASS" -or $regOpsResult.StatusCode -eq 200) {
    if ($regOpsResult.Response) {
        $script:opsToken = $regOpsResult.Response.token
        $script:opsId = $regOpsResult.Response.userId
        Write-Host "    OPS Token obtained, User ID: $($script:opsId)" -ForegroundColor Gray
    }
}

# Register Admin
$regAdminBody = @{
    email = "testadmin$randomNum@example.com"
    password = "Test123@abc"
    name = "Test Admin $randomNum"
    role = "ADMIN"
} | ConvertTo-Json

$regAdminResult = Test-API -Name "Register Admin" -Method "POST" -Url "http://localhost:8080/api/auth/register" -Body $regAdminBody -ExpectedStatus 201 -Role "PUBLIC"
if ($regAdminResult.Status -eq "PASS" -or $regAdminResult.StatusCode -eq 200) {
    if ($regAdminResult.Response) {
        $script:adminToken = $regAdminResult.Response.token
        $script:adminId = $regAdminResult.Response.userId
        Write-Host "    Admin Token obtained, User ID: $($script:adminId)" -ForegroundColor Gray
    }
}

# 2.1 Login
Write-Host "`n2.1 LOGIN (PUBLIC)" -ForegroundColor Cyan

if (-not $script:customerToken) {
    $loginBody = '{"email":"customer@retailx.com","password":"Test123!@#"}'
    try {
        $loginResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -TimeoutSec 10
        $json = $loginResponse.Content | ConvertFrom-Json
        $script:customerToken = $json.token
        $script:customerId = $json.userId
    } catch {}
}

if ($script:customerToken) {
    Test-API -Name "Login Customer" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body '{"email":"customer@retailx.com","password":"Test123!@#"}' -Role "PUBLIC"
}

if (-not $script:merchantToken) {
    $loginBody = '{"email":"merchant@retailx.com","password":"Test123!@#"}'
    try {
        $loginResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -TimeoutSec 10
        $json = $loginResponse.Content | ConvertFrom-Json
        $script:merchantToken = $json.token
        $script:merchantId = $json.userId
    } catch {}
}

if ($script:merchantToken) {
    Test-API -Name "Login Merchant" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body '{"email":"merchant@retailx.com","password":"Test123!@#"}' -Role "PUBLIC"
}

if (-not $script:opsToken) {
    $loginBody = '{"email":"ops@retailx.com","password":"Test123!@#"}'
    try {
        $loginResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -TimeoutSec 10
        $json = $loginResponse.Content | ConvertFrom-Json
        $script:opsToken = $json.token
        $script:opsId = $json.userId
    } catch {}
}

if ($script:opsToken) {
    Test-API -Name "Login OPS" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body '{"email":"ops@retailx.com","password":"Test123!@#"}' -Role "PUBLIC"
}

if (-not $script:adminToken) {
    $loginBody = '{"email":"admin@retailx.com","password":"Admin@123"}'
    try {
        $loginResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/auth/login" -Method POST -Body $loginBody -ContentType "application/json" -TimeoutSec 10
        $json = $loginResponse.Content | ConvertFrom-Json
        $script:adminToken = $json.token
        $script:adminId = $json.userId
    } catch {}
}

if ($script:adminToken) {
    Test-API -Name "Login Admin" -Method "POST" -Url "http://localhost:8080/api/auth/login" -Body '{"email":"admin@retailx.com","password":"Admin@123"}' -Role "PUBLIC"
}

# 2.2 Additional Auth APIs
Write-Host "`n2.2. AUTH SERVICE - Additional APIs" -ForegroundColor Cyan

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
    }
    Test-API -Name "Update Email (CUSTOMER)" -Method "PUT" -Url "http://localhost:8080/api/auth/email" -Headers $headers -Body '{"newEmail":"updated' + $randomNum + '@example.com"}' -Role "CUSTOMER"
    Test-API -Name "Update Password (CUSTOMER)" -Method "PUT" -Url "http://localhost:8080/api/auth/password" -Headers $headers -Body '{"currentPassword":"Test123!@#","newPassword":"NewPass123@abc"}' -Role "CUSTOMER"
    Test-API -Name "Logout (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/auth/logout" -Headers $headers -Role "CUSTOMER"
}

Test-API -Name "Forgot Password (PUBLIC)" -Method "POST" -Url "http://localhost:8080/api/auth/forgot-password" -Body '{"email":"test@example.com"}' -Role "PUBLIC"
Test-API -Name "Reset Password (PUBLIC - invalid token)" -Method "POST" -Url "http://localhost:8080/api/auth/reset-password" -Body '{"token":"invalid-token-for-testing","newPassword":"NewPass123@abc"}' -ExpectedStatus 400 -Role "PUBLIC"

# 3. Product Service - Public Read
Write-Host "`n3. PRODUCT SERVICE APIs - PUBLIC READ ACCESS" -ForegroundColor Cyan

$listProductsResult = Test-API -Name "List Products (Paginated)" -Method "GET" -Url "http://localhost:8080/api/products?page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
if ($listProductsResult.Status -eq "PASS" -and $listProductsResult.Response -and $listProductsResult.Response.content.Count -gt 0) {
    $script:productId = $listProductsResult.Response.content[0].id
    $script:productSku = $listProductsResult.Response.content[0].sku
    Write-Host "    Using Product ID: $($script:productId), SKU: $($script:productSku)" -ForegroundColor Gray
}

Test-API -Name "List Products (Filtered)" -Method "GET" -Url "http://localhost:8080/api/products?status=ACTIVE&page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
Test-API -Name "List Products (Price Range)" -Method "GET" -Url "http://localhost:8080/api/products?minPrice=10&maxPrice=1000&page=0&size=10" -Role "PUBLIC" -SkipOnFail $true

if ($script:productId) {
    Test-API -Name "Get Product by ID" -Method "GET" -Url "http://localhost:8080/api/products/$($script:productId)" -Role "PUBLIC" -SkipOnFail $true
}

if ($script:productSku) {
    Test-API -Name "Get Product by SKU" -Method "GET" -Url "http://localhost:8080/api/products/sku/$($script:productSku)" -Role "PUBLIC" -SkipOnFail $true
}

Test-API -Name "Search Products (Query)" -Method "GET" -Url "http://localhost:8080/api/products?search=laptop&page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
Test-API -Name "Regex Search Products" -Method "GET" -Url "http://localhost:8080/api/products/search/regex?pattern=/catalog/electronics/.*" -Role "PUBLIC" -SkipOnFail $true

if ($script:merchantId) {
    Test-API -Name "Get Products by Merchant" -Method "GET" -Url "http://localhost:8080/api/products?merchantId=$($script:merchantId)&page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
}

# 4. Product Service - MERCHANT/ADMIN Write
Write-Host "`n4. PRODUCT SERVICE APIs - MERCHANT/ADMIN ACCESS" -ForegroundColor Cyan

if ($script:merchantToken) {
    $createProductBody = @{
        sku = "TEST-PROD-$randomNum"
        name = "Test Product $randomNum"
        description = "Test Description"
        basePrice = 99.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    $newProductSku = "TEST-PROD-$randomNum"
    $createProductResult = Test-API -Name "Create Product (MERCHANT)" -Method "POST" -Url "http://localhost:8080/api/products" -Headers $headers -Body $createProductBody -ExpectedStatus 201 -Role "MERCHANT"
    if ($createProductResult.Status -eq "PASS" -and $createProductResult.Response) {
        $script:productId = $createProductResult.Response.id
        $script:productSku = $newProductSku
        Write-Host "    Product created with ID: $($script:productId), SKU: $newProductSku" -ForegroundColor Gray
        
        # Create inventory for the new product immediately
        if ($script:adminToken) {
            $inventoryHeaders = @{
                "Authorization" = "Bearer $script:adminToken"
                "X-User-Id" = "$script:adminId"
                "X-User-Role" = "ADMIN"
            }
            try {
                $null = Invoke-WebRequest -Uri "http://localhost:8084/api/inventory/adjust?sku=$newProductSku&warehouseId=WH-001&quantity=100" -Method POST -Headers $inventoryHeaders -TimeoutSec 10 -ErrorAction SilentlyContinue
                Write-Host "    Inventory created for $newProductSku" -ForegroundColor Gray
            } catch {
                Write-Host "    Inventory creation for $newProductSku skipped" -ForegroundColor Gray
            }
        }
    }
}

# Test CUSTOMER cannot create product
if ($script:customerToken -and $script:productId) {
    $createProductBody = @{
        sku = "TEST-PROD-CUSTOMER-$randomNum"
        name = "Test Product Customer"
        description = "This should fail"
        basePrice = 99.99
        currency = "USD"
        categoryPath = "/test/category"
        status = "ACTIVE"
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Create Product (CUSTOMER - should fail)" -Method "POST" -Url "http://localhost:8080/api/products" -Headers $headers -Body $createProductBody -ExpectedStatus 403 -Role "CUSTOMER"
}

# Update Product
if ($script:merchantToken -and $script:productId) {
    $updateProductBody = @{
        name = "Updated Test Product"
        description = "Updated description"
        basePrice = 129.99
    } | ConvertTo-Json
    
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Update Product (MERCHANT)" -Method "PUT" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -Body $updateProductBody -Role "MERCHANT"
}

if ($script:customerToken -and $script:productId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Update Product (CUSTOMER - should fail)" -Method "PUT" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -Body '{"name":"Hacked"}' -ExpectedStatus 403 -Role "CUSTOMER"
}

# 5. Review Service
Write-Host "`n5. REVIEW SERVICE APIs" -ForegroundColor Cyan

if ($script:productId) {
    Test-API -Name "Get Reviews by Product (PUBLIC)" -Method "GET" -Url "http://localhost:8080/api/reviews/products/$($script:productId)?page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
    Test-API -Name "Get Reviews by Product (Filtered)" -Method "GET" -Url "http://localhost:8080/api/reviews/products/$($script:productId)?status=APPROVED&page=0&size=10" -Role "PUBLIC" -SkipOnFail $true
}

if ($script:customerToken -and $script:productId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    $reviewBody = @{
        rating = 5
        text = "Great product!"
    } | ConvertTo-Json
    Test-API -Name "Create Review (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/reviews/products/$($script:productId)?orderItemId=1" -Headers $headers -Body $reviewBody -Role "CUSTOMER" -SkipOnFail $true
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    Test-API -Name "Get Pending Reviews (OPS)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -Role "OPS"
}

if ($script:adminToken) {
    $headers = @{
        "Authorization" = "Bearer $script:adminToken"
        "X-User-Id" = "$script:adminId"
        "X-User-Role" = "ADMIN"
    }
    Test-API -Name "Get Pending Reviews (ADMIN)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -Role "ADMIN"
}

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Pending Reviews (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/reviews/pending" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Moderate Review
if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    # Get first pending review ID if available
    try {
        $pendingResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/reviews/pending" -Headers $headers -TimeoutSec 10 -ErrorAction SilentlyContinue
        if ($pendingResponse) {
            $pendingReviews = $pendingResponse.Content | ConvertFrom-Json
            if ($pendingReviews.Count -gt 0) {
                $reviewId = $pendingReviews[0].id
                Test-API -Name "Moderate Review (OPS)" -Method "PUT" -Url "http://localhost:8080/api/reviews/$reviewId/moderate?action=approve" -Headers $headers -Role "OPS" -SkipOnFail $true
            }
        }
    } catch {}
}

# 6. Cart Service
Write-Host "`n6. CART SERVICE APIs - CUSTOMER/ADMIN ACCESS" -ForegroundColor Cyan

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Cart (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/carts" -Headers $headers -Role "CUSTOMER"
    
    # Add to Cart
    $addToCartBody = @{
        sku = if ($script:productSku) { $script:productSku } else { "PROD-001" }
        quantity = 2
    } | ConvertTo-Json
    Test-API -Name "Add to Cart (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/carts/items" -Headers $headers -Body $addToCartBody -Role "CUSTOMER"
    
    # Update Cart Item
    try {
        $cartResponse = Invoke-WebRequest -Uri "http://localhost:8080/api/carts" -Headers $headers -TimeoutSec 10 -ErrorAction SilentlyContinue
        if ($cartResponse) {
            $cart = $cartResponse.Content | ConvertFrom-Json
            if ($cart.items.Count -gt 0) {
                $itemId = $cart.items[0].id
                Test-API -Name "Update Cart Item (CUSTOMER)" -Method "PUT" -Url "http://localhost:8080/api/carts/items/$itemId?quantity=3" -Headers $headers -Role "CUSTOMER"
            }
        }
    } catch {}
}

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Get Cart (MERCHANT - should fail)" -Method "GET" -Url "http://localhost:8080/api/carts" -Headers $headers -ExpectedStatus 403 -Role "MERCHANT"
}

# 7. Checkout Service
Write-Host "`n7. CHECKOUT SERVICE APIs - CUSTOMER/ADMIN ACCESS" -ForegroundColor Cyan

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    
    # Create inventory for the test product (required for checkout)
    $checkoutSku = if ($script:productSku) { $script:productSku } else { "PROD-001" }
    if ($script:adminToken) {
        $inventoryHeaders = @{
            "Authorization" = "Bearer $script:adminToken"
            "X-User-Id" = "$script:adminId"
            "X-User-Role" = "ADMIN"
        }
        try {
            $null = Invoke-WebRequest -Uri "http://localhost:8084/api/inventory/adjust?sku=$checkoutSku&warehouseId=WH-001&quantity=100" -Method POST -Headers $inventoryHeaders -TimeoutSec 10 -ErrorAction SilentlyContinue
            Write-Host "    Inventory created for $checkoutSku" -ForegroundColor Gray
        } catch {
            Write-Host "    Inventory already exists or creation skipped for $checkoutSku" -ForegroundColor Gray
        }
    }
    
    # Ensure cart has items
    $addToCartForCheckoutBody = @{
        sku = $checkoutSku
        quantity = 1
    } | ConvertTo-Json
    Test-API -Name "Add Item for Checkout (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/carts/items" -Headers $headers -Body $addToCartForCheckoutBody -Role "CUSTOMER" -SkipOnFail $true
    
    # Checkout
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $checkoutBody = @{
        shippingAddress = "123 Test St, City, State 12345"
        shippingMethod = "STANDARD"
        giftNote = "Test gift note"
    } | ConvertTo-Json
    $checkoutHeaders = $headers.Clone()
    $checkoutHeaders["Idempotency-Key"] = $idempotencyKey
    $checkoutResult = Test-API -Name "Checkout (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/checkout" -Headers $checkoutHeaders -Body $checkoutBody -Role "CUSTOMER" -SkipOnFail $true
    if ($checkoutResult.Status -eq "PASS" -and $checkoutResult.Response) {
        $script:orderId = $checkoutResult.Response.orderId
        $script:orderNumber = $checkoutResult.Response.orderNumber
        Write-Host "    Order created: ID=$($script:orderId), Number=$($script:orderNumber)" -ForegroundColor Gray
    }
}

# 8. Order Service
Write-Host "`n8. ORDER SERVICE APIs" -ForegroundColor Cyan

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Order by ID (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
    
    if ($script:orderNumber) {
        Test-API -Name "Get Order by Number (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/number/$($script:orderNumber)" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
        Test-API -Name "Get Order Audit Log (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/$($script:orderId)/audit" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
    }
}

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Customer Orders (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/customer?page=0&size=20" -Headers $headers -Role "CUSTOMER"
    Test-API -Name "Get Order History (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/orders/history?page=0&size=20" -Headers $headers -Role "CUSTOMER"
}

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Get Merchant Orders (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    Test-API -Name "Get Merchant Orders (OPS)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -Role "OPS"
}

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Merchant Orders (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/orders/merchant?page=0&size=20" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Update Order Status
if ($script:merchantToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Update Order Status (MERCHANT)" -Method "PUT" -Url "http://localhost:8080/api/orders/$($script:orderId)/status?status=FULFILLING" -Headers $headers -Role "MERCHANT" -SkipOnFail $true
}

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Update Order Status (CUSTOMER - should fail)" -Method "PUT" -Url "http://localhost:8080/api/orders/$($script:orderId)/status?status=PAID" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# 9. Shipment Service
Write-Host "`n9. SHIPMENT SERVICE APIs" -ForegroundColor Cyan

if ($script:merchantToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    
    Test-API -Name "Update Order to PAID (for Shipment)" -Method "PUT" -Url "http://localhost:8080/api/orders/$($script:orderId)/status?status=PAID" -Headers $headers -Role "MERCHANT" -SkipOnFail $true
    
    Start-Sleep -Milliseconds 500
    
    $shipmentBody = @{
        carrier = "UPS"
        trackingNumber = "UPS$randomNum"
        skus = @(if ($script:productSku) { $script:productSku } else { "PROD-001" })
    } | ConvertTo-Json
    $createShipmentResult = Test-API -Name "Create Shipment (MERCHANT)" -Method "POST" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Body $shipmentBody -Role "MERCHANT" -SkipOnFail $true
    if ($createShipmentResult.Status -eq "PASS" -and $createShipmentResult.Response) {
        $script:shipmentId = $createShipmentResult.Response.id
    }
}

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    $shipmentBody = @{
        carrier = "UPS"
        trackingNumber = "UPS-INVALID"
        skus = @("TEST-SKU")
    } | ConvertTo-Json
    Test-API -Name "Create Shipment (CUSTOMER - should fail)" -Method "POST" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Body $shipmentBody -ExpectedStatus 403 -Role "CUSTOMER"
}

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Shipments by Order (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/shipments/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
}

# 10. Return Service
Write-Host "`n10. RETURN SERVICE APIs" -ForegroundColor Cyan

if ($script:merchantToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Update Order to DELIVERED (for Return)" -Method "PUT" -Url "http://localhost:8080/api/orders/$($script:orderId)/status?status=DELIVERED" -Headers $headers -Role "MERCHANT" -SkipOnFail $true
}

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    $returnBody = @{
        reason = "DEFECTIVE"
        items = @(
            @{
                sku = if ($script:productSku) { $script:productSku } else { "PROD-001" }
                quantity = 1
            }
        )
    } | ConvertTo-Json
    $returnResult = Test-API -Name "Request Return (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/returns/orders/$($script:orderId)" -Headers $headers -Body $returnBody -Role "CUSTOMER" -SkipOnFail $true
    if ($returnResult.Status -eq "PASS" -and $returnResult.Response) {
        $script:returnId = $returnResult.Response.id
    }
}

if ($script:customerToken -and $script:orderId) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Returns by Order (CUSTOMER)" -Method "GET" -Url "http://localhost:8080/api/returns/orders/$($script:orderId)" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
}

# 11. Payment Service
Write-Host "`n11. PAYMENT SERVICE APIs" -ForegroundColor Cyan

if ($script:customerToken -and $script:orderId) {
    $headers = @{ "Authorization" = "Bearer $script:customerToken" }
    
    $idempotencyKey = [System.Guid]::NewGuid().ToString()
    $createIntentHeaders = $headers.Clone()
    $createIntentHeaders["Idempotency-Key"] = $idempotencyKey
    $createIntentResult = Test-API -Name "Create Payment Intent (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/payments/intents?orderId=$($script:orderId)&amount=199.98&currency=USD" -Headers $createIntentHeaders -Role "CUSTOMER" -SkipOnFail $true
    if ($createIntentResult.Status -eq "PASS" -and $createIntentResult.Response) {
        $script:paymentIntentId = $createIntentResult.Response.id
    }
}

# 12. Inventory Service
Write-Host "`n12. INVENTORY SERVICE APIs" -ForegroundColor Cyan

if ($script:customerToken) {
    # Create fresh inventory for reservation test
    $reserveSku = "RESERVE-TEST-$randomNum"
    if ($script:adminToken) {
        $inventoryHeaders = @{
            "Authorization" = "Bearer $script:adminToken"
            "X-User-Id" = "$script:adminId"
            "X-User-Role" = "ADMIN"
        }
        try {
            $null = Invoke-WebRequest -Uri "http://localhost:8084/api/inventory/adjust?sku=$reserveSku&warehouseId=WH-001&quantity=100" -Method POST -Headers $inventoryHeaders -TimeoutSec 10 -ErrorAction SilentlyContinue
            Write-Host "    Inventory created for $reserveSku" -ForegroundColor Gray
        } catch {
            Write-Host "    Inventory creation skipped for $reserveSku" -ForegroundColor Gray
        }
    }
    
    $headers = @{ 
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Reserve Inventory (CUSTOMER)" -Method "POST" -Url "http://localhost:8080/api/inventory/reserve?sku=$reserveSku&quantity=5&warehouseId=WH-001" -Headers $headers -Role "CUSTOMER" -SkipOnFail $true
}

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Get Low Stock Items (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    Test-API -Name "Get Low Stock Items (OPS)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -Role "OPS"
}

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    Test-API -Name "Get Low Stock Items (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/inventory/low-stock" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# Adjust Inventory
$adjustSku = "TEST-ADJUST-$randomNum"
if ($script:opsToken) {
    $headers = @{ 
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    Test-API -Name "Adjust Inventory (OPS)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=$adjustSku&warehouseId=WH-001&quantity=10" -Headers $headers -Role "OPS" -SkipOnFail $true
}

if ($script:adminToken) {
    $headers = @{ 
        "Authorization" = "Bearer $script:adminToken"
        "X-User-Id" = "$script:adminId"
        "X-User-Role" = "ADMIN"
    }
    Test-API -Name "Adjust Inventory (ADMIN)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=$adjustSku&warehouseId=WH-001&quantity=10" -Headers $headers -Role "ADMIN" -SkipOnFail $true
}

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Adjust Inventory (MERCHANT - should fail)" -Method "POST" -Url "http://localhost:8080/api/inventory/adjust?sku=$adjustSku&warehouseId=WH-001&quantity=10" -Headers $headers -ExpectedStatus 403 -Role "MERCHANT"
}

# 13. Reporting Service
Write-Host "`n13. REPORTING SERVICE APIs - MERCHANT/ADMIN/OPS ACCESS" -ForegroundColor Cyan

if ($script:merchantToken) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    $startDate = (Get-Date).AddMonths(-1).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -Role "MERCHANT"
    Test-API -Name "Order Status Report (MERCHANT)" -Method "GET" -Url "http://localhost:8080/api/reports/order-status" -Headers $headers -Role "MERCHANT"
}

if ($script:opsToken) {
    $headers = @{
        "Authorization" = "Bearer $script:opsToken"
        "X-User-Id" = "$script:opsId"
        "X-User-Role" = "OPS"
    }
    $startDate = (Get-Date).AddMonths(-1).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (OPS)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -Role "OPS"
}

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    $startDate = (Get-Date).AddMonths(-1).ToString("yyyy-MM-ddTHH:mm:ss")
    $endDate = (Get-Date).ToString("yyyy-MM-ddTHH:mm:ss")
    Test-API -Name "Sales Report (CUSTOMER - should fail)" -Method "GET" -Url "http://localhost:8080/api/reports/sales?startDate=$startDate&endDate=$endDate" -Headers $headers -ExpectedStatus 403 -Role "CUSTOMER"
}

# 14. Notification Service
Write-Host "`n14. NOTIFICATION SERVICE APIs" -ForegroundColor Cyan

Test-API -Name "Notification Service Health" -Method "GET" -Url "http://localhost:8086/api/notifications/health" -Role "PUBLIC"
Test-API -Name "Notification Service Info" -Method "GET" -Url "http://localhost:8086/api/notifications/info" -Role "PUBLIC"

if ($script:customerToken) {
    $headers = @{
        "Authorization" = "Bearer $script:customerToken"
        "X-User-Id" = "$script:customerId"
        "X-User-Role" = "CUSTOMER"
    }
    $notificationBody = @{
        recipientEmail = "test@example.com"
        subject = "Test Notification"
        message = "This is a test notification"
    } | ConvertTo-Json
    Test-API -Name "Send Notification (CUSTOMER)" -Method "POST" -Url "http://localhost:8086/api/notifications/send" -Headers $headers -Body $notificationBody -ExpectedStatus 201 -Role "CUSTOMER" -SkipOnFail $true
}

# 15. Cleanup
Write-Host "`n15. CLEANUP APIs" -ForegroundColor Cyan

if ($script:merchantToken -and $script:productId) {
    $headers = @{
        "Authorization" = "Bearer $script:merchantToken"
        "X-User-Id" = "$script:merchantId"
        "X-User-Role" = "MERCHANT"
    }
    Test-API -Name "Delete Product (MERCHANT)" -Method "DELETE" -Url "http://localhost:8080/api/products/$($script:productId)" -Headers $headers -ExpectedStatus 204 -Role "MERCHANT"
}

# 16. API Documentation
Write-Host "`n16. API DOCUMENTATION (PUBLIC)" -ForegroundColor Cyan
Test-API -Name "Product Service Swagger" -Method "GET" -Url "http://localhost:8082/v3/api-docs" -Role "PUBLIC" -SkipOnFail $true
Test-API -Name "Order Service Swagger" -Method "GET" -Url "http://localhost:8083/v3/api-docs" -Role "PUBLIC" -SkipOnFail $true
Test-API -Name "Auth Service Swagger" -Method "GET" -Url "http://localhost:8081/v3/api-docs" -Role "PUBLIC" -SkipOnFail $true

# Summary
Write-Host "`n=== TEST SUMMARY ===" -ForegroundColor Magenta
$passed = ($script:testResults | Where-Object { $_.Status -eq "PASS" }).Count
$skipped = ($script:testResults | Where-Object { $_.Status -eq "SKIP" }).Count
$failed = ($script:testResults | Where-Object { $_.Status -eq "FAIL" }).Count
$total = $script:testResults.Count
$effectiveTotal = $total - $skipped

Write-Host "Total Tests: $total" -ForegroundColor Cyan
Write-Host "Passed: $passed" -ForegroundColor Green
Write-Host "Skipped: $skipped" -ForegroundColor Gray
Write-Host "Failed: $failed" -ForegroundColor Red
Write-Host "Success Rate: $([Math]::Round(($passed / [Math]::Max(1, $effectiveTotal)) * 100, 2))% (excluding skipped)" -ForegroundColor $(if ($failed -eq 0) { "Green" } else { "Yellow" })

# Role-based summary
Write-Host "`nRole-Based Test Summary:" -ForegroundColor Cyan
$roleGroups = $script:testResults | Group-Object -Property Role | Where-Object { $_.Name -ne "N/A" }
foreach ($roleGroup in $roleGroups) {
    $role = $roleGroup.Name
    $roleTests = $roleGroup.Group
    $rolePassed = ($roleTests | Where-Object { $_.Status -eq "PASS" }).Count
    $roleTotal = $roleTests.Count
    Write-Host "  $role : $rolePassed/$roleTotal passed" -ForegroundColor $(if ($rolePassed -eq $roleTotal) { "Green" } else { "Yellow" })
}

if ($failed -gt 0) {
    Write-Host "`nFailed Tests:" -ForegroundColor Yellow
    $script:testResults | Where-Object { $_.Status -eq "FAIL" } | ForEach-Object {
        Write-Host "  - [$($_.Role)] $($_.Name): Status $($_.StatusCode) (Expected: $($_.ExpectedStatus)) - $($_.Url)" -ForegroundColor Red
    }
}

# Export results
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$resultsFile = "api-test-results-$timestamp.json"
$script:testResults | ConvertTo-Json -Depth 5 | Out-File $resultsFile
Write-Host "`nResults exported to: $resultsFile" -ForegroundColor Gray
