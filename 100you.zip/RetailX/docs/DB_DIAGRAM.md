# RetailX Database Diagram

## Overview

RetailX uses a **database per service** pattern. Each microservice has its own database schema. This document provides visual database diagrams for all microservices.

## Database Schemas

1. **retailx_auth** - Authentication and User Management
2. **retailx_product** - Product Catalog and Reviews
3. **retailx_order** - Orders, Carts, Shipments, and Returns
4. **retailx_payment** - Payment Transactions
5. **retailx_inventory** - Inventory Management
6. **zipkin** - Distributed Tracing (Infrastructure)

---

## 1. Auth Service Database (retailx_auth)

### Entity Relationship Diagram

```mermaid
erDiagram
    users ||--o{ user_roles : "has"
    users ||--o{ password_reset_tokens : "has"
    
    users {
        bigint id PK
        varchar email UK "UNIQUE"
        varchar password_hash
        boolean active
        datetime last_login_at
        datetime password_changed_at
        int failed_login_attempts
        datetime locked_until
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    user_roles {
        bigint user_id FK
        varchar role "CUSTOMER, MERCHANT, OPS, ADMIN"
    }
    
    password_reset_tokens {
        bigint id PK
        bigint user_id FK
        varchar token UK "UNIQUE"
        datetime expires_at "1 hour expiry"
        boolean used
        datetime used_at
        datetime created_on
        datetime updated_on
    }
```

### Table Details

**users**
- Primary Key: `id`
- Unique Index: `email`
- Stores all user accounts (customers, merchants, ops, admins)
- Supports account lockout after 5 failed login attempts

**user_roles**
- Foreign Key: `user_id` → `users.id`
- Stores user role mappings (one user can have multiple roles)
- Roles: CUSTOMER, MERCHANT, OPS, ADMIN

**password_reset_tokens**
- Primary Key: `id`
- Foreign Key: `user_id` → `users.id`
- Unique Index: `token`
- Expires after 1 hour
- Single-use tokens

---

## 2. Product Service Database (retailx_product)

### Entity Relationship Diagram

```mermaid
erDiagram
    products ||--o{ variants : "has"
    products ||--o{ reviews : "has"
    products ||--o{ product_media : "has"
    
    products {
        bigint id PK
        varchar sku UK "UNIQUE"
        varchar name
        text description
        decimal base_price
        varchar currency
        varchar category_path
        varchar catalog_path "for regex search"
        varchar status "DRAFT, ACTIVE, DISCONTINUED"
        json attributes
        bigint merchant_id "reference to auth service"
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    variants {
        bigint id PK
        varchar variant_sku UK "UNIQUE"
        bigint product_id FK
        json options "size, color, etc."
        decimal price_override
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    product_media {
        bigint product_id FK
        varchar url
    }
    
    reviews {
        bigint id PK
        bigint product_id FK
        bigint customer_id "reference to auth service"
        bigint order_item_id "reference to order service"
        int rating "1-5"
        text text
        varchar status "PENDING, APPROVED, HIDDEN"
        boolean moderated
        datetime created_on
        datetime updated_on
        boolean deleted
    }
```

### Table Details

**products**
- Primary Key: `id`
- Unique Index: `sku`
- Indexes: `category_path`, `catalog_path`
- Stores product catalog information
- References `merchant_id` from auth service

**variants**
- Primary Key: `id`
- Foreign Key: `product_id` → `products.id`
- Unique Index: `variant_sku`
- Stores product variants (size, color, etc.)

**product_media**
- Foreign Key: `product_id` → `products.id`
- Stores product images/media URLs

**reviews**
- Primary Key: `id`
- Foreign Key: `product_id` → `products.id`
- Indexes: `product_id`, `customer_id`, `status`
- Requires valid order item and is moderated before being visible
- Can only be created for DELIVERED orders

---

## 3. Order Service Database (retailx_order)

### Entity Relationship Diagram

```mermaid
erDiagram
    orders ||--o{ order_items : "has"
    orders ||--o{ order_versions : "has"
    orders ||--o{ shipments : "has"
    orders ||--o{ returns : "has"
    orders ||--o{ audit_logs : "has"
    carts ||--o{ cart_items : "has"
    shipments ||--o{ shipment_items : "has"
    returns ||--o{ return_items : "has"
    
    orders {
        bigint id PK
        varchar order_number UK "UNIQUE"
        bigint customer_id "reference to auth service"
        bigint merchant_id "reference to auth service"
        varchar status "PENDING, PAID, FULFILLING, SHIPPED, DELIVERED, CANCELLED, RETURN_REQUESTED, PARTIALLY_RETURNED, RETURNED, REJECTED"
        decimal subtotal
        decimal tax
        decimal shipping
        decimal discount
        decimal total
        json shipping_address "encrypted"
        varchar shipping_method
        text gift_note
        int version "optimistic locking"
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    order_items {
        bigint id PK
        bigint order_id FK
        varchar sku
        varchar product_name
        int quantity
        decimal unit_price
        decimal line_total
        int returned_quantity "cumulative"
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    order_versions {
        bigint id PK
        bigint order_id FK
        int version_number
        json shipping_address
        varchar shipping_method
        text gift_note
        decimal shipping
        bigint changed_by
        varchar change_reason
        datetime created_on
        datetime updated_on
    }
    
    carts {
        bigint id PK
        bigint customer_id "reference to auth service"
        decimal subtotal
        decimal tax
        decimal shipping
        decimal discount
        decimal total
        datetime expires_at
        boolean abandoned
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    cart_items {
        bigint id PK
        bigint cart_id FK
        varchar sku
        int quantity
        decimal unit_price
        decimal line_total
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    shipments {
        bigint id PK
        bigint order_id "reference to orders"
        varchar shipment_number UK "UNIQUE"
        varchar carrier
        varchar tracking_number
        datetime shipped_at
        datetime delivered_at
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    shipment_items {
        bigint id PK
        bigint shipment_id FK
        varchar sku
        int quantity
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    returns {
        bigint id PK
        bigint order_id "reference to orders"
        varchar rma_number UK "UNIQUE"
        varchar status "REQUESTED, APPROVED, REJECTED, COMPLETED"
        text reason
        decimal refund_amount
        boolean restocked
        datetime requested_at
        datetime approved_at
        datetime completed_at
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    return_items {
        bigint id PK
        bigint return_id FK
        varchar sku
        int quantity
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    idempotency_keys {
        bigint id PK
        varchar key_value UK "UNIQUE"
        varchar request_hash
        text response_summary
        datetime expires_at "24 hours"
        boolean used
        datetime created_on
        datetime updated_on
    }
    
    audit_logs {
        bigint id PK
        bigint order_id FK
        varchar action "STATUS_CHANGED, CANCELLED, etc."
        bigint actor_id
        varchar old_value
        varchar new_value
        text reason
        datetime created_on
        datetime updated_on
    }
```

### Table Details

**orders**
- Primary Key: `id`
- Unique Index: `order_number`
- Indexes: `customer_id`, `merchant_id`, `status`
- Supports optimistic locking via `version` field
- Status transitions: PENDING → PAID → FULFILLING → SHIPPED → DELIVERED
- Can be CANCELLED, RETURN_REQUESTED, PARTIALLY_RETURNED, RETURNED, REJECTED

**order_items**
- Primary Key: `id`
- Foreign Key: `order_id` → `orders.id`
- Tracks `returned_quantity` cumulatively for partial returns

**order_versions**
- Primary Key: `id`
- Foreign Key: `order_id` → `orders.id`
- Limited to 10 versions per order
- Tracks order modification history

**carts**
- Primary Key: `id`
- Index: `customer_id`
- Stores shopping cart information
- Has expiration time

**cart_items**
- Primary Key: `id`
- Foreign Key: `cart_id` → `carts.id`
- Stores cart line items

**shipments**
- Primary Key: `id`
- Unique Index: `shipment_number`
- Indexes: `order_id`, `tracking_number`
- Can be created for orders in PAID or FULFILLING status

**shipment_items**
- Primary Key: `id`
- Foreign Key: `shipment_id` → `shipments.id`
- Stores shipment line items

**returns**
- Primary Key: `id`
- Unique Index: `rma_number`
- Index: `order_id`
- Can only be requested for DELIVERED orders within 30 days
- Supports partial returns

**return_items**
- Primary Key: `id`
- Foreign Key: `return_id` → `returns.id`
- Stores return line items

**idempotency_keys**
- Primary Key: `id`
- Unique Index: `key_value`
- Expires after 24 hours
- Prevents duplicate operations

**audit_logs**
- Primary Key: `id`
- Foreign Key: `order_id` → `orders.id`
- Tracks all order operations for audit trail

---

## 4. Payment Service Database (retailx_payment)

### Entity Relationship Diagram

```mermaid
erDiagram
    payment_intents {
        bigint id PK
        bigint order_id UK "UNIQUE, reference to order service"
        varchar payment_intent_id
        decimal amount
        varchar currency
        varchar status "PENDING, AUTHORIZED, CAPTURED, FAILED, REFUNDED"
        varchar correlation_id "for idempotency"
        varchar payment_method
        varchar error_code
        text error_message
        decimal refunded_amount "cumulative for partial refunds"
        datetime created_on
        datetime updated_on
        boolean deleted
    }
```

### Table Details

**payment_intents**
- Primary Key: `id`
- Unique Index: `order_id` (one-to-one with orders)
- Index: `correlation_id` (for idempotency)
- Tracks payment transactions
- Status flow: PENDING → AUTHORIZED → CAPTURED
- Can be FAILED or REFUNDED
- Tracks cumulative `refunded_amount` for partial refunds

---

## 5. Inventory Service Database (retailx_inventory)

### Entity Relationship Diagram

```mermaid
erDiagram
    inventory ||--o{ inventory_holds : "has"
    
    inventory {
        bigint id PK
        varchar sku "product SKU or variant SKU"
        varchar warehouse_id
        int on_hand
        int reserved
        int available "computed: on_hand - reserved"
        int version "optimistic locking"
        datetime created_on
        datetime updated_on
        boolean deleted
    }
    
    inventory_holds {
        bigint id PK
        varchar sku
        int quantity
        varchar warehouse_id
        bigint cart_id "for cart holds"
        bigint order_id "for order holds"
        datetime expires_at
        boolean released
        datetime created_on
        datetime updated_on
        boolean deleted
    }
```

### Table Details

**inventory**
- Primary Key: `id`
- Unique Index: `(sku, warehouse_id)`
- Index: `sku`
- Uses optimistic locking via `version` field
- `available` is computed as `on_hand - reserved`

**inventory_holds**
- Primary Key: `id`
- Indexes: `cart_id`, `order_id`, `expires_at`
- Stores inventory reservations
- Expires and is automatically released
- Can be for cart holds or order holds

---

## 6. Zipkin Database (zipkin)

### Entity Relationship Diagram

```mermaid
erDiagram
    zipkin_spans {
        bigint trace_id_high PK
        bigint trace_id PK
        bigint id PK
        varchar name
        bigint parent_id
        bigint debug
        bigint start_ts
        bigint duration
        bigint trace_id_high_1
        bigint trace_id_1
    }
    
    zipkin_annotations {
        bigint trace_id_high PK
        bigint trace_id PK
        bigint span_id PK
        bigint a_key PK
        blob a_value
        bigint a_timestamp
        bigint endpoint_ipv4
        smallint endpoint_port
        varchar endpoint_service_name
    }
    
    zipkin_dependencies {
        date day PK
        bigint parent PK
        bigint child PK
        bigint call_count
        bigint error_count
    }
```

### Table Details

**zipkin_spans**
- Stores distributed tracing span data
- Auto-created by Zipkin on first startup

**zipkin_annotations**
- Stores span annotations
- Auto-created by Zipkin on first startup

**zipkin_dependencies**
- Stores service dependency data
- Auto-created by Zipkin on first startup

---

## Cross-Service Relationships

### Visual Flow Diagram

```mermaid
graph TD
    A[Auth Service<br/>users] -->|customer_id| B[Order Service<br/>orders]
    A -->|merchant_id| B
    A -->|merchant_id| C[Product Service<br/>products]
    B -->|order_id| D[Payment Service<br/>payment_intents]
    B -->|order_id| E[Order Service<br/>shipments]
    B -->|order_id| F[Order Service<br/>returns]
    C -->|sku| G[Inventory Service<br/>inventory]
    B -->|sku| G
    G -->|reserve| H[Inventory Service<br/>inventory_holds]
    B -->|order_id| H
    I[Cart Service<br/>carts] -->|cart_id| H
    B -->|order_item_id| J[Product Service<br/>reviews]
    A -->|customer_id| J
    
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style C fill:#e8f5e9
    style D fill:#fce4ec
    style E fill:#fff4e1
    style F fill:#fff4e1
    style G fill:#f3e5f5
    style H fill:#f3e5f5
    style I fill:#fff4e1
    style J fill:#e8f5e9
```

### Service Dependencies

1. **Auth Service** → **Order Service**: Provides `customer_id` and `merchant_id`
2. **Auth Service** → **Product Service**: Provides `merchant_id`
3. **Order Service** → **Payment Service**: One-to-one via `order_id`
4. **Order Service** → **Inventory Service**: Uses `sku` for inventory operations
5. **Product Service** → **Inventory Service**: Uses `sku` for inventory tracking
6. **Order Service** → **Product Service**: Provides `order_item_id` for reviews

---

## Key Constraints and Rules

### Unique Constraints
- `users.email` - Unique email per user
- `products.sku` - Unique SKU per product
- `variants.variant_sku` - Unique variant SKU
- `orders.order_number` - Unique order number
- `shipments.shipment_number` - Unique shipment number
- `returns.rma_number` - Unique RMA number
- `payment_intents.order_id` - One payment per order
- `inventory(sku, warehouse_id)` - Unique inventory per SKU/warehouse
- `idempotency_keys.key_value` - Unique idempotency key
- `password_reset_tokens.token` - Unique reset token

### Foreign Key Relationships
- All foreign keys are within the same database (same service)
- Cross-service references use IDs only (no foreign keys due to microservices architecture)

### Business Rules
- Order versions limited to 10 per order
- Inventory holds expire and are automatically released
- Returns can only be requested for DELIVERED orders within 30 days
- Reviews require valid order item and are moderated
- Password reset tokens expire after 1 hour
- Idempotency keys expire after 24 hours
- Account lockout after 5 failed login attempts (30 minutes)
- Partial returns tracked via `returned_quantity` in `order_items`
- Refunds tracked via `refunded_amount` in `payment_intents`

---

## Indexes Summary

### Critical Indexes for Performance

**Auth Service:**
- `users.email` (UNIQUE)

**Product Service:**
- `products.sku` (UNIQUE)
- `products.category_path`
- `products.catalog_path`
- `reviews.product_id`
- `reviews.customer_id`
- `reviews.status`

**Order Service:**
- `orders.order_number` (UNIQUE)
- `orders.customer_id`
- `orders.merchant_id`
- `orders.status`
- `order_items.order_id`
- `shipments.shipment_number` (UNIQUE)
- `shipments.order_id`
- `shipments.tracking_number`
- `returns.rma_number` (UNIQUE)
- `returns.order_id`
- `idempotency_keys.key_value` (UNIQUE)
- `audit_logs.order_id`

**Payment Service:**
- `payment_intents.order_id` (UNIQUE)
- `payment_intents.correlation_id`

**Inventory Service:**
- `inventory(sku, warehouse_id)` (UNIQUE)
- `inventory.sku`
- `inventory_holds.cart_id`
- `inventory_holds.order_id`
- `inventory_holds.expires_at`

---

## Data Types and Standards

### Common Fields
All tables include:
- `id` (BIGINT, Primary Key, Auto-increment)
- `created_on` (DATETIME)
- `updated_on` (DATETIME)
- `deleted` (BOOLEAN, for soft delete)

### Encryption
- PII fields (email, addresses) are encrypted at rest using AES GCM
- `shipping_address` in orders is JSON and encrypted

### Status Enums
- **Order Status**: PENDING, PAID, FULFILLING, SHIPPED, DELIVERED, CANCELLED, RETURN_REQUESTED, PARTIALLY_RETURNED, RETURNED, REJECTED
- **Payment Status**: PENDING, AUTHORIZED, CAPTURED, FAILED, REFUNDED
- **Return Status**: REQUESTED, APPROVED, REJECTED, COMPLETED
- **Review Status**: PENDING, APPROVED, HIDDEN
- **Product Status**: DRAFT, ACTIVE, DISCONTINUED

---

## Notes

- All tables support soft delete via `deleted` field
- Cross-service references use IDs only (no foreign keys)
- Optimistic locking used in `orders` and `inventory` tables
- All timestamps use `DATETIME` type
- Monetary values use `DECIMAL(19,2)` for precision
- JSON fields used for flexible attribute storage
- Indexes optimized for common query patterns

