# RetailX - System Flow Diagrams

## 1. User Registration & Authentication Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/auth/register
     ▼
┌─────────────────┐
│  API Gateway    │
│  (Port 8080)    │
└────┬────────────┘
     │
     │ 2. Forward to Auth Service
     ▼
┌─────────────────┐
│  Auth Service   │
│  (Port 8081)    │
└────┬────────────┘
     │
     │ 3. Hash password (BCrypt)
     │ 4. Save user to DB
     │ 5. Return user info (NO token)
     │
     ▼
┌─────────────┐
│   MySQL    │
│ retailx_auth│
└─────────────┘
     │
     │ 6. Client must login to get token
     │ 7. POST /api/auth/login
     │ 8. Validate credentials
     │ 9. Generate JWT token
     │
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 2. Product Browsing Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. GET /api/products?category=/electronics
     ▼
┌─────────────────┐
│  API Gateway    │
│  (JWT Validate) │
└────┬────────────┘
     │
     │ 2. Extract roles, add headers
     ▼
┌─────────────────┐
│ Product Service │
│  (Port 8082)    │
└────┬────────────┘
     │
     │ 3. Query products from cache/DB
     │ 4. Apply filters (category, price, search)
     │ 5. Paginate results
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_product│
└─────────────┘
     │
     │ 6. Return paginated products
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 3. Shopping Cart & Checkout Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/carts/items
     │    {sku, quantity}
     ▼
┌─────────────────┐
│  API Gateway    │
└────┬────────────┘
     │
     ▼
┌─────────────────┐
│  Order Service  │
│  (Port 8083)    │
└────┬────────────┘
     │
     │ 2. Validate product (Feign → Product Service)
     │ 3. Check inventory (Feign → Inventory Service)
     │ 4. Add to cart
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_order│
└─────────────┘
     │
     │ 5. POST /api/checkout
     │    (with Idempotency-Key)
     │
     ▼
┌─────────────────┐
│ CheckoutService │
└────┬────────────┘
     │
     │ 6. Reserve inventory
     │ 7. Create order
     │ 8. Clear cart
     │ 9. Publish order.created event (Kafka)
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
     │
     │ 10. Return order details
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 4. Payment Processing Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/payments/intents
     │    {orderId, amount, currency}
     │    (amount must match order total)
     ▼
┌─────────────────┐
│  API Gateway    │
└────┬────────────┘
     │
     ▼
┌─────────────────┐
│ Payment Service │
│  (Port 8084)    │
└────┬────────────┘
     │
     │ 2. Validate order exists
     │ 3. Validate amount matches order total
     │ 4. Create payment intent (status: PENDING)
     │ 5. POST /api/payments/{id}/authorize
     │    (with Circuit Breaker)
     │
     ▼
┌─────────────────┐
│ Mock Provider   │
│ (Resilience4j)  │
└────┬────────────┘
     │
     │ 6. Authorize payment (status: AUTHORIZED)
     │ 7. POST /api/payments/{id}/capture
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_payment│
└─────────────┘
     │
     │ 8. Update payment status to CAPTURED
     │ 9. Publish payment.captured event
     │
     ▼
┌─────────────┐
│   Kafka    │
└────┬───────┘
     │
     │ 10. Order Service consumes event
     │ 11. Update order status to PAID
     │
     ▼
┌─────────────────┐
│  Order Service  │
└─────────────────┘

Alternative: Payment Failure Flow
     │
     │ POST /api/payments/{id}/fail
     │
     ▼
┌─────────────────┐
│ Payment Service │
└────┬────────────┘
     │
     │ Update status to FAILED
     │ Publish payment.failed event
     │
     ▼
┌─────────────┐
│   Kafka    │
└────┬───────┘
     │
     │ Order Service consumes event
     │ Cancel order automatically
     │
     ▼
┌─────────────────┐
│  Order Service  │
└─────────────────┘
```

## 5. Shipping & Fulfillment Flow

```
┌─────────┐
│  OPS    │
└────┬────┘
     │
     │ 1. POST /api/shipments/orders/{orderId}
     │    {carrier, trackingNumber}
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 2. Create shipment
     │ 3. Update order status to SHIPPED
     │ 4. Publish shipment.created event
     │
     ▼
┌─────────────┐
│   Kafka    │
└────┬───────┘
     │
     │ 5. Notification Service consumes event
     │ 6. Send shipping notification
     │
     ▼
┌─────────────────┐
│Notification Svc │
│  (Port 8086)    │
└─────────────────┘
     │
     │ 7. PUT /api/shipments/{id}/delivered
     │
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 8. Mark shipment as delivered
     │ 9. Update order status to DELIVERED
     │ 10. Publish order.delivered event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
```

## 6. Return & Refund Flow

```
┌─────────┐
│Customer │
└────┬────┘
     │
     │ 1. POST /api/returns/orders/{orderId}
     │    {reason, items: [{sku, quantity}]}
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 2. Validate return window (30 days)
     │ 3. Validate return quantities
     │ 4. Create return request (status: REQUESTED)
     │ 5. Publish return.requested event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
     │
     │ 6. PUT /api/returns/{id}/approve
     │    (OPS/ADMIN/MERCHANT)
     │
     ▼
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ 7. Restock inventory (Feign → Inventory Service)
     │ 8. Process refund (Feign → Payment Service)
     │ 9. Update return status to COMPLETED
     │ 10. Publish return.completed event
     │
     ▼
┌─────────────┐
│   Kafka    │
└─────────────┘
```

## 7. Review & Moderation Flow

```
┌─────────┐
│Customer │
└────┬────┘
     │
     │ 1. POST /api/reviews/products/{productId}
     │    {rating, text, orderItemId}
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 2. Validate order item ownership
     │ 3. Check if review already exists
     │ 4. Create review (status: PENDING)
     │
     ▼
┌─────────────┐
│   MySQL    │
│retailx_product│
└─────────────┘
     │
     │ 5. GET /api/reviews/pending
     │    (ADMIN/OPS)
     │
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 6. PUT /api/reviews/{id}/moderate?action=approve
     │
     ▼
┌─────────────────┐
│ Product Service │
└────┬────────────┘
     │
     │ 7. Update review status to APPROVED
     │ 8. GET /api/reviews/products/{id} (public)
     │    Returns only APPROVED reviews
     │
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## 8. Event-Driven Architecture Flow

```
┌─────────────────┐
│  Order Service  │
└────┬────────────┘
     │
     │ order.created
     │ inventory.reserved
     │ shipment.created
     │ order.delivered
     │ return.requested
     │ return.completed
     │
     ▼
┌─────────────────┐
│ Payment Service │
└────┬────────────┘
     │
     │ payment.captured → Order Service (updates order to PAID)
     │ payment.failed → Order Service (cancels order)
     │ payment.refunded → Order Service (cancels order)
     │
     ▼
┌─────────────┐
│   Kafka     │
│  (Broker)   │
└────┬────────┘
     │
     ├─────────────────┬─────────────────┬─────────────────┐
     │                 │                 │                 │
     ▼                 ▼                 ▼                 ▼
┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
│ Inventory   │  │Notification │  │  Order      │  │  Analytics  │
│  Service    │  │  Service    │  │  Service    │  │  (Future)   │
│             │  │             │  │             │  │             │
│ Consumes:   │  │ Consumes:    │  │ Consumes:   │  │             │
│ - order.    │  │ - order.*    │  │ - payment.  │  │             │
│   created   │  │ - payment.*  │  │   captured │  │             │
│ - inventory.│  │ - shipment.*│  │ - payment.  │  │             │
│   reserved  │  │ - return.*   │  │   failed    │  │             │
│             │  │              │  │ - payment.  │  │             │
│             │  │              │  │   refunded  │  │             │
└─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘
```

## 9. Service Discovery Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ Request to API Gateway
     ▼
┌─────────────────┐
│  API Gateway    │
│  (Port 8080)    │
└────┬────────────┘
     │
     │ 1. Query Eureka for service
     │ 2. Get service instance
     │ 3. Load balance request
     │
     ▼
┌─────────────────┐
│ Eureka Server   │
│  (Port 8761)    │
└────┬────────────┘
     │
     │ Service Registry:
     │ - retailx-auth-service
     │ - retailx-product-service
     │ - retailx-order-service
     │ - retailx-payment-service
     │ - retailx-inventory-service
     │ - retailx-notification-service
     │ - retailx-frontend-service
     │
     ▼
┌─────────────────┐
│ Target Service  │
└─────────────────┘
```

## 10. Idempotency Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ POST /api/checkout
     │ Headers: Idempotency-Key: abc123
     │
     ▼
┌─────────────────┐
│ CheckoutService │
└────┬────────────┘
     │
     │ 1. Check idempotency_keys table
     │    WHERE key_value = 'abc123'
     │
     ├─ Key exists? ──┐
     │                 │
     ▼                 ▼
┌─────────────┐  ┌─────────────┐
│   Yes       │  │    No       │
│             │  │             │
│ 2. Compare │  │ 2. Process  │
│    request │  │    checkout  │
│    hash    │  │             │
│             │  │ 3. Save key │
│ 3. Same?   │  │    & result │
│    └─Yes───┼──┼─Return cached│
│    └─No────┼──┼─Return 409   │
│            │  │   Conflict   │
└────────────┘  └─────────────┘
```

## 11. Password Reset Flow

```
┌─────────┐
│ Client  │
└────┬────┘
     │
     │ 1. POST /api/auth/forgot-password
     │    {email}
     ▼
┌─────────────────┐
│  Auth Service   │
└────┬────────────┘
     │
     │ 2. Generate secure reset token
     │ 3. Save token to DB (expires in 1 hour)
     │ 4. Send email with reset link
     │
     ▼
┌─────────────┐
│   MySQL    │
│ retailx_auth│
└─────────────┘
     │
     │ 5. Client clicks link in email
     │ 6. POST /api/auth/reset-password
     │    {token, newPassword}
     │
     ▼
┌─────────────────┐
│  Auth Service   │
└────┬────────────┘
     │
     │ 7. Validate token (not expired, not used)
     │ 8. Update password
     │ 9. Mark token as used
     │
     ▼
┌─────────┐
│ Client  │
└─────────┘
```

## Notes

- All flows use JWT authentication via API Gateway
- Services communicate via Feign clients (synchronous) or Kafka (asynchronous)
- Idempotency keys expire after 24 hours
- Circuit breakers protect external service calls
- All events are published to Kafka for eventual consistency
- Database per service pattern ensures service independence
- Payment capture automatically updates order to PAID via Kafka
- Payment failure/refund automatically cancels order via Kafka
- Return approval automatically processes refund and updates order to RETURNED
- Password reset tokens expire after 1 hour and are single-use
- Account lockout after 5 failed login attempts (30-minute lockout)
- Scheduled jobs: Order expiration (auto-cancel PENDING orders), Cart cleanup, Payment intent expiration

