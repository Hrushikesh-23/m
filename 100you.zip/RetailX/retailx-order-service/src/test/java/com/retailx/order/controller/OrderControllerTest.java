package com.retailx.order.controller;

import com.retailx.order.domain.AuditLog;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for OrderController.
 */
@ExtendWith(MockitoExtension.class)
class OrderControllerTest {
    
    @Mock
    private OrderService orderService;
    
    @InjectMocks
    private OrderController orderController;
    
    private OrderResponse orderResponse;
    
    @BeforeEach
    void setUp() {
        orderResponse = OrderResponse.builder()
                .id(1L)
                .orderNumber("ORD-20241213-000001-abc12345")
                .customerId(1L)
                .merchantId(2L)
                .status(OrderStatus.PENDING)
                .subtotal(new BigDecimal("100.00"))
                .tax(new BigDecimal("10.00"))
                .total(new BigDecimal("110.00"))
                .build();
    }
    
    @Test
    void testGetOrderById_Success() {
        when(orderService.getOrderById(1L)).thenReturn(orderResponse);
        
        ResponseEntity<OrderResponse> response = orderController.getOrderById(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("ORD-20241213-000001-abc12345", response.getBody().getOrderNumber());
        verify(orderService, times(1)).getOrderById(1L);
    }
    
    @Test
    void testGetOrderByNumber_Success() {
        when(orderService.getOrderByNumber("ORD-20241213-000001-abc12345"))
                .thenReturn(orderResponse);
        
        ResponseEntity<OrderResponse> response = 
                orderController.getOrderByNumber("ORD-20241213-000001-abc12345");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(orderService, times(1)).getOrderByNumber("ORD-20241213-000001-abc12345");
    }
    
    @Test
    void testGetCustomerOrders_Success() {
        Page<OrderResponse> page = new PageImpl<>(Arrays.asList(orderResponse));
        when(orderService.getOrdersByCustomer(anyLong(), any())).thenReturn(page);
        
        ResponseEntity<Page<OrderResponse>> response = 
                orderController.getCustomerOrders(1L, 0, 20);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().getTotalElements());
        verify(orderService, times(1)).getOrdersByCustomer(eq(1L), any());
    }
    
    @Test
    void testGetMerchantOrders_Success() {
        Page<OrderResponse> page = new PageImpl<>(Arrays.asList(orderResponse));
        when(orderService.getOrdersByMerchant(anyLong(), any())).thenReturn(page);
        
        ResponseEntity<Page<OrderResponse>> response = 
                orderController.getMerchantOrders(2L, 0, 20);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(orderService, times(1)).getOrdersByMerchant(eq(2L), any());
    }
    
    @Test
    void testUpdateOrderStatus_Success() {
        OrderResponse updatedResponse = OrderResponse.builder()
                .id(1L)
                .orderNumber("ORD-20241213-000001-abc12345")
                .status(OrderStatus.PAID)
                .build();
        when(orderService.getOrderById(1L)).thenReturn(orderResponse);
        when(orderService.updateOrderStatus(anyLong(), any(), anyString(), anyString()))
                .thenReturn(updatedResponse);
        
        ResponseEntity<OrderResponse> response = 
                orderController.updateOrderStatus(1L, OrderStatus.PAID, "1", "ADMIN", "Payment received");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(OrderStatus.PAID, response.getBody().getStatus());
        verify(orderService, times(1)).updateOrderStatus(1L, OrderStatus.PAID, "1", "Payment received");
    }
    
    @Test
    void testCancelOrder_Success() {
        OrderResponse cancelledResponse = OrderResponse.builder()
                .id(1L)
                .orderNumber("ORD-20241213-000001-abc12345")
                .status(OrderStatus.CANCELLED)
                .build();
        when(orderService.getOrderById(1L)).thenReturn(orderResponse);
        when(orderService.cancelOrder(anyLong(), anyString(), anyString()))
                .thenReturn(cancelledResponse);
        
        ResponseEntity<OrderResponse> response = 
                orderController.cancelOrder(1L, "1", "CUSTOMER", "Changed mind");
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(OrderStatus.CANCELLED, response.getBody().getStatus());
        verify(orderService, times(1)).cancelOrder(1L, "1", "Changed mind");
    }
    
    @Test
    void testGetOrderHistory_Success() {
        Page<OrderResponse> page = new PageImpl<>(Arrays.asList(orderResponse));
        when(orderService.getOrdersByCustomer(anyLong(), any())).thenReturn(page);
        
        ResponseEntity<Page<OrderResponse>> response = 
                orderController.getOrderHistory(1L, 0, 20);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(orderService, times(1)).getOrdersByCustomer(eq(1L), any());
    }
    
    @Test
    void testGetOrderAuditLog_Success() {
        AuditLog auditLog = AuditLog.builder()
                .id(1L)
                .orderId(1L)
                .action("STATUS_UPDATED")
                .actorId("1")
                .oldStatus("PENDING")
                .newStatus("PAID")
                .build();
        List<AuditLog> auditLogs = Arrays.asList(auditLog);
        when(orderService.getOrderAuditLog(1L)).thenReturn(auditLogs);
        
        ResponseEntity<List<AuditLog>> response = orderController.getOrderAuditLog(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        verify(orderService, times(1)).getOrderAuditLog(1L);
    }
}

