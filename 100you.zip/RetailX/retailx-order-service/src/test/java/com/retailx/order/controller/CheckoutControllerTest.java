package com.retailx.order.controller;

import com.retailx.order.dto.request.CheckoutRequest;
import com.retailx.order.dto.response.CheckoutResponse;
import com.retailx.order.service.CheckoutService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CheckoutController.
 */
@ExtendWith(MockitoExtension.class)
class CheckoutControllerTest {
    
    @Mock
    private CheckoutService checkoutService;
    
    @InjectMocks
    private CheckoutController checkoutController;
    
    private CheckoutRequest checkoutRequest;
    private CheckoutResponse checkoutResponse;
    
    @BeforeEach
    void setUp() {
        checkoutRequest = new CheckoutRequest();
        checkoutRequest.setShippingAddress("123 Main St, City, State, ZIP");
        checkoutRequest.setShippingMethod("STANDARD");
        checkoutRequest.setGiftNote("Happy Birthday!");
        
        checkoutResponse = CheckoutResponse.builder()
                .orderNumber("ORD-20241213-000001-abc12345")
                .orderId("1")
                .status("PENDING")
                .message("Order created successfully")
                .build();
    }
    
    @Test
    void testCheckout_Success() {
        when(checkoutService.checkout(anyLong(), any(CheckoutRequest.class), anyString()))
                .thenReturn(checkoutResponse);
        
        ResponseEntity<CheckoutResponse> response = 
                checkoutController.checkout(1L, "idempotency-key-123", checkoutRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("ORD-20241213-000001-abc12345", response.getBody().getOrderNumber());
        verify(checkoutService, times(1)).checkout(1L, checkoutRequest, "idempotency-key-123");
    }
    
    @Test
    void testCheckout_WithoutIdempotencyKey() {
        when(checkoutService.checkout(anyLong(), any(CheckoutRequest.class), isNull()))
                .thenReturn(checkoutResponse);
        
        ResponseEntity<CheckoutResponse> response = 
                checkoutController.checkout(1L, null, checkoutRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(checkoutService, times(1)).checkout(1L, checkoutRequest, null);
    }
}

