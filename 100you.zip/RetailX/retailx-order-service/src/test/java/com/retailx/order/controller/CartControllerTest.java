package com.retailx.order.controller;

import com.retailx.order.dto.request.AddToCartRequest;
import com.retailx.order.dto.response.CartResponse;
import com.retailx.order.service.CartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CartController.
 */
@ExtendWith(MockitoExtension.class)
class CartControllerTest {
    
    @Mock
    private CartService cartService;
    
    @InjectMocks
    private CartController cartController;
    
    private CartResponse cartResponse;
    private AddToCartRequest addToCartRequest;
    
    @BeforeEach
    void setUp() {
        cartResponse = CartResponse.builder()
                .customerId(1L)
                .items(new ArrayList<>())
                .subtotal(BigDecimal.ZERO)
                .tax(BigDecimal.ZERO)
                .shipping(BigDecimal.ZERO)
                .total(BigDecimal.ZERO)
                .build();
        
        addToCartRequest = new AddToCartRequest();
        addToCartRequest.setSku("PROD-001");
        addToCartRequest.setQuantity(BigInteger.valueOf(2));
    }
    
    @Test
    void testGetCart_Success() {
        when(cartService.getOrCreateCart(anyLong())).thenReturn(cartResponse);
        
        ResponseEntity<CartResponse> response = cartController.getCart(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getCustomerId());
        verify(cartService, times(1)).getOrCreateCart(1L);
    }
    
    @Test
    void testAddToCart_Success() {
        when(cartService.addToCart(anyLong(), any(AddToCartRequest.class))).thenReturn(cartResponse);
        
        ResponseEntity<CartResponse> response = cartController.addToCart(1L, addToCartRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(cartService, times(1)).addToCart(1L, addToCartRequest);
    }
    
    @Test
    void testUpdateCartItem_Success() {
        when(cartService.updateCartItem(anyLong(), anyLong(), any(BigInteger.class)))
                .thenReturn(cartResponse);
        
        ResponseEntity<CartResponse> response = 
                cartController.updateCartItem(1L, 1L, BigInteger.valueOf(3));
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(cartService, times(1)).updateCartItem(1L, 1L, BigInteger.valueOf(3));
    }
    
    @Test
    void testRemoveFromCart_Success() {
        when(cartService.removeFromCart(anyLong(), anyLong())).thenReturn(cartResponse);
        
        ResponseEntity<CartResponse> response = cartController.removeFromCart(1L, 1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        verify(cartService, times(1)).removeFromCart(1L, 1L);
    }
    
    @Test
    void testClearCart_Success() {
        doNothing().when(cartService).clearCart(anyLong());
        
        ResponseEntity<Void> response = cartController.clearCart(1L);
        
        assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
        assertNull(response.getBody());
        verify(cartService, times(1)).clearCart(1L);
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = cartController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Order Service is running", response.getBody());
    }
}

