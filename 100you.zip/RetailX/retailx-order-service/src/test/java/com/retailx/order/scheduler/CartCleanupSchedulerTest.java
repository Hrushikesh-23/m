package com.retailx.order.scheduler;

import com.retailx.order.domain.Cart;
import com.retailx.order.repository.CartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CartCleanupScheduler.
 */
@ExtendWith(MockitoExtension.class)
class CartCleanupSchedulerTest {
    
    @Mock
    private CartRepository cartRepository;
    
    @InjectMocks
    private CartCleanupScheduler scheduler;
    
    private Cart expiredCart;
    
    @BeforeEach
    void setUp() {
        expiredCart = Cart.builder()
                .customerId(1L)
                .expiresAt(LocalDateTime.now().minusHours(1))
                .subtotal(BigDecimal.ZERO)
                .tax(BigDecimal.ZERO)
                .shipping(BigDecimal.ZERO)
                .total(BigDecimal.ZERO)
                .build();
        // Set ID and deleted using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(expiredCart, 1L);
            
            java.lang.reflect.Field deletedField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("deleted");
            deletedField.setAccessible(true);
            deletedField.set(expiredCart, false);
        } catch (Exception e) {
            // Ignore
        }
    }
    
    @Test
    void testCleanupExpiredCarts_WithExpiredCarts() {
        List<Cart> expiredCarts = Arrays.asList(expiredCart);
        when(cartRepository.findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class)))
                .thenReturn(expiredCarts);
        when(cartRepository.save(any(Cart.class))).thenReturn(expiredCart);
        
        scheduler.cleanupExpiredCarts();
        
        verify(cartRepository, times(1)).findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class));
        verify(cartRepository, times(1)).save(any(Cart.class));
        // Verify cart was marked as deleted
        verify(cartRepository).save(argThat(cart -> cart.getDeleted() != null && cart.getDeleted()));
    }
    
    @Test
    void testCleanupExpiredCarts_NoExpiredCarts() {
        when(cartRepository.findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class)))
                .thenReturn(Arrays.asList());
        
        scheduler.cleanupExpiredCarts();
        
        verify(cartRepository, times(1)).findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class));
        verify(cartRepository, never()).save(any(Cart.class));
    }
    
    @Test
    void testCleanupExpiredCarts_WithException() {
        List<Cart> expiredCarts = Arrays.asList(expiredCart);
        when(cartRepository.findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class)))
                .thenReturn(expiredCarts);
        when(cartRepository.save(any(Cart.class))).thenThrow(new RuntimeException("Database error"));
        
        scheduler.cleanupExpiredCarts();
        
        verify(cartRepository, times(1)).findByExpiresAtBeforeAndDeletedFalse(any(LocalDateTime.class));
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
}

