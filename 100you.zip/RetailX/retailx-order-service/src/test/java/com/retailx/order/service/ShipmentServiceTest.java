package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Shipment;
import com.retailx.order.domain.ShipmentItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ShipmentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ShipmentService.
 */
@ExtendWith(MockitoExtension.class)
class ShipmentServiceTest {
    
    @Mock
    private ShipmentRepository shipmentRepository;
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private OrderService orderService;
    
    @Mock
    private InventoryServiceClient inventoryServiceClient;
    
    @Mock
    private org.springframework.kafka.core.KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private ShipmentService shipmentService;
    
    private Order order;
    private Shipment shipment;
    
    @BeforeEach
    void setUp() {
        order = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(2L)
                .status(OrderStatus.PAID)
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(order, 1L);
        } catch (Exception e) {
            // Ignore
        }
        
        OrderItem item = OrderItem.builder()
                .order(order)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("50.00"))
                .build();
        order.setItems(Arrays.asList(item));
        
        shipment = Shipment.builder()
                .orderId(1L)
                .shipmentNumber("SHIP-001")
                .carrier("FedEx")
                .trackingNumber("TRACK123")
                .shippedAt(LocalDateTime.now())
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(shipment, 1L);
        } catch (Exception e) {
            // Ignore
        }
        
        ShipmentItem shipmentItem = ShipmentItem.builder()
                .shipment(shipment)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .build();
        shipment.setItems(Arrays.asList(shipmentItem));
    }
    
    @Test
    void testCreateShipment_Success() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(shipmentRepository.save(any(Shipment.class))).thenAnswer(invocation -> {
            Shipment s = invocation.getArgument(0);
            // Set ID on saved shipment
            try {
                java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
                idField.setAccessible(true);
                idField.set(s, 1L);
            } catch (Exception e) {
                // Ignore
            }
            return s;
        });
        doAnswer(invocation -> {
            // Return OrderResponse mock
            return com.retailx.order.dto.response.OrderResponse.builder()
                    .id(1L)
                    .orderNumber("ORD-001")
                    .status(OrderStatus.SHIPPED)
                    .build();
        }).when(orderService).updateOrderStatus(anyLong(), any(), anyString(), anyString());
        doAnswer(invocation -> null).when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        Shipment response = shipmentService.createShipment(1L, "FedEx", "123456789012", 
                Arrays.asList("PROD-001"));
        
        assertNotNull(response);
        verify(shipmentRepository, times(1)).save(any(Shipment.class));
        verify(orderService, times(1)).updateOrderStatus(eq(1L), eq(OrderStatus.SHIPPED), eq("SYSTEM"), anyString());
    }
    
    @Test
    void testCreateShipment_OrderNotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());
        
        assertThrows(RuntimeException.class, () -> 
                shipmentService.createShipment(1L, "FedEx", "TRACK123", Arrays.asList("PROD-001")));
        verify(shipmentRepository, never()).save(any(Shipment.class));
    }
    
    @Test
    void testMarkDelivered_Success() {
        when(shipmentRepository.findById(1L)).thenReturn(Optional.of(shipment));
        when(shipmentRepository.save(any(Shipment.class))).thenReturn(shipment);
        doAnswer(invocation -> {
            // Return OrderResponse mock
            return com.retailx.order.dto.response.OrderResponse.builder()
                    .id(1L)
                    .orderNumber("ORD-001")
                    .status(OrderStatus.DELIVERED)
                    .build();
        }).when(orderService).updateOrderStatus(anyLong(), any(), anyString(), anyString());
        doAnswer(invocation -> null).when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        Shipment response = shipmentService.markDelivered(1L);
        
        assertNotNull(response);
        assertNotNull(response.getDeliveredAt());
        verify(shipmentRepository, times(1)).save(any(Shipment.class));
        verify(orderService, times(1)).updateOrderStatus(eq(1L), eq(OrderStatus.DELIVERED), eq("SYSTEM"), anyString());
    }
    
    @Test
    void testGetShipmentsByOrder_Success() {
        List<Shipment> shipments = Arrays.asList(shipment);
        when(shipmentRepository.findByOrderIdAndDeletedFalse(1L)).thenReturn(shipments);
        
        List<Shipment> response = shipmentService.getShipmentsByOrder(1L);
        
        assertNotNull(response);
        assertEquals(1, response.size());
        verify(shipmentRepository, times(1)).findByOrderIdAndDeletedFalse(1L);
    }
}

