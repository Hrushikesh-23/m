package com.retailx.order.scheduler;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.service.InventoryServiceClient;
import com.retailx.order.service.OrderService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for OrderExpirationScheduler.
 */
@ExtendWith(MockitoExtension.class)
class OrderExpirationSchedulerTest {
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private OrderService orderService;
    
    @Mock
    private InventoryServiceClient inventoryServiceClient;
    
    @InjectMocks
    private OrderExpirationScheduler scheduler;
    
    private Order expiredOrder;
    
    @BeforeEach
    void setUp() {
        // Set expiration hours using reflection
        try {
            java.lang.reflect.Field field = OrderExpirationScheduler.class.getDeclaredField("orderExpirationHours");
            field.setAccessible(true);
            field.setInt(scheduler, 24);
        } catch (Exception e) {
            // Ignore
        }
        
        expiredOrder = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(1L)
                .status(OrderStatus.PENDING)
                .build();
        // Set ID and createdOn using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(expiredOrder, 1L);
            
            java.lang.reflect.Field createdOnField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("createdOn");
            createdOnField.setAccessible(true);
            createdOnField.set(expiredOrder, LocalDateTime.now().minusHours(25));
        } catch (Exception e) {
            // Ignore
        }
        
        OrderItem item = OrderItem.builder()
                .order(expiredOrder)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("50.00"))
                .build();
        expiredOrder.setItems(Arrays.asList(item));
    }
    
    @Test
    void testCancelExpiredOrders_WithExpiredOrders() {
        List<Order> expiredOrders = Arrays.asList(expiredOrder);
        when(orderRepository.findByStatusAndCreatedOnBeforeAndDeletedFalse(
                eq(OrderStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(expiredOrders);
        when(inventoryServiceClient.releaseReservedInventory(anyString(), any(), anyString()))
                .thenReturn(true);
        OrderResponse orderResponse = OrderResponse.builder()
                .id(1L)
                .orderNumber("ORD-001")
                .status(OrderStatus.CANCELLED)
                .build();
        when(orderService.cancelOrder(anyLong(), anyString(), anyString())).thenReturn(orderResponse);
        
        scheduler.cancelExpiredOrders();
        
        verify(orderRepository, times(1)).findByStatusAndCreatedOnBeforeAndDeletedFalse(
                eq(OrderStatus.PENDING), any(LocalDateTime.class));
        verify(inventoryServiceClient, atLeastOnce()).releaseReservedInventory(anyString(), any(), anyString());
        verify(orderService, times(1)).cancelOrder(eq(1L), eq("SYSTEM"), anyString());
    }
    
    @Test
    void testCancelExpiredOrders_NoExpiredOrders() {
        when(orderRepository.findByStatusAndCreatedOnBeforeAndDeletedFalse(
                eq(OrderStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(Arrays.asList());
        
        scheduler.cancelExpiredOrders();
        
        verify(orderRepository, times(1)).findByStatusAndCreatedOnBeforeAndDeletedFalse(
                eq(OrderStatus.PENDING), any(LocalDateTime.class));
        verify(orderService, never()).cancelOrder(anyLong(), anyString(), anyString());
    }
    
    @Test
    void testCancelExpiredOrders_InventoryReleaseFailure() {
        List<Order> expiredOrders = Arrays.asList(expiredOrder);
        when(orderRepository.findByStatusAndCreatedOnBeforeAndDeletedFalse(
                eq(OrderStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(expiredOrders);
        when(inventoryServiceClient.releaseReservedInventory(anyString(), any(), eq("WH-001")))
                .thenReturn(false);
        when(inventoryServiceClient.releaseReservedInventory(anyString(), any(), eq("default-warehouse")))
                .thenReturn(false);
        OrderResponse orderResponse = OrderResponse.builder()
                .id(1L)
                .orderNumber("ORD-001")
                .status(OrderStatus.CANCELLED)
                .build();
        when(orderService.cancelOrder(anyLong(), anyString(), anyString())).thenReturn(orderResponse);
        
        scheduler.cancelExpiredOrders();
        
        verify(inventoryServiceClient, atLeastOnce()).releaseReservedInventory(anyString(), any(), anyString());
        verify(orderService, times(1)).cancelOrder(eq(1L), eq("SYSTEM"), anyString());
    }
}

