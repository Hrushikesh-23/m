package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Return;
import com.retailx.order.domain.ReturnItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ReturnRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ReturnService.
 */
@ExtendWith(MockitoExtension.class)
class ReturnServiceTest {
    
    @Mock
    private ReturnRepository returnRepository;
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private PaymentServiceClient paymentServiceClient;
    
    @Mock
    private InventoryServiceClient inventoryServiceClient;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private ReturnService returnService;
    
    private Order order;
    private Return returnEntity;
    
    @BeforeEach
    void setUp() {
        // Set returnWindowDays using reflection
        try {
            java.lang.reflect.Field field = ReturnService.class.getDeclaredField("returnWindowDays");
            field.setAccessible(true);
            field.setInt(returnService, 30);
        } catch (Exception e) {
            // Ignore
        }
        
        order = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(2L)
                .status(OrderStatus.DELIVERED)
                .build();
        // Set ID and updatedOn using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(order, 1L);
            
            java.lang.reflect.Field updatedOnField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("updatedOn");
            updatedOnField.setAccessible(true);
            updatedOnField.set(order, LocalDateTime.now().minusDays(5));
        } catch (Exception e) {
            // Ignore
        }
        
        OrderItem item = OrderItem.builder()
                .order(order)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("50.00"))
                .returnedQuantity(BigInteger.ZERO)
                .build();
        order.setItems(Arrays.asList(item));
        
        returnEntity = Return.builder()
                .orderId(1L)
                .rmaNumber("RMA-001")
                .status("REQUESTED")
                .reason("Defective item")
                .requestedAt(LocalDateTime.now())
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(returnEntity, 1L);
        } catch (Exception e) {
            // Ignore
        }
        
        ReturnItem returnItem = ReturnItem.builder()
                .returnEntity(returnEntity)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(1))
                .build();
        returnEntity.setItems(Arrays.asList(returnItem));
    }
    
    @Test
    void testRequestReturn_Success() {
        com.retailx.order.service.ReturnService.ReturnItemRequest itemRequest = 
                new com.retailx.order.service.ReturnService.ReturnItemRequest();
        itemRequest.setSku("PROD-001");
        itemRequest.setQuantity(BigInteger.valueOf(1));
        
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(returnRepository.save(any(Return.class))).thenReturn(returnEntity);
        
        Return response = returnService.requestReturn(1L, 1L, "Defective item", 
                Arrays.asList(itemRequest));
        
        assertNotNull(response);
        assertEquals("RMA-001", response.getRmaNumber());
        verify(returnRepository, times(1)).save(any(Return.class));
    }
    
    @Test
    void testRequestReturn_OrderNotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());
        
        ReturnService.ReturnItemRequest itemRequest = new ReturnService.ReturnItemRequest();
        itemRequest.setSku("PROD-001");
        itemRequest.setQuantity(BigInteger.valueOf(1));
        
        assertThrows(RuntimeException.class, () -> 
                returnService.requestReturn(1L, 1L, "Defective item", Arrays.asList(itemRequest)));
    }
    
    @Test
    void testRequestReturn_WrongCustomer() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        
        ReturnService.ReturnItemRequest itemRequest = new ReturnService.ReturnItemRequest();
        itemRequest.setSku("PROD-001");
        itemRequest.setQuantity(BigInteger.valueOf(1));
        
        assertThrows(RuntimeException.class, () -> 
                returnService.requestReturn(1L, 999L, "Defective item", Arrays.asList(itemRequest)));
    }
    
    @Test
    void testApproveReturn_Success() {
        returnEntity.setRefundAmount(new BigDecimal("50.00"));
        when(returnRepository.findById(1L)).thenReturn(Optional.of(returnEntity));
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        when(returnRepository.save(any(Return.class))).thenReturn(returnEntity);
        doNothing().when(paymentServiceClient).refund(anyLong(), any());
        doNothing().when(inventoryServiceClient).adjustInventory(anyString(), anyString(), any());
        doAnswer(invocation -> null).when(kafkaTemplate).send(anyString(), anyString(), anyString());
        
        Return response = returnService.approveReturn(1L, "1");
        
        assertNotNull(response);
        verify(returnRepository, atLeast(1)).save(any(Return.class));
        verify(paymentServiceClient, times(1)).refund(eq(1L), any());
    }
    
    @Test
    void testRejectReturn_Success() {
        when(returnRepository.findById(1L)).thenReturn(Optional.of(returnEntity));
        when(returnRepository.save(any(Return.class))).thenReturn(returnEntity);
        
        Return response = returnService.rejectReturn(1L, "Not eligible", "1");
        
        assertNotNull(response);
        assertEquals("REJECTED", response.getStatus());
        verify(returnRepository, times(1)).save(any(Return.class));
    }
    
    @Test
    void testGetReturnsByOrder_Success() {
        List<Return> returns = Arrays.asList(returnEntity);
        when(returnRepository.findByOrderIdAndDeletedFalse(1L)).thenReturn(returns);
        
        List<Return> response = returnService.getReturnsByOrder(1L);
        
        assertNotNull(response);
        assertEquals(1, response.size());
        verify(returnRepository, times(1)).findByOrderIdAndDeletedFalse(1L);
    }
}

