package com.retailx.order.service;

import com.retailx.order.domain.AuditLog;
import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.repository.AuditLogRepository;
import com.retailx.order.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for OrderService.
 */
@ExtendWith(MockitoExtension.class)
class OrderServiceTest {
    
    @Mock
    private OrderRepository orderRepository;
    
    @Mock
    private InventoryServiceClient inventoryServiceClient;
    
    @Mock
    private PaymentServiceClient paymentServiceClient;
    
    @Mock
    private AuditLogRepository auditLogRepository;
    
    @InjectMocks
    private OrderService orderService;
    
    private Order order;
    
    @BeforeEach
    void setUp() {
        order = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(2L)
                .status(OrderStatus.PENDING)
                .subtotal(new BigDecimal("100.00"))
                .tax(new BigDecimal("10.00"))
                .total(new BigDecimal("110.00"))
                .build();
        // Set ID using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(order, 1L);
            
            java.lang.reflect.Field deletedField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("deleted");
            deletedField.setAccessible(true);
            deletedField.set(order, false);
        } catch (Exception e) {
            // Ignore
        }
        
        OrderItem item = OrderItem.builder()
                .order(order)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("50.00"))
                .build();
        order.setItems(Arrays.asList(item));
    }
    
    @Test
    void testGetOrderById_Success() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        
        OrderResponse response = orderService.getOrderById(1L);
        
        assertNotNull(response);
        assertEquals("ORD-001", response.getOrderNumber());
        verify(orderRepository, times(1)).findById(1L);
    }
    
    @Test
    void testGetOrderById_NotFound() {
        when(orderRepository.findById(1L)).thenReturn(Optional.empty());
        
        assertThrows(RuntimeException.class, () -> orderService.getOrderById(1L));
        verify(orderRepository, times(1)).findById(1L);
    }
    
    @Test
    void testGetOrderByNumber_Success() {
        when(orderRepository.findByOrderNumberAndDeletedFalse("ORD-001"))
                .thenReturn(Optional.of(order));
        
        OrderResponse response = orderService.getOrderByNumber("ORD-001");
        
        assertNotNull(response);
        assertEquals("ORD-001", response.getOrderNumber());
        verify(orderRepository, times(1)).findByOrderNumberAndDeletedFalse("ORD-001");
    }
    
    @Test
    void testGetOrdersByCustomer_Success() {
        Page<Order> page = new PageImpl<>(Arrays.asList(order));
        when(orderRepository.findByCustomerIdAndDeletedFalse(anyLong(), any()))
                .thenReturn(page);
        
        Page<OrderResponse> response = orderService.getOrdersByCustomer(1L, PageRequest.of(0, 20));
        
        assertNotNull(response);
        assertEquals(1, response.getTotalElements());
        verify(orderRepository, times(1)).findByCustomerIdAndDeletedFalse(eq(1L), any());
    }
    
    @Test
    void testGetOrdersByMerchant_Success() {
        Page<Order> page = new PageImpl<>(Arrays.asList(order));
        when(orderRepository.findByMerchantIdAndDeletedFalse(anyLong(), any()))
                .thenReturn(page);
        
        Page<OrderResponse> response = orderService.getOrdersByMerchant(2L, PageRequest.of(0, 20));
        
        assertNotNull(response);
        assertEquals(1, response.getTotalElements());
        verify(orderRepository, times(1)).findByMerchantIdAndDeletedFalse(eq(2L), any());
    }
    
    @Test
    void testUpdateOrderStatus_Success() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        Order updatedOrder = Order.builder()
                .orderNumber("ORD-001")
                .customerId(1L)
                .merchantId(2L)
                .status(OrderStatus.PAID)
                .build();
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(updatedOrder, 1L);
        } catch (Exception e) {
            // Ignore
        }
        when(orderRepository.save(any(Order.class))).thenReturn(updatedOrder);
        when(auditLogRepository.save(any(AuditLog.class))).thenAnswer(invocation -> invocation.getArgument(0));
        
        OrderResponse response = orderService.updateOrderStatus(1L, OrderStatus.PAID, "1", "Payment received");
        
        assertNotNull(response);
        verify(orderRepository, times(1)).save(any(Order.class));
        verify(auditLogRepository, times(1)).save(any(AuditLog.class));
    }
    
    @Test
    void testCancelOrder_Success() {
        when(orderRepository.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        when(auditLogRepository.save(any(AuditLog.class))).thenAnswer(invocation -> invocation.getArgument(0));
        
        OrderResponse response = orderService.cancelOrder(1L, "1", "Customer request");
        
        assertNotNull(response);
        verify(orderRepository, times(1)).save(any(Order.class));
        verify(auditLogRepository, times(1)).save(any(AuditLog.class));
    }
    
    @Test
    void testGetOrderAuditLog_Success() {
        AuditLog auditLog = new AuditLog();
        // Set fields using reflection
        try {
            java.lang.reflect.Field idField = com.retailx.order.domain.BaseEntity.class.getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(auditLog, 1L);
            
            java.lang.reflect.Field orderIdField = AuditLog.class.getDeclaredField("orderId");
            orderIdField.setAccessible(true);
            orderIdField.set(auditLog, 1L);
            
            java.lang.reflect.Field actionField = AuditLog.class.getDeclaredField("action");
            actionField.setAccessible(true);
            actionField.set(auditLog, "STATUS_UPDATED");
            
            java.lang.reflect.Field actorIdField = AuditLog.class.getDeclaredField("actorId");
            actorIdField.setAccessible(true);
            actorIdField.set(auditLog, "1");
            
            java.lang.reflect.Field oldStatusField = AuditLog.class.getDeclaredField("oldStatus");
            oldStatusField.setAccessible(true);
            oldStatusField.set(auditLog, "PENDING");
            
            java.lang.reflect.Field newStatusField = AuditLog.class.getDeclaredField("newStatus");
            newStatusField.setAccessible(true);
            newStatusField.set(auditLog, "PAID");
        } catch (Exception e) {
            // Ignore
        }
        List<AuditLog> auditLogs = Arrays.asList(auditLog);
        when(auditLogRepository.findByOrderIdOrderByTimestampDesc(1L)).thenReturn(auditLogs);
        
        List<AuditLog> response = orderService.getOrderAuditLog(1L);
        
        assertNotNull(response);
        assertEquals(1, response.size());
        verify(auditLogRepository, times(1)).findByOrderIdOrderByTimestampDesc(1L);
    }
}

