package com.retailx.order.service;

import com.retailx.order.domain.Cart;
import com.retailx.order.domain.CartItem;
import com.retailx.order.dto.request.AddToCartRequest;
import com.retailx.order.dto.response.CartResponse;
import com.retailx.order.repository.CartRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for CartService.
 */
@ExtendWith(MockitoExtension.class)
class CartServiceTest {
    
    @Mock
    private CartRepository cartRepository;
    
    @Mock
    private ProductServiceClient productServiceClient;
    
    @InjectMocks
    private CartService cartService;
    
    private Cart testCart;
    private Long customerId;
    
    @BeforeEach
    void setUp() {
        customerId = 1L;
        testCart = Cart.builder()
                .customerId(customerId)
                .items(new ArrayList<>())
                .subtotal(BigDecimal.ZERO)
                .tax(BigDecimal.ZERO)
                .shipping(BigDecimal.ZERO)
                .discount(BigDecimal.ZERO)
                .total(BigDecimal.ZERO)
                .expiresAt(LocalDateTime.now().plusHours(24))
                .abandoned(false)
                .build();
        
        // Set @Value fields using reflection since we're using MockitoExtension
        try {
            java.lang.reflect.Field maxItemsField = CartService.class.getDeclaredField("maxItems");
            maxItemsField.setAccessible(true);
            maxItemsField.setInt(cartService, 50);
            
            java.lang.reflect.Field maxTotalValueField = CartService.class.getDeclaredField("maxTotalValue");
            maxTotalValueField.setAccessible(true);
            maxTotalValueField.set(cartService, new BigDecimal("10000"));
            
            java.lang.reflect.Field maxQuantityPerItemField = CartService.class.getDeclaredField("maxQuantityPerItem");
            maxQuantityPerItemField.setAccessible(true);
            maxQuantityPerItemField.setInt(cartService, 100);
        } catch (Exception e) {
            // Ignore reflection errors
        }
    }
    
    @Test
    void testGetOrCreateCart_ExistingCart() {
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);
        
        CartResponse response = cartService.getOrCreateCart(customerId);
        
        assertNotNull(response);
        assertEquals(customerId, response.getCustomerId());
        verify(cartRepository, times(1)).findByCustomerIdAndDeletedFalse(customerId);
    }
    
    @Test
    void testGetOrCreateCart_NewCart() {
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.empty());
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);
        
        CartResponse response = cartService.getOrCreateCart(customerId);
        
        assertNotNull(response);
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
    
    @Test
    void testAddToCart_NewItem() {
        AddToCartRequest request = new AddToCartRequest();
        request.setSku("PROD-001");
        request.setQuantity(BigInteger.valueOf(2));
        
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.of(testCart));
        when(productServiceClient.getProductBySku("PROD-001"))
                .thenReturn(java.util.Map.of("status", "ACTIVE", "basePrice", 100.0));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);
        
        CartResponse response = cartService.addToCart(customerId, request);
        
        assertNotNull(response);
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
    
    @Test
    void testUpdateCartItem() {
        CartItem item = CartItem.builder()
                .cart(testCart)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("100"))
                .lineTotal(new BigDecimal("200"))
                .build();
        item.setId(1L);
        testCart.getItems().add(item);
        
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));
        
        CartResponse response = cartService.updateCartItem(customerId, 1L, BigInteger.valueOf(3));
        
        assertNotNull(response);
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
    
    @Test
    void testRemoveFromCart() {
        CartItem item = CartItem.builder()
                .cart(testCart)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("100"))
                .lineTotal(new BigDecimal("200"))
                .build();
        item.setId(1L);
        testCart.getItems().add(item);
        
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenAnswer(invocation -> invocation.getArgument(0));
        
        CartResponse response = cartService.removeFromCart(customerId, 1L);
        
        assertNotNull(response);
        assertTrue(testCart.getItems().isEmpty());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
    
    @Test
    void testClearCart() {
        CartItem item = CartItem.builder()
                .cart(testCart)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(2))
                .unitPrice(new BigDecimal("100"))
                .lineTotal(new BigDecimal("200"))
                .build();
        testCart.getItems().add(item);
        
        when(cartRepository.findByCustomerIdAndDeletedFalse(customerId))
                .thenReturn(Optional.of(testCart));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);
        
        cartService.clearCart(customerId);
        
        assertTrue(testCart.getItems().isEmpty());
        verify(cartRepository, times(1)).save(any(Cart.class));
    }
}

