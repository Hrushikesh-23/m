package com.retailx.order.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Return response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReturnResponse {
    
    private Long id;
    private Long orderId;
    private String rmaNumber;
    private String status;
    private String reason;
    private BigDecimal refundAmount;
    private Boolean restocked;
    private LocalDateTime requestedAt;
    private LocalDateTime approvedAt;
    private LocalDateTime completedAt;
    private List<ReturnItemResponse> items;
}

