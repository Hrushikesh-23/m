package com.retailx.order.repository;

import com.retailx.order.domain.Return;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository for Return entity.
 */
@Repository
public interface ReturnRepository extends JpaRepository<Return, Long> {
    
    Optional<Return> findByRmaNumberAndDeletedFalse(String rmaNumber);
    
    List<Return> findByOrderIdAndDeletedFalse(Long orderId);
    
    /**
     * Find all returns for an order with specific statuses (to check for pending returns).
     */
    List<Return> findByOrderIdAndStatusInAndDeletedFalse(Long orderId, List<String> statuses);
}

