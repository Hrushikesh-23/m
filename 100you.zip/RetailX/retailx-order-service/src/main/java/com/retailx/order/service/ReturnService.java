package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Return;
import com.retailx.order.domain.ReturnItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ReturnRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Service for returns and refunds.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReturnService {
    
    private final ReturnRepository returnRepository;
    private final OrderRepository orderRepository;
    private final PaymentServiceClient paymentServiceClient;
    private final InventoryServiceClient inventoryServiceClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${retailx.return.window-days:30}")
    private int returnWindowDays;
    
    @Transactional
    public Return requestReturn(Long orderId, Long customerId, String reason, List<ReturnItemRequest> items) {
        log.info("Processing return request for order: {}", orderId);
        
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Verify ownership
        if (!order.getCustomerId().equals(customerId)) {
            throw new RuntimeException("Order does not belong to customer");
        }
        
        // Check return window - allow returns for DELIVERED or PARTIALLY_RETURNED orders
        if (order.getStatus() != OrderStatus.DELIVERED && order.getStatus() != OrderStatus.PARTIALLY_RETURNED) {
            throw new RuntimeException("Order must be DELIVERED or PARTIALLY_RETURNED to request return");
        }
        
        LocalDateTime deliveryDate = order.getUpdatedOn(); // Assuming delivery date
        if (deliveryDate.plusDays(returnWindowDays).isBefore(LocalDateTime.now())) {
            throw new RuntimeException("RETURN_WINDOW_EXPIRED: Return window has expired");
        }
        
        String rmaNumber = "RMA-" + LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd")) + "-" + 
                UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        Return returnEntity = Return.builder()
                .orderId(orderId)
                .rmaNumber(rmaNumber)
                .requestedAt(LocalDateTime.now())
                .status("REQUESTED")
                .reason(reason)
                .build();
        
        // Create return items and calculate refund with proportional taxes
        BigDecimal totalRefund = BigDecimal.ZERO;
        BigDecimal orderSubtotal = order.getSubtotal();
        BigDecimal orderTax = order.getTax();
        
        // Get all existing return requests (REQUESTED, APPROVED) for this order
        // to check for pending returns - COMPLETED returns are already processed and tracked via returnedQuantity
        List<Return> existingReturns = returnRepository.findByOrderIdAndStatusInAndDeletedFalse(
                orderId, List.of("REQUESTED", "APPROVED"));
        
        for (ReturnItemRequest itemRequest : items) {
            // Validate quantity
            OrderItem orderItem = order.getItems().stream()
                    .filter(item -> item.getSku().equals(itemRequest.getSku()))
                    .findFirst()
                    .orElseThrow(() -> new RuntimeException("INVALID_RETURN_QTY: SKU not found in order"));
            
            // Calculate already returned quantity (from approved/completed returns)
            // This is updated when a return is approved, so it reflects all processed returns
            BigInteger totalReturned = orderItem.getReturnedQuantity() != null ? 
                    orderItem.getReturnedQuantity() : BigInteger.ZERO;
            
            // Calculate pending return quantity (from REQUESTED or APPROVED returns that haven't been completed)
            // These are returns that are in progress but not yet completed
            BigInteger pendingReturnQty = existingReturns.stream()
                    .filter(r -> "REQUESTED".equals(r.getStatus()) || "APPROVED".equals(r.getStatus()))
                    .flatMap(r -> r.getItems().stream())
                    .filter(ri -> ri.getSku().equals(itemRequest.getSku()))
                    .map(ReturnItem::getQuantity)
                    .reduce(BigInteger.ZERO, BigInteger::add);
            
            BigInteger newReturnQty = itemRequest.getQuantity();
            
            // Calculate remaining quantity that can be returned
            // Remaining = Ordered - Already Returned (from completed returns) - Pending Returns (in progress)
            BigInteger remainingQty = orderItem.getQuantity().subtract(totalReturned).subtract(pendingReturnQty);
            
            log.info("Return validation for SKU {}: Ordered={}, Already Returned={}, Pending Returns={}, Remaining={}, Requested={}", 
                    itemRequest.getSku(), orderItem.getQuantity(), totalReturned, pendingReturnQty, remainingQty, newReturnQty);
            
            if (remainingQty.compareTo(BigInteger.ZERO) <= 0) {
                if (pendingReturnQty.compareTo(BigInteger.ZERO) > 0) {
                    throw new RuntimeException(
                        String.format("INVALID_RETURN_QTY: There is already a pending return request for SKU %s. " +
                                "Please wait for the existing return to be processed. " +
                                "Pending quantity: %d, Already returned: %d, Ordered: %d", 
                                itemRequest.getSku(), pendingReturnQty, totalReturned, orderItem.getQuantity()));
                } else {
                    throw new RuntimeException(
                        String.format("INVALID_RETURN_QTY: All items for SKU %s have already been returned. " +
                                "Returned: %d, Ordered: %d", 
                                itemRequest.getSku(), totalReturned, orderItem.getQuantity()));
                }
            }
            
            if (newReturnQty.compareTo(BigInteger.ZERO) <= 0) {
                throw new RuntimeException("INVALID_RETURN_QTY: Return quantity must be positive");
            }
            
            if (newReturnQty.compareTo(remainingQty) > 0) {
                throw new RuntimeException(
                    String.format("INVALID_RETURN_QTY: Return quantity (%d) exceeds available quantity (%d) for SKU %s. " +
                            "Already returned: %d, Pending returns: %d, Ordered: %d", 
                            newReturnQty, remainingQty, itemRequest.getSku(), 
                            totalReturned, pendingReturnQty, orderItem.getQuantity()));
            }
            
            ReturnItem returnItem = ReturnItem.builder()
                    .returnEntity(returnEntity)
                    .sku(itemRequest.getSku())
                    .quantity(itemRequest.getQuantity())
                    .build();
            returnEntity.getItems().add(returnItem);
            
            // Calculate proportional refund: item line total + proportional tax
            BigDecimal itemLineTotal = orderItem.getUnitPrice().multiply(new BigDecimal(itemRequest.getQuantity()));
            
            // Calculate proportional tax for this item
            // Tax ratio = (item line total / order subtotal) * order tax
            BigDecimal taxRatio = BigDecimal.ZERO;
            if (orderSubtotal.compareTo(BigDecimal.ZERO) > 0) {
                taxRatio = itemLineTotal.divide(orderSubtotal, 4, java.math.RoundingMode.HALF_UP)
                        .multiply(orderTax);
            }
            
            // Refund amount = item line total + proportional tax
            BigDecimal itemRefund = itemLineTotal.add(taxRatio);
            totalRefund = totalRefund.add(itemRefund);
        }
        
        returnEntity.setRefundAmount(totalRefund);
        returnEntity = returnRepository.save(returnEntity);
        
        // Publish event (non-blocking)
        try {
            kafkaTemplate.send("return.requested", rmaNumber,
                    String.format("{\"returnId\":%d,\"orderId\":%d,\"rmaNumber\":\"%s\"}", 
                            returnEntity.getId(), orderId, rmaNumber));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for return request: {}", e.getMessage());
        }
        
        return returnEntity;
    }
    
    @Transactional
    public Return approveReturn(Long returnId, String actorId) {
        Return returnEntity = returnRepository.findById(returnId)
                .orElseThrow(() -> new RuntimeException("Return not found"));
        
        if (!"REQUESTED".equals(returnEntity.getStatus())) {
            throw new RuntimeException("Return must be REQUESTED to approve");
        }
        
        returnEntity.setStatus("APPROVED");
        returnEntity.setApprovedAt(LocalDateTime.now());
        returnEntity = returnRepository.save(returnEntity);
        
        // Restock inventory - mandatory for return approval
        try {
            for (ReturnItem item : returnEntity.getItems()) {
                inventoryServiceClient.adjustInventory(item.getSku(), "default-warehouse", item.getQuantity());
            }
            returnEntity.setRestocked(true);
            log.info("Inventory restocked for return: {}", returnId);
        } catch (Exception e) {
            log.error("Failed to restock inventory for return {}: {}", returnId, e.getMessage());
            // Fail return approval if inventory adjustment fails
            throw new RuntimeException("Failed to restock inventory for return. Return approval aborted: " + e.getMessage(), e);
        }
        returnEntity = returnRepository.save(returnEntity);
        
        // Process refund - ONLY for items being returned in this return request
        Order order = orderRepository.findById(returnEntity.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // CRITICAL VALIDATION: Refund should ONLY be done for items that are being returned in THIS return request
        // Delivered items or partially delivered items that are NOT in the return request must NEVER be refunded
        // This ensures refund happens ONLY AFTER return is done for that specific item
        
        BigDecimal calculatedRefund = BigDecimal.ZERO;
        BigDecimal orderSubtotal = order.getSubtotal();
        BigDecimal orderTax = order.getTax();
        
        // Create final reference for use in lambdas (returnEntity may be reassigned)
        final Return finalReturnEntity = returnEntity;
        
        log.info("Processing refund for return {}: Validating refund amount for {} items being returned", 
                returnId, finalReturnEntity.getItems().size());
        
        // Track which SKUs are being returned in this return request
        java.util.Set<String> returnedSkus = finalReturnEntity.getItems().stream()
                .map(ReturnItem::getSku)
                .collect(java.util.stream.Collectors.toSet());
        
        // Verify that we're ONLY refunding items in the return request, NOT delivered items
        log.info("Items being returned in this return: {}", returnedSkus);
        log.info("All order items: {}", order.getItems().stream()
                .map(OrderItem::getSku)
                .collect(java.util.stream.Collectors.toList()));
        
        for (ReturnItem returnItem : returnEntity.getItems()) {
            OrderItem orderItem = order.getItems().stream()
                    .filter(item -> item.getSku().equals(returnItem.getSku()))
                    .findFirst()
                    .orElse(null);
            
            if (orderItem == null) {
                throw new RuntimeException(
                    String.format("Order item not found for SKU %s in return request", returnItem.getSku()));
            }
            
            // CRITICAL: Verify the item is actually in the order and not already fully returned
            BigInteger alreadyReturned = orderItem.getReturnedQuantity() != null ? 
                    orderItem.getReturnedQuantity() : BigInteger.ZERO;
            BigInteger remainingQty = orderItem.getQuantity().subtract(alreadyReturned);
            
            // Calculate how much of this item is still delivered (not returned)
            BigInteger deliveredQty = remainingQty.subtract(returnItem.getQuantity());
            
            if (returnItem.getQuantity().compareTo(remainingQty) > 0) {
                throw new RuntimeException(
                    String.format("Cannot return more items than available. SKU: %s, Requested: %d, Available: %d, Already Returned: %d, Ordered: %d", 
                            returnItem.getSku(), returnItem.getQuantity(), remainingQty, alreadyReturned, orderItem.getQuantity()));
            }
            
            // CRITICAL: Calculate refund ONLY for the quantity being returned in THIS return request
            // Delivered quantity (remainingQty - returnItem.getQuantity()) is NOT included in refund
            BigDecimal itemLineTotal = orderItem.getUnitPrice().multiply(new BigDecimal(returnItem.getQuantity()));
            BigDecimal taxRatio = BigDecimal.ZERO;
            if (orderSubtotal.compareTo(BigDecimal.ZERO) > 0) {
                taxRatio = itemLineTotal.divide(orderSubtotal, 4, java.math.RoundingMode.HALF_UP)
                        .multiply(orderTax);
            }
            BigDecimal itemRefund = itemLineTotal.add(taxRatio);
            calculatedRefund = calculatedRefund.add(itemRefund);
            
            log.info("Refund calculation for SKU {}: Returned Qty={}, Delivered Qty={}, UnitPrice={}, LineTotal={}, Tax={}, ItemRefund={}", 
                    returnItem.getSku(), returnItem.getQuantity(), deliveredQty, orderItem.getUnitPrice(), 
                    itemLineTotal, taxRatio, itemRefund);
            log.info("CRITICAL: Refund for SKU {} is ONLY for returned quantity ({}), NOT for delivered quantity ({})", 
                    returnItem.getSku(), returnItem.getQuantity(), deliveredQty);
        }
        
        // CRITICAL: Verify that delivered items (not in return request) are NOT included in refund
        for (OrderItem orderItem : order.getItems()) {
            if (!returnedSkus.contains(orderItem.getSku())) {
                BigInteger returnedQty = orderItem.getReturnedQuantity() != null ? 
                        orderItem.getReturnedQuantity() : BigInteger.ZERO;
                BigInteger deliveredQty = orderItem.getQuantity().subtract(returnedQty);
                if (deliveredQty.compareTo(BigInteger.ZERO) > 0) {
                    log.info("VERIFIED: SKU {} is delivered (Qty: {}) and NOT in return request - will NOT be refunded", 
                            orderItem.getSku(), deliveredQty);
                }
            }
        }
        
        // Verify refund amount matches calculated amount (with small tolerance for rounding)
        BigDecimal refundDifference = finalReturnEntity.getRefundAmount().subtract(calculatedRefund).abs();
        if (refundDifference.compareTo(new BigDecimal("0.01")) > 0) {
            log.warn("Refund amount mismatch for return {}. Stored: {}, Calculated: {}. Using calculated amount.", 
                    returnId, finalReturnEntity.getRefundAmount(), calculatedRefund);
            returnEntity.setRefundAmount(calculatedRefund);
            returnEntity = returnRepository.save(returnEntity);
        }
        
        log.info("Total refund amount for return {}: {} (calculated for {} returned items only)", 
                returnId, calculatedRefund, finalReturnEntity.getItems().size());
        log.info("CRITICAL VALIDATION: Refund amount {} is ONLY for items in return request. Delivered items are NOT refunded.", 
                calculatedRefund);
        
        // Final validation: Ensure refund amount does not exceed the value of returned items
        // This prevents any possibility of refunding delivered items
        BigDecimal maxRefundForReturnedItems = order.getItems().stream()
                .filter(item -> returnedSkus.contains(item.getSku()))
                .map(item -> {
                    ReturnItem returnItem = finalReturnEntity.getItems().stream()
                            .filter(ri -> ri.getSku().equals(item.getSku()))
                            .findFirst()
                            .orElse(null);
                    if (returnItem == null) return BigDecimal.ZERO;
                    BigDecimal itemLineTotal = item.getUnitPrice().multiply(new BigDecimal(returnItem.getQuantity()));
                    BigDecimal taxRatio = BigDecimal.ZERO;
                    if (orderSubtotal.compareTo(BigDecimal.ZERO) > 0) {
                        taxRatio = itemLineTotal.divide(orderSubtotal, 4, java.math.RoundingMode.HALF_UP)
                                .multiply(orderTax);
                    }
                    return itemLineTotal.add(taxRatio);
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        
        if (calculatedRefund.compareTo(maxRefundForReturnedItems.add(new BigDecimal("0.01"))) > 0) {
            throw new RuntimeException(
                String.format("CRITICAL ERROR: Refund amount (%.2f) exceeds maximum for returned items (%.2f). " +
                        "This indicates delivered items may be included in refund, which is not allowed.", 
                        calculatedRefund.doubleValue(), maxRefundForReturnedItems.doubleValue()));
        }
        
        // Update returned quantities for order items (ONLY for items in this return)
        // This tracks which items have been returned and prevents duplicate return requests
        for (ReturnItem returnItem : finalReturnEntity.getItems()) {
            OrderItem orderItem = order.getItems().stream()
                    .filter(item -> item.getSku().equals(returnItem.getSku()))
                    .findFirst()
                    .orElse(null);
            if (orderItem != null) {
                BigInteger currentReturned = orderItem.getReturnedQuantity() != null ? 
                        orderItem.getReturnedQuantity() : BigInteger.ZERO;
                BigInteger newReturnedQty = currentReturned.add(returnItem.getQuantity());
                orderItem.setReturnedQuantity(newReturnedQty);
                log.info("Updated returned quantity for SKU {}: {} -> {} (returned {} in this return). " +
                        "Ordered: {}, Remaining: {}", 
                        returnItem.getSku(), currentReturned, newReturnedQty, returnItem.getQuantity(),
                        orderItem.getQuantity(), orderItem.getQuantity().subtract(newReturnedQty));
            }
        }
        orderRepository.save(order);
        
        // CRITICAL: Call payment service to refund - ONLY the amount for items being returned in THIS return
        // This refund is calculated ONLY for returned items, NOT for delivered or partially delivered items
        // Refund happens ONLY AFTER return is done for that specific item
        try {
            log.info("Processing refund for return {}: Amount {} (for {} items being returned)", 
                    returnId, finalReturnEntity.getRefundAmount(), finalReturnEntity.getItems().size());
            
            // Calculate delivered items value to verify they're NOT being refunded
            BigDecimal deliveredItemsValue = order.getItems().stream()
                    .filter(item -> !returnedSkus.contains(item.getSku()))
                    .map(item -> {
                        BigInteger returnedQty = item.getReturnedQuantity() != null ? 
                                item.getReturnedQuantity() : BigInteger.ZERO;
                        BigInteger deliveredQty = item.getQuantity().subtract(returnedQty);
                        return item.getUnitPrice().multiply(new BigDecimal(deliveredQty));
                    })
                    .reduce(BigDecimal.ZERO, BigDecimal::add);
            
            log.info("Refund breakdown: Order Total={}, Refund Amount={}, Items Returned={}, Items Still Delivered={}, Delivered Items Value={}", 
                    order.getTotal(), finalReturnEntity.getRefundAmount(), 
                    finalReturnEntity.getItems().size(), 
                    order.getItems().size() - finalReturnEntity.getItems().size(),
                    deliveredItemsValue);
            log.info("CRITICAL: Refund amount {} is ONLY for returned items. Delivered items value {} is NOT included in refund.", 
                    finalReturnEntity.getRefundAmount(), deliveredItemsValue);
            
            paymentServiceClient.refund(order.getId(), finalReturnEntity.getRefundAmount());
            log.info("Refund processed successfully for return: {} - Amount: {} (ONLY for returned items, delivered items NOT refunded)", 
                    returnId, finalReturnEntity.getRefundAmount());
        } catch (Exception e) {
            log.error("Failed to process refund for return {}: {}", returnId, e.getMessage());
            throw new RuntimeException("Failed to process refund: " + e.getMessage(), e);
        }
        
        // Determine order status based on item-level return completeness
        // This ensures order status accurately reflects which items are returned vs delivered
        boolean allItemsReturned = order.getItems().stream()
                .allMatch(item -> {
                    BigInteger returnedQty = item.getReturnedQuantity() != null ? 
                            item.getReturnedQuantity() : BigInteger.ZERO;
                    boolean fullyReturned = returnedQty.compareTo(item.getQuantity()) >= 0;
                    log.debug("Item status check - SKU: {}, Ordered: {}, Returned: {}, Fully Returned: {}", 
                            item.getSku(), item.getQuantity(), returnedQty, fullyReturned);
                    return fullyReturned;
                });
        
        // Update order status based on item-level states:
        // - RETURNED: All items fully returned (returnedQuantity >= quantity for all items)
        // - PARTIALLY_RETURNED: Some items returned but not all
        // This ensures delivered items are not marked as returned
        try {
            OrderStatus newStatus = allItemsReturned ? OrderStatus.RETURNED : OrderStatus.PARTIALLY_RETURNED;
            OrderStatus oldStatus = order.getStatus();
            order.setStatus(newStatus);
            orderRepository.save(order);
            log.info("Order {} status updated: {} -> {} after return approval. All items returned: {}", 
                    order.getId(), oldStatus, newStatus, allItemsReturned);
            
            // Log item-level status for debugging
            order.getItems().forEach(item -> {
                BigInteger returnedQty = item.getReturnedQuantity() != null ? 
                        item.getReturnedQuantity() : BigInteger.ZERO;
                log.info("Item status - SKU: {}, Ordered: {}, Returned: {}, Remaining: {}, Status: {}", 
                        item.getSku(), item.getQuantity(), returnedQty, 
                        item.getQuantity().subtract(returnedQty),
                        returnedQty.compareTo(item.getQuantity()) >= 0 ? "RETURNED" : "DELIVERED");
            });
        } catch (Exception e) {
            log.error("Failed to update order status after return approval: {}", e.getMessage());
            // Continue - order status update is not critical for return completion
        }
        
        returnEntity.setStatus("COMPLETED");
        returnEntity.setCompletedAt(LocalDateTime.now());
        returnEntity = returnRepository.save(returnEntity);
        
        // Publish event (non-blocking)
        try {
            kafkaTemplate.send("return.completed", returnEntity.getRmaNumber(),
                    String.format("{\"returnId\":%d,\"refundAmount\":%s}", 
                            returnEntity.getId(), returnEntity.getRefundAmount()));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for return completion: {}", e.getMessage());
        }
        
        return returnEntity;
    }
    
    @Transactional
    public Return rejectReturn(Long returnId, String reason, String actorId) {
        Return returnEntity = returnRepository.findById(returnId)
                .orElseThrow(() -> new RuntimeException("Return not found"));
        
        returnEntity.setStatus("REJECTED");
        returnEntity.setReason(returnEntity.getReason() + " | Rejection: " + reason);
        returnEntity = returnRepository.save(returnEntity);
        
        return returnEntity;
    }
    
    public List<Return> getReturnsByOrder(Long orderId) {
        return returnRepository.findByOrderIdAndDeletedFalse(orderId);
    }
    
    // DTO for return item request
    public static class ReturnItemRequest {
        private String sku;
        private java.math.BigInteger quantity;
        
        public String getSku() { return sku; }
        public void setSku(String sku) { this.sku = sku; }
        public java.math.BigInteger getQuantity() { return quantity; }
        public void setQuantity(java.math.BigInteger quantity) { this.quantity = quantity; }
    }
}

