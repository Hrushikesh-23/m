package com.retailx.order.messaging;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

/**
 * Kafka consumer for handling payment events from Payment Service.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentEventConsumer {
    
    private final OrderService orderService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Consume payment.captured events and update order status to PAID.
     */
    @KafkaListener(topics = "payment.captured", groupId = "order-service-group")
    public void handlePaymentCaptured(String message, Acknowledgment acknowledgment) {
        log.info("Received payment.captured event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long orderId = json.get("orderId").asLong();
            Long paymentIntentId = json.has("paymentIntentId") ? json.get("paymentIntentId").asLong() : null;
            
            log.info("Processing payment captured event: orderId={}, paymentIntentId={}", orderId, paymentIntentId);
            
            // Update order status to PAID
            orderService.updateOrderStatus(orderId, OrderStatus.PAID, "SYSTEM", 
                    "Payment captured - automatic status update");
            
            log.info("Order status updated to PAID: orderId={}", orderId);
            
            // Acknowledge the message
            if (acknowledgment != null) {
                acknowledgment.acknowledge();
            }
        } catch (Exception e) {
            log.error("Error processing payment.captured event: {}", message, e);
            // Don't acknowledge on error - message will be retried
            // In production, you might want to send to a dead-letter queue
        }
    }
    
    /**
     * Consume payment.failed events and cancel the order.
     */
    @KafkaListener(topics = "payment.failed", groupId = "order-service-group")
    public void handlePaymentFailed(String message, Acknowledgment acknowledgment) {
        log.info("Received payment.failed event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long orderId = json.get("orderId").asLong();
            String errorCode = json.has("errorCode") ? json.get("errorCode").asText() : "UNKNOWN";
            String errorMessage = json.has("errorMessage") ? json.get("errorMessage").asText() : "Payment failed";
            
            log.info("Processing payment failed event: orderId={}, errorCode={}, errorMessage={}", 
                    orderId, errorCode, errorMessage);
            
            // Cancel the order automatically when payment fails
            orderService.cancelOrder(orderId, "SYSTEM", 
                    String.format("Payment failed - %s: %s", errorCode, errorMessage));
            
            log.info("Order cancelled due to payment failure: orderId={}", orderId);
            
            // Acknowledge the message
            if (acknowledgment != null) {
                acknowledgment.acknowledge();
            }
        } catch (Exception e) {
            log.error("Error processing payment.failed event: {}", message, e);
            // Don't acknowledge on error - message will be retried
        }
    }
    
    /**
     * Consume payment.refunded events and cancel the order (if not already returned).
     */
    @KafkaListener(topics = "payment.refunded", groupId = "order-service-group")
    public void handlePaymentRefunded(String message, Acknowledgment acknowledgment) {
        log.info("Received payment.refunded event: {}", message);
        try {
            JsonNode json = objectMapper.readTree(message);
            Long orderId = json.get("orderId").asLong();
            String refundAmount = json.has("refundAmount") ? json.get("refundAmount").asText() : "0";
            
            log.info("Processing payment refunded event: orderId={}, refundAmount={}", orderId, refundAmount);
            
            // Check if order is already in RETURNED or PARTIALLY_RETURNED status (from return approval)
            // If not, cancel the order when payment is refunded
            try {
                // Use lightweight status check to avoid lazy loading issues
                OrderStatus currentStatus = orderService.getOrderStatus(orderId);
                
                // Skip cancellation if order is already in terminal states (DELIVERED, RETURNED, PARTIALLY_RETURNED)
                if (currentStatus == OrderStatus.DELIVERED || 
                    currentStatus == OrderStatus.RETURNED || 
                    currentStatus == OrderStatus.PARTIALLY_RETURNED) {
                    log.info("Order already in {} status, skipping cancellation: orderId={}", currentStatus, orderId);
                } else {
                    // Only cancel if not in terminal states
                    orderService.cancelOrder(orderId, "SYSTEM", 
                            String.format("Payment refunded - amount: %s", refundAmount));
                    log.info("Order cancelled due to payment refund: orderId={}", orderId);
                }
            } catch (Exception e) {
                // If we can't check status or cancellation fails, log the error but don't retry
                // The order might already be in a state that prevents cancellation
                log.warn("Could not process payment refund for order: orderId={}, error={}. " +
                        "Order may already be in a terminal state (DELIVERED/RETURNED/PARTIALLY_RETURNED).", 
                        orderId, e.getMessage());
            }
            
            // Acknowledge the message
            if (acknowledgment != null) {
                acknowledgment.acknowledge();
            }
        } catch (Exception e) {
            log.error("Error processing payment.refunded event: {}", message, e);
            // Don't acknowledge on error - message will be retried
        }
    }
}

