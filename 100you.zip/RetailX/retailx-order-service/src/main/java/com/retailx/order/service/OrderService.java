package com.retailx.order.service;

import com.retailx.order.domain.AuditLog;
import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.OrderVersion;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.dto.response.OrderItemResponse;
import com.retailx.order.dto.response.OrderResponse;
import com.retailx.order.repository.AuditLogRepository;
import com.retailx.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Service for order management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {
    
    private final OrderRepository orderRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final PaymentServiceClient paymentServiceClient;
    private final AuditLogRepository auditLogRepository;
    private static final int MAX_VERSIONS = 10;
    
    @Transactional(readOnly = true)
    public OrderResponse getOrderById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + id));
        
        if (order.getDeleted()) {
            throw new RuntimeException("Order not found with id: " + id);
        }
        
        return mapToResponse(order);
    }
    
    /**
     * Get order status only (without loading items) - for lightweight status checks.
     */
    @Transactional(readOnly = true)
    public OrderStatus getOrderStatus(Long orderId) {
        return orderRepository.findById(orderId)
                .map(Order::getStatus)
                .orElseThrow(() -> new RuntimeException("Order not found with id: " + orderId));
    }
    
    public OrderResponse getOrderByNumber(String orderNumber) {
        Order order = orderRepository.findByOrderNumberAndDeletedFalse(orderNumber)
                .orElseThrow(() -> new RuntimeException("Order not found: " + orderNumber));
        
        return mapToResponse(order);
    }
    
    public Page<OrderResponse> getOrdersByCustomer(Long customerId, Pageable pageable) {
        Page<Order> orders = orderRepository.findByCustomerIdAndDeletedFalse(customerId, pageable);
        return orders.map(this::mapToResponse);
    }
    
    public Page<OrderResponse> getOrdersByMerchant(Long merchantId, Pageable pageable) {
        Page<Order> orders = orderRepository.findByMerchantIdAndDeletedFalse(merchantId, pageable);
        return orders.map(this::mapToResponse);
    }
    
    @Transactional
    public OrderResponse updateOrderStatus(Long orderId, OrderStatus newStatus, String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        OrderStatus oldStatus = order.getStatus();
        
        // Validate state transition
        validateOrderStatusTransition(oldStatus, newStatus);
        
        order.setStatus(newStatus);
        order = orderRepository.save(order);
        
        // Log audit trail
        logAudit(orderId, "STATUS_CHANGED", actorId, null, oldStatus.name(), newStatus.name(), reason);
        
        log.info("Order status updated: orderId={}, {} -> {}, actor={}, reason={}", 
                orderId, oldStatus, newStatus, actorId, reason);
        
        return mapToResponse(order);
    }
    
    /**
     * Validates order status transitions to prevent invalid state changes.
     */
    private void validateOrderStatusTransition(OrderStatus currentStatus, OrderStatus newStatus) {
        // Same status is always allowed (idempotency)
        if (currentStatus == newStatus) {
            return;
        }
        
        // Cannot change status if already in terminal states
        if (currentStatus == OrderStatus.CANCELLED) {
            throw new RuntimeException(
                String.format("Cannot change status from CANCELLED. Current: %s, Requested: %s", 
                    currentStatus, newStatus));
        }
        
        if (currentStatus == OrderStatus.DELIVERED) {
            throw new RuntimeException(
                String.format("Cannot change status from DELIVERED. Current: %s, Requested: %s", 
                    currentStatus, newStatus));
        }
        
        if (currentStatus == OrderStatus.RETURNED) {
            throw new RuntimeException(
                String.format("Cannot change status from RETURNED. Current: %s, Requested: %s", 
                    currentStatus, newStatus));
        }
        
        // Cannot go backwards in the lifecycle (except specific cases)
        if (newStatus == OrderStatus.PENDING && 
            (currentStatus == OrderStatus.PAID || currentStatus == OrderStatus.FULFILLING 
             || currentStatus == OrderStatus.SHIPPED || currentStatus == OrderStatus.DELIVERED)) {
            throw new RuntimeException(
                String.format("Cannot revert order from %s to PENDING", currentStatus));
        }
        
        // Cannot mark as DELIVERED if not SHIPPED
        if (newStatus == OrderStatus.DELIVERED && currentStatus != OrderStatus.SHIPPED) {
            throw new RuntimeException(
                String.format("Cannot mark order as DELIVERED. Order must be SHIPPED first. Current: %s", 
                    currentStatus));
        }
        
        // Cannot mark as SHIPPED if not PAID or FULFILLING
        if (newStatus == OrderStatus.SHIPPED && 
            currentStatus != OrderStatus.PAID && currentStatus != OrderStatus.FULFILLING) {
            throw new RuntimeException(
                String.format("Cannot mark order as SHIPPED. Order must be PAID or FULFILLING first. Current: %s", 
                    currentStatus));
        }
        
        // Cannot mark as PAID if order is cancelled
        if (newStatus == OrderStatus.PAID && currentStatus == OrderStatus.CANCELLED) {
            throw new RuntimeException("Cannot mark cancelled order as PAID");
        }
    }
    
    @Transactional
    public OrderResponse updateOrderPreFulfillment(Long orderId, String shippingAddress, 
                                                   String shippingMethod, String giftNote, 
                                                   String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Validate order can still be updated
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new RuntimeException("Cannot update a cancelled order");
        }
        
        if (order.getStatus() == OrderStatus.DELIVERED) {
            throw new RuntimeException("Cannot update a delivered order");
        }
        
        if (order.getStatus() == OrderStatus.RETURNED || order.getStatus() == OrderStatus.PARTIALLY_RETURNED) {
            throw new RuntimeException("Cannot update a returned order");
        }
        
        if (order.getStatus().ordinal() >= OrderStatus.SHIPPED.ordinal()) {
            throw new RuntimeException(
                String.format("Cannot update order after it has been shipped. Current status: %s", 
                    order.getStatus()));
        }
        
        // Create version history
        if (order.getVersions().size() >= MAX_VERSIONS) {
            // Remove oldest version
            order.getVersions().remove(0);
        }
        
        OrderVersion version = OrderVersion.builder()
                .order(order)
                .versionNumber(order.getVersion())
                .shippingAddress(order.getShippingAddress())
                .shippingMethod(order.getShippingMethod())
                .giftNote(order.getGiftNote())
                .shipping(order.getShipping())
                .changedBy(actorId)
                .changeReason(reason)
                .build();
        
        order.getVersions().add(version);
        
        // Update order
        order.setShippingAddress(shippingAddress);
        order.setShippingMethod(shippingMethod);
        order.setGiftNote(giftNote);
        order.setVersion(order.getVersion() + 1);
        
        order = orderRepository.save(order);
        
        return mapToResponse(order);
    }
    
    @Transactional
    public OrderResponse cancelOrder(Long orderId, String actorId, String reason) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        // Validate cancellation is allowed
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new RuntimeException("Order is already cancelled");
        }
        
        if (order.getStatus() == OrderStatus.DELIVERED) {
            throw new RuntimeException("Cannot cancel a delivered order. Please process a return instead.");
        }
        
        if (order.getStatus() == OrderStatus.RETURNED || order.getStatus() == OrderStatus.PARTIALLY_RETURNED) {
            throw new RuntimeException("Cannot cancel a returned order");
        }
        
        if (order.getStatus().ordinal() >= OrderStatus.SHIPPED.ordinal()) {
            throw new RuntimeException(
                String.format("Cannot cancel order after it has been shipped. Current status: %s", 
                    order.getStatus()));
        }
        
        // Release reserved inventory
        releaseOrderInventory(order);
        
        // If order is PAID, process refund
        if (order.getStatus() == OrderStatus.PAID) {
            try {
                log.info("Order is PAID, processing refund for order: {}", orderId);
                paymentServiceClient.refund(orderId, order.getTotal());
                log.info("Refund processed for order: {}", orderId);
            } catch (Exception e) {
                log.error("Failed to process refund for cancelled order {}: {}", orderId, e.getMessage());
                // Continue with cancellation even if refund fails (can be processed manually)
            }
        }
        
        order.setStatus(OrderStatus.CANCELLED);
        order = orderRepository.save(order);
        
        // Log audit trail
        logAudit(orderId, "CANCELLED", actorId, null, order.getStatus().name(), OrderStatus.CANCELLED.name(), reason);
        
        log.info("Order cancelled: orderId={}, actor={}, reason={}", orderId, actorId, reason);
        
        return mapToResponse(order);
    }
    
    /**
     * Release reserved inventory for an order.
     */
    private void releaseOrderInventory(Order order) {
        log.info("Releasing reserved inventory for order: {}", order.getId());
        for (OrderItem item : order.getItems()) {
            try {
                // Try WH-001 first, then default-warehouse
                boolean released = inventoryServiceClient.releaseReservedInventory(
                        item.getSku(), item.getQuantity(), "WH-001");
                if (!released) {
                    released = inventoryServiceClient.releaseReservedInventory(
                            item.getSku(), item.getQuantity(), "default-warehouse");
                }
                if (!released) {
                    log.warn("Failed to release reserved inventory: sku={}, quantity={}", 
                            item.getSku(), item.getQuantity());
                }
            } catch (Exception e) {
                log.error("Error releasing reserved inventory: sku={}, error={}", 
                        item.getSku(), e.getMessage());
            }
        }
    }
    
    private OrderResponse mapToResponse(Order order) {
        List<OrderItemResponse> items = order.getItems().stream()
                .map(this::mapItemToResponse)
                .collect(Collectors.toList());
        
        return OrderResponse.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .customerId(order.getCustomerId())
                .merchantId(order.getMerchantId())
                .status(order.getStatus())
                .items(items)
                .subtotal(order.getSubtotal())
                .tax(order.getTax())
                .shipping(order.getShipping())
                .discount(order.getDiscount())
                .total(order.getTotal())
                .shippingAddress(order.getShippingAddress())
                .shippingMethod(order.getShippingMethod())
                .giftNote(order.getGiftNote())
                .version(order.getVersion())
                .createdOn(order.getCreatedOn())
                .updatedOn(order.getUpdatedOn())
                .build();
    }
    
    private OrderItemResponse mapItemToResponse(OrderItem item) {
        return OrderItemResponse.builder()
                .id(item.getId())
                .sku(item.getSku())
                .productName(item.getProductName())
                .quantity(item.getQuantity())
                .unitPrice(item.getUnitPrice())
                .lineTotal(item.getLineTotal())
                .build();
    }
    
    /**
     * Log audit trail for order operations.
     */
    private void logAudit(Long orderId, String action, String actorId, String actorRole, 
                         String oldStatus, String newStatus, String reason) {
        try {
            AuditLog auditLog = AuditLog.builder()
                    .orderId(orderId)
                    .action(action)
                    .actorId(actorId)
                    .actorRole(actorRole)
                    .oldStatus(oldStatus)
                    .newStatus(newStatus)
                    .reason(reason)
                    .timestamp(java.time.LocalDateTime.now())
                    .build();
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.warn("Failed to log audit trail: {}", e.getMessage());
            // Don't fail the operation if audit logging fails
        }
    }
    
    /**
     * Get audit log for an order.
     */
    public List<AuditLog> getOrderAuditLog(Long orderId) {
        return auditLogRepository.findByOrderIdOrderByTimestampDesc(orderId);
    }
}

