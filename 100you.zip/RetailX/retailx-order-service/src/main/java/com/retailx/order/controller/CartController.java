package com.retailx.order.controller;

import com.retailx.order.dto.request.AddToCartRequest;
import com.retailx.order.dto.response.CartResponse;
import com.retailx.order.service.CartService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

/**
 * REST controller for shopping cart operations.
 * Handles cart retrieval, adding/removing items, and cart management.
 */
@Slf4j
@RestController
@RequestMapping("/api/carts")
@RequiredArgsConstructor
public class CartController {
    
    private final CartService cartService;
    
    /**
     * Get or create cart for customer - only CUSTOMER or ADMIN can access.
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartResponse> getCart(@RequestHeader("X-User-Id") Long customerId) {
        log.info("Fetching cart for customer: {}", customerId);
        CartResponse response = cartService.getOrCreateCart(customerId);
        log.debug("Cart retrieved: totalItems={}, total={}", 
                response.getItems().size(), response.getTotal());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Add item to cart - only CUSTOMER or ADMIN can access.
     */
    @PostMapping("/items")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartResponse> addToCart(
            @RequestHeader("X-User-Id") Long customerId,
            @Valid @RequestBody AddToCartRequest request) {
        log.info("Adding item to cart: customerId={}, sku={}, quantity={}", 
                customerId, request.getSku(), request.getQuantity());
        CartResponse response = cartService.addToCart(customerId, request);
        log.info("Item added to cart successfully: customerId={}, sku={}", 
                customerId, request.getSku());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Update cart item quantity - only CUSTOMER or ADMIN can access.
     */
    @PutMapping("/items/{itemId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartResponse> updateCartItem(
            @RequestHeader("X-User-Id") Long customerId,
            @PathVariable Long itemId,
            @RequestParam BigInteger quantity) {
        log.info("Updating cart item: customerId={}, itemId={}, newQuantity={}", 
                customerId, itemId, quantity);
        CartResponse response = cartService.updateCartItem(customerId, itemId, quantity);
        log.info("Cart item updated successfully: itemId={}", itemId);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Remove item from cart - only CUSTOMER or ADMIN can access.
     */
    @DeleteMapping("/items/{itemId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartResponse> removeFromCart(
            @RequestHeader("X-User-Id") Long customerId,
            @PathVariable Long itemId) {
        log.info("Removing item from cart: customerId={}, itemId={}", customerId, itemId);
        CartResponse response = cartService.removeFromCart(customerId, itemId);
        log.info("Item removed from cart successfully: itemId={}", itemId);
        return ResponseEntity.ok(response);
    }
    
    /**
     * Clear entire cart - only CUSTOMER or ADMIN can access.
     */
    @DeleteMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Void> clearCart(@RequestHeader("X-User-Id") Long customerId) {
        log.info("Clearing cart for customer: {}", customerId);
        cartService.clearCart(customerId);
        log.info("Cart cleared successfully: customerId={}", customerId);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Order Service is running");
    }
}

