package com.retailx.order.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Utility for generating unique order numbers.
 * Uses timestamp + UUID to ensure uniqueness even in concurrent scenarios.
 */
public class OrderNumberGenerator {
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static volatile int sequence = 0;
    private static volatile String lastDate = "";
    
    /**
     * Generates a unique order number.
     * Format: ORD-YYYYMMDD-XXXXXX-UUID
     * Includes UUID suffix to ensure uniqueness even with concurrent requests.
     */
    public static synchronized String generate() {
        String date = LocalDateTime.now().format(FORMATTER);
        
        // Reset sequence if date changed
        if (!date.equals(lastDate)) {
            sequence = 0;
            lastDate = date;
        }
        
        sequence = (sequence + 1) % 1000000;
        
        // Add UUID suffix (first 8 chars) to ensure uniqueness
        String uuidSuffix = UUID.randomUUID().toString().substring(0, 8).replace("-", "").toUpperCase();
        
        return String.format("ORD-%s-%06d-%s", date, sequence, uuidSuffix);
    }
}

