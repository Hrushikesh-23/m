package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Shipment;
import com.retailx.order.domain.ShipmentItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ShipmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Service for shipment and fulfillment operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ShipmentService {
    
    private final ShipmentRepository shipmentRepository;
    private final OrderRepository orderRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final OrderService orderService;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    // Tracking number format validation patterns
    private static final String FEDEX_PATTERN = "^\\d{12}$";
    private static final String UPS_PATTERN = "^1Z[0-9A-Z]{16}$";
    private static final String USPS_PATTERN = "^\\d{20,22}$";
    
    @Transactional
    public Shipment createShipment(Long orderId, String carrier, String trackingNumber, List<String> skus) {
        log.info("Creating shipment for order: {}", orderId);
        
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (order.getStatus() != OrderStatus.PAID && order.getStatus() != OrderStatus.FULFILLING) {
            throw new RuntimeException("Order must be PAID or FULFILLING to create shipment");
        }
        
        // Validate tracking number format based on carrier
        validateTrackingNumber(carrier, trackingNumber);
        
        String shipmentNumber = "SHP-" + LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd")) + "-" + 
                UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        Shipment shipment = Shipment.builder()
                .orderId(orderId)
                .shipmentNumber(shipmentNumber)
                .carrier(carrier)
                .trackingNumber(trackingNumber)
                .shippedAt(LocalDateTime.now())
                .build();
        
        // Validate shipment items
        if (skus != null && !skus.isEmpty()) {
            // Validate all SKUs exist in order
            for (String sku : skus) {
                boolean exists = order.getItems().stream()
                        .anyMatch(item -> item.getSku().equals(sku));
                if (!exists) {
                    throw new RuntimeException("Shipment item SKU not found in order: " + sku);
                }
            }
        }
        
        // Create shipment items from order items with validation
        final Shipment finalShipment = shipment;
        List<ShipmentItem> shipmentItems = new java.util.ArrayList<>();
        
        for (OrderItem orderItem : order.getItems()) {
            // Filter by SKUs if provided
            if (skus != null && !skus.isEmpty() && !skus.contains(orderItem.getSku())) {
                continue;
            }
            
            // Validate shipment quantity doesn't exceed order quantity
            // For now, ship full quantity - can be enhanced for partial shipments
            BigInteger shipmentQty = orderItem.getQuantity();
            
            // Validate SKU matches
            if (!orderItem.getSku().equals(orderItem.getSku())) {
                throw new RuntimeException("Shipment item SKU mismatch with order item");
            }
            
            ShipmentItem shipmentItem = ShipmentItem.builder()
                    .shipment(finalShipment)
                    .sku(orderItem.getSku())
                    .quantity(shipmentQty)
                    .build();
            shipmentItems.add(shipmentItem);
        }
        
        if (shipmentItems.isEmpty()) {
            throw new RuntimeException("No valid shipment items to create");
        }
        
        shipment.setItems(shipmentItems);
        shipment = shipmentRepository.save(shipment);
        
        // Update order status via OrderService (maintain separation of concerns)
        orderService.updateOrderStatus(orderId, OrderStatus.SHIPPED, "SYSTEM", 
                "Shipment created - automatic status update");
        
        // Publish event (non-blocking)
        try {
            kafkaTemplate.send("shipment.created", shipmentNumber,
                    String.format("{\"shipmentId\":%d,\"orderId\":%d,\"trackingNumber\":\"%s\"}", 
                            shipment.getId(), orderId, trackingNumber));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for shipment creation: {}", e.getMessage());
        }
        
        return shipment;
    }
    
    @Transactional
    public Shipment markDelivered(Long shipmentId) {
        Shipment shipment = shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
        
        shipment.setDeliveredAt(LocalDateTime.now());
        shipment = shipmentRepository.save(shipment);
        
        // Update order status via OrderService (maintain separation of concerns)
        orderService.updateOrderStatus(shipment.getOrderId(), OrderStatus.DELIVERED, "SYSTEM", 
                "Shipment delivered - automatic status update");
        
        // Publish event (non-blocking)
        try {
            kafkaTemplate.send("order.delivered", String.valueOf(shipment.getOrderId()),
                    String.format("{\"orderId\":%d,\"shipmentId\":%d}", shipment.getOrderId(), shipmentId));
        } catch (Exception e) {
            log.warn("Failed to send Kafka event for order delivery: {}", e.getMessage());
        }
        
        return shipment;
    }
    
    public List<Shipment> getShipmentsByOrder(Long orderId) {
        return shipmentRepository.findByOrderIdAndDeletedFalse(orderId);
    }
    
    /**
     * Validate tracking number format based on carrier.
     */
    private void validateTrackingNumber(String carrier, String trackingNumber) {
        if (trackingNumber == null || trackingNumber.trim().isEmpty()) {
            throw new RuntimeException("Tracking number is required");
        }
        
        // Basic validation - can be enhanced with carrier-specific formats
        if (trackingNumber.length() < 10 || trackingNumber.length() > 30) {
            throw new RuntimeException("Tracking number must be between 10 and 30 characters");
        }
        
        // Carrier-specific validation (optional, can be enhanced)
        if (carrier != null) {
            carrier = carrier.toUpperCase();
            if (carrier.contains("FEDEX")) {
                if (!trackingNumber.matches(FEDEX_PATTERN)) {
                    log.warn("Tracking number format may not match FedEx format: {}", trackingNumber);
                }
            } else if (carrier.contains("UPS")) {
                if (!trackingNumber.matches(UPS_PATTERN)) {
                    log.warn("Tracking number format may not match UPS format: {}", trackingNumber);
                }
            } else if (carrier.contains("USPS")) {
                if (!trackingNumber.matches(USPS_PATTERN)) {
                    log.warn("Tracking number format may not match USPS format: {}", trackingNumber);
                }
            }
        }
    }
}

