package com.retailx.order.domain.enums;

/**
 * Order lifecycle statuses.
 */
public enum OrderStatus {
    PENDING,
    PAID,
    FULFILLING,
    SHIPPED,
    DELIVERED,
    CANCELLED,
    RETURN_REQUESTED,
    PARTIALLY_RETURNED,
    RETURNED,
    REJECTED
}

