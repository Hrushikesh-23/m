package com.retailx.order.aspect;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * AOP aspect for audit trail logging.
 */
@Slf4j
@Aspect
@Component
public class AuditAspect {
    
    @Before("@annotation(com.retailx.order.annotation.Auditable)")
    public void logBefore(JoinPoint joinPoint) {
        String correlationId = UUID.randomUUID().toString();
        MDC.put("correlationId", correlationId);
        
        log.info("Audit: Method={}, Args={}", 
                joinPoint.getSignature().toShortString(), 
                sanitizeArgs(joinPoint.getArgs()));
    }
    
    @AfterReturning(pointcut = "@annotation(com.retailx.order.annotation.Auditable)", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        log.info("Audit: Method={}, Result={}", 
                joinPoint.getSignature().toShortString(), 
                sanitizeResult(result));
        MDC.clear();
    }
    
    private String sanitizeArgs(Object[] args) {
        if (args == null || args.length == 0) {
            return "[]";
        }
        // Sanitize sensitive data
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < args.length; i++) {
            if (i > 0) sb.append(", ");
            String argStr = String.valueOf(args[i]);
            // Mask sensitive fields
            if (argStr.contains("password") || argStr.contains("token")) {
                sb.append("***");
            } else {
                sb.append(argStr.length() > 100 ? argStr.substring(0, 100) + "..." : argStr);
            }
        }
        sb.append("]");
        return sb.toString();
    }
    
    private String sanitizeResult(Object result) {
        if (result == null) {
            return "null";
        }
        String resultStr = result.toString();
        return resultStr.length() > 200 ? resultStr.substring(0, 200) + "..." : resultStr;
    }
}

