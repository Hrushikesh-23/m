﻿-- Fix status column length to support PARTIALLY_RETURNED (20 characters)
-- Run this script on the retailx_order database

USE retailx_order;

-- Update status column to VARCHAR(50) to support all status values
ALTER TABLE orders MODIFY COLUMN status VARCHAR(50) NOT NULL;

-- Verify the change
DESCRIBE orders;
