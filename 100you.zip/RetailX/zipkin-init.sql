-- Zipkin Database Initialization Script
-- Run this script to create the zipkin database for distributed tracing

CREATE DATABASE IF NOT EXISTS zipkin CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE zipkin;

-- Zipkin will create its own tables automatically on first startup
-- This script just ensures the database exists

