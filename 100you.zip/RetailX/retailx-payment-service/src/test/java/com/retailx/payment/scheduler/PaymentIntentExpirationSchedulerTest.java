package com.retailx.payment.scheduler;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PaymentIntentExpirationScheduler.
 */
@ExtendWith(MockitoExtension.class)
class PaymentIntentExpirationSchedulerTest {
    
    @Mock
    private PaymentIntentRepository paymentIntentRepository;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private PaymentIntentExpirationScheduler scheduler;
    
    private PaymentIntent expiredIntent;
    
    @BeforeEach
    void setUp() {
        // Set expiration minutes using reflection
        try {
            java.lang.reflect.Field field = PaymentIntentExpirationScheduler.class.getDeclaredField("paymentIntentExpirationMinutes");
            field.setAccessible(true);
            field.setInt(scheduler, 30);
        } catch (Exception e) {
            // Ignore
        }
        
        expiredIntent = PaymentIntent.builder()
                .orderId(1L)
                .amount(new BigDecimal("100.00"))
                .currency("USD")
                .status(PaymentStatus.PENDING)
                .build();
        // Set ID and createdOn using reflection
        try {
            java.lang.reflect.Field idField = expiredIntent.getClass().getSuperclass().getDeclaredField("id");
            idField.setAccessible(true);
            idField.set(expiredIntent, 1L);
            
            java.lang.reflect.Field createdOnField = expiredIntent.getClass().getSuperclass().getDeclaredField("createdOn");
            createdOnField.setAccessible(true);
            createdOnField.set(expiredIntent, LocalDateTime.now().minusMinutes(31));
        } catch (Exception e) {
            // Ignore
        }
    }
    
    @Test
    void testExpirePaymentIntents_WithExpiredIntents() {
        List<PaymentIntent> expiredIntents = Arrays.asList(expiredIntent);
        when(paymentIntentRepository.findByStatusAndCreatedOnBefore(
                eq(PaymentStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(expiredIntents);
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenReturn(expiredIntent);
        
        scheduler.expirePaymentIntents();
        
        verify(paymentIntentRepository, times(1)).findByStatusAndCreatedOnBefore(
                eq(PaymentStatus.PENDING), any(LocalDateTime.class));
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), anyString());
        // Verify the intent was updated
        verify(paymentIntentRepository).save(argThat(intent -> 
                intent.getStatus() == PaymentStatus.FAILED && 
                "PAYMENT_INTENT_EXPIRED".equals(intent.getErrorCode())));
    }
    
    @Test
    void testExpirePaymentIntents_NoExpiredIntents() {
        when(paymentIntentRepository.findByStatusAndCreatedOnBefore(
                eq(PaymentStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(Arrays.asList());
        
        scheduler.expirePaymentIntents();
        
        verify(paymentIntentRepository, times(1)).findByStatusAndCreatedOnBefore(
                eq(PaymentStatus.PENDING), any(LocalDateTime.class));
        verify(paymentIntentRepository, never()).save(any(PaymentIntent.class));
        verify(kafkaTemplate, never()).send(anyString(), anyString(), anyString());
    }
    
    @Test
    void testExpirePaymentIntents_KafkaFailure() {
        List<PaymentIntent> expiredIntents = Arrays.asList(expiredIntent);
        when(paymentIntentRepository.findByStatusAndCreatedOnBefore(
                eq(PaymentStatus.PENDING), any(LocalDateTime.class)))
                .thenReturn(expiredIntents);
        when(paymentIntentRepository.save(any(PaymentIntent.class))).thenReturn(expiredIntent);
        doThrow(new RuntimeException("Kafka error")).when(kafkaTemplate)
                .send(anyString(), anyString(), anyString());
        
        scheduler.expirePaymentIntents();
        
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), anyString());
    }
}

