package com.retailx.payment.config;

import feign.RequestInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Feign client configuration for Payment Service.
 * Forwards authentication headers to downstream services.
 */
@Slf4j
@Configuration
public class FeignConfig {
    
    @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            try {
                ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
                if (attributes != null) {
                    HttpServletRequest request = attributes.getRequest();
                    
                    // Forward user context headers
                    String userId = request.getHeader("X-User-Id");
                    String userEmail = request.getHeader("X-User-Email");
                    String userRoles = request.getHeader("X-User-Role");
                    
                    if (userId != null) {
                        requestTemplate.header("X-User-Id", userId);
                    }
                    if (userEmail != null) {
                        requestTemplate.header("X-User-Email", userEmail);
                    }
                    if (userRoles != null) {
                        requestTemplate.header("X-User-Role", userRoles);
                    }
                    
                    log.debug("Feign request - Forwarded headers: X-User-Id={}, X-User-Email={}, X-User-Role={}", 
                            userId, userEmail, userRoles);
                }
            } catch (Exception e) {
                log.warn("Failed to forward headers in Feign request: {}", e.getMessage());
            }
        };
    }
}

