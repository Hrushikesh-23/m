package com.retailx.payment.controller;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;

/**
 * Payment endpoints - create intent, authorize, capture, refund.
 */
@Slf4j
@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {
    
    private final PaymentService paymentService;
    
    /**
     * Create payment intent for an order.
     */
    @PostMapping("/intents")
    public ResponseEntity<PaymentIntent> createPaymentIntent(
            @RequestParam Long orderId,
            @RequestParam BigDecimal amount,
            @RequestParam String currency,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Creating payment intent: order {} amount {} {}", orderId, amount, currency);
        PaymentIntent paymentIntent = paymentService.createPaymentIntent(
                orderId, amount, currency, correlationId);
        log.info("Payment intent created: ID {} status {}", 
                paymentIntent.getId(), paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Authorize payment.
     */
    @PostMapping("/{paymentIntentId}/authorize")
    public ResponseEntity<PaymentIntent> authorize(
            @PathVariable Long paymentIntentId,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Authorizing payment: {}", paymentIntentId);
        PaymentIntent paymentIntent = paymentService.authorize(paymentIntentId, correlationId);
        log.info("Payment {} authorized: {}", paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Capture an authorized payment - accessible to authenticated users.
     */
    @PostMapping("/{paymentIntentId}/capture")
    public ResponseEntity<PaymentIntent> capture(
            @PathVariable Long paymentIntentId,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Capturing payment: paymentIntentId={}, idempotencyKey={}", 
                paymentIntentId, correlationId);
        PaymentIntent paymentIntent = paymentService.capture(paymentIntentId, correlationId);
        log.info("Payment captured: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Refund a payment - accessible to authenticated users (typically OPS/ADMIN).
     */
    @PostMapping("/{paymentIntentId}/refund")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN')")
    public ResponseEntity<PaymentIntent> refund(
            @PathVariable Long paymentIntentId,
            @RequestParam BigDecimal amount,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Processing refund: paymentIntentId={}, amount={}, idempotencyKey={}", 
                paymentIntentId, amount, correlationId);
        PaymentIntent paymentIntent = paymentService.refund(paymentIntentId, amount, correlationId);
        log.info("Refund processed: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Refund a payment by order ID - accessible to authenticated users (typically OPS/ADMIN/MERCHANT).
     * This endpoint is used by Order Service when processing returns.
     */
    @PostMapping("/refund")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN', 'MERCHANT')")
    public ResponseEntity<PaymentIntent> refundByOrderId(
            @RequestParam Long orderId,
            @RequestParam BigDecimal amount,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Processing refund by orderId: orderId={}, amount={}, idempotencyKey={}", 
                orderId, amount, correlationId);
        PaymentIntent paymentIntent = paymentService.refundByOrderId(orderId, amount, correlationId);
        log.info("Refund processed: orderId={}, paymentIntentId={}, status={}", 
                orderId, paymentIntent.getId(), paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    /**
     * Mark a payment as failed - accessible to authenticated users.
     * This endpoint allows explicit marking of payment as failed (e.g., when authorization fails).
     */
    @PostMapping("/{paymentIntentId}/fail")
    public ResponseEntity<PaymentIntent> failPayment(
            @PathVariable Long paymentIntentId,
            @RequestParam(required = false) String errorCode,
            @RequestParam(required = false) String errorMessage,
            @RequestHeader(value = "Idempotency-Key", required = false) String correlationId) {
        
        log.info("Marking payment as failed: paymentIntentId={}, errorCode={}, errorMessage={}, idempotencyKey={}", 
                paymentIntentId, errorCode, errorMessage, correlationId);
        PaymentIntent paymentIntent = paymentService.failPayment(
                paymentIntentId, 
                errorCode != null ? errorCode : "PAYMENT_FAILED",
                errorMessage != null ? errorMessage : "Payment failed",
                correlationId);
        log.info("Payment marked as failed: paymentIntentId={}, status={}", 
                paymentIntentId, paymentIntent.getStatus());
        return ResponseEntity.ok(paymentIntent);
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Payment Service is running");
    }
}

