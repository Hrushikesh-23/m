package com.retailx.auth.scheduler;

import com.retailx.auth.repository.PasswordResetTokenRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PasswordResetTokenCleanupScheduler.
 */
@ExtendWith(MockitoExtension.class)
class PasswordResetTokenCleanupSchedulerTest {
    
    @Mock
    private PasswordResetTokenRepository passwordResetTokenRepository;
    
    @InjectMocks
    private PasswordResetTokenCleanupScheduler scheduler;
    
    @Test
    void testCleanupExpiredTokens_Success() {
        doNothing().when(passwordResetTokenRepository).deleteByExpiresAtBefore(any(LocalDateTime.class));
        
        scheduler.cleanupExpiredTokens();
        
        verify(passwordResetTokenRepository, times(1)).deleteByExpiresAtBefore(any(LocalDateTime.class));
    }
    
    @Test
    void testCleanupExpiredTokens_WithException() {
        doThrow(new RuntimeException("Database error"))
                .when(passwordResetTokenRepository).deleteByExpiresAtBefore(any(LocalDateTime.class));
        
        try {
            scheduler.cleanupExpiredTokens();
        } catch (Exception e) {
            // Exception should be logged but not rethrown
        }
        
        verify(passwordResetTokenRepository, times(1)).deleteByExpiresAtBefore(any(LocalDateTime.class));
    }
}

