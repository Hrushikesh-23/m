package com.retailx.auth.controller;

import com.retailx.auth.dto.request.*;
import com.retailx.auth.dto.response.AuthResponse;
import com.retailx.auth.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for AuthController.
 */
@ExtendWith(MockitoExtension.class)
class AuthControllerTest {
    
    @Mock
    private AuthService authService;
    
    @InjectMocks
    private AuthController authController;
    
    private RegisterRequest registerRequest;
    private LoginRequest loginRequest;
    private UpdateEmailRequest updateEmailRequest;
    private UpdatePasswordRequest updatePasswordRequest;
    private ForgotPasswordRequest forgotPasswordRequest;
    private ResetPasswordRequest resetPasswordRequest;
    private AuthResponse authResponse;
    
    @BeforeEach
    void setUp() {
        registerRequest = new RegisterRequest();
        registerRequest.setEmail("test@example.com");
        registerRequest.setPassword("Password@123");
        registerRequest.setName("Test User");
        registerRequest.setRole("CUSTOMER");
        
        loginRequest = new LoginRequest();
        loginRequest.setEmail("test@example.com");
        loginRequest.setPassword("Password@123");
        
        updateEmailRequest = new UpdateEmailRequest();
        updateEmailRequest.setNewEmail("newemail@example.com");
        
        updatePasswordRequest = new UpdatePasswordRequest();
        updatePasswordRequest.setCurrentPassword("OldPassword@123");
        updatePasswordRequest.setNewPassword("NewPassword@123");
        
        forgotPasswordRequest = new ForgotPasswordRequest();
        forgotPasswordRequest.setEmail("test@example.com");
        
        resetPasswordRequest = new ResetPasswordRequest();
        resetPasswordRequest.setToken("reset-token-123");
        resetPasswordRequest.setNewPassword("NewPassword@123");
        
        authResponse = AuthResponse.builder()
                .userId(1L)
                .email("test@example.com")
                .token(null)
                .build();
    }
    
    @Test
    void testRegister_Success() {
        when(authService.register(any(RegisterRequest.class))).thenReturn(authResponse);
        
        ResponseEntity<AuthResponse> response = authController.register(registerRequest);
        
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(1L, response.getBody().getUserId());
        verify(authService, times(1)).register(any(RegisterRequest.class));
    }
    
    @Test
    void testLogin_Success() {
        AuthResponse loginResponse = AuthResponse.builder()
                .userId(1L)
                .email("test@example.com")
                .token("jwt-token-123")
                .build();
        when(authService.login(any(LoginRequest.class))).thenReturn(loginResponse);
        
        ResponseEntity<AuthResponse> response = authController.login(loginRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertNotNull(response.getBody().getToken());
        verify(authService, times(1)).login(any(LoginRequest.class));
    }
    
    @Test
    void testUpdateEmail_Success() {
        doNothing().when(authService).updateEmail(anyLong(), any(UpdateEmailRequest.class));
        
        ResponseEntity<java.util.Map<String, String>> response = 
                authController.updateEmail(1L, updateEmailRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Email updated successfully", response.getBody().get("message"));
        verify(authService, times(1)).updateEmail(1L, updateEmailRequest);
    }
    
    @Test
    void testUpdatePassword_Success() {
        doNothing().when(authService).updatePassword(anyLong(), any(UpdatePasswordRequest.class));
        
        ResponseEntity<java.util.Map<String, String>> response = 
                authController.updatePassword(1L, updatePasswordRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Password updated successfully", response.getBody().get("message"));
        verify(authService, times(1)).updatePassword(1L, updatePasswordRequest);
    }
    
    @Test
    void testLogout_Success() {
        doNothing().when(authService).logout(anyLong());
        
        ResponseEntity<java.util.Map<String, String>> response = authController.logout(1L);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Logged out successfully", response.getBody().get("message"));
        verify(authService, times(1)).logout(1L);
    }
    
    @Test
    void testForgotPassword_Success() {
        doNothing().when(authService).forgotPassword(any(ForgotPasswordRequest.class));
        
        ResponseEntity<java.util.Map<String, String>> response = 
                authController.forgotPassword(forgotPasswordRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody().get("message").contains("password reset link"));
        verify(authService, times(1)).forgotPassword(any(ForgotPasswordRequest.class));
    }
    
    @Test
    void testResetPassword_Success() {
        doNothing().when(authService).resetPassword(any(ResetPasswordRequest.class));
        
        ResponseEntity<java.util.Map<String, String>> response = 
                authController.resetPassword(resetPasswordRequest);
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Password reset successfully", response.getBody().get("message"));
        verify(authService, times(1)).resetPassword(any(ResetPasswordRequest.class));
    }
    
    @Test
    void testHealth() {
        ResponseEntity<String> response = authController.health();
        
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Auth Service is running", response.getBody());
    }
}

