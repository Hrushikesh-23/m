package com.retailx.auth.service;

import com.retailx.auth.domain.PasswordResetToken;
import com.retailx.auth.domain.User;
import com.retailx.auth.domain.enums.Role;
import com.retailx.auth.dto.request.*;
import com.retailx.auth.dto.response.AuthResponse;
import com.retailx.auth.repository.PasswordResetTokenRepository;
import com.retailx.auth.repository.UserRepository;
import com.retailx.auth.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Authentication and authorization.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final PasswordResetTokenRepository passwordResetTokenRepository;
    private final EmailService emailService;
    
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        log.info("Registering new user with email: {}", request.getEmail());
        
        if (userRepository.existsByEmailAndDeletedFalse(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        // Trim password to ensure consistent encoding
        String passwordToEncode = request.getPassword() != null ? request.getPassword().trim() : "";
        log.info("Encoding password for registration - password length: {}", passwordToEncode.length());
        
        User user = User.builder()
                .email(request.getEmail())
                .passwordHash(passwordEncoder.encode(passwordToEncode))
                .active(true)
                .passwordChangedAt(LocalDateTime.now())
                .build();
        
        // Set default role
        Set<Role> roles = new HashSet<>();
        if (request.getRole() != null) {
            try {
                roles.add(Role.valueOf(request.getRole().toUpperCase()));
            } catch (IllegalArgumentException e) {
                roles.add(Role.CUSTOMER); // Default to CUSTOMER
            }
        } else {
            roles.add(Role.CUSTOMER);
        }
        user.setRoles(roles);
        
        user = userRepository.save(user);
        
        Set<String> roleStrings = user.getRoles().stream()
                .map(Enum::name)
                .collect(Collectors.toSet());
        
        // Registration does NOT generate token - user must login to get token
        return AuthResponse.builder()
                .token(null)  // No token on registration
                .userId(user.getId())
                .email(user.getEmail())
                .roles(roleStrings)
                .expiresIn(null)  // No expiration since no token
                .build();
    }
    
    @Transactional
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for email: {}", request.getEmail());
        
        // First check if any user exists with this email (case-insensitive)
        Optional<User> userOpt = userRepository.findActiveByEmail(request.getEmail());
        
        if (userOpt.isEmpty()) {
            log.warn("Login failed: No user found with email: {}", request.getEmail());
            // List all users for debugging
            long userCount = userRepository.count();
            log.debug("Total users in database: {}", userCount);
            throw new RuntimeException("Invalid credentials");
        }
        
        User user = userOpt.get();
        log.info("User found: id={}, email={}, active={}", user.getId(), user.getEmail(), user.getActive());
        
        if (!user.getActive()) {
            log.warn("Login failed: Account is inactive for email: {}", request.getEmail());
            throw new RuntimeException("Account is inactive");
        }
        
        // Trim password to handle any whitespace issues (same as registration)
        String providedPassword = request.getPassword() != null ? request.getPassword().trim() : "";
        boolean passwordMatches = passwordEncoder.matches(providedPassword, user.getPasswordHash());
        log.info("Password match result for email {}: {} (provided password length: {}, stored hash length: {})", 
                request.getEmail(), passwordMatches, providedPassword.length(), 
                user.getPasswordHash() != null ? user.getPasswordHash().length() : 0);
        
        if (!passwordMatches) {
            log.warn("Login failed: Password mismatch for email: {}", request.getEmail());
            Integer currentAttempts = user.getFailedLoginAttempts() != null ? user.getFailedLoginAttempts() : 0;
            currentAttempts = currentAttempts + 1;
            user.setFailedLoginAttempts(currentAttempts);
            
            // Lock account after 5 failed attempts
            if (currentAttempts >= 5) {
                user.setActive(false);
                log.warn("Account locked due to {} failed login attempts: email={}", currentAttempts, request.getEmail());
                userRepository.save(user);
                throw new RuntimeException("Account locked due to multiple failed login attempts. Please contact administrator.");
            }
            
            userRepository.save(user);
            throw new RuntimeException("Invalid credentials");
        }
        
        log.info("Password verified successfully for email: {}", request.getEmail());
        
        // Reset failed attempts on successful login
        user.setFailedLoginAttempts(0);
        user.setLastLoginAt(LocalDateTime.now());
        userRepository.save(user);
        
        Set<String> roleStrings = user.getRoles().stream()
                .map(Enum::name)
                .collect(Collectors.toSet());
        
        String token = jwtUtil.generateToken(user.getId(), user.getEmail(), roleStrings);
        
        return AuthResponse.builder()
                .token(token)
                .userId(user.getId())
                .email(user.getEmail())
                .roles(roleStrings)
                .expiresIn(jwtUtil.getExpirationDateFromToken(token).getTime() - System.currentTimeMillis())
                .build();
    }
    
    /**
     * Update user email.
     */
    @Transactional
    public void updateEmail(Long userId, UpdateEmailRequest request) {
        log.info("Updating email for user: {}", userId);
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Check if new email already exists
        if (userRepository.existsByEmailAndDeletedFalse(request.getNewEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        String oldEmail = user.getEmail();
        user.setEmail(request.getNewEmail());
        userRepository.save(user);
        
        log.info("Email updated successfully: userId={}, oldEmail={}, newEmail={}", 
                userId, oldEmail, request.getNewEmail());
    }
    
    /**
     * Update user password.
     */
    @Transactional
    public void updatePassword(Long userId, UpdatePasswordRequest request) {
        log.info("Updating password for user: {}", userId);
        
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Verify current password
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPasswordHash())) {
            throw new RuntimeException("Current password is incorrect");
        }
        
        // Update password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        user.setPasswordChangedAt(LocalDateTime.now());
        user.setFailedLoginAttempts(0); // Reset failed attempts on password change
        userRepository.save(user);
        
        log.info("Password updated successfully for user: {}", userId);
    }
    
    /**
     * Logout - invalidate token (client-side implementation, server can track if needed).
     * For now, this is a placeholder as JWT tokens are stateless.
     * In production, you might want to maintain a blacklist of tokens.
     */
    public void logout(Long userId) {
        log.info("Logout request for user: {}", userId);
        // JWT tokens are stateless, so logout is typically handled client-side
        // by removing the token from storage.
        // In a production system, you might want to:
        // 1. Maintain a token blacklist in Redis
        // 2. Store tokens in database and mark as invalid
        // 3. Use refresh tokens and invalidate them
        log.info("User logged out: {}", userId);
    }
    
    /**
     * Forgot password - generate reset token and send email.
     */
    @Transactional
    public void forgotPassword(ForgotPasswordRequest request) {
        log.info("Forgot password request for email: {}", request.getEmail());
        
        Optional<User> userOpt = userRepository.findActiveByEmail(request.getEmail());
        
        // Don't reveal if email exists or not (security best practice)
        if (userOpt.isEmpty()) {
            log.warn("Forgot password requested for non-existent email: {}", request.getEmail());
            // Return success even if email doesn't exist (security best practice)
            return;
        }
        
        User user = userOpt.get();
        
        // Invalidate any existing reset tokens for this user
        passwordResetTokenRepository.findByUserIdAndUsedFalse(user.getId())
                .ifPresent(token -> {
                    token.setUsed(true);
                    token.setUsedAt(LocalDateTime.now());
                    passwordResetTokenRepository.save(token);
                });
        
        // Generate secure reset token
        String resetToken = generateSecureToken();
        
        // Create password reset token (expires in 1 hour)
        PasswordResetToken passwordResetToken = PasswordResetToken.builder()
                .userId(user.getId())
                .token(resetToken)
                .expiresAt(LocalDateTime.now().plusHours(1))
                .used(false)
                .build();
        
        passwordResetTokenRepository.save(passwordResetToken);
        
        // Send password reset email
        emailService.sendPasswordResetEmail(user.getEmail(), resetToken);
        
        log.info("Password reset token generated and email sent for user: {}", user.getId());
    }
    
    /**
     * Reset password using token.
     */
    @Transactional
    public void resetPassword(ResetPasswordRequest request) {
        log.info("Password reset request with token");
        
        // Find valid token
        Optional<PasswordResetToken> tokenOpt = passwordResetTokenRepository
                .findByTokenAndUsedFalse(request.getToken());
        
        if (tokenOpt.isEmpty()) {
            throw new RuntimeException("Invalid or expired reset token");
        }
        
        PasswordResetToken resetToken = tokenOpt.get();
        
        // Check if token is expired
        if (resetToken.getExpiresAt().isBefore(LocalDateTime.now())) {
            resetToken.setUsed(true);
            resetToken.setUsedAt(LocalDateTime.now());
            passwordResetTokenRepository.save(resetToken);
            throw new RuntimeException("Reset token has expired");
        }
        
        // Get user
        User user = userRepository.findById(resetToken.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found"));
        
        // Update password
        user.setPasswordHash(passwordEncoder.encode(request.getNewPassword()));
        user.setPasswordChangedAt(LocalDateTime.now());
        user.setFailedLoginAttempts(0); // Reset failed attempts
        userRepository.save(user);
        
        // Mark token as used
        resetToken.setUsed(true);
        resetToken.setUsedAt(LocalDateTime.now());
        passwordResetTokenRepository.save(resetToken);
        
        log.info("Password reset successfully for user: {}", user.getId());
    }
    
    /**
     * Generate secure random token for password reset.
     */
    private String generateSecureToken() {
        SecureRandom random = new SecureRandom();
        byte[] bytes = new byte[32];
        random.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}

