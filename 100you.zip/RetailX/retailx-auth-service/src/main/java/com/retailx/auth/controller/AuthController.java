package com.retailx.auth.controller;

import com.retailx.auth.dto.request.*;
import com.retailx.auth.dto.response.AuthResponse;
import com.retailx.auth.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Auth endpoints - registration, login, password management.
 */
@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {
    
    private final AuthService authService;
    
    /**
     * Register new user.
     */
    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        log.info("Registering user: {}", request.getEmail());
        AuthResponse response = authService.register(request);
        log.info("User registered: {} (ID: {})", request.getEmail(), response.getUserId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
    
    /**
     * Login and get JWT token.
     */
    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        log.info("Login attempt: {}", request.getEmail());
        AuthResponse response = authService.login(request);
        log.info("Login successful: {} (ID: {})", request.getEmail(), response.getUserId());
        return ResponseEntity.ok(response);
    }
    
    /**
     * Update email.
     */
    @PutMapping("/email")
    public ResponseEntity<Map<String, String>> updateEmail(
            @RequestHeader("X-User-Id") Long userId,
            @Valid @RequestBody UpdateEmailRequest request) {
        log.info("Updating email for user: {}", userId);
        authService.updateEmail(userId, request);
        return ResponseEntity.ok(Map.of("message", "Email updated successfully"));
    }
    
    /**
     * Update password.
     */
    @PutMapping("/password")
    public ResponseEntity<Map<String, String>> updatePassword(
            @RequestHeader("X-User-Id") Long userId,
            @Valid @RequestBody UpdatePasswordRequest request) {
        log.info("Updating password for user: {}", userId);
        authService.updatePassword(userId, request);
        return ResponseEntity.ok(Map.of("message", "Password updated successfully"));
    }
    
    /**
     * Logout.
     */
    @PostMapping("/logout")
    public ResponseEntity<Map<String, String>> logout(@RequestHeader("X-User-Id") Long userId) {
        log.info("User logging out: {}", userId);
        authService.logout(userId);
        return ResponseEntity.ok(Map.of("message", "Logged out successfully"));
    }
    
    /**
     * Forgot password - sends reset link.
     */
    @PostMapping("/forgot-password")
    public ResponseEntity<Map<String, String>> forgotPassword(
            @Valid @RequestBody ForgotPasswordRequest request) {
        log.info("Forgot password requested: {}", request.getEmail());
        authService.forgotPassword(request);
        // Don't reveal if email exists
        return ResponseEntity.ok(Map.of("message", 
                "If the email exists, a password reset link has been sent"));
    }
    
    /**
     * Reset password using token.
     */
    @PostMapping("/reset-password")
    public ResponseEntity<Map<String, String>> resetPassword(
            @Valid @RequestBody ResetPasswordRequest request) {
        log.info("Resetting password with token");
        authService.resetPassword(request);
        return ResponseEntity.ok(Map.of("message", "Password reset successfully"));
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Auth Service is running");
    }
}

