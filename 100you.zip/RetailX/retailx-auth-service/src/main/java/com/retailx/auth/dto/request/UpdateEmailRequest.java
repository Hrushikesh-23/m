package com.retailx.auth.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * Request DTO for updating user email.
 */
@Data
public class UpdateEmailRequest {
    
    @NotBlank(message = "New email is required")
    @Email(message = "Invalid email format", regexp = "^[A-Za-z0-9+_.-]+@([A-Za-z0-9.-]+\\.[A-Za-z]{2,})$")
    private String newEmail;
}

