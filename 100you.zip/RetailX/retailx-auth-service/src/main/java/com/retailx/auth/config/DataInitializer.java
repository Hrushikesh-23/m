package com.retailx.auth.config;

import com.retailx.auth.domain.User;
import com.retailx.auth.domain.enums.Role;
import com.retailx.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

/**
 * Initializes default admin user on application startup.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) {
        if (userRepository.findByEmailAndDeletedFalse("admin@retailx.com").isEmpty()) {
            log.info("Creating default admin user");
            
            Set<Role> adminRoles = new HashSet<>();
            adminRoles.add(Role.ADMIN);
            
            User admin = User.builder()
                    .email("admin@retailx.com")
                    .passwordHash(passwordEncoder.encode("Admin@123"))
                    .roles(adminRoles)
                    .active(true)
                    .passwordChangedAt(LocalDateTime.now())
                    .build();
            
            userRepository.save(admin);
            log.info("Default admin user created: admin@retailx.com / Admin@123");
        }
    }
}

