package com.retailx.notification.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.Map;

/**
 * Feign client for Auth Service to get user information.
 */
@FeignClient(name = "retailx-api-gateway", path = "/api/auth")
public interface AuthServiceClient {
    
    /**
     * Get user email by user ID.
     * Note: This endpoint needs to be created in Auth Service if not exists.
     */
    @GetMapping("/users/{userId}/email")
    Map<String, String> getUserEmail(@PathVariable Long userId);
}



