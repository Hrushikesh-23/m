package com.retailx.gateway.controller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;

/**
 * Configuration for centralized Swagger documentation index.
 */
@Configuration
public class SwaggerController {
    
    @Bean
    public RouterFunction<ServerResponse> swaggerRoutes() {
        return route()
                .GET("/swagger", request -> {
        String html = """
            <!DOCTYPE html>
            <html>
            <head>
                <title>RetailX API Gateway - Swagger Documentation</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        max-width: 1200px;
                        margin: 50px auto;
                        padding: 20px;
                        background-color: #f5f5f5;
                    }
                    h1 {
                        color: #333;
                        text-align: center;
                        margin-bottom: 40px;
                    }
                    .services-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 20px;
                        margin-top: 30px;
                    }
                    .service-card {
                        background: white;
                        border-radius: 8px;
                        padding: 20px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                        transition: transform 0.2s;
                    }
                    .service-card:hover {
                        transform: translateY(-2px);
                        box-shadow: 0 4px 8px rgba(0,0,0,0.15);
                    }
                    .service-card h3 {
                        margin-top: 0;
                        color: #2c3e50;
                    }
                    .service-card p {
                        color: #666;
                        margin: 10px 0;
                    }
                    .service-card a {
                        display: inline-block;
                        margin-top: 10px;
                        padding: 10px 20px;
                        background-color: #007bff;
                        color: white;
                        text-decoration: none;
                        border-radius: 4px;
                        transition: background-color 0.2s;
                    }
                    .service-card a:hover {
                        background-color: #0056b3;
                    }
                    .info-box {
                        background: #e7f3ff;
                        border-left: 4px solid #007bff;
                        padding: 15px;
                        margin-bottom: 30px;
                        border-radius: 4px;
                    }
                </style>
            </head>
            <body>
                <h1>🚀 RetailX API Gateway - Swagger Documentation</h1>
                
                <div class="info-box">
                    <strong>📌 Centralized API Access:</strong><br>
                    All APIs are accessible through port 8080 (API Gateway).<br>
                    Click on any service below to view its Swagger documentation.
                </div>
                
                <div class="services-grid">
                    <div class="service-card">
                        <h3>🔐 Auth Service</h3>
                        <p>Authentication, authorization, user management</p>
                        <p><strong>Port:</strong> 8081</p>
                        <a href="/swagger-ui/auth/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                    
                    <div class="service-card">
                        <h3>📦 Product Service</h3>
                        <p>Product catalog, reviews, search</p>
                        <p><strong>Port:</strong> 8082</p>
                        <a href="/swagger-ui/product/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                    
                    <div class="service-card">
                        <h3>🛒 Order Service</h3>
                        <p>Orders, carts, checkout, shipments, returns</p>
                        <p><strong>Port:</strong> 8083</p>
                        <a href="/swagger-ui/order/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                    
                    <div class="service-card">
                        <h3>💳 Payment Service</h3>
                        <p>Payment processing, authorization, refunds</p>
                        <p><strong>Port:</strong> 8084</p>
                        <a href="/swagger-ui/payment/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                    
                    <div class="service-card">
                        <h3>📊 Inventory Service</h3>
                        <p>Inventory management, stock tracking</p>
                        <p><strong>Port:</strong> 8085</p>
                        <a href="/swagger-ui/inventory/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                    
                    <div class="service-card">
                        <h3>🔔 Notification Service</h3>
                        <p>Notifications, alerts, messaging</p>
                        <p><strong>Port:</strong> 8086</p>
                        <a href="/swagger-ui/notification/swagger-ui.html" target="_blank">Open Swagger UI</a>
                    </div>
                </div>
                
                <div style="margin-top: 40px; padding: 20px; background: white; border-radius: 8px;">
                    <h3>📡 API Endpoints (via Gateway - Port 8080)</h3>
                    <ul>
                        <li><code>/api/auth/**</code> - Auth Service</li>
                        <li><code>/api/products/**</code> - Product Service</li>
                        <li><code>/api/orders/**</code> - Order Service</li>
                        <li><code>/api/payments/**</code> - Payment Service</li>
                        <li><code>/api/inventory/**</code> - Inventory Service</li>
                        <li><code>/api/notifications/**</code> - Notification Service</li>
                    </ul>
                </div>
            </body>
            </html>
            """;
                    return ok().contentType(MediaType.TEXT_HTML).bodyValue(html);
                })
                .build();
    }
}

