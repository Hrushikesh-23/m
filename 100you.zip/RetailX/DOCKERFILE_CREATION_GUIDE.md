# Dockerfile Creation Guide

## Overview
You have 2 docker-compose files:
1. **docker-compose.yml** - Infrastructure only (MySQL, Kafka, Zookeeper)
2. **docker-compose-full.yml** - Complete deployment (all microservices + infrastructure)

## Creating Dockerfiles

Each microservice needs a Dockerfile. Use the template below or create service-specific ones.

### Option 1: Multi-stage Build (Recommended - Smaller Images)

Create `Dockerfile` in each service directory:

```dockerfile
# Stage 1: Build
FROM maven:3.9-eclipse-temurin-17 AS build
WORKDIR /app
COPY pom.xml .
COPY src ./src
RUN mvn clean package -DskipTests

# Stage 2: Run
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY --from=build /app/target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### Option 2: Simple Build (Faster Development)

```dockerfile
FROM openjdk:17-jdk-slim
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

**Note**: For Option 2, you need to build JARs first:
```bash
cd retailx-auth-service
mvn clean package -DskipTests
```

## Service-Specific Dockerfiles

### 1. Eureka Server (`retailx-eureka-server/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8761
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 2. API Gateway (`retailx-api-gateway/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 3. Auth Service (`retailx-auth-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8081
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 4. Product Service (`retailx-product-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8082
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 5. Order Service (`retailx-order-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8083
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 6. Payment Service (`retailx-payment-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8084
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 7. Inventory Service (`retailx-inventory-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8085
ENTRYPOINT ["java", "-jar", "app.jar"]
```

### 8. Notification Service (`retailx-notification-service/Dockerfile`)
```dockerfile
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8086
ENTRYPOINT ["java", "-jar", "app.jar"]
```

## Quick Setup Script

Create all Dockerfiles at once:

```bash
# For each service directory
for service in retailx-eureka-server retailx-api-gateway retailx-auth-service retailx-product-service retailx-order-service retailx-payment-service retailx-inventory-service retailx-notification-service; do
  cat > $service/Dockerfile << 'EOF'
FROM eclipse-temurin:17-jre-alpine
WORKDIR /app
COPY target/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
EOF
done
```

## Building and Running

### Build JARs First (if using simple Dockerfile)
```bash
# Build all services
mvn clean package -DskipTests
```

### Build Docker Images
```bash
# Build all images
docker-compose -f docker-compose-full.yml build

# Or build specific service
docker-compose -f docker-compose-full.yml build auth-service
```

### Run Services
```bash
# Start all services
docker-compose -f docker-compose-full.yml up -d

# View logs
docker-compose -f docker-compose-full.yml logs -f

# Stop all services
docker-compose -f docker-compose-full.yml down
```

## Port Mappings

- Eureka Server: 8761
- API Gateway: 8080
- Auth Service: 8081
- Product Service: 8082
- Order Service: 8083
- Payment Service: 8084
- Inventory Service: 8085
- Notification Service: 8086
- MySQL: 3306
- Kafka: 9092
- Zookeeper: 2181

## Troubleshooting

### Issue: "Cannot find Dockerfile"
**Solution**: Ensure Dockerfile exists in each service directory

### Issue: "JAR file not found"
**Solution**: Build JARs first with `mvn clean package -DskipTests`

### Issue: "Port already in use"
**Solution**: Stop existing services or change port mappings in docker-compose-full.yml

### Issue: "Service not starting"
**Solution**: Check logs with `docker-compose -f docker-compose-full.yml logs <service-name>`

