package com.retailx.gateway.filter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Rate limiting filter based on user role.
 */
@Slf4j
@Component
public class RateLimitFilter extends AbstractGatewayFilterFactory<RateLimitFilter.Config> {
    
    private final ConcurrentHashMap<String, RateLimitInfo> rateLimitMap = new ConcurrentHashMap<>();
    
    public RateLimitFilter() {
        super(Config.class);
    }
    
    @Override
    public GatewayFilter apply(Config config) {
        return (exchange, chain) -> {
            String userId = exchange.getRequest().getHeaders().getFirst("X-User-Id");
            String role = exchange.getRequest().getHeaders().getFirst("X-User-Role");
            
            if (userId == null || role == null) {
                return chain.filter(exchange);
            }
            
            String key = userId + ":" + role;
            int limit = getLimitForRole(role);
            
            RateLimitInfo info = rateLimitMap.computeIfAbsent(key, k -> new RateLimitInfo(limit));
            
            long currentTime = System.currentTimeMillis();
            if (currentTime - info.getWindowStart() > 60000) { // 1 minute window
                info.reset(currentTime);
            }
            
            if (info.getCount().get() >= limit) {
                log.warn("Rate limit exceeded for user: {}, role: {}", userId, role);
                ServerHttpResponse response = exchange.getResponse();
                response.setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
                response.getHeaders().add("Retry-After", "60");
                return response.setComplete();
            }
            
            info.getCount().incrementAndGet();
            return chain.filter(exchange);
        };
    }
    
    private int getLimitForRole(String role) {
        return switch (role.toUpperCase()) {
            case "CUSTOMER" -> 60;
            case "MERCHANT" -> 90;
            case "OPS", "ADMIN" -> 120;
            default -> 60;
        };
    }
    
    private static class RateLimitInfo {
        private final int limit;
        private long windowStart;
        private final AtomicInteger count;
        
        public RateLimitInfo(int limit) {
            this.limit = limit;
            this.windowStart = System.currentTimeMillis();
            this.count = new AtomicInteger(0);
        }
        
        public void reset(long newStart) {
            this.windowStart = newStart;
            this.count.set(0);
        }
        
        public long getWindowStart() { return windowStart; }
        public AtomicInteger getCount() { return count; }
    }
    
    public static class Config {
        // Configuration properties if needed
    }
}

