package com.retailx.inventory.controller;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.service.InventoryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.util.List;

/**
 * REST controller for inventory management endpoints.
 * Handles inventory reservations, adjustments, and low stock alerts.
 */
@Slf4j
@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {
    
    private final InventoryService inventoryService;
    
    /**
     * Reserve inventory for an order - accessible to authenticated users (typically Order Service).
     */
    @PostMapping("/reserve")
    public ResponseEntity<Boolean> reserveInventory(
            @RequestParam String sku,
            @RequestParam BigInteger quantity,
            @RequestParam String warehouseId) {
        
        log.info("Reserving inventory: sku={}, quantity={}, warehouseId={}", 
                sku, quantity, warehouseId);
        boolean reserved = inventoryService.reserveInventory(sku, quantity, warehouseId);
        log.info("Inventory reservation result: sku={}, reserved={}", sku, reserved);
        return ResponseEntity.ok(reserved);
    }
    
    /**
     * Get low stock items - only MERCHANT, ADMIN, or OPS can access.
     */
    @GetMapping("/low-stock")
    @PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN', 'OPS')")
    public ResponseEntity<List<Inventory>> getLowStockItems() {
        log.info("Fetching low stock items");
        List<Inventory> items = inventoryService.getLowStockItems();
        log.debug("Found {} low stock items", items.size());
        return ResponseEntity.ok(items);
    }
    
    /**
     * Adjust inventory quantity - only OPS or ADMIN can access.
     */
    @PostMapping("/adjust")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN')")
    public ResponseEntity<Void> adjustInventory(
            @RequestParam String sku,
            @RequestParam String warehouseId,
            @RequestParam BigInteger quantity) {
        
        log.info("Adjusting inventory: sku={}, warehouseId={}, quantity={}", 
                sku, warehouseId, quantity);
        inventoryService.adjustInventory(sku, warehouseId, quantity);
        log.info("Inventory adjusted successfully: sku={}", sku);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Inventory Service is running");
    }
}

