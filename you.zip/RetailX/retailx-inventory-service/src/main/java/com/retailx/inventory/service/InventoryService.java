package com.retailx.inventory.service;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.domain.InventoryHold;
import com.retailx.inventory.repository.InventoryHoldRepository;
import com.retailx.inventory.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for inventory management operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryService {
    
    private final InventoryRepository inventoryRepository;
    private final InventoryHoldRepository inventoryHoldRepository;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Value("${retailx.inventory.low-stock-threshold:10}")
    private BigInteger lowStockThreshold;
    
    @Transactional
    public boolean reserveInventory(String sku, BigInteger quantity, String warehouseId) {
        log.info("Reserving inventory: sku={}, quantity={}, warehouseId={}", 
                sku, quantity, warehouseId);
        
        Inventory inventory = inventoryRepository.findBySkuAndWarehouseId(sku, warehouseId)
                .orElseThrow(() -> new RuntimeException("Inventory not found for SKU: " + sku));
        
        if (inventory.getAvailable().compareTo(quantity) < 0) {
            log.warn("Insufficient inventory: available={}, requested={}", 
                    inventory.getAvailable(), quantity);
            return false;
        }
        
        inventory.setReserved(inventory.getReserved().add(quantity));
        inventoryRepository.save(inventory);
        
        // Publish event
        kafkaTemplate.send("inventory.reserved", sku, 
                String.format("{\"sku\":\"%s\",\"quantity\":%s,\"warehouseId\":\"%s\"}", 
                        sku, quantity, warehouseId));
        
        return true;
    }
    
    @Transactional
    public void createHold(String sku, BigInteger quantity, String warehouseId, 
                          String cartId, Long orderId, LocalDateTime expiresAt) {
        InventoryHold hold = InventoryHold.builder()
                .sku(sku)
                .quantity(quantity)
                .warehouseId(warehouseId)
                .cartId(cartId)
                .orderId(orderId)
                .expiresAt(expiresAt)
                .released(false)
                .build();
        
        inventoryHoldRepository.save(hold);
    }
    
    @Transactional
    public void releaseHold(String cartId) {
        log.info("Releasing holds for cart: {}", cartId);
        List<InventoryHold> holds = inventoryHoldRepository.findByCartId(cartId);
        releaseHolds(holds);
    }
    
    @Transactional
    public void releaseHoldByOrder(Long orderId) {
        log.info("Releasing holds for order: {}", orderId);
        List<InventoryHold> holds = inventoryHoldRepository.findByOrderId(orderId);
        releaseHolds(holds);
    }
    
    private void releaseHolds(List<InventoryHold> holds) {
        for (InventoryHold hold : holds) {
            if (!hold.getReleased()) {
                Inventory inventory = inventoryRepository
                        .findBySkuAndWarehouseId(hold.getSku(), hold.getWarehouseId())
                        .orElse(null);
                
                if (inventory != null) {
                    inventory.setReserved(inventory.getReserved().subtract(hold.getQuantity()));
                    inventoryRepository.save(inventory);
                }
                
                hold.setReleased(true);
                inventoryHoldRepository.save(hold);
            }
        }
    }
    
    @Transactional
    public void releaseExpiredHolds() {
        log.info("Releasing expired holds");
        List<InventoryHold> expiredHolds = inventoryHoldRepository
                .findExpiredHolds(LocalDateTime.now());
        releaseHolds(expiredHolds);
    }
    
    public List<Inventory> getLowStockItems() {
        return inventoryRepository.findLowStock(lowStockThreshold);
    }
    
    @Transactional
    public void adjustInventory(String sku, String warehouseId, BigInteger quantity) {
        Inventory inventory = inventoryRepository.findBySkuAndWarehouseId(sku, warehouseId)
                .orElse(Inventory.builder()
                        .sku(sku)
                        .warehouseId(warehouseId)
                        .onHand(BigInteger.ZERO)
                        .reserved(BigInteger.ZERO)
                        .available(BigInteger.ZERO)
                        .build());
        
        inventory.setOnHand(inventory.getOnHand().add(quantity));
        inventoryRepository.save(inventory);
        
        // Check for low stock
        if (inventory.getAvailable().compareTo(lowStockThreshold) < 0) {
            kafkaTemplate.send("inventory.low-stock", sku,
                    String.format("{\"sku\":\"%s\",\"available\":%s,\"warehouseId\":\"%s\"}", 
                            sku, inventory.getAvailable(), warehouseId));
        }
    }
}

