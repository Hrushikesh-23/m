package com.retailx.inventory.service;

import com.retailx.inventory.domain.Inventory;
import com.retailx.inventory.domain.InventoryHold;
import com.retailx.inventory.repository.InventoryHoldRepository;
import com.retailx.inventory.repository.InventoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for InventoryService.
 */
@ExtendWith(MockitoExtension.class)
class InventoryServiceTest {
    
    @Mock
    private InventoryRepository inventoryRepository;
    
    @Mock
    private InventoryHoldRepository inventoryHoldRepository;
    
    @Mock
    private KafkaTemplate<String, String> kafkaTemplate;
    
    @InjectMocks
    private InventoryService inventoryService;
    
    private Inventory inventory;
    
    @BeforeEach
    void setUp() {
        inventory = Inventory.builder()
                .id(1L)
                .sku("PROD-001")
                .warehouseId("default-warehouse")
                .onHand(BigInteger.valueOf(100))
                .reserved(BigInteger.valueOf(10))
                .available(BigInteger.valueOf(90))
                .build();
    }
    
    @Test
    void testReserveInventory_Success() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "default-warehouse"))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
        
        boolean result = inventoryService.reserveInventory("PROD-001", 
                BigInteger.valueOf(5), "default-warehouse");
        
        assertTrue(result);
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
        verify(kafkaTemplate, times(1)).send(anyString(), anyString(), anyString());
    }
    
    @Test
    void testReserveInventory_InsufficientStock() {
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "default-warehouse"))
                .thenReturn(Optional.of(inventory));
        
        boolean result = inventoryService.reserveInventory("PROD-001", 
                BigInteger.valueOf(200), "default-warehouse");
        
        assertFalse(result);
        verify(inventoryRepository, never()).save(any());
    }
    
    @Test
    void testGetLowStockItems() {
        List<Inventory> lowStock = new ArrayList<>();
        lowStock.add(inventory);
        
        when(inventoryRepository.findLowStock(BigInteger.valueOf(10)))
                .thenReturn(lowStock);
        
        List<Inventory> result = inventoryService.getLowStockItems();
        
        assertNotNull(result);
        assertFalse(result.isEmpty());
    }
    
    @Test
    void testReleaseHold() {
        InventoryHold hold = InventoryHold.builder()
                .id(1L)
                .sku("PROD-001")
                .quantity(BigInteger.valueOf(5))
                .warehouseId("default-warehouse")
                .cartId("cart-123")
                .released(false)
                .build();
        
        List<InventoryHold> holds = new ArrayList<>();
        holds.add(hold);
        
        when(inventoryHoldRepository.findByCartId("cart-123"))
                .thenReturn(holds);
        when(inventoryRepository.findBySkuAndWarehouseId("PROD-001", "default-warehouse"))
                .thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
        when(inventoryHoldRepository.save(any(InventoryHold.class))).thenReturn(hold);
        
        inventoryService.releaseHold("cart-123");
        
        assertTrue(hold.getReleased());
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }
}

