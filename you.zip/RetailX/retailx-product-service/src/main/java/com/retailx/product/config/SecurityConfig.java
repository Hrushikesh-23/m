package com.retailx.product.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security configuration for Product Service with role-based access control.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/products/**", "/api/reviews/products/**")
                    .permitAll() // Public read access
                .requestMatchers("/api/products", "/api/products/**/bulk/**")
                    .hasAnyRole("MERCHANT", "ADMIN")
                .requestMatchers("/api/reviews/products/**")
                    .hasAnyRole("CUSTOMER", "ADMIN")
                .requestMatchers("/api/reviews/**")
                    .hasAnyRole("ADMIN", "OPS")
                .requestMatchers("/actuator/**")
                    .permitAll()
                .anyRequest().authenticated()
            );
        
        return http.build();
    }
}

