package com.retailx.product.controller;

import com.retailx.product.service.BulkImportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * REST controller for bulk product import/export operations.
 * Handles CSV and XLSX file imports for merchants.
 */
@Slf4j
@RestController
@RequestMapping("/api/products/bulk")
@RequiredArgsConstructor
public class BulkImportController {
    
    private final BulkImportService bulkImportService;
    
    /**
     * Import products from CSV file - only MERCHANT or ADMIN can access.
     */
    @PostMapping("/import/csv")
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")
    public ResponseEntity<BulkImportService.BulkImportResult> importCsv(
            @RequestParam("file") MultipartFile file,
            @RequestHeader("X-User-Id") Long merchantId) {
        
        log.info("CSV import request: merchantId={}, filename={}, size={} bytes", 
                merchantId, file.getOriginalFilename(), file.getSize());
        BulkImportService.BulkImportResult result = bulkImportService.importFromCsv(file, merchantId);
        log.info("CSV import completed: merchantId={}, success={}, failed={}", 
                merchantId, result.getSuccessCount(), result.getFailureCount());
        return ResponseEntity.ok(result);
    }
    
    /**
     * Import products from XLSX file - only MERCHANT or ADMIN can access.
     */
    @PostMapping("/import/xlsx")
    @org.springframework.security.access.prepost.PreAuthorize("hasAnyRole('MERCHANT', 'ADMIN')")
    public ResponseEntity<BulkImportService.BulkImportResult> importXlsx(
            @RequestParam("file") MultipartFile file,
            @RequestHeader("X-User-Id") Long merchantId) {
        
        log.info("XLSX import request: merchantId={}, filename={}, size={} bytes", 
                merchantId, file.getOriginalFilename(), file.getSize());
        BulkImportService.BulkImportResult result = bulkImportService.importFromXlsx(file, merchantId);
        log.info("XLSX import completed: merchantId={}, success={}, failed={}", 
                merchantId, result.getSuccessCount(), result.getFailureCount());
        return ResponseEntity.ok(result);
    }
}

