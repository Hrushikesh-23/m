package com.retailx.product.dto.request;

import com.retailx.product.domain.enums.ProductStatus;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;

/**
 * Product creation/update request DTO.
 */
@Data
public class ProductRequest {
    
    @NotBlank(message = "SKU is required")
    private String sku;
    
    @NotBlank(message = "Name is required")
    private String name;
    
    private String description;
    
    @NotNull(message = "Base price is required")
    @Positive(message = "Base price must be positive")
    private BigDecimal basePrice;
    
    private String currency = "USD";
    
    @NotBlank(message = "Category path is required")
    private String categoryPath;
    
    private ProductStatus status = ProductStatus.DRAFT;
    
    private List<String> media;
    
    private String attributes; // JSON string
    
    private Long merchantId;
}

