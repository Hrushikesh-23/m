package com.retailx.product.util;

import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for SkuUtil.
 */
class SkuUtilTest {
    
    @Test
    void testIsValidSku_Valid() {
        assertTrue(SkuUtil.isValidSku("PROD-001"));
        assertTrue(SkuUtil.isValidSku("ABC123"));
        assertTrue(SkuUtil.isValidSku("SKU-2024-001"));
    }
    
    @Test
    void testIsValidSku_Invalid() {
        assertFalse(SkuUtil.isValidSku(null));
        assertFalse(SkuUtil.isValidSku(""));
        assertFalse(SkuUtil.isValidSku("prod-001")); // lowercase
        assertFalse(SkuUtil.isValidSku("PROD 001")); // space
    }
    
    @Test
    void testNormalizeSku() {
        assertEquals("PROD-001", SkuUtil.normalizeSku("prod-001"));
        assertEquals("PROD-001", SkuUtil.normalizeSku("  PROD-001  "));
        assertEquals("", SkuUtil.normalizeSku(null));
    }
    
    @Test
    void testValidateSkus() {
        List<String> skus = Arrays.asList("PROD-001", "invalid", "PROD-002", "");
        Set<String> invalid = SkuUtil.validateSkus(skus);
        
        assertEquals(2, invalid.size());
        assertTrue(invalid.contains("invalid"));
        assertTrue(invalid.contains(""));
    }
    
    @Test
    void testDeduplicateSkus() {
        List<String> skus = Arrays.asList("PROD-001", "prod-001", "PROD-002", "PROD-001");
        Set<String> deduplicated = SkuUtil.deduplicateSkus(skus);
        
        assertEquals(2, deduplicated.size());
        assertTrue(deduplicated.contains("PROD-001"));
        assertTrue(deduplicated.contains("PROD-002"));
    }
    
    @Test
    void testGroupSkusByValidity() {
        List<String> skus = Arrays.asList("PROD-001", "invalid", "PROD-002");
        Map<String, Set<String>> grouped = SkuUtil.groupSkusByValidity(skus);
        
        assertEquals(2, grouped.get("valid").size());
        assertEquals(1, grouped.get("invalid").size());
        assertTrue(grouped.get("valid").contains("PROD-001"));
        assertTrue(grouped.get("invalid").contains("invalid"));
    }
}

