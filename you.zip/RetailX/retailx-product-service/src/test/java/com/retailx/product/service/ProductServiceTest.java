package com.retailx.product.service;

import com.retailx.product.domain.Product;
import com.retailx.product.domain.enums.ProductStatus;
import com.retailx.product.dto.request.ProductRequest;
import com.retailx.product.dto.response.ProductResponse;
import com.retailx.product.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for ProductService.
 */
@ExtendWith(MockitoExtension.class)
class ProductServiceTest {
    
    @Mock
    private ProductRepository productRepository;
    
    @InjectMocks
    private ProductService productService;
    
    private ProductRequest productRequest;
    private Product product;
    
    @BeforeEach
    void setUp() {
        productRequest = new ProductRequest();
        productRequest.setSku("PROD-001");
        productRequest.setName("Test Product");
        productRequest.setDescription("Test Description");
        productRequest.setBasePrice(new BigDecimal("99.99"));
        productRequest.setCurrency("USD");
        productRequest.setCategoryPath("/electronics");
        productRequest.setStatus(ProductStatus.ACTIVE);
        productRequest.setMerchantId(1L);
        
        product = Product.builder()
                .id(1L)
                .sku("PROD-001")
                .name("Test Product")
                .basePrice(new BigDecimal("99.99"))
                .currency("USD")
                .categoryPath("/electronics")
                .catalogPath("/catalog/electronics/PROD-001")
                .status(ProductStatus.ACTIVE)
                .merchantId(1L)
                .build();
    }
    
    @Test
    void testCreateProduct_Success() {
        when(productRepository.findBySkuAndDeletedFalse("PROD-001"))
                .thenReturn(Optional.empty());
        when(productRepository.save(any(Product.class))).thenReturn(product);
        
        ProductResponse response = productService.createProduct(productRequest);
        
        assertNotNull(response);
        assertEquals("PROD-001", response.getSku());
        verify(productRepository, times(1)).save(any(Product.class));
    }
    
    @Test
    void testCreateProduct_DuplicateSku() {
        when(productRepository.findBySkuAndDeletedFalse("PROD-001"))
                .thenReturn(Optional.of(product));
        
        assertThrows(IllegalArgumentException.class, () -> {
            productService.createProduct(productRequest);
        });
    }
    
    @Test
    void testGetProductById() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        
        ProductResponse response = productService.getProductById(1L);
        
        assertNotNull(response);
        assertEquals(1L, response.getId());
    }
    
    @Test
    void testGetProductById_NotFound() {
        when(productRepository.findById(1L)).thenReturn(Optional.empty());
        
        assertThrows(RuntimeException.class, () -> {
            productService.getProductById(1L);
        });
    }
    
    @Test
    void testUpdateProduct() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(productRepository.save(any(Product.class))).thenReturn(product);
        
        ProductResponse response = productService.updateProduct(1L, productRequest);
        
        assertNotNull(response);
        verify(productRepository, times(1)).save(any(Product.class));
    }
    
    @Test
    void testDeleteProduct() {
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(productRepository.save(any(Product.class))).thenReturn(product);
        
        productService.deleteProduct(1L);
        
        assertTrue(product.getDeleted());
        verify(productRepository, times(1)).save(any(Product.class));
    }
}

