package com.retailx.order.service;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.OrderItem;
import com.retailx.order.domain.Shipment;
import com.retailx.order.domain.ShipmentItem;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import com.retailx.order.repository.ShipmentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * Service for shipment and fulfillment operations.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ShipmentService {
    
    private final ShipmentRepository shipmentRepository;
    private final OrderRepository orderRepository;
    private final InventoryServiceClient inventoryServiceClient;
    private final KafkaTemplate<String, String> kafkaTemplate;
    
    @Transactional
    public Shipment createShipment(Long orderId, String carrier, String trackingNumber, List<String> skus) {
        log.info("Creating shipment for order: {}", orderId);
        
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        
        if (order.getStatus() != OrderStatus.PAID && order.getStatus() != OrderStatus.FULFILLING) {
            throw new RuntimeException("Order must be PAID or FULFILLING to create shipment");
        }
        
        String shipmentNumber = "SHP-" + LocalDateTime.now().format(
                java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd")) + "-" + 
                UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        
        Shipment shipment = Shipment.builder()
                .orderId(orderId)
                .shipmentNumber(shipmentNumber)
                .carrier(carrier)
                .trackingNumber(trackingNumber)
                .shippedAt(LocalDateTime.now())
                .build();
        
        // Create shipment items from order items
        List<ShipmentItem> shipmentItems = order.getItems().stream()
                .filter(item -> skus == null || skus.isEmpty() || skus.contains(item.getSku()))
                .map(orderItem -> ShipmentItem.builder()
                        .shipment(shipment)
                        .sku(orderItem.getSku())
                        .quantity(orderItem.getQuantity())
                        .build())
                .toList();
        
        shipment.setItems(shipmentItems);
        shipment = shipmentRepository.save(shipment);
        
        // Update order status
        order.setStatus(OrderStatus.SHIPPED);
        orderRepository.save(order);
        
        // Publish event
        kafkaTemplate.send("shipment.created", shipmentNumber,
                String.format("{\"shipmentId\":%d,\"orderId\":%d,\"trackingNumber\":\"%s\"}", 
                        shipment.getId(), orderId, trackingNumber));
        
        return shipment;
    }
    
    @Transactional
    public Shipment markDelivered(Long shipmentId) {
        Shipment shipment = shipmentRepository.findById(shipmentId)
                .orElseThrow(() -> new RuntimeException("Shipment not found"));
        
        shipment.setDeliveredAt(LocalDateTime.now());
        shipment = shipmentRepository.save(shipment);
        
        // Update order status
        Order order = orderRepository.findById(shipment.getOrderId())
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(OrderStatus.DELIVERED);
        orderRepository.save(order);
        
        // Publish event
        kafkaTemplate.send("order.delivered", String.valueOf(order.getId()),
                String.format("{\"orderId\":%d,\"shipmentId\":%d}", order.getId(), shipmentId));
        
        return shipment;
    }
    
    public List<Shipment> getShipmentsByOrder(Long orderId) {
        return shipmentRepository.findByOrderIdAndDeletedFalse(orderId);
    }
}

