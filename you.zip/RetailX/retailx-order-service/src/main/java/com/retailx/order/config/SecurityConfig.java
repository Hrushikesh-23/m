package com.retailx.order.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Security configuration for Order Service with role-based access control.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/carts/**", "/api/checkout", "/api/orders/customer/**", "/api/returns/orders/**")
                    .hasAnyRole("CUSTOMER", "ADMIN")
                .requestMatchers("/api/orders/merchant/**", "/api/reports/**", "/api/shipments/**", "/api/returns/**")
                    .hasAnyRole("MERCHANT", "ADMIN", "OPS")
                .requestMatchers("/api/orders/**", "/actuator/**")
                    .authenticated()
                .anyRequest().permitAll()
            );
        
        return http.build();
    }
}

