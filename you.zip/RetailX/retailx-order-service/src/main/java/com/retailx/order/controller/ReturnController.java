package com.retailx.order.controller;

import com.retailx.order.domain.Return;
import com.retailx.order.dto.request.ReturnRequest;
import com.retailx.order.dto.response.ReturnItemResponse;
import com.retailx.order.dto.response.ReturnResponse;
import com.retailx.order.service.ReturnService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for return endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/returns")
@RequiredArgsConstructor
public class ReturnController {
    
    private final ReturnService returnService;
    
    @PostMapping("/orders/{orderId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<ReturnResponse> requestReturn(
            @PathVariable Long orderId,
            @RequestHeader("X-User-Id") Long customerId,
            @RequestBody ReturnRequest request) {
        log.info("Processing return request for order: {}, customer: {}", orderId, customerId);
        
        // Convert DTO items to service DTOs
        List<ReturnService.ReturnItemRequest> itemRequests = request.getItems().stream()
                .map(item -> {
                    ReturnService.ReturnItemRequest req = new ReturnService.ReturnItemRequest();
                    req.setSku(item.getSku());
                    req.setQuantity(item.getQuantity());
                    return req;
                })
                .collect(Collectors.toList());
        
        Return returnEntity = returnService.requestReturn(orderId, customerId, request.getReason(), itemRequests);
        return ResponseEntity.ok(mapToResponse(returnEntity));
    }
    
    @PutMapping("/{returnId}/approve")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN', 'MERCHANT')")
    public ResponseEntity<ReturnResponse> approveReturn(
            @PathVariable Long returnId,
            @RequestHeader("X-User-Id") String actorId) {
        log.info("Approving return: {}, actor: {}", returnId, actorId);
        
        Return returnEntity = returnService.approveReturn(returnId, actorId);
        return ResponseEntity.ok(mapToResponse(returnEntity));
    }
    
    @PutMapping("/{returnId}/reject")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN', 'MERCHANT')")
    public ResponseEntity<ReturnResponse> rejectReturn(
            @PathVariable Long returnId,
            @RequestParam String reason,
            @RequestHeader("X-User-Id") String actorId) {
        log.info("Rejecting return: {}, reason: {}, actor: {}", returnId, reason, actorId);
        
        Return returnEntity = returnService.rejectReturn(returnId, reason, actorId);
        return ResponseEntity.ok(mapToResponse(returnEntity));
    }
    
    @GetMapping("/orders/{orderId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'MERCHANT', 'OPS', 'ADMIN')")
    public ResponseEntity<List<ReturnResponse>> getReturnsByOrder(@PathVariable Long orderId) {
        List<Return> returns = returnService.getReturnsByOrder(orderId);
        List<ReturnResponse> responses = returns.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responses);
    }
    
    private ReturnResponse mapToResponse(Return returnEntity) {
        List<ReturnItemResponse> itemResponses = returnEntity.getItems().stream()
                .map(item -> ReturnItemResponse.builder()
                        .id(item.getId())
                        .sku(item.getSku())
                        .quantity(item.getQuantity())
                        .build())
                .collect(Collectors.toList());
        
        return ReturnResponse.builder()
                .id(returnEntity.getId())
                .orderId(returnEntity.getOrderId())
                .rmaNumber(returnEntity.getRmaNumber())
                .status(returnEntity.getStatus())
                .reason(returnEntity.getReason())
                .refundAmount(returnEntity.getRefundAmount())
                .restocked(returnEntity.getRestocked())
                .requestedAt(returnEntity.getRequestedAt())
                .approvedAt(returnEntity.getApprovedAt())
                .completedAt(returnEntity.getCompletedAt())
                .items(itemResponses)
                .build();
    }
}

