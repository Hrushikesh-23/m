package com.retailx.order.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

/**
 * AOP configuration for audit aspects.
 */
@Configuration
@EnableAspectJAutoProxy
public class AopConfig {
}

