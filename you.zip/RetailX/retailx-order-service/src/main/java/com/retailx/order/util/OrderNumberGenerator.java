package com.retailx.order.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Utility for generating unique order numbers.
 */
public class OrderNumberGenerator {
    
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static volatile int sequence = 0;
    
    /**
     * Generates a unique order number.
     * Format: ORD-YYYYMMDD-XXXXXX
     */
    public static synchronized String generate() {
        String date = LocalDateTime.now().format(FORMATTER);
        sequence = (sequence + 1) % 1000000;
        return String.format("ORD-%s-%06d", date, sequence);
    }
}

