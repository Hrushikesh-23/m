package com.retailx.order.controller;

import com.retailx.order.domain.Shipment;
import com.retailx.order.dto.request.CreateShipmentRequest;
import com.retailx.order.dto.response.ShipmentItemResponse;
import com.retailx.order.dto.response.ShipmentResponse;
import com.retailx.order.service.ShipmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

/**
 * REST controller for shipment endpoints.
 */
@Slf4j
@RestController
@RequestMapping("/api/shipments")
@RequiredArgsConstructor
public class ShipmentController {
    
    private final ShipmentService shipmentService;
    
    @PostMapping("/orders/{orderId}")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN', 'MERCHANT')")
    public ResponseEntity<ShipmentResponse> createShipment(
            @PathVariable Long orderId,
            @RequestBody CreateShipmentRequest request) {
        log.info("Creating shipment for order: {}", orderId);
        
        Shipment shipment = shipmentService.createShipment(
                orderId, 
                request.getCarrier(), 
                request.getTrackingNumber(), 
                request.getSkus());
        
        return ResponseEntity.ok(mapToResponse(shipment));
    }
    
    @PutMapping("/{shipmentId}/delivered")
    @PreAuthorize("hasAnyRole('OPS', 'ADMIN')")
    public ResponseEntity<ShipmentResponse> markDelivered(@PathVariable Long shipmentId) {
        log.info("Marking shipment as delivered: {}", shipmentId);
        
        Shipment shipment = shipmentService.markDelivered(shipmentId);
        return ResponseEntity.ok(mapToResponse(shipment));
    }
    
    @GetMapping("/orders/{orderId}")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'MERCHANT', 'OPS', 'ADMIN')")
    public ResponseEntity<List<ShipmentResponse>> getShipmentsByOrder(@PathVariable Long orderId) {
        List<Shipment> shipments = shipmentService.getShipmentsByOrder(orderId);
        List<ShipmentResponse> responses = shipments.stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(responses);
    }
    
    private ShipmentResponse mapToResponse(Shipment shipment) {
        List<ShipmentItemResponse> itemResponses = shipment.getItems().stream()
                .map(item -> ShipmentItemResponse.builder()
                        .id(item.getId())
                        .sku(item.getSku())
                        .quantity(item.getQuantity())
                        .build())
                .collect(Collectors.toList());
        
        return ShipmentResponse.builder()
                .id(shipment.getId())
                .orderId(shipment.getOrderId())
                .shipmentNumber(shipment.getShipmentNumber())
                .carrier(shipment.getCarrier())
                .trackingNumber(shipment.getTrackingNumber())
                .shippedAt(shipment.getShippedAt())
                .deliveredAt(shipment.getDeliveredAt())
                .items(itemResponses)
                .build();
    }
}

