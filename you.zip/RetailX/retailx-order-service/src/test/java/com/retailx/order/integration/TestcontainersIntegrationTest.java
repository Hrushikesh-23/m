package com.retailx.order.integration;

import com.retailx.order.domain.Order;
import com.retailx.order.domain.enums.OrderStatus;
import com.retailx.order.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration test using Testcontainers with real MySQL.
 * Requires Docker to be running.
 */
@DataJpaTest
@Testcontainers
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class TestcontainersIntegrationTest {
    
    @Container
    static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0")
            .withDatabaseName("test_retailx_order")
            .withUsername("test")
            .withPassword("test");
    
    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", mysql::getJdbcUrl);
        registry.add("spring.datasource.username", mysql::getUsername);
        registry.add("spring.datasource.password", mysql::getPassword);
    }
    
    @Autowired
    private OrderRepository orderRepository;
    
    @BeforeEach
    void setUp() {
        // Testcontainers will start MySQL container automatically
    }
    
    @Test
    void testCreateOrderWithTestcontainers() {
        Order order = Order.builder()
                .orderNumber("ORD-TEST-001")
                .customerId(1L)
                .merchantId(1L)
                .status(OrderStatus.PENDING)
                .subtotal(new BigDecimal("100"))
                .tax(new BigDecimal("10"))
                .shipping(new BigDecimal("5"))
                .total(new BigDecimal("115"))
                .version(1)
                .build();
        
        Order saved = orderRepository.save(order);
        
        assertNotNull(saved.getId());
        assertEquals("ORD-TEST-001", saved.getOrderNumber());
        assertEquals(OrderStatus.PENDING, saved.getStatus());
    }
    
    @Test
    void testFindOrderByNumberWithTestcontainers() {
        Order order = Order.builder()
                .orderNumber("ORD-TEST-002")
                .customerId(1L)
                .merchantId(1L)
                .status(OrderStatus.PENDING)
                .total(new BigDecimal("100"))
                .version(1)
                .build();
        order = orderRepository.save(order);
        
        Optional<Order> found = orderRepository.findByOrderNumberAndDeletedFalse("ORD-TEST-002");
        
        assertTrue(found.isPresent());
        assertEquals("ORD-TEST-002", found.get().getOrderNumber());
    }
}

