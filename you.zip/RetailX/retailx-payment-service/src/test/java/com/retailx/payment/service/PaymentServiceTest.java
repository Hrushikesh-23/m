package com.retailx.payment.service;

import com.retailx.payment.domain.PaymentIntent;
import com.retailx.payment.domain.enums.PaymentStatus;
import com.retailx.payment.repository.PaymentIntentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Unit tests for PaymentService.
 */
@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
    
    @Mock
    private PaymentIntentRepository paymentIntentRepository;
    
    @InjectMocks
    private PaymentService paymentService;
    
    private PaymentIntent paymentIntent;
    private String correlationId;
    
    @BeforeEach
    void setUp() {
        correlationId = UUID.randomUUID().toString();
        paymentIntent = PaymentIntent.builder()
                .id(1L)
                .orderId(1L)
                .paymentIntentId("pi_" + UUID.randomUUID().toString().replace("-", ""))
                .amount(new BigDecimal("100.00"))
                .currency("USD")
                .status(PaymentStatus.PENDING)
                .correlationId(correlationId)
                .build();
    }
    
    @Test
    void testCreatePaymentIntent_Success() {
        when(paymentIntentRepository.findByCorrelationId(correlationId))
                .thenReturn(Optional.empty());
        when(paymentIntentRepository.save(any(PaymentIntent.class)))
                .thenReturn(paymentIntent);
        
        PaymentIntent result = paymentService.createPaymentIntent(1L, 
                new BigDecimal("100.00"), "USD", correlationId);
        
        assertNotNull(result);
        assertEquals(PaymentStatus.PENDING, result.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testCreatePaymentIntent_Idempotent() {
        when(paymentIntentRepository.findByCorrelationId(correlationId))
                .thenReturn(Optional.of(paymentIntent));
        
        PaymentIntent result = paymentService.createPaymentIntent(1L, 
                new BigDecimal("100.00"), "USD", correlationId);
        
        assertEquals(paymentIntent, result);
        verify(paymentIntentRepository, never()).save(any());
    }
    
    @Test
    void testAuthorize_Success() {
        when(paymentIntentRepository.findById(1L))
                .thenReturn(Optional.of(paymentIntent));
        when(paymentIntentRepository.save(any(PaymentIntent.class)))
                .thenReturn(paymentIntent);
        
        // Mock successful payment
        PaymentIntent authorized = paymentIntent;
        authorized.setStatus(PaymentStatus.AUTHORIZED);
        when(paymentIntentRepository.save(any(PaymentIntent.class)))
                .thenReturn(authorized);
        
        PaymentIntent result = paymentService.authorize(1L, correlationId);
        
        assertNotNull(result);
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testCapture_Success() {
        paymentIntent.setStatus(PaymentStatus.AUTHORIZED);
        when(paymentIntentRepository.findById(1L))
                .thenReturn(Optional.of(paymentIntent));
        
        PaymentIntent captured = paymentIntent;
        captured.setStatus(PaymentStatus.CAPTURED);
        when(paymentIntentRepository.save(any(PaymentIntent.class)))
                .thenReturn(captured);
        
        PaymentIntent result = paymentService.capture(1L, correlationId);
        
        assertEquals(PaymentStatus.CAPTURED, result.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
    
    @Test
    void testCapture_NotAuthorized() {
        when(paymentIntentRepository.findById(1L))
                .thenReturn(Optional.of(paymentIntent));
        
        assertThrows(RuntimeException.class, () -> {
            paymentService.capture(1L, correlationId);
        });
    }
    
    @Test
    void testRefund_Success() {
        paymentIntent.setStatus(PaymentStatus.CAPTURED);
        when(paymentIntentRepository.findById(1L))
                .thenReturn(Optional.of(paymentIntent));
        
        PaymentIntent refunded = paymentIntent;
        refunded.setStatus(PaymentStatus.REFUNDED);
        when(paymentIntentRepository.save(any(PaymentIntent.class)))
                .thenReturn(refunded);
        
        PaymentIntent result = paymentService.refund(1L, new BigDecimal("100.00"), correlationId);
        
        assertEquals(PaymentStatus.REFUNDED, result.getStatus());
        verify(paymentIntentRepository, times(1)).save(any(PaymentIntent.class));
    }
}

