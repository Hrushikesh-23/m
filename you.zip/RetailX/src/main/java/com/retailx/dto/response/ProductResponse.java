package com.retailx.dto.response;

import com.retailx.domain.enums.ProductStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * Product response DTO.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductResponse {
    
    private Long id;
    private String sku;
    private String name;
    private String description;
    private BigDecimal basePrice;
    private String currency;
    private String categoryPath;
    private ProductStatus status;
    private List<String> media;
    private String attributes;
    private Long merchantId;
    private String merchantName;
}

