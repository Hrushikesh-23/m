package com.retailx.domain;

import com.retailx.domain.enums.AuditAction;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Audit trail entity for tracking all system actions.
 */
@Entity
@Table(name = "audit_events", indexes = {
    @Index(name = "idx_audit_actor", columnList = "actorId"),
    @Index(name = "idx_audit_entity", columnList = "entityType,entityId"),
    @Index(name = "idx_audit_timestamp", columnList = "timestamp"),
    @Index(name = "idx_audit_correlation", columnList = "correlationId")
})
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditEvent extends BaseEntity {
    
    @Column(nullable = false, length = 100)
    private String actorId; // User ID who performed the action
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 50)
    private AuditAction action;
    
    @Column(nullable = false, length = 100)
    private String entityType; // e.g., "Order", "Product", "Customer"
    
    @Column(length = 100)
    private String entityId;
    
    @Column(nullable = false)
    private java.time.LocalDateTime timestamp;
    
    @Column(length = 100)
    private String correlationId; // For request tracing
    
    @Column(columnDefinition = "TEXT")
    private String requestContext; // Sanitized request info
    
    @Column(columnDefinition = "TEXT")
    private String redactedPayload; // Encrypted payload
}

