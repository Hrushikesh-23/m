package com.retailx.domain.enums;

/**
 * Merchant onboarding status.
 */
public enum OnboardingStatus {
    PENDING,
    APPROVED,
    REJECTED
}

