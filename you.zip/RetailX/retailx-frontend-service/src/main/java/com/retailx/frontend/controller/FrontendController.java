package com.retailx.frontend.controller;

import com.retailx.frontend.client.AuthServiceClient;
import com.retailx.frontend.client.OrderServiceClient;
import com.retailx.frontend.client.ProductServiceClient;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Frontend controller for Thymeleaf pages.
 */
@Slf4j
@Controller
@RequiredArgsConstructor
public class FrontendController {
    
    private final ProductServiceClient productServiceClient;
    private final OrderServiceClient orderServiceClient;
    private final AuthServiceClient authServiceClient;
    
    @GetMapping("/")
    public String index() {
        return "redirect:/catalog";
    }
    
    @GetMapping("/catalog")
    public String catalog(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) Double minPrice,
            @RequestParam(required = false) Double maxPrice,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "0") int page,
            Model model) {
        try {
            Map<String, Object> response = productServiceClient.getProducts(
                    category, minPrice, maxPrice, search, page, 20);
            model.addAttribute("products", response);
            model.addAttribute("currentPage", page);
        } catch (Exception e) {
            log.error("Error fetching products", e);
            model.addAttribute("error", "Failed to load products");
        }
        return "catalog";
    }
    
    @GetMapping("/products/{id}")
    public String productDetail(@PathVariable Long id, Model model) {
        try {
            Map<String, Object> product = productServiceClient.getProductById(id);
            model.addAttribute("product", product);
        } catch (Exception e) {
            log.error("Error fetching product", e);
            model.addAttribute("error", "Product not found");
        }
        return "product-detail";
    }
    
    @GetMapping("/cart")
    public String cart(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> cart = orderServiceClient.getCart("Bearer " + token);
            model.addAttribute("cart", cart);
        } catch (Exception e) {
            log.error("Error fetching cart", e);
            model.addAttribute("error", "Failed to load cart");
        }
        return "cart";
    }
    
    @PostMapping("/cart/add")
    public String addToCart(
            @RequestParam String sku,
            @RequestParam Integer quantity,
            HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> request = new HashMap<>();
            request.put("sku", sku);
            request.put("quantity", quantity);
            orderServiceClient.addToCart("Bearer " + token, request);
        } catch (Exception e) {
            log.error("Error adding to cart", e);
        }
        return "redirect:/cart";
    }
    
    @PostMapping("/cart/remove/{id}")
    public String removeFromCart(@PathVariable Long id, HttpSession session) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            orderServiceClient.removeFromCart("Bearer " + token, id);
        } catch (Exception e) {
            log.error("Error removing from cart", e);
        }
        return "redirect:/cart";
    }
    
    @GetMapping("/checkout")
    public String checkout(HttpSession session, Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> cart = orderServiceClient.getCart("Bearer " + token);
            model.addAttribute("cart", cart);
            // Generate idempotency key
            model.addAttribute("idempotencyKey", UUID.randomUUID().toString());
        } catch (Exception e) {
            log.error("Error loading checkout", e);
            model.addAttribute("error", "Failed to load checkout");
        }
        return "checkout";
    }
    
    @PostMapping("/checkout")
    public String processCheckout(
            @RequestParam String shippingAddress,
            @RequestParam String shippingMethod,
            @RequestParam String idempotencyKey,
            HttpSession session,
            Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> request = new HashMap<>();
            request.put("shippingAddress", shippingAddress);
            request.put("shippingMethod", shippingMethod);
            
            Map<String, Object> response = orderServiceClient.checkout(
                    "Bearer " + token, idempotencyKey, request);
            model.addAttribute("order", response);
            return "order-confirmation";
        } catch (Exception e) {
            log.error("Error processing checkout", e);
            model.addAttribute("error", "Checkout failed");
            return "checkout";
        }
    }
    
    @GetMapping("/orders")
    public String orders(
            @RequestParam(defaultValue = "0") int page,
            HttpSession session,
            Model model) {
        String token = (String) session.getAttribute("token");
        if (token == null) {
            return "redirect:/login";
        }
        
        try {
            Map<String, Object> orders = orderServiceClient.getCustomerOrders("Bearer " + token, page, 20);
            model.addAttribute("orders", orders);
            model.addAttribute("currentPage", page);
        } catch (Exception e) {
            log.error("Error fetching orders", e);
            model.addAttribute("error", "Failed to load orders");
        }
        return "orders";
    }
    
    @GetMapping("/merchant/dashboard")
    public String merchantDashboard(Model model) {
        // Merchant dashboard - can be extended with merchant-specific data
        return "merchant-dashboard";
    }
    
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }
    
    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            Model model) {
        try {
            Map<String, String> request = new HashMap<>();
            request.put("email", email);
            request.put("password", password);
            
            Map<String, Object> response = authServiceClient.login(request);
            String token = (String) response.get("token");
            session.setAttribute("token", token);
            session.setAttribute("userId", response.get("userId"));
            return "redirect:/catalog";
        } catch (Exception e) {
            log.error("Login failed", e);
            model.addAttribute("error", "Invalid credentials");
            return "login";
        }
    }
    
    @GetMapping("/register")
    public String registerPage() {
        return "register";
    }
    
    @PostMapping("/register")
    public String register(
            @RequestParam String email,
            @RequestParam String password,
            Model model) {
        try {
            Map<String, String> request = new HashMap<>();
            request.put("email", email);
            request.put("password", password);
            
            authServiceClient.register(request);
            return "redirect:/login?registered=true";
        } catch (Exception e) {
            log.error("Registration failed", e);
            model.addAttribute("error", "Registration failed");
            return "register";
        }
    }
}

