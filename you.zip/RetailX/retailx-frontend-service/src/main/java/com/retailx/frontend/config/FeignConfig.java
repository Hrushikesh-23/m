package com.retailx.frontend.config;

import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;

/**
 * Feign client configuration.
 */
@Configuration
@EnableFeignClients(basePackages = "com.retailx.frontend.client")
public class FeignConfig {
}

